"""Build the V5 SD policy bridge from the immutable strict-68 corpus.

This bridge is deliberately upstream of SD calibration.  It reconstructs the
policy-side risk/response proxies and an equal-base-event institutional-
collaboration proxy on the same 68 formal full texts used by the semantic-network and trend
modules.  A G0 policy remains in the formal denominator and never contributes
to G1--G3 action supply.
"""

from __future__ import annotations

import math
import re
from importlib import import_module
from typing import Any

import numpy as np
import pandas as pd

cfg = import_module("00_config")
from common import sha256_file, write_json

G_CODES = ["G1", "G2", "G3"]
HISTORY_YEARS = list(range(2000, 2024))
MODEL_YEARS = list(range(2011, 2024))
RISK_RULE_VERSION = "policy_side_risk_response_v1"

# This is the frozen transparent policy-language lexicon used by the legacy
# interface.  Reusing it isolates the V5 change to the strict full-text sample
# and equal-event collaboration definition rather than silently changing rules.
RISK_SIGNAL_TERMS = {
    "pressure_signal": [
        "工业废水", "城镇污水", "农业面源", "农村生活污水", "化肥减量",
        "畜禽养殖", "养殖尾水", "港口船舶", "围填海", "岸线开发",
        "入海排污口", "排污口", "陆源污染", "海洋污染", "水污染",
        "污染物排放", "污染源", "超标排放",
    ],
    "ecological_state_signal": [
        "总氮", "总磷", "营养盐", "富营养化", "溶解氧", "缺氧", "赤潮",
        "湿地退化", "生境退化", "生态退化", "生态破坏", "生态损害",
        "岸线侵蚀", "湿地丧失", "水质恶化", "环境质量下降", "海洋灾害",
    ],
    "explicit_feedback_signal": [
        "生态损害", "渔业损失", "养殖损失", "海洋灾害", "赤潮损失", "投诉",
        "督察整改", "应急处置", "应急响应", "问题清单", "风险预警",
        "突发环境事件", "超标",
    ],
}
RESPONSE_ACTION_TERMS = [
    "加强", "完善", "建立", "开展", "实施", "推进", "整改", "防治", "控制",
    "修复", "保护", "监测", "预警", "应急", "处置", "治理", "减少", "削减",
    "禁止", "限制", "监管", "督察", "考核", "问责",
]
RELATION_TYPES = {"observed_joint_issuance", "vertical_administrative_linkage"}

def clean_text(value: Any) -> str:
    if value is None or (isinstance(value, float) and pd.isna(value)):
        return ""
    return re.sub(r"\s+", " ", str(value)).strip()

def safe_ratio(numerator: float, denominator: float) -> float:
    return float(numerator / denominator) if denominator > 0 else 0.0

def phase_for_year(year: int) -> str:
    if year <= 2010:
        return "2000-2010"
    if year <= 2016:
        return "2011-2016"
    if year <= 2020:
        return "2017-2020"
    return "2021-2023"

def _numeric(frame: pd.DataFrame, columns: list[str]) -> pd.DataFrame:
    copied = frame.copy()
    for column in columns:
        copied[column] = pd.to_numeric(copied[column], errors="coerce").fillna(0.0)
    return copied

def _required(frame: pd.DataFrame, columns: set[str], label: str) -> None:
    missing = sorted(columns.difference(frame.columns))
    if missing:
        raise RuntimeError(f"{label} is missing required columns: {missing}")

def load_inputs() -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    master = pd.read_csv(cfg.POLICY_ENTITY_FILE)
    ledger = pd.read_csv(cfg.POLICY_INPUT_FLOW_FILE)
    actions = pd.read_csv(cfg.POLICY_ACTION_UNITS_FILE)
    relations = pd.read_csv(cfg.POLICY_RELATION_EVENTS_FILE)
    source_interface = pd.read_csv(cfg.POLICY_INPUT_INTERFACE_FILE)

    _required(
        master,
        {"policy_id", "publication_year", "phase", "temporal_role", "title", "semantic_analysis_eligible", "text_evidence_grade", "text_complete"},
        "Strict-68 policy master",
    )
    _required(
        ledger,
        {"policy_id", "publication_year", "stock_start_year", "stock_end_year", "stock_exit_transition_year", "semantic_codable", "G0_no_observable_target_action", *[f"{code}_share" for code in G_CODES]},
        "Strict-68 stock ledger",
    )
    _required(
        actions,
        {"action_unit_id", "policy_id", "publication_year", "phase", "source_location", "evidence_text", "G_codes", "T_codes", "document_unit_weight", "coding_scope"},
        "Strict-68 action-unit coding",
    )
    _required(
        relations,
        {"policy_id", "relation_type", "institutional_collaboration_event_weight"},
        "Strict-68 collaboration events",
    )

    if len(master) != 68 or not pd.to_numeric(master["semantic_analysis_eligible"], errors="coerce").eq(1).all():
        raise RuntimeError("V5 requires exactly 68 semantic-eligible formal full texts")
    if master["policy_id"].duplicated().any() or ledger["policy_id"].duplicated().any():
        raise RuntimeError("Policy IDs must be unique in the strict-68 master and stock ledger")
    if set(master["policy_id"].astype(str)) != set(ledger["policy_id"].astype(str)):
        raise RuntimeError("Strict-68 master and stock ledger do not contain the same policies")
    if not set(actions["policy_id"].astype(str)).issubset(set(master["policy_id"].astype(str))):
        raise RuntimeError("Action-unit codes include a policy outside the strict-68 sample")
    if not set(relations["policy_id"].astype(str)).issubset(set(master["policy_id"].astype(str))):
        raise RuntimeError("Collaboration events include a policy outside the strict-68 sample")
    if not set(relations["relation_type"].dropna().astype(str)).issubset(RELATION_TYPES):
        raise RuntimeError("Unexpected collaboration relation type")
    weights = pd.to_numeric(relations["institutional_collaboration_event_weight"], errors="coerce")
    if weights.isna().any() or not np.allclose(weights.to_numpy(float), 1.0):
        raise RuntimeError("V5 requires every observed collaboration event to have equal unit weight")

    ledger = _numeric(
        ledger,
        ["semantic_codable", "G0_no_observable_target_action", *[f"{code}_share" for code in G_CODES]],
    )
    g0 = ledger["G0_no_observable_target_action"].eq(1)
    if int(g0.sum()) != 1 or not ledger.loc[g0, [f"{code}_share" for code in G_CODES]].eq(0.0).all().all():
        raise RuntimeError("The strict-68 G0 policy must be retained with zero G1-G3 contribution")
    if not ledger["publication_year"].between(2000, 2023).all():
        raise RuntimeError("Strict-68 policy ledger contains a policy outside 2000-2023")
    return master, ledger, actions, relations, source_interface

def build_risk_signal_trace(
    actions: pd.DataFrame,
    master: pd.DataFrame,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Recompute language flags on the strict full-text action units only."""

    meta = master.set_index("policy_id")[
        ["publication_year", "phase", "temporal_role", "title"]
    ]
    rows: list[dict[str, Any]] = []
    for record in actions.to_dict("records"):
        evidence_text = clean_text(record.get("evidence_text"))
        if not evidence_text:
            continue
        response_terms = [term for term in RESPONSE_ACTION_TERMS if term in evidence_text]
        g_codes = clean_text(record.get("G_codes"))
        explicit_response = int(bool(g_codes) and bool(response_terms))
        for category, terms in RISK_SIGNAL_TERMS.items():
            matched = [term for term in terms if term in evidence_text]
            if not matched:
                continue
            policy_id = str(record["policy_id"])
            policy_meta = meta.loc[policy_id]
            rows.append(
                {
                    "action_unit_id": record["action_unit_id"],
                    "policy_id": policy_id,
                    "publication_year": int(record["publication_year"]),
                    "phase": record["phase"],
                    "temporal_role": policy_meta["temporal_role"],
                    "signal_category": category,
                    "matched_terms": ";".join(matched),
                    "matched_response_terms": ";".join(response_terms),
                    "explicit_governance_response_proxy": explicit_response,
                    "source_location": record["source_location"],
                    "evidence_text": evidence_text,
                    "G_codes": g_codes,
                    "T_codes": clean_text(record.get("T_codes")),
                    "document_unit_weight": float(record["document_unit_weight"]),
                    "coding_scope": record["coding_scope"],
                    "rule_version": RISK_RULE_VERSION,
                }
            )
    evidence = pd.DataFrame(rows)
    if evidence.empty:
        raise RuntimeError("The registered policy-language lexicon matched no strict-68 evidence")

    action_policy_ids = set(actions["policy_id"].astype(str))
    summary_rows: list[dict[str, Any]] = []
    for policy_id, values in meta.iterrows():
        selected = evidence.loc[evidence["policy_id"].eq(policy_id)]
        summary: dict[str, Any] = {
            "policy_id": policy_id,
            "publication_year": int(values["publication_year"]),
            "phase": values["phase"],
            "temporal_role": values["temporal_role"],
            "title": values["title"],
            "risk_evidence_observable": int(policy_id in action_policy_ids),
        }
        matched_risk_terms: set[str] = set()
        for category in RISK_SIGNAL_TERMS:
            category_rows = selected.loc[selected["signal_category"].eq(category)]
            summary[f"{category}_action_units_n"] = int(category_rows["action_unit_id"].nunique())
            summary[f"{category}_present"] = int(not category_rows.empty)
            for text in category_rows["matched_terms"].astype(str):
                matched_risk_terms.update(term for term in text.split(";") if term)
        summary["any_risk_signal_action_units_n"] = int(selected["action_unit_id"].nunique())
        summary["any_risk_signal_present"] = int(not selected.empty)
        response_rows = selected.loc[selected["explicit_governance_response_proxy"].eq(1)]
        summary["explicit_governance_response_proxy_action_units_n"] = int(response_rows["action_unit_id"].nunique())
        summary["explicit_governance_response_proxy_present"] = int(not response_rows.empty)
        response_terms: set[str] = set()
        for text in response_rows["matched_response_terms"].astype(str):
            response_terms.update(term for term in text.split(";") if term)
        summary["matched_response_terms"] = ";".join(sorted(response_terms))
        summary["matched_risk_terms"] = ";".join(sorted(matched_risk_terms))
        summary_rows.append(summary)
    summary = pd.DataFrame(summary_rows).sort_values(["publication_year", "policy_id"]).reset_index(drop=True)
    evidence = evidence.sort_values(["publication_year", "policy_id", "action_unit_id", "signal_category"]).reset_index(drop=True)
    return evidence, summary

def aggregate_signal_counts(selected: pd.DataFrame, prefix: str) -> dict[str, Any]:
    denominator = int(len(selected))
    values: dict[str, Any] = {
        f"{prefix}_risk_evidence_observable_policy_count": int(selected["risk_evidence_observable"].sum()),
        f"{prefix}_any_risk_signal_policy_count": int(selected["any_risk_signal_present"].sum()),
        f"{prefix}_explicit_feedback_signal_policy_count": int(selected["explicit_feedback_signal_present"].sum()),
        f"{prefix}_explicit_governance_response_proxy_policy_count": int(selected["explicit_governance_response_proxy_present"].sum()),
    }
    for category in RISK_SIGNAL_TERMS:
        values[f"{prefix}_{category}_policy_count"] = int(selected[f"{category}_present"].sum())
    for label in ["any_risk_signal", "explicit_feedback_signal", "explicit_governance_response_proxy"]:
        values[f"{prefix}_{label}_policy_share_all_formal"] = safe_ratio(
            values[f"{prefix}_{label}_policy_count"], denominator
        )
    values[f"{prefix}_formal_policy_denominator"] = denominator
    return values

def build_basic_history(ledger: pd.DataFrame, risk_summary: pd.DataFrame) -> pd.DataFrame:
    risk_lookup = risk_summary.set_index("policy_id")
    rows: list[dict[str, Any]] = []
    for year in HISTORY_YEARS:
        flow = ledger.loc[ledger["publication_year"].eq(year)].copy()
        active = ledger.loc[
            pd.to_numeric(ledger["stock_start_year"], errors="coerce").le(year)
            & pd.to_numeric(ledger["stock_end_year"], errors="coerce").ge(year)
        ].copy()
        entries = ledger.loc[pd.to_numeric(ledger["stock_start_year"], errors="coerce").eq(year)].copy()
        exits = ledger.loc[pd.to_numeric(ledger["stock_exit_transition_year"], errors="coerce").eq(year)].copy()
        row: dict[str, Any] = {
            "year": year,
            "phase": phase_for_year(year),
            "sample_universe": "strict_68_formal_full_texts",
            "new_policy_count": int(len(flow)),
            "active_policy_count": int(len(active)),
            "new_semantic_codable_count": int(flow["semantic_codable"].sum()),
            "active_semantic_codable_count": int(active["semantic_codable"].sum()),
            "new_G0_policy_count": int(flow["G0_no_observable_target_action"].sum()),
            "active_G0_policy_count": int(active["G0_no_observable_target_action"].sum()),
            "stock_entry_policy_count": int(len(entries)),
            "stock_exit_policy_count": int(len(exits)),
            "stock_entry_G0_policy_count": int(entries["G0_no_observable_target_action"].sum()),
            "stock_exit_G0_policy_count": int(exits["G0_no_observable_target_action"].sum()),
        }
        for code in G_CODES:
            row[f"{code}_new_flow"] = float(flow[f"{code}_share"].sum())
            row[f"{code}_active_stock"] = float(active[f"{code}_share"].sum())
            row[f"{code}_stock_entry"] = float(entries[f"{code}_share"].sum())
            row[f"{code}_stock_exit"] = float(exits[f"{code}_share"].sum())
            row[f"{code}_active_stock_share_all_formal"] = safe_ratio(row[f"{code}_active_stock"], len(active))
            row[f"{code}_active_stock_share_codable"] = safe_ratio(row[f"{code}_active_stock"], int(active["semantic_codable"].sum()))
            row[f"{code}_new_flow_share_all_formal"] = safe_ratio(row[f"{code}_new_flow"], len(flow))
            row[f"{code}_new_flow_share_codable"] = safe_ratio(row[f"{code}_new_flow"], int(flow["semantic_codable"].sum()))
        row["new_semantic_coding_coverage"] = safe_ratio(row["new_semantic_codable_count"], len(flow))
        row["active_semantic_coding_coverage"] = safe_ratio(row["active_semantic_codable_count"], len(active))
        row["new_G0_policy_share_all_formal"] = safe_ratio(row["new_G0_policy_count"], len(flow))
        row["active_G0_policy_share_all_formal"] = safe_ratio(row["active_G0_policy_count"], len(active))
        new_risk = risk_lookup.loc[sorted(flow["policy_id"].astype(str))] if len(flow) else risk_lookup.iloc[0:0]
        active_risk = risk_lookup.loc[sorted(active["policy_id"].astype(str))] if len(active) else risk_lookup.iloc[0:0]
        row.update(aggregate_signal_counts(new_risk, "new"))
        row.update(aggregate_signal_counts(active_risk, "active"))
        rows.append(row)
    history = pd.DataFrame(rows)
    for code in G_CODES:
        history[f"{code}_active_stock_net_change"] = history[f"{code}_active_stock"].diff()
    history["active_policy_stock_net_change"] = history["active_policy_count"].diff()
    return history

def build_collaboration_history(ledger: pd.DataFrame, relations: pd.DataFrame) -> pd.DataFrame:
    """Build annual active-stock collaboration fields using unit event weights."""

    rows: list[dict[str, Any]] = []
    for year in HISTORY_YEARS:
        active_ids = set(
            ledger.loc[
                pd.to_numeric(ledger["stock_start_year"], errors="coerce").le(year)
                & pd.to_numeric(ledger["stock_end_year"], errors="coerce").ge(year),
                "policy_id",
            ].astype(str)
        )
        selected = relations.loc[relations["policy_id"].astype(str).isin(active_ids)].copy()
        joint = selected.loc[selected["relation_type"].eq("observed_joint_issuance")]
        vertical = selected.loc[selected["relation_type"].eq("vertical_administrative_linkage")]
        total_weight = float(selected["institutional_collaboration_event_weight"].sum())
        joint_weight = float(joint["institutional_collaboration_event_weight"].sum())
        vertical_weight = float(vertical["institutional_collaboration_event_weight"].sum())
        joint_policy_share = safe_ratio(int(joint["policy_id"].nunique()), len(active_ids))
        vertical_share = safe_ratio(vertical_weight, total_weight)
        rows.append(
            {
                "year": year,
                "stock_network_relation_event_count": int(len(selected)),
                "stock_network_relation_policy_count": int(selected["policy_id"].nunique()),
                "stock_network_joint_issue_policy_count": int(joint["policy_id"].nunique()),
                "stock_network_joint_issue_policy_share": joint_policy_share,
                "stock_network_joint_issue_event_weight": joint_weight,
                "stock_network_vertical_relation_event_count": int(len(vertical)),
                "stock_network_vertical_relation_event_weight": vertical_weight,
                "stock_network_total_relation_event_weight": total_weight,
                "stock_network_vertical_relation_weight_share": vertical_share,
                "stock_network_synergy_equal_event_share": float(math.sqrt(max(joint_policy_share, 0.0) * max(vertical_share, 0.0))),
                "institutional_collaboration_weight_rule": "each_observed_coissuance_or_administrative_coverage_event_weight_1",
            }
        )
    return pd.DataFrame(rows)

def stock_identity_errors(history: pd.DataFrame) -> dict[str, float]:
    later = history.index > 0
    errors: dict[str, float] = {}
    for code in G_CODES:
        expected = history[f"{code}_active_stock"].shift(1) + history[f"{code}_stock_entry"] - history[f"{code}_stock_exit"]
        errors[f"{code}_stock_identity_max_abs_error"] = float((history.loc[later, f"{code}_active_stock"] - expected.loc[later]).abs().max())
    expected_count = history["active_policy_count"].shift(1) + history["stock_entry_policy_count"] - history["stock_exit_policy_count"]
    errors["policy_stock_identity_max_abs_error"] = float((history.loc[later, "active_policy_count"] - expected_count.loc[later]).abs().max())
    return errors

def source_interface_crosscheck(history: pd.DataFrame, source_interface: pd.DataFrame) -> dict[str, float]:
    fields = [
        "new_policy_count", "active_policy_count", "new_semantic_codable_count",
        "active_semantic_codable_count", "new_G0_policy_count", "active_G0_policy_count",
        "stock_entry_policy_count", "stock_exit_policy_count",
        *[f"{code}_{suffix}" for code in G_CODES for suffix in ["new_flow", "active_stock", "stock_entry", "stock_exit", "active_stock_share_all_formal", "active_stock_share_codable"]],
    ]
    _required(source_interface, {"year", *fields}, "Strict-68 V4 interface")
    left = history.loc[history["year"].isin(MODEL_YEARS), ["year", *fields]].set_index("year")
    right = source_interface.loc[source_interface["year"].isin(MODEL_YEARS), ["year", *fields]].set_index("year")
    if set(left.index) != set(MODEL_YEARS) or set(right.index) != set(MODEL_YEARS):
        raise RuntimeError("Strict-68 source interface does not cover every 2011-2023 model year")
    errors = {field: float(np.nanmax(np.abs(left[field].to_numpy(float) - right.loc[left.index, field].to_numpy(float)))) for field in fields}
    if max(errors.values()) > 1e-10:
        raise RuntimeError(f"Rebuilt strict policy history drifted from V4 interface: {errors}")
    return errors

def write_manifest(audit: dict[str, Any]) -> None:
    text = f"""# V5 strict-68 SD policy bridge

## Scope

- Policy universe: exactly 68 formal full texts (2000-2023).
- Model interface: 2011-2023; 2000-2010 is retained as a stock warm-up.
- G0: one formal policy has no observable G1-G3 target action, remains in the all-formal denominator, and contributes zero action supply.

## Policy-side proxies

- Risk/feedback/response language uses `{RISK_RULE_VERSION}`, unchanged from the frozen interface and re-screened on strict-68 action units.
- Response remains a policy-language proxy, not an observed implementation rate or causal effect.
- Institutional collaboration uses active-policy stocks. Every observed joint-issuance and administrative-coverage relation event has equal base weight 1. The synergy proxy is `sqrt(joint-issue-policy-share * vertical-event-weight-share)`: it intentionally combines horizontal joint-issue policy coverage with vertical equal-event embedding, and is therefore a mixed collaboration proxy rather than a symmetric event-count centrality measure.

## QA

- Formal policies: {audit['strict_policy_n']}.
- G-observable policies: {audit['semantic_codable_policy_n']}.
- G0 policies: {audit['G0_policy_n']}.
- Collaboration events: {audit['relation_event_n']}.
- Maximum stock identity error: {audit['max_stock_identity_error']:.3g}.
- Maximum V4 strict-interface reconciliation error: {audit['source_interface_max_abs_error']:.3g}.
"""
    cfg.POLICY_BRIDGE_MANIFEST_FILE.parent.mkdir(parents=True, exist_ok=True)
    cfg.POLICY_BRIDGE_MANIFEST_FILE.write_text(text, encoding="utf-8")

def main() -> None:
    cfg.ensure_directories()
    master, ledger, actions, relations, source_interface = load_inputs()
    evidence, risk_summary = build_risk_signal_trace(actions, master)
    history = build_basic_history(ledger, risk_summary)
    collaboration = build_collaboration_history(ledger, relations)
    history = history.merge(collaboration, on="year", how="left", validate="one_to_one")
    history["governance_bridge_version"] = "V5_strict68_equal_event_collaboration"
    history["risk_rule_version"] = RISK_RULE_VERSION
    history["active_explicit_governance_response_proxy_policy_share"] = history["active_explicit_governance_response_proxy_policy_share_all_formal"]
    history["active_explicit_feedback_signal_policy_share"] = history["active_explicit_feedback_signal_policy_share_all_formal"]
    history["active_any_risk_signal_policy_share"] = history["active_any_risk_signal_policy_share_all_formal"]
    history["synergy_share"] = history["stock_network_synergy_equal_event_share"]
    interface_errors = source_interface_crosscheck(history, source_interface)
    identities = stock_identity_errors(history)
    interface = history.loc[history["year"].isin(MODEL_YEARS)].copy()

    source_records = []
    for artifact, path, role in [
        ("strict68_policy_master", cfg.POLICY_ENTITY_FILE, "only formal full-text policy universe"),
        ("strict68_stock_ledger", cfg.POLICY_INPUT_FLOW_FILE, "G1-G3/G0 stock-flow source"),
        ("strict68_action_units", cfg.POLICY_ACTION_UNITS_FILE, "risk-response language evidence"),
        ("strict68_collaboration_events", cfg.POLICY_RELATION_EVENTS_FILE, "equal-weight institutional collaboration events"),
        ("strict68_v4_interface", cfg.POLICY_INPUT_INTERFACE_FILE, "reconciliation reference; not directly consumed by calibration"),
    ]:
        source_records.append({"artifact": artifact, "path": str(path), "sha256": sha256_file(path), "role": role, "sample_universe": "strict_68_formal_full_texts"})
    registry = pd.DataFrame(source_records)

    g0_rows = ledger.loc[ledger["G0_no_observable_target_action"].eq(1)]
    audit: dict[str, Any] = {
        "status": "PASS",
        "analysis_id": cfg.ANALYSIS_ID,
        "sample_universe": "strict_68_formal_full_texts",
        "strict_policy_n": int(len(ledger)),
        "semantic_codable_policy_n": int(ledger["semantic_codable"].sum()),
        "G0_policy_n": int(len(g0_rows)),
        "G0_policy_ids": g0_rows["policy_id"].astype(str).tolist(),
        "G0_has_zero_G_contribution": bool(g0_rows[[f"{code}_share" for code in G_CODES]].eq(0.0).all().all()),
        "historical_years": [int(history["year"].min()), int(history["year"].max())],
        "interface_years": [int(interface["year"].min()), int(interface["year"].max())],
        "relation_event_n": int(len(relations)),
        "relation_supported_policy_n": int(relations["policy_id"].nunique()),
        "relation_event_weights_all_equal_one": bool(np.allclose(pd.to_numeric(relations["institutional_collaboration_event_weight"], errors="raise").to_numpy(float), 1.0)),
        "risk_rule_version": RISK_RULE_VERSION,
        "risk_evidence_rows": int(len(evidence)),
        "risk_signal_policies": int(risk_summary["any_risk_signal_present"].sum()),
        "explicit_feedback_signal_policies": int(risk_summary["explicit_feedback_signal_present"].sum()),
        "explicit_governance_response_proxy_policies": int(risk_summary["explicit_governance_response_proxy_present"].sum()),
        "stock_identity_errors": identities,
        "max_stock_identity_error": float(max(identities.values())),
        "source_interface_crosscheck_max_abs_errors": interface_errors,
        "source_interface_max_abs_error": float(max(interface_errors.values())),
        "no_2024_policy_included": bool(int(ledger["publication_year"].max()) == 2023),
        "bridge_policy_files_sha256": {record["artifact"]: record["sha256"] for record in source_records},
    }
    if audit["max_stock_identity_error"] > 1e-10 or audit["source_interface_max_abs_error"] > 1e-10:
        raise RuntimeError("Strict-68 V5 bridge QA failed")

    ledger.to_csv(cfg.POLICY_FLOW_FILE, index=False)
    relations.to_csv(cfg.POLICY_RELATION_SNAPSHOT_FILE, index=False)
    evidence.to_csv(cfg.POLICY_RISK_EVIDENCE_FILE, index=False)
    risk_summary.to_csv(cfg.POLICY_RISK_SUMMARY_FILE, index=False)
    collaboration.to_csv(cfg.POLICY_COLLABORATION_FILE, index=False)
    history.to_csv(cfg.POLICY_HISTORY_FILE, index=False)
    interface.to_csv(cfg.POLICY_SYSTEM_FILE, index=False)
    registry.to_csv(cfg.POLICY_BRIDGE_SOURCE_REGISTRY_FILE, index=False)
    write_json(cfg.POLICY_BRIDGE_AUDIT_FILE, audit)
    write_manifest(audit)
    print("V5 strict-68 SD policy bridge completed.")

if __name__ == "__main__":
    main()
