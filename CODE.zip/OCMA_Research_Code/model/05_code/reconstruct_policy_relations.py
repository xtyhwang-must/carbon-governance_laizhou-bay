"""Extract formal issuance and applicability events with auditable text spans."""
from __future__ import annotations

import json
from pathlib import Path
import re

import pandas as pd

ROOT=Path(__file__).resolve().parents[1]
POL=ROOT/'02_policy/reconstructed'
LEVEL_PATTERNS={
 'province':re.compile(r'各省[、，,]?自治区[、，,]?直辖市|沿海各省|全省|本省行政区域'),
 'city':re.compile(r'沿海城市|各市[、，,]?县|各设区市|本市行政区域|全市'),
 'county':re.compile(r'各县[（(]市[、，,]?区[）)]|各县区|各县[、，,]市[、，,]区|沿海县|各镇[（(]街道[）)]|各街道'),
}

def main():
    audit=pd.read_csv(POL/'text_source_audit.csv').set_index('policy_id')
    admission=pd.read_csv(ROOT/'01_sources/policy/admission_68.csv').set_index('policy_id')
    events=[];review=[]
    for pid,row in admission.iterrows():
        body=(ROOT/audit.loc[pid,'clean_text_relative_path']).read_text(encoding='utf-8')
        title=str(row['政策标题'])
        issuer=title.split('关于')[0].split('印发')[0].strip()
        if not issuer or len(issuer)>100:issuer=str(row['层级'])+'_issuer_unspecified'
        prefix=title.split('关于')[0]
        joint=bool((('、' in prefix or '，' in prefix) and len(re.findall(r'部|厅|局|委|政府|办公室',prefix))>=2)
                   or re.search(r'等[一二三四五六七八九十\d]+(?:个)?部门',prefix))
        if joint:
            anchor=prefix if prefix in body else title[:min(15,len(title))]
            loc=body.find(anchor)
            if loc<0:loc=0;anchor=body[:min(120,len(body))]
            events.append({'event_id':pid+'__JOINT_ISSUANCE','policy_id':pid,
                           'relation_type':'observed_joint_issuance','issuer_text':issuer,
                           'target_level':'co_issuers','covered_counties_text':str(row['适用县域']),
                           'source_location':f'clean_chars={loc}:{loc+len(anchor)}',
                           'exact_evidence_text':anchor,'source_sha256':audit.loc[pid,'body_source_sha256'],
                           'institutional_collaboration_event_weight':1.0,
                           'mapping_status':'JOINT_ISSUER_COUNT_FROM_TITLE_PREFIX_ACTORS_REQUIRE_AUTHOR_CHECK',
                           'author_review_status':'PENDING'})
        vertical=0
        for level,pattern in LEVEL_PATTERNS.items():
            match=pattern.search(body)
            if match is None:continue
            start=max(0,match.start()-100);end=min(len(body),match.end()+100)
            snippet=body[start:end]
            # A table of contents alone does not provide applicability.
            if re.search(r'\.{4,}|…{3,}',snippet):continue
            vertical+=1
            events.append({'event_id':pid+'__VERTICAL_'+level.upper(),'policy_id':pid,
                           'relation_type':'vertical_administrative_linkage','issuer_text':issuer,
                           'target_level':level,'covered_counties_text':str(row['适用县域']),
                           'source_location':f'clean_chars={start}:{end}',
                           'exact_evidence_text':snippet,'source_sha256':audit.loc[pid,'body_source_sha256'],
                           'institutional_collaboration_event_weight':1.0,
                           'mapping_status':'TEXT_LEVEL_APPLICABILITY_EVENT_COUNTY_LIST_IS_ADMISSION_METADATA_NOT_NAMED_EDGE',
                           'author_review_status':'PENDING'})
        review.append({'policy_id':pid,'joint_event_count':int(joint),'vertical_event_count':vertical,
                       'issuer_text':issuer,'admission_covered_counties':str(row['适用县域']),
                       'author_review_status':'PENDING'})
    event=pd.DataFrame(events)
    if event.event_id.duplicated().any():raise AssertionError('duplicate relation event identity')
    assert set(event.relation_type)=={'observed_joint_issuance','vertical_administrative_linkage'}
    event.to_csv(POL/'relation_events_B1.csv',index=False,encoding='utf-8-sig')
    pd.DataFrame(review).to_csv(POL/'policy_relation_audit_B1.csv',index=False,encoding='utf-8-sig')
    event[['relation_type','issuer_text','target_level']].drop_duplicates().to_csv(POL/'unique_relation_types_B1.csv',index=False,encoding='utf-8-sig')
    print(json.dumps({'policies':len(review),'joint_policies':int(event.loc[event.relation_type.eq('observed_joint_issuance'),'policy_id'].nunique()),
                      'vertical_events':int(event.relation_type.eq('vertical_administrative_linkage').sum()),
                      'events':len(event)},ensure_ascii=False))

if __name__=='__main__':main()
