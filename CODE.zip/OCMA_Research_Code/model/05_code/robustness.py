"""Predefined matched climate, habitat, reporting and structural stress tests."""
from __future__ import annotations
import hashlib,json,sys
from concurrent.futures import ProcessPoolExecutor,as_completed
from pathlib import Path
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'05_code/engine'),str(ROOT/'05_code')]
import engine_config as cfg
import sd_model as model
from revised_core import top_mean
from modeling import reference_for
from scenario_summary import summarize
from numeric_analysis import load_settings,climate_path,scenario_forcing
from cache_safety import ChunkCache,signature,atomic_json

CAL=ROOT/'06_runs/formal_main/calibration'
SCEN=ROOT/'06_runs/formal_main/scenarios'
OUT=ROOT/'06_runs/formal_main/robustness'

def sample_parameters(ensemble,n=100):
    if len(ensemble)<=n:return ensemble.copy()
    work=ensemble.copy()
    if work.loss.nunique()<3:
        work['loss_tercile']='ALL'
    else:
        work['loss_tercile']=pd.qcut(work.loss,3,labels=False,duplicates='drop').astype(str)
    work['stratum']=work.source_type.astype(str)+'|'+work.loss_tercile
    groups=list(work.groupby('stratum',sort=True))
    sizes=np.array([len(g) for _,g in groups],float)
    exact=n*sizes/sizes.sum();alloc=np.floor(exact).astype(int)
    for j in np.argsort(-(exact-alloc))[:n-alloc.sum()]:alloc[j]+=1
    rng=np.random.default_rng(cfg.CONTRACT['seeds']['propagation_subsample']+1)
    chosen=[]
    for (_,g),count in zip(groups,alloc):
        if count:chosen.append(g.iloc[np.sort(rng.choice(len(g),size=count,replace=False))])
    return pd.concat(chosen,ignore_index=True).sort_values('parameter_set_id')

def climate_paths(frame):
    primary=climate_path(frame,shock=True);raw=frame[['PPT','RUNOFF','SST']].reset_index(drop=True)
    history=raw.copy();history['compound']=(history.PPT*history.RUNOFF*history.SST)**(1/3)
    extreme=history.nlargest(3,'compound')
    worst=extreme[['PPT','RUNOFF','SST']].to_numpy(float)
    worst_years=frame.year.iloc[extreme.index].to_numpy(int)
    result=[];manifest=[]
    for draw in range(20):
        draw_id=f'CLIM_{draw+1:02d}'
        if draw==0:
            shock_path=primary.copy()
            no_path=climate_path(frame,shock=False)
            seed=20260725
            rng=np.random.default_rng(seed);blocks=[]
            while len(blocks)<7:
                start=int(rng.integers(0,len(raw)-2));blocks.extend(range(start,start+3))
        else:
            seed=20261100+draw;rng=np.random.default_rng(seed);blocks=[]
            while len(blocks)<7:
                start=int(rng.integers(0,len(raw)-2));blocks.extend(range(start,start+3))
            no_path=raw.iloc[blocks[:7]].reset_index(drop=True)
            no_path.insert(0,'year',np.arange(2024,2031))
            shock_path=no_path.copy()
            for i,y in enumerate([2026,2027,2028]):
                shock_path.loc[shock_path.year.eq(y),['PPT','RUNOFF','SST']]=worst[i]
        for kind,path in [('compound',shock_path),('no_compound',no_path)]:
            x=path.copy();x.insert(0,'bootstrap_source_year',frame.year.iloc[blocks[:7]].to_numpy())
            x.insert(0,'compound_override_source_year',[
                int(worst_years[[2026,2027,2028].index(int(y))]) if kind=='compound' and int(y) in [2026,2027,2028]
                else '' for y in x.year])
            x.insert(0,'seed',seed);x.insert(0,'shock_spec',kind);x.insert(0,'draw_id',draw_id)
            result.append((draw_id,kind,path))
            manifest.append(x)
    return result,pd.concat(manifest,ignore_index=True)

def habitat_initial(frame,endpoint):
    initial=model.initial_state(frame,year=2023).copy()
    endpoint_table=pd.read_csv(ROOT/'01_sources/indicators/habitat_2023_class_endpoint_sensitivity.csv')
    scales=pd.read_csv(ROOT/'03_indicators/scaling_registry.csv').set_index('variable')
    for idx,var in [(8,'TF'),(9,'SM')]:
        area=float(endpoint_table.loc[(endpoint_table['class'].eq(var.lower()))&
            endpoint_table.endpoint.eq(endpoint),'nine_county_km2'].iloc[0])
        low=float(scales.loc[var,'lower']);high=float(scales.loc[var,'upper'])
        initial[idx]=float(np.clip(.02+.96*(area-low)/(high-low),.02,.98))
    # PRS is a social memory and remains unchanged. Update the 2023 ecological
    # PRE memory from the 2022 value and the substituted 2023 habitat only.
    row2022=frame.loc[frame.year.eq(2022)].iloc[0]
    pre2022=(3*float(row2022.PR)-float(row2022.PRS))/2
    wq=float(frame.loc[frame.year.eq(2023),'WQ'].iloc[0]);h=float(np.sqrt(initial[8]*initial[9]))
    ecological_risk=((1-wq)+(1-h))/2
    pre2023=.45*ecological_risk+.55*pre2022
    initial[10]=(initial[11]+2*pre2023)/3
    return initial

def metrics(result,pid,sid,draw_id,spec,initial_hash,forcing_hash,ref_hash):
    years=result.year.to_numpy(int);shock=result[result.year.between(2026,2030)]
    end=result[result.year.eq(2030)]
    if len(shock)!=5 or len(end)!=1:raise ValueError('Incomplete annual path')
    if np.min(result[cfg.STATE_NAMES].to_numpy(float))<-1e-9 or np.max(result[cfg.STATE_NAMES].to_numpy(float))>1+1e-9:
        raise ValueError('Bound violation')
    return {'cache_row_id':f'{pid}:{spec}:{draw_id}:{sid}',
        'parameter_set_id':pid,'specification_id':spec,'forcing_draw_id':draw_id,
        'scenario':sid,'initial_state_hash':initial_hash,'forcing_sha256':forcing_hash,
        'reference_context_sha256':ref_hash,
        'min_ES_2026_2030':float(shock.ES.min()),'ES_2030':float(end.ES.iloc[0]),
        'SR_2030':float(end.SR.iloc[0]),
        'min_SR_2024_2030':float(result[result.year.between(2024,2030)].SR.min())}

def one(args):
    pid,params,structure,frame,settings,paths=args
    hist=model.historical_forcing(frame);init2011=model.initial_state(frame,year=2011)
    standard=model.initial_state(frame,year=2023)
    base_ref=reference_for(frame,hist,init2011,params,structure)
    mode_specs={'NO_ADAPTIVE_FEEDBACK':model.ModelMode(adaptive_feedback=False),
        'NO_IMPLEMENTATION_GATE':model.ModelMode(sc_implementation=False),
        'NO_GOVERNANCE_SYNERGY':model.ModelMode(governance_synergy=False),
        'NO_TF_SM_CONVERSION':model.ModelMode(tf_sm_conversion=False)}
    primary=next(path for did,kind,path in paths if did=='CLIM_01' and kind=='compound')
    rows=[]
    planned=[('CLIMATE_'+kind,did,path,standard,None,base_ref)
        for did,kind,path in paths]
    planned += [('HABITAT_'+endpoint.upper(),'CLIM_01',primary,habitat_initial(frame,endpoint),None,base_ref)
        for endpoint in ['lower','upper']]
    planned += [('STRUCTURE_'+name,'CLIM_01',primary,standard,mode,base_ref)
        for name,mode in mode_specs.items()]
    continuation=model.simulate(params,hist,frame.year.to_numpy(float),init2011,structure=structure,reference_context=base_ref).iloc[-1][cfg.STATE_NAMES].to_numpy(float)
    planned += [('HISTORICAL_CONTINUATION_2023','CLIM_01',primary,continuation,None,base_ref)]
    for spec,did,climate,initial,mode,ref in planned:
        ih=hashlib.sha256(initial.tobytes()).hexdigest()
        rh=hashlib.sha256(json.dumps(ref,sort_keys=True).encode()).hexdigest() if ref is not None else 'RUN_SPECIFIC'
        for sid in sorted(settings):
            forcing,_,f_frame=scenario_forcing(frame,settings[sid],climate)
            result=model.simulate(params,forcing,np.arange(2023,2031,dtype=float),initial,
                mode=mode,structure=structure,reference_context=ref)
            if not np.allclose(result.iloc[0][cfg.STATE_NAMES].to_numpy(float),initial,atol=1e-12):
                raise AssertionError('Initial state mismatch in robustness')
            fh=hashlib.sha256(f_frame.to_csv(index=False).encode()).hexdigest()
            rows.append(metrics(result,pid,sid,did,spec,ih,fh,rh))
    return pid,pd.DataFrame(rows)

def reporting_variants(main_paths):
    # Only outputs change. Dynamics, vector, climate, and initial state are untouched.
    out=[]
    for es_mode,sr_mode in [('arithmetic','geometric'),('harmonic','geometric'),
        ('weight_0.3','geometric'),('weight_0.7','geometric'),
        ('geometric','arithmetic'),('geometric','harmonic'),
        ('geometric','weight_0.3'),('geometric','weight_0.7')]:
        mode='ES_'+es_mode if es_mode!='geometric' else 'SR_'+sr_mode
        frame=main_paths.copy()
        if es_mode!='geometric':frame['ES']=top_mean(frame.WQ,frame.H,es_mode)
        if sr_mode!='geometric':frame['SR']=top_mean(1-frame.SP,frame.SC,sr_mode)
        for keys,g in frame.groupby(['parameter_set_id','scenario'],sort=False):
            pid,sid=keys;shock=g[g.year.between(2026,2030)];end=g[g.year.eq(2030)].iloc[0]
            out.append({'parameter_set_id':pid,'specification_id':'REPORTING_'+mode,
                'forcing_draw_id':'CLIM_01','scenario':sid,'initial_state_hash':str(g.initial_state_hash.iloc[0]),
                'min_ES_2026_2030':float(shock.ES.min()),'ES_2030':float(end.ES),
                'SR_2030':float(end.SR),'min_SR_2024_2030':float(g.SR.min())})
    return pd.DataFrame(out)

def summarize_specs(data):
    summary=[];screen=[];pairs=[]
    for (spec,did),g in data.groupby(['specification_id','forcing_draw_id']):
        if g.scenario.nunique()!=7:raise AssertionError(f'Missing scenarios {spec} {did}')
        social,sc,rank,pair=summarize(g)
        sc.insert(0,'forcing_draw_id',did);sc.insert(0,'specification_id',spec)
        rank.insert(0,'forcing_draw_id',did);rank.insert(0,'specification_id',spec)
        pair.insert(0,'forcing_draw_id',did);pair.insert(0,'specification_id',spec)
        summary.append(rank);screen.append(sc);pairs.append(pair)
    return pd.concat(summary,ignore_index=True),pd.concat(screen,ignore_index=True),pd.concat(pairs,ignore_index=True)

def main():
    OUT.mkdir(parents=True,exist_ok=True)
    frame=pd.read_csv(ROOT/'03_indicators/model_input_B1.csv').sort_values('year').reset_index(drop=True)
    status=json.loads((CAL/'formal_calibration_status.json').read_text(encoding='utf-8'))
    structure=status['structure'];names=model.parameter_names(structure)
    ensemble=pd.read_csv(CAL/'accepted_parameter_ensemble.csv')
    if ensemble.empty:raise RuntimeError('No accepted parameter population')
    sample=sample_parameters(ensemble,100)
    sample.to_csv(OUT/'stratified_parameter_sample.csv',index=False,encoding='utf-8-sig')
    settings=load_settings();paths,climate_manifest=climate_paths(frame)
    climate_manifest.to_csv(OUT/'climate_draw_manifest.csv',index=False,encoding='utf-8-sig')
    main_paths=pd.read_csv(SCEN/'scenario_trajectories_long.csv')
    report=reporting_variants(main_paths)
    report.to_csv(OUT/'reporting_only_metrics.csv',index=False,encoding='utf-8-sig')
    dependencies=[ROOT/p for p in ['03_indicators/model_input_B1.csv','04_model/scenario_registry.csv',
        '04_model/scenario_lever_audit.csv','04_model/equation_registry.csv',
        '04_model/parameter_registry.csv','02_policy/reconstructed/policy_stock_by_year_B1.csv',
        '02_policy/reconstructed/interface_quantiles_B1.csv','01_sources/indicators/habitat_2023_class_endpoint_sensitivity.csv',
        '03_indicators/scaling_registry.csv','00_contract/baseline_contract.yaml',
        '05_code/engine/sd_model.py','05_code/engine/engine_config.py','05_code/engine/engine_common.py',
        '05_code/numeric_analysis.py','05_code/modeling.py','05_code/robustness.py',
        '05_code/scenario_summary.py','05_code/cache_safety.py',
        '06_runs/formal_main/calibration/accepted_parameter_ensemble.csv',
        '06_runs/formal_main/scenarios/scenario_trajectories_long.csv']]
    dependencies += [OUT/'stratified_parameter_sample.csv',OUT/'climate_draw_manifest.csv']
    key,material=signature(dependencies,{'structure':structure,'sample_vectors':sample[names].to_numpy(float).tolist(),
        'initial_year':2023,'reference_year':2011,'climate_draws':20,'paired_no_shock':True,
        'habitat_endpoints':['lower','upper'],'structural_modes':4,'step':.05},
        code_version=cfg.CONTRACT['version'],root=ROOT)
    cache=ChunkCache(OUT/'cache',key,material)
    specs=[];jobs=[];required=['cache_row_id','parameter_set_id','specification_id','scenario','ES_2030']
    spec_draws=[('CLIMATE_'+kind,did) for did,kind,_ in paths]
    spec_draws += [('HABITAT_'+e.upper(),'CLIM_01') for e in ['lower','upper']]
    spec_draws += [('STRUCTURE_'+e,'CLIM_01') for e in ['NO_ADAPTIVE_FEEDBACK','NO_IMPLEMENTATION_GATE',
        'NO_GOVERNANCE_SYNERGY','NO_TF_SM_CONVERSION']]
    spec_draws += [('HISTORICAL_CONTINUATION_2023','CLIM_01')]
    for r in sample.itertuples(index=False):
        pid=r.parameter_set_id
        ids=[f'{pid}:{spec}:{did}:S{s}' for spec,did in spec_draws for s in range(7)]
        specs.append((pid,ids,required))
        if cache.load(pid,ids,required) is None:
            jobs.append((pid,{n:float(getattr(r,n)) for n in names},structure,frame,settings,paths))
    with ProcessPoolExecutor(max_workers=8) as pool:
        futures=[pool.submit(one,j) for j in jobs]
        for i,f in enumerate(as_completed(futures),1):
            pid,rows=f.result();ids=next(s[1] for s in specs if s[0]==pid)
            cache.commit(pid,rows,ids,required)
            if i%10==0 or i==len(futures):print(f'robustness vectors={i}/{len(futures)}',flush=True)
    cache.finalize(specs)
    experimental=pd.concat([cache.load(*s) for s in specs],ignore_index=True)
    experimental.to_csv(OUT/'robustness_metrics_by_vector.csv',index=False,encoding='utf-8-sig')
    all_metrics=pd.concat([experimental,report],ignore_index=True,sort=False)
    ranked,screen,pairs=summarize_specs(all_metrics)
    ranked.to_csv(OUT/'specification_rankings.csv',index=False,encoding='utf-8-sig')
    screen.to_csv(OUT/'specification_social_screens.csv',index=False,encoding='utf-8-sig')
    pairs.to_csv(OUT/'specification_pair_tolerance.csv',index=False,encoding='utf-8-sig')
    atomic_json(OUT/'robustness_status.json',{'complete':True,'sample_parameter_sets':len(sample),
        'main_parameter_sets':len(ensemble),'joint_climate_draws':20,
        'shock_comparison':'same_bootstrap_blocks_with_without_compound_override',
        'habitat_endpoints':2,'reporting_only_variants':8,'fixed_parameter_structure_stress_tests':4,
        'dynamics_simulation_cells':len(experimental),'cache_signature':key,
        'parameter_sample_is_full_population':len(sample)==len(ensemble),
        'not_probability_of_policy_success':True})

if __name__=='__main__':main()
