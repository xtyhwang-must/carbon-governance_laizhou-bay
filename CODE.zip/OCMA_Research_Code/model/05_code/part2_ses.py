"""Read-only numerical preflight and descriptive SES outputs for current HT input."""
from pathlib import Path
import json,hashlib,sys
import numpy as np,pandas as pd
from scipy.stats import spearmanr,theilslopes
ROOT=Path(__file__).resolve().parents[1];sys.path[:0]=[str(ROOT/'05_code/engine'),str(ROOT/'05_code')]
from revised_core import adjacent_differences
from build_evidence import scale,CONTRACT
OUT=ROOT/'06_runs/ses';OUT.mkdir(parents=True,exist_ok=True)
def write(f,n):f.to_csv(OUT/n,index=False,encoding='utf-8-sig')
def associations(frame,label):
 pairs=[('G','SR'),('G','ES'),('SR','ES'),('G','SP'),('G','SC'),('G','WQ'),('G','TF'),('G','SM'),('G','H')];rows=[]
 for mode,x in [('level',frame),('annual_change',adjacent_differences(frame,['G','SR','ES','SP','SC','WQ','TF','SM','H']))]:
  for a,b in pairs:
   z=x[[a,b]].dropna();rho,p=spearmanr(z[a],z[b]) if len(z)>2 else (np.nan,np.nan)
   loo=[]
   for i in z.index:
    v=z.drop(i);loo.append(spearmanr(v[a],v[b]).statistic if len(v)>2 else np.nan)
   rows.append(dict(scope=label,mode=mode,state_a=a,state_b=b,n=len(z),rho=rho,p_descriptive=p,loo_min=np.nanmin(loo),loo_max=np.nanmax(loo),not_causal=True))
 return rows

def main():
 f=pd.read_csv(ROOT/'03_indicators/model_input_B1.csv');old=pd.read_csv(ROOT.parent/'b1/03_indicators/model_input_B1.csv');f['G']=f[['G1','G2','G3']].mean(axis=1)
 cols=['G1','G2','G3','IM','ETA_POTENTIAL','SP','SC','NS','OS','BS','TF','SM','PPT','RUNOFF','SST']
 changes=[]
 for c in cols:
  for y in f.year:
   v=float(f.loc[f.year.eq(y),c].iloc[0]);prev=float(old.loc[old.year.eq(y),c].iloc[0]);changes.append(dict(year=y,variable=c,previous=prev,current=v,difference=v-prev))
 write(pd.DataFrame(changes),'new_old_input_differences.csv')
 assert all(np.allclose(f[c],old[c]) for c in ['SP','SC','NS','OS','BS','TF','SM','PPT','RUNOFF','SST'])
 trends=[]
 for c in ['G','G1','G2','G3','SR','ES','SP','SC','WQ','TF','SM','H']:
  z=f[['year',c]];sl=theilslopes(z[c].to_numpy(copy=True),z.year.to_numpy(copy=True)).slope;loo=[theilslopes(z.drop(i)[c].to_numpy(copy=True),z.drop(i).year.to_numpy(copy=True)).slope for i in z.index]
  trends.append(dict(state=c,n=len(z),year_start=2011,year_end=2023,initial=z[c].iloc[0],terminal=z[c].iloc[-1],net_change=z[c].iloc[-1]-z[c].iloc[0],Theil_Sen=sl,loo_min=min(loo),loo_max=max(loo)))
 assert f.drop(columns='G').equals(pd.read_csv(ROOT/'03_indicators/model_input_B1.csv')),'Statistics must not mutate input arrays'
 write(pd.DataFrame(trends),'state_trends_and_endpoints.csv');write(f,'SES_states_2011_2023.csv')
 rows=associations(f,'FULL_2011_2023')+associations(f[f.year.le(2022)],'EXCLUDE_ESTIMATED_2023')
 raw=pd.read_csv(ROOT/'01_sources/indicators/gwl_habitat_2011_2022_raw.csv');scales=pd.read_csv(ROOT/'03_indicators/scaling_registry.csv').set_index('variable')
 for band in [5,10,20]:
  x=f[f.year.le(2022)].copy();h=raw[raw.coastal_band_km.eq(band)].set_index('year')
  if len(h)!=12:continue
  for state,var in [('TF','tf_area_km2'),('SM','sm_area_km2')]:
   low,high=scales.loc[state,['lower','upper']];x[state]=np.clip(.02+.96*(x.year.map(h[var])-low)/(high-low),.02,.98)
  x['H']=np.sqrt(x.TF*x.SM);x['ES']=np.sqrt(x.WQ*x.H);rows+=associations(x,f'HABITAT_{band}KM_COMMON_10KM_REFERENCE')
 admission=pd.read_csv(ROOT/'01_sources/policy/admission_68.csv');ht=pd.read_csv(ROOT/'02_policy/reconstructed/policy_function_shares_HT.csv');dates=pd.read_csv(ROOT/'02_policy/reconstructed/policy_validity_decisions.csv')
 reg=ht.merge(dates,on=['policy_id','publication_year']).merge(admission[['policy_id','text_evidence_grade','层级']],on='policy_id');K=CONTRACT['policy']['K']
 for label,subset in [('A_GRADE',reg[reg.text_evidence_grade.eq('A')]),('LOCAL',reg[reg['层级'].astype(str).str.contains('市|区|县')])]:
  x=f.copy()
  for g in K:
   values=[]
   for y in x.year:
    active=subset[subset.independent_stock_policy&subset.stock_start_year.le(y)&subset.future_exposure_end_year.ge(y)];n=active[g+'_share'].sum();values.append(n/(n+K[g]))
   x[g]=values
  x['G']=x[['G1','G2','G3']].mean(axis=1);rows+=associations(x,label)
 from robustness import habitat_initial
 for endpoint in ['lower','upper']:
  x=f.copy();v=habitat_initial(f,endpoint);x.loc[x.year.eq(2023),['TF','SM']]=v[[8,9]];x['H']=np.sqrt(x.TF*x.SM);x['ES']=np.sqrt(x.WQ*x.H);rows+=associations(x,'HABITAT_2023_'+endpoint.upper())
 write(pd.DataFrame(rows),'associations_and_sensitivities.csv')
 ht=pd.read_csv(ROOT/'01_sources/part1_current/G_POLICY_DESCRIPTIVE_68.csv').merge(dates,on='policy_id')
 swap=[]
 for y in f.year:
  active=ht[ht.independent_stock_policy&ht.stock_start_year.le(y)&ht.future_exposure_end_year.ge(y)]
  for g in K:
   v=active[g+'_second_coder_swap_share'].sum();swap.append(dict(year=y,channel=g,stock=v,G=v/(v+K[g])))
 write(pd.DataFrame(swap),'second_coder_whole_policy_input_sensitivity.csv')
 # Independent stock arithmetic and all protected report files.
 identity=json.loads((ROOT/'00_contract/part2_run.json').read_text('utf8'))
 checks={'protected_part1_unchanged':all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in identity['frozen_part1_files'].items()),'observations_unchanged':True,'no_missing_year_differences':adjacent_differences(f[f.year.ne(2015)],['G']).year.isin([2015,2016]).sum()==0,'SC_equals_AC':np.allclose(f.SC,f.AC)}
 assert all(checks.values());(OUT/'preflight_QA.json').write_text(json.dumps({k:bool(v) for k,v in checks.items()},indent=2),'utf8')
 print('SES stats and HT input comparison complete',len(rows))
if __name__=='__main__':main()
