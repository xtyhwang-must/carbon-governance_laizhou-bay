"""research accepted-vector spread and one-at-a-time training-loss diagnostics."""
from __future__ import annotations
import json,sys
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib as mpl
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'05_code/engine'),str(ROOT/'05_code')]
import sd_model as model
from modeling import TrainingContext,bounds

CAL=ROOT/'06_runs/formal_main/calibration'
OUT=ROOT/'07_publication/figures'

def save(fig,stem):
    for ext,kw in [('svg',{}),('pdf',{}),('png',{'dpi':450})]:
        fig.savefig(OUT/(stem+'.'+ext),bbox_inches='tight',facecolor='white',**kw)
    plt.close(fig)

def main():
    OUT.mkdir(parents=True,exist_ok=True)
    status=json.loads((CAL/'formal_calibration_status.json').read_text(encoding='utf-8'))
    structure=status['structure'];names,box=bounds(structure)
    ensemble=pd.read_csv(CAL/'accepted_parameter_ensemble.csv')
    if ensemble.empty:raise RuntimeError('No accepted vectors to visualize')
    best=json.loads((CAL/'best_parameter_set.json').read_text(encoding='utf-8'))
    frame=pd.read_csv(ROOT/'03_indicators/model_input_B1.csv')
    context=TrainingContext(frame,structure,2020)
    vector=np.array([best['parameters'][n] for n in names],float)
    best_loss=context.evaluate(vector)
    if abs(best_loss-best['diagnostics']['loss'])>1e-9:
        raise AssertionError('Loss profiles and formal fit use different objective')
    rows=[]
    for i,name in enumerate(names):
        vals=ensemble[name].to_numpy(float)
        unit=(vals-box[i,0])/(box[i,1]-box[i,0])
        rows.append({'parameter':name,'lower':box[i,0],'upper':box[i,1],
            'n_accepted':len(vals),'P5':float(np.quantile(vals,.05)),
            'median':float(np.median(vals)),'P95':float(np.quantile(vals,.95)),
            'normalized_P5':float(np.quantile(unit,.05)),
            'normalized_median':float(np.median(unit)),
            'normalized_P95':float(np.quantile(unit,.95)),
            'set_range_not_posterior_interval':True})
    spread=pd.DataFrame(rows)
    spread.to_csv(OUT/'parameter_distribution_source_data.csv',index=False,encoding='utf-8-sig')
    preferred=[n for n in ['alpha_AC','alpha_SM','k_restore','r_habitat','k_governance'] if n in names]
    selected=preferred[:3]
    profiles=[]
    for name in selected:
        i=names.index(name)
        for val in np.linspace(box[i,0],box[i,1],41):
            trial=vector.copy();trial[i]=val
            loss=float(context.evaluate(trial))
            profiles.append({'parameter':name,'grid_value':float(val),'training_loss':loss,
                'delta_from_best_loss':loss-best_loss,'best_value':float(vector[i]),
                'best_loss':float(best_loss),'all_other_parameters_fixed':True,
                'not_profile_likelihood_or_confidence_interval':True})
    profile=pd.DataFrame(profiles)
    profile.to_csv(OUT/'calibration_loss_profile_source_data.csv',index=False,encoding='utf-8-sig')
    mpl.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Arial','DejaVu Sans','sans-serif'],
        'svg.fonttype':'none','pdf.fonttype':42,'font.size':8,'axes.spines.right':False,
        'axes.spines.top':False,'axes.linewidth':.8,'legend.frameon':False})
    fig,ax=plt.subplots(figsize=(7.0,4.0),layout='constrained')
    y=np.arange(len(names))
    for i,row in spread.iterrows():
        color='#2b5b71' if row.parameter.startswith('alpha_') else '#9b6c3b'
        ax.plot([row.normalized_P5,row.normalized_P95],[i,i],lw=4.0,color=color,
            alpha=.67,solid_capstyle='round')
        ax.scatter(row.normalized_median,i,s=30,color='#1d3440',zorder=3)
    ax.set_yticks(y,names);ax.invert_yaxis();ax.set_xlim(-.03,1.03)
    ax.set_xlabel('Position within registered numeric bounds')
    ax.set_title('Accepted parameter set spread',loc='left',weight='bold',pad=12)
    ax.grid(axis='x',lw=.5,color='#d7dfe3');ax.set_axisbelow(True)
    ax.text(1.0,1.02,f'n = {len(ensemble)} accepted vectors; bar = P5–P95, dot = median',
        transform=ax.transAxes,ha='right',fontsize=7,color='#51616a')
    save(fig,'B12_parameter_spread')
    fig,axes=plt.subplots(1,len(selected),figsize=(8.5,2.65),layout='constrained')
    if len(selected)==1:axes=[axes]
    for ax,name in zip(axes,selected):
        g=profile[profile.parameter.eq(name)]
        ax.plot(g.grid_value,g.delta_from_best_loss,color='#2b5b71',lw=1.8)
        ax.axhline(0,color='#9daab0',lw=.7)
        ax.axvline(g.best_value.iloc[0],color='#9b6c3b',lw=1,ls='--')
        ax.scatter([g.best_value.iloc[0]],[0],color='#9b6c3b',s=22,zorder=3)
        ax.set_title(name,fontsize=8,weight='bold')
        ax.set_xlabel('Registered parameter units')
        ax.set_ylabel('Δ training loss')
        ax.grid(axis='y',lw=.5,color='#d7dfe3');ax.set_axisbelow(True)
    save(fig,'B12_local_loss_profiles')
    from surface_figure import main as surface_figure_main
    surface_figure_main()
    (OUT/'figure_notes.md').write_text('''# Figure contract\n\nCore conclusion: The accepted-set spread, fixed-other-parameter training-loss shapes, and registered B1 response surface disclose distinct diagnostic and conditional scenario information.\n\nEvidence: The distribution uses the actual propagated accepted ensemble. Each 41-point loss profile recomputes the 2011–2020 seven-state objective with all other fitted parameters fixed. The 13 by 13 response surface uses 24 registered parameter vectors and has its own source grid and endpoint checks. Source CSV files accompany all figures.\n\nArchetype: Quantitative diagnostics plus a replacement conditional response surface, separate from trajectory, interval and network figures. The set quantiles are not posterior probabilities or confidence intervals; the loss scans are not profile-likelihood intervals; the surface is not a policy-success probability.\n\nExports: Editable SVG and PDF plus high-resolution PNG. All figure text is English.\n''',encoding='utf-8')
    print({'accepted_sets':len(ensemble),'profile_rows':len(profile),'exports':9},flush=True)

if __name__=='__main__':main()
