"""Separate dated text facts from annual exposure conventions and stock math."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import re

import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parents[1]
POL=ROOT/'02_policy/reconstructed'
DATE=r'(?P<year>20\d{2}|19\d{2})\s*[年./-]\s*(?P<month>\d{1,2})\s*[月./-]\s*(?P<day>\d{1,2})\s*日?'
START_PATTERNS=[
 ('SELF_EFFECTIVE',re.compile(r'(?:本法|本条例|本办法|本规定|本方案|本规划)[^。；\n]{0,45}?自\s*'+DATE+r'\s*起(?:施行|实施|执行)')),
 ('SELF_EFFECTIVE',re.compile(r'自\s*'+DATE+r'\s*起(?:施行|实施|执行)')),
 ('METADATA_EFFECTIVE',re.compile(r'(?:【实施日期】|实施日期[:：])\s*'+DATE)),
]
PUB_PATTERNS=[
 ('METADATA_PUBLICATION',re.compile(r'(?:【发布日期】|发布日期[:：]|发文日期[:：])\s*'+DATE)),
 ('SIGNED_DATE',re.compile(DATE+r'\s*(?:印发|公布|发布|签发)')),
]
EXPIRY_PATTERN=re.compile(r'(?:本办法|本规定|本通知|本方案|本规划|本条例)[^。；\n]{0,100}?(?:有效期|施行期限)[^。；\n]{0,30}?(?:至|到)\s*'+DATE)

def iso(match):
    try:return f"{int(match.group('year')):04d}-{int(match.group('month')):02d}-{int(match.group('day')):02d}"
    except (ValueError,KeyError):return None

def pick(candidates,priority):
    chosen=sorted((r for r in candidates if r['event_type'] in priority and r['date_iso']),
                  key=lambda r:(priority.index(r['event_type']),r['char_start']))
    return chosen[0] if chosen else None

def main():
    audit=pd.read_csv(POL/'text_source_audit.csv').set_index('policy_id')
    shares=pd.read_csv(POL/'policy_function_shares_B1.csv')
    admission=pd.read_csv(ROOT/'01_sources/policy/admission_68.csv').set_index('policy_id')
    evidence=[];decisions=[]
    for policy_id,row in admission.iterrows():
        body=(ROOT/audit.loc[policy_id,'clean_text_relative_path']).read_text(encoding='utf-8')
        candidates=[]
        for event_type,pattern in START_PATTERNS+PUB_PATTERNS+[('SELF_EXPLICIT_EXPIRY',EXPIRY_PATTERN)]:
            for match in pattern.finditer(body):
                date=iso(match)
                if date is None:continue
                context=body[max(0,match.start()-90):min(len(body),match.end()+90)]
                candidates.append({'policy_id':policy_id,'event_type':event_type,'date_iso':date,
                                   'source_relative_path':audit.loc[policy_id,'body_source_relative_path'],
                                   'source_sha256':audit.loc[policy_id,'body_source_sha256'],
                                   'clean_text_relative_path':audit.loc[policy_id,'clean_text_relative_path'],
                                   'locator_coordinate_system':'normalized_clean_text_chars',
                                   'char_start':match.start(),'char_end':match.end(),
                                   'evidence_text':match.group(0),'context':context,
                                   'selected_for_exposure':False,'fact_review_status':'RULE_ASSISTED_EXTRACTED_AUTHOR_PENDING'})
        publication=pick(candidates,['METADATA_PUBLICATION','SIGNED_DATE'])
        effective=pick(candidates,['SELF_EFFECTIVE','METADATA_EFFECTIVE'])
        expiry=pick(candidates,['SELF_EXPLICIT_EXPIRY'])
        pub_year=int(row['publication_year'])
        if publication and int(publication['date_iso'][:4])!=pub_year:
            # A page or attachment can mention another policy's date. Do not
            # override the admitted publication year without a reviewed match.
            publication=None
        if effective and int(effective['date_iso'][:4]) < pub_year-1:
            effective=None
        if effective and int(effective['date_iso'][:4]) > pub_year+5:
            effective=None
        if expiry and int(expiry['date_iso'][:4]) < pub_year:
            expiry=None
        for chosen in [publication,effective,expiry]:
            if chosen:chosen['selected_for_exposure']=True
        evidence.extend(candidates)
        publication_date=publication['date_iso'] if publication else None
        effective_date=effective['date_iso'] if effective else None
        expiry_date=expiry['date_iso'] if expiry else None
        start_year=int(effective_date[:4]) if effective_date else int(publication_date[:4]) if publication_date else pub_year
        start_rule='EXPLICIT_SELF_EFFECTIVE' if effective_date else 'PUBLICATION_FALLBACK_FOR_EXPOSURE'
        end_year=int(expiry_date[:4]) if expiry_date else None
        amendment=(policy_id=='DY_2023_14FIVE_ECO_AMEND_01')
        decisions.append({'policy_id':policy_id,'policy_version_id':policy_id+'_CAPTURED_VERSION',
                          'publication_year':pub_year,'publication_date_fact':publication_date,
                          'effective_date_fact':effective_date,'explicit_expiry_date_fact':expiry_date,
                          'repeal_date_fact':pd.NA,'replacement_date_fact':pd.NA,
                          'plan_horizon_text':str(row['政策标题']) if re.search(r'20\d{2}.{0,4}20\d{2}',str(row['政策标题'])) else pd.NA,
                          'stock_start_year':start_year,'stock_end_fact_year':end_year,
                          'historical_stock_end_year':min(end_year,2023) if end_year else 2023,
                          'future_exposure_end_year':min(end_year,2030) if end_year else 2030,
                          'stock_exit_transition_year':end_year+1 if end_year is not None else pd.NA,
                          'start_rule':start_rule,
                          'end_rule':'EXPLICIT_EXPIRY' if end_year is not None else 'OPEN_ENDED_ASSUMED_THROUGH_2030',
                          'open_ended_fact_unknown':end_year is None,
                          'independent_stock_policy':not amendment,
                          'amendment_parent_policy_id':'DY_2021_14FIVE_ECO_PLAN_01' if amendment else pd.NA,
                          'policy_source_sha256':audit.loc[policy_id,'body_source_sha256'],
                          'author_review_status':'PENDING'})
    ev=pd.DataFrame(evidence)
    if not ev.empty:ev.to_csv(POL/'policy_time_evidence.csv',index=False,encoding='utf-8-sig')
    dec=pd.DataFrame(decisions)
    assert len(dec)==68 and dec.policy_id.is_unique
    dec.to_csv(POL/'policy_validity_decisions.csv',index=False,encoding='utf-8-sig')
    if not (ROOT/'02_policy/review/author_decisions.csv').exists():
        p=ROOT/'02_policy/review/author_decisions.csv';p.parent.mkdir(parents=True,exist_ok=True)
        pd.DataFrame(columns=['decision_id','policy_id','unit_id','field','author_decision','author_evidence','author_name','author_timestamp','status']).to_csv(p,index=False,encoding='utf-8-sig')
    full=dec.merge(shares,on=['policy_id','publication_year'],validate='one_to_one',suffixes=('_time','_code'))
    rows=[];exposure=[]
    for year in range(2000,2031):
        active=full[(full.independent_stock_policy)&(full.stock_start_year.le(year))&
                    (full.future_exposure_end_year.ge(year))]
        entry=full[(full.independent_stock_policy)&(full.stock_start_year.eq(year))]
        exit_=full[(full.independent_stock_policy)&(full.stock_exit_transition_year.eq(year))]
        for record in full.itertuples():
            exposure.append({'policy_id':record.policy_id,'year':year,
                             'independent_stock_policy':bool(record.independent_stock_policy),
                             'active':bool(record.independent_stock_policy and record.stock_start_year<=year<=record.future_exposure_end_year),
                             'start_rule':record.start_rule,'end_rule':record.end_rule,
                             'source_sha256':record.policy_source_sha256})
        for channel,k in [('G1',6.608),('G2',6.605),('G3',7.936)]:
            n=float(active[channel+'_share'].sum())
            rows.append({'year':year,'channel':channel,'active_formal_policy_count':len(active),
                         'active_valid_policy_stock':n,
                         'new_effective_admissions':float(entry[channel+'_share'].sum()),
                         'exits_at_transition':float(exit_[channel+'_share'].sum()),
                         'stock_K':k,'G_observed_supply':n/(n+k),
                         'active_policy_ids':'|'.join(active.policy_id),
                         'annual_exposure_status':'SOURCE_RECONSTRUCTED_OPEN_END_CONVENTION'})
    stock=pd.DataFrame(rows)
    errs=[]
    for channel,g in stock.groupby('channel'):
        g=g.sort_values('year')
        diff=g.active_valid_policy_stock.to_numpy()[1:]-(g.active_valid_policy_stock.to_numpy()[:-1]+g.new_effective_admissions.to_numpy()[1:]-g.exits_at_transition.to_numpy()[1:])
        errs.append((channel,float(np.abs(diff).max())))
    if max(v for _,v in errs)>1e-10:raise AssertionError(f'Stock identity: {errs}')
    stock.to_csv(POL/'policy_stock_by_year_B1.csv',index=False,encoding='utf-8-sig')
    pd.DataFrame(exposure).to_csv(POL/'policy_exposure_2000_2030_B1.csv',index=False,encoding='utf-8-sig')
    print(json.dumps({'policies':68,'selected_explicit_effective':int(dec.effective_date_fact.notna().sum()),
                      'explicit_expiry':int(dec.explicit_expiry_date_fact.notna().sum()),
                      'publication_fallback':int(dec.start_rule.eq('PUBLICATION_FALLBACK_FOR_EXPOSURE').sum()),
                      'amendment_not_independent_stock':int((~dec.independent_stock_policy).sum()),
                      'max_stock_identity_error':max(v for _,v in errs)},ensure_ascii=False))

if __name__=='__main__':main()
