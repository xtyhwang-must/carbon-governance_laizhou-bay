"""Replace the old response-surface image with the computed B1 grid."""
from __future__ import annotations
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT/'06_runs/formal_main/mechanisms/response_surface/response_surface_summary.csv'
OUT=ROOT/'07_publication/figures'

def main():
    data=pd.read_csv(SOURCE)
    if len(data)!=169 or data.parameter_sets.nunique()!=1:
        raise ValueError('Expected complete 13 by 13 B1 response surface')
    value=data.pivot(index='disturbance_grid_index',columns='governance_grid_index',
        values='min_ES_2026_2030_median').sort_index().sort_index(axis=1)
    if value.shape!=(13,13) or not np.isfinite(value.to_numpy(float)).all():
        raise ValueError('Incomplete or nonfinite response-surface cells')
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,
        'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none'})
    fig,ax=plt.subplots(figsize=(7.2,5.5))
    fig.subplots_adjust(left=.15,right=.84,bottom=.22,top=.89)
    grid=np.linspace(0,1,13)
    mesh=ax.pcolormesh(grid,grid,value.to_numpy(float),cmap='viridis',shading='nearest')
    levels=np.linspace(value.to_numpy(float).min(),value.to_numpy(float).max(),6)[1:-1]
    contours=ax.contour(grid,grid,value.to_numpy(float),levels=levels,
        colors='white',linewidths=.65,alpha=.8)
    ax.clabel(contours,inline=True,fmt='%.3f',fontsize=7)
    ax.scatter([0,1],[1,1],s=70,facecolors='none',edgecolors='white',linewidths=1.4,zorder=5)
    ax.annotate('S0',(.0,1.),xytext=(9,-14),textcoords='offset points',
        color='white',fontweight='bold',ha='left')
    ax.annotate('S4',(1.,1.),xytext=(-9,-14),textcoords='offset points',
        color='white',fontweight='bold',ha='right')
    ax.set(xlabel='Governance lever path: S0 to S4',
        ylabel='Compound disturbance: absent to full',
        title='B1 conditional response surface')
    ax.set_xticks(np.linspace(0,1,6));ax.set_yticks(np.linspace(0,1,6))
    bar=fig.colorbar(mesh,ax=ax,pad=.025,shrink=.87)
    bar.set_label('Median minimum ES, 2026–2030')
    fig.text(.5,.065,f'{int(data.parameter_sets.iloc[0])} fixed parameter vectors; registered 13 × 13 grid; not a probability surface',
        ha='center',va='bottom',fontsize=8,color='#43515a')
    OUT.mkdir(parents=True,exist_ok=True)
    for ext in ['svg','pdf','png']:
        fig.savefig(OUT/f'B12_response_surface.{ext}',dpi=300,bbox_inches='tight')
    plt.close(fig)
    print({'grid_points':len(data),'parameter_sets':int(data.parameter_sets.iloc[0]),
        'exports':3},flush=True)

if __name__=='__main__':main()
