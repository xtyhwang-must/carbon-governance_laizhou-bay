"""Run the locked, finite training-internal structure comparison."""
from __future__ import annotations
import json,sys
from concurrent.futures import ProcessPoolExecutor,as_completed
from pathlib import Path
import numpy as np
import pandas as pd
import yaml
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'05_code/engine'),str(ROOT/'05_code')]
import engine_config as cfg
import sd_model as model
from modeling import fit_one,diagnostic_rows,TrainingContext,STATES

OUT=ROOT/'06_runs/structure_compare'
PROTOCOL=yaml.safe_load((ROOT/'00_contract/structure_selection_protocol.yaml').read_text(encoding='utf-8'))
FOLDS=[(2016,2018),(2018,2020)]
SEEDS=PROTOCOL['fit']['seeds']
BUDGET={'maxiter':PROTOCOL['fit']['differential_evolution']['maxiter'],
 'popsize_per_dimension':PROTOCOL['fit']['differential_evolution']['popsize_per_dimension'],
 'tol':PROTOCOL['fit']['differential_evolution']['tol'],
 'Powell_maxiter':PROTOCOL['fit']['Powell']['maxiter'],
 'xtol':PROTOCOL['fit']['Powell']['xtol'],'ftol':PROTOCOL['fit']['Powell']['ftol']}

def run_fits(structures):
    tasks=[(s,start,seed,BUDGET,str(OUT)) for s in structures for start,_ in FOLDS for seed in SEEDS]
    results=[]
    with ProcessPoolExecutor(max_workers=4) as pool:
        futures=[pool.submit(fit_one,t) for t in tasks]
        for i,f in enumerate(as_completed(futures),1):
            result=f.result();results.append(result)
            print(f"compare fit={i}/{len(tasks)} {result['structure']} train={result['train_end']} seed={result['seed']} loss={result['diagnostics']['loss']:.5f}",flush=True)
    return results

def selected_by_training(fits):
    chosen=[]
    for _,g in pd.DataFrame([{'structure':r['structure'],'train_end':r['train_end'],'seed':r['seed'],
      'loss':r['diagnostics']['loss']} for r in fits]).groupby(['structure','train_end']):
        row=g.sort_values(['loss','seed']).iloc[0]
        chosen.append(next(r for r in fits if r['structure']==row.structure and r['train_end']==row.train_end and r['seed']==row.seed))
    return chosen

def diagnostics(frame,chosen):
    rows=[]
    for fit in chosen:
        end=dict(FOLDS)[fit['train_end']]
        rows.extend(diagnostic_rows(frame,fit,end))
    return pd.DataFrame(rows)

def score(rows):
    values=[]
    for s,g in rows.groupby('structure'):
        entry={'structure':s,'mean_seven_state_NRMSE':float(np.sqrt(g.groupby(['fold_train_end','state']).NRMSE_squared_error.mean()).mean())}
        for state in STATES:
            d=g[g.state.eq(state)]
            entry[state+'_RMSE']=float(np.sqrt(np.mean(d.squared_error)))
            entry[state+'_bias']=float(d.error.mean())
            entry[state+'_persistence_RMSE']=float(np.sqrt(np.mean((d.persistence-d.observed)**2)))
            entry[state+'_trend_RMSE']=float(np.sqrt(np.mean((d.training_linear_trend-d.observed)**2)))
        values.append(entry)
    return pd.DataFrame(values)

def target_bounds(frame):
    # Loose necessary upper bounds over registered parameter/state support.
    # Each positive driver uses its full [0,1] range; no old fitted vector is
    # used as a bound input or as evidence for model selection.
    mode=model.ModelMode();initial=model.initial_state(frame,year=2011)
    forcing=model.historical_forcing(frame)
    first=forcing.at(2011.)
    compound=float(np.cbrt(first['PPT']*first['RUNOFF']*first['SST']))
    base={'SC':float(initial[4]),'SM':float(initial[9]),'H':float(np.sqrt(initial[8]*initial[9])),
      'SP':float(initial[3]),'COMPOUND':compound,
      'HABITAT_DRIVER':float(.60*initial[3]+.40*compound)}
    ka=cfg.PARAMETER_BOUNDS['k_adaptive'][1]
    k_nat=cfg.PARAMETER_BOUNDS['k_natural'][1]
    k_res=cfg.PARAMETER_BOUNDS['k_restore'][1]
    ac_terms=ka+.55*(1-base['H'])+.78*base['SP']+.20*cfg.FIXED_PARAMETERS['k_compound']*base['COMPOUND']
    sm_terms=1.20*k_res+.82*k_nat*base['HABITAT_DRIVER']+.30*ka*(1-base['SC'])
    ac_old=float(model.logistic(model.logit(base['SC'])+ac_terms))
    sm_old=float(model.logistic(model.logit(base['SM'])+sm_terms))
    upper_alpha=cfg.STRUCTURAL_PARAMETER_BOUNDS['alpha_AC'][1]
    ac_new=float(model.logistic(upper_alpha+ac_terms))
    sm_new=float(model.logistic(cfg.STRUCTURAL_PARAMETER_BOUNDS['alpha_SM'][1]+sm_terms))
    conversion_max=cfg.TF_TO_SM_AREA_SCALE_RATIO*mode.tf_sm_conversion_scale
    r_lower=cfg.PARAMETER_BOUNDS['r_habitat'][0]*1.55
    sm_dynamic_old=max(float(initial[9]),(r_lower*sm_old+conversion_max)/(r_lower+conversion_max))
    sm_dynamic_new=max(float(initial[9]),(r_lower*sm_new+conversion_max)/(r_lower+conversion_max))
    obs_ac=float(frame[frame.year.le(2020)].SC.max());obs_sm=float(frame[frame.year.le(2020)].SM.max())
    out=[]
    for s in model.STRUCTURE_EXTRA_PARAMETERS:
        ac=ac_old if s.startswith('M0') else ac_new
        sm_t=sm_new if s in ('M2_AC_SM_INTERCEPTS','M3_AC_SM_TF_INTERCEPTS') else sm_old
        sm_d=sm_dynamic_new if s in ('M2_AC_SM_INTERCEPTS','M3_AC_SM_TF_INTERCEPTS') else sm_dynamic_old
        out.append({'structure':s,'AC_observed_training_max':obs_ac,'AC_target_upper':ac,
          'AC_excluded_by_bound':obs_ac>ac+1e-12,'SM_observed_training_max':obs_sm,
          'SM_target_upper':sm_t,'SM_dynamic_barrier_upper':sm_d,
          'SM_excluded_by_bound':obs_sm>sm_d+1e-12,
          'bound_role':'necessary_loose_state_box_bound_not_joint_path_fit'})
    return pd.DataFrame(out)

def main():
    OUT.mkdir(parents=True,exist_ok=True)
    frame=pd.read_csv(ROOT/'03_indicators/model_input_B1.csv').sort_values('year')
    all_fits=run_fits(['M0_FIXED_REFERENCE','M1_AC_INTERCEPT'])
    prelim=diagnostics(frame,selected_by_training(all_fits))
    prelim_scores=score(prelim).set_index('structure')
    bounds=target_bounds(frame)
    m1_sm=prelim_scores.loc['M1_AC_INTERCEPT','SM_RMSE']
    m1_bound=bool(bounds.set_index('structure').loc['M1_AC_INTERCEPT','SM_excluded_by_bound'])
    trigger=m1_bound or m1_sm>.20
    if trigger:all_fits+=run_fits(['M2_AC_SM_INTERCEPTS'])
    preliminary_m2=score(diagnostics(frame,selected_by_training(all_fits))).set_index('structure')
    if 'M2_AC_SM_INTERCEPTS' in preliminary_m2.index and abs(preliminary_m2.loc['M2_AC_SM_INTERCEPTS','TF_bias'])>.20:
        all_fits+=run_fits(['M3_AC_SM_TF_INTERCEPTS'])
    chosen=selected_by_training(all_fits)
    rows=diagnostics(frame,chosen)
    scores=score(rows)
    bounds.to_csv(OUT/'necessary_target_bounds.csv',index=False,encoding='utf-8-sig')
    rows.to_csv(OUT/'internal_fold_predictions_by_state.csv',index=False,encoding='utf-8-sig')
    scores.to_csv(OUT/'internal_fold_structure_scores.csv',index=False,encoding='utf-8-sig')
    pd.DataFrame([{'structure':r['structure'],'train_end':r['train_end'],'seed':r['seed'],
        'loss':r['diagnostics']['loss'],'DE_nfev':r['DE_nfev'],'Powell_nfev':r['Powell_nfev'],
        'DE_success':r['DE_success'],'Powell_success':r['Powell_success'],
        'objective_failures':r['objective_failures'],'parameter_count':r['parameter_count'],
        'selected_seed_for_fold':r in chosen} for r in all_fits]).to_csv(
        OUT/'fit_execution_summary.csv',index=False,encoding='utf-8-sig')
    decisions=scores[['structure','mean_seven_state_NRMSE','SC_RMSE','SM_RMSE']].copy()
    valid=decisions[np.isfinite(decisions.mean_seven_state_NRMSE)].copy()
    if valid.empty:raise ValueError('No finite development structure')
    valid['parameter_count']=valid.structure.map(lambda x:len(model.parameter_names(x)))
    best=float(valid.mean_seven_state_NRMSE.min());near=valid[valid.mean_seven_state_NRMSE<=best+1e-5]
    selected=str(near.sort_values(['parameter_count','mean_seven_state_NRMSE']).iloc[0].structure)
    decisions['decision']=np.where(decisions.structure.eq(selected),'SELECTED_DEVELOPMENT_EXPLORATION','NOT_SELECTED')
    decisions.to_csv(OUT/'model_selection_machine.csv',index=False,encoding='utf-8-sig')
    decision={'selected_structure':selected,'empirical_structure_qualifies':False,'M2_triggered':bool(trigger),
      'M2_trigger_details':{'SM_RMSE_M1':float(m1_sm),'SM_bound_excluded_M1':m1_bound},
      'selection_rule_locked_before_fit':True,'holdout_not_used_for_selection':True,
      'status':'SELECTED_DEVELOPMENT_EXPLORATION_NOT_BEHAVIORAL_CERTIFICATION'}
    (OUT/'model_selection.json').write_text(json.dumps(decision,ensure_ascii=False,indent=2),encoding='utf-8')
    lines=['# Finite research structure choice','',
      'The 2011–2020 fixed measurement scale and previously viewed 2021–2023 outcomes make these development diagnostics, not blind validation.',
      f"Selected executable specification: `{selected}`; qualification: `{decision['status']}`.",
      f"M2 conditional trigger: {trigger}; M1 pooled SM RMSE={m1_sm:.4f}; M1 SM bound excluded={m1_bound}.",
      '', 'See `internal_fold_structure_scores.csv`, `necessary_target_bounds.csv`, `fit_execution_summary.csv`, and `model_selection_machine.csv` for every candidate and trade-off.',
      'No scenario ranking, original-manuscript distance, or 2021–2023 value entered selection.']
    (OUT/'model_selection_report.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print(json.dumps(decision,ensure_ascii=False),flush=True)

if __name__=='__main__':main()
