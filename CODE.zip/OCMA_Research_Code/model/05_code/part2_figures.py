"""Publication figures from the unique Part2 input and same-version outputs."""
from pathlib import Path
import json
import numpy as np,pandas as pd
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parents[1];RUN=ROOT/'06_runs/formal_main';OUT=ROOT/'07_publication/figures';OUT.mkdir(parents=True,exist_ok=True)
plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['DejaVu Sans','Arial'],'font.size':10,'svg.fonttype':'none','pdf.fonttype':42,'axes.spines.top':False,'axes.spines.right':False,'legend.frameon':False})
COLORS=['#244A73','#278A7A','#C9755E','#8B749E','#BD9A43','#5A8B9C','#7D7D7D']
def rd(p):return pd.read_csv(p)
def save(fig,name):
 fig.tight_layout()
 for ext in ['svg','pdf','png']:fig.savefig(OUT/(name+'.'+ext),dpi=450,bbox_inches='tight',facecolor='white')
 plt.close(fig)
def main():
 # Figure3 contains model-defined links, not a recovered institutional network.
 from matplotlib.patches import FancyArrowPatch
 fig,ax=plt.subplots(figsize=(8.4,5.6));ax.set(xlim=(0,1),ylim=(0,1));ax.axis('off')
 positions={'G':(.5,.78),'S':(.16,.25),'E':(.84,.25)}
 labels={'G':'Formal governance supply\nHT-weighted G1, G2, G3\nImplementation state IM','S':'Social subsystem\nPressure SP; capacity AC\nSocial memory PRS','E':'Ecological subsystem\nNS, OS, BS; TF, SM\nEcological-risk memory'}
 for key,pos in positions.items():ax.text(*pos,labels[key],ha='center',va='center',fontsize=10,bbox=dict(boxstyle='round,pad=.6',facecolor='#F0F3F5',edgecolor=COLORS[0]))
 for a,b,rad,label in [('G','S',.15,'actions / capacity'),('S','G',.15,'gate / social risk'),('G','E',-.15,'pollution / habitat actions'),('E','G',-.15,'ecological risk'),('S','E',.14,'social pressure'),('E','S',.14,'ecological feedback')]:
  x,y=positions[a],positions[b];patch=FancyArrowPatch(x,y,connectionstyle='arc3,rad='+str(rad),arrowstyle='-|>',mutation_scale=12,shrinkA=65,shrinkB=65,color=COLORS[0],lw=1.2);ax.add_patch(patch)
 for x,y,text in [(.2,.59,'Governance actions'),(.38,.48,'Social gate / risk'),(.8,.59,'Restoration / control'),(.62,.48,'Ecological risk'),(.5,.19,'Social pressure'),(.5,.33,'Ecological feedback')]:ax.text(x,y,text,ha='center',fontsize=8,bbox=dict(facecolor='white',edgecolor='none',pad=1))
 ax.text(.5,.09,'External forcing: precipitation, modeled runoff, SST',ha='center',fontsize=9)
 ax.text(.5,.015,'Fixed 2011 training reference; explicit 2023 scenario state\nConstant target backgrounds: alpha_AC, alpha_SM, alpha_TF',ha='center',fontsize=9)
 save(fig,'Figure3')
 f=rd(ROOT/'06_runs/ses/SES_states_2011_2023.csv');assoc=rd(ROOT/'06_runs/ses/associations_and_sensitivities.csv')
 fig,ax=plt.subplots(figsize=(8,3.6))
 for c,color in zip(['G','SR','ES'],COLORS):ax.plot(f.year,f[c],marker='o',ms=4,label=c,color=color)
 ax.axvspan(2022.8,2023.2,color='.9',zorder=0);ax.set(xlabel='Year',ylabel='Normalized state',ylim=(0,1));ax.legend(ncol=3);save(fig,'Figure5')
 fig,axs=plt.subplots(1,2,figsize=(9,4))
 for ax,mode in zip(axs,['level','annual_change']):
  z=assoc[(assoc.scope=='FULL_2011_2023')&assoc['mode'].eq(mode)].iloc[:3];y=np.arange(len(z));ax.axvline(0,color='.8');ax.hlines(y,z.loo_min,z.loo_max,color=COLORS[0]);ax.scatter(z.rho,y,c=COLORS[0]);ax.set_yticks(y,[a+' / '+b for a,b in zip(z.state_a,z.state_b)]);ax.set(xlim=(-1,1),xlabel='Spearman rho',title=mode.replace('_',' ')+'; n='+str(z.n.iloc[0]))
 save(fig,'Figure6')
 fig,axs=plt.subplots(1,2,figsize=(10,4));z=assoc[(assoc['mode']=='level')&(assoc.state_a=='G')&(assoc.state_b=='ES')]
 for ax,prefix,title in [(axs[0],'HABITAT_','Spatial support (2011–2022)'),(axs[1],None,'Policy / endpoint scope')]:
  q=z[z.scope.str.startswith(prefix)] if prefix else z[~z.scope.str.startswith('HABITAT_')];y=np.arange(len(q));ax.axvline(0,color='.8');ax.hlines(y,q.loo_min,q.loo_max,color=COLORS[1]);ax.scatter(q.rho,y,c=COLORS[1]);ax.set_yticks(y,[s.replace('HABITAT_','').replace('_COMMON_10KM_REFERENCE','').replace('_2011_2023','') for s in q.scope],fontsize=8);ax.set(xlim=(-1,1),xlabel='Spearman rho (lines: leave-one-year range)',title=title)
 save(fig,'Figure7')
 hist=rd(RUN/'evaluation/historical_ensemble_trajectories.csv');scenario=rd(RUN/'scenarios/scenario_trajectories_long.csv');n=scenario.parameter_set_id.nunique()
 fig,ax=plt.subplots(figsize=(9,4))
 for i,s in enumerate(sorted(scenario.scenario.unique())):
  z=scenario[scenario.scenario.eq(s)].groupby('year').ES.quantile([.05,.5,.95]).unstack();ax.plot(z.index,z[.5],label=s,color=COLORS[i]);ax.fill_between(z.index,z[.05],z[.95],color=COLORS[i],alpha=.10)
 ax.axvspan(2026,2028,color='.85',zorder=0);ax.set(xlabel='Year',ylabel='Ecological support',title=f'Conditional scenario paths; n = {n} parameter vectors');ax.legend(ncol=7);save(fig,'Figure9')
 pair=rd(RUN/'scenarios/four_primary_paired_differences.csv');sh=rd(RUN/'attribution/shapley_summary.csv');fig,axs=plt.subplots(1,3,figsize=(12,4.4))
 for col,metric,title in [(0,'D_min_ES_2026_2030','Paired minimum ES difference'),(1,'D_SR_2030','Paired terminal SR difference')]:
  for i,(c,z) in enumerate(pair.groupby('contrast',sort=False)):
   vals=z[metric]*1000;lo,mid,hi=vals.quantile([.05,.5,.95]);axs[col].plot([lo,hi],[i,i],color=COLORS[i]);axs[col].scatter(mid,i,c=COLORS[i])
  axs[col].set_yticks(range(pair.contrast.nunique()),list(pair.contrast.unique()));axs[col].axvline(0,color='.6');axs[col].set_xlabel(title+' (×10⁻³)')
 axs[1].axvline(-.5,color=COLORS[2],ls='--',label='SR screen −0.0005');axs[1].legend(fontsize=7)
 q=sh[(sh.contrast=='S4-S0')&(sh.metric=='min_ES_2026_2030')]
 axs[2].axvline(0,color='.6');axs[2].barh(q['group'],q['median']*1000,color=COLORS[0]);axs[2].set_xlabel('Grouped Shapley contribution (×10⁻³)');axs[2].tick_params(axis='y',labelsize=8);fig.suptitle(f'Matched parameter set n = {n}; ranges = P5–P95');save(fig,'Figure10')
 effects=rd(RUN/'mechanisms/ablation_effects_by_parameter.csv');annual=rd(RUN/'mechanisms/ablation_annual_effects.csv');joint=rd(RUN/'mechanisms/reciprocal_nonadditivity_annual.csv');surface=rd(RUN/'mechanisms/response_surface/response_surface_summary.csv')
 fig,axs=plt.subplots(2,2,figsize=(10,7.2));q=effects[(effects.metric=='ES_2030')&~effects.disabled_link_spec.str.contains('reciprocal')].groupby('disabled_link_spec').contribution_full_minus_ablated.median()
 axs[0,0].barh(q.index,q*1000,color=COLORS[0]);axs[0,0].set_title('a  Directional ablation');axs[0,0].set_xlabel('ES2030 effect (×10⁻³)')
 for i,(link,z) in enumerate(annual[(annual.metric=='ES')&~annual.link.str.contains('reciprocal')].groupby('link')):
  z=z.groupby('year').effect.median();axs[0,1].plot(z.index,z*1000,label=link,color=COLORS[i])
 axs[0,1].set_title('b  Annual ES effect propagation');axs[0,1].set_ylabel('Effect (×10⁻³)');axs[0,1].legend(fontsize=6,ncol=2)
 q=joint[(joint.metric=='ES')&(joint.year==2030)].groupby('pair').nonadditivity.median();axs[1,0].barh(q.index,q*1000,color=COLORS[1]);axs[1,0].set_title('c  Reciprocal non-additivity');axs[1,0].set_xlabel('ES2030 J (×10⁻³)')
 # Schema from actual surface, no interpolation of uncomputed cells.
 value=next(x for x in surface.columns if x in ['min_ES_2026_2030','min_ES_2026_2030_median','median_min_ES'])
 grid=surface.pivot(index='disturbance_intensity',columns='governance_intensity',values=value);im=axs[1,1].pcolormesh(grid.columns,grid.index,grid,shading='nearest',cmap='viridis');fig.colorbar(im,ax=axs[1,1],label='Median minimum ES');axs[1,1].set(title='d  Governance / disturbance response',xlabel='S0 → S4 governance combination',ylabel='Compound disturbance amplitude');save(fig,'Figure8')
 robust=rd(RUN/'robustness/specification_pair_tolerance.csv');extra=rd(RUN/'additional_sensitivity/paired_sensitivity_summary.csv');both=pd.concat([robust,extra],ignore_index=True);matrix=[]
 for spec,z in both[both.metric.eq('min_ES_2026_2030')].groupby('specification_id'):
  row={'specification':('A: ' if spec.startswith('REPORTING') else 'C: ' if 'REFIT' in spec else 'B: ')+spec}
  for label,a,b in [('S4−S0','S0','S4'),('S4−S6','S4','S6')]:
   q=z[z.scenario_a.eq(a)&z.scenario_b.eq(b)];v=q.median_a_minus_b.median();row[label]=float(-v if a=='S0' else v)*1000
  matrix.append(row)
 matrix=pd.DataFrame(matrix).set_index('specification').sort_index();matrix.to_csv(OUT/'Figure11_source.csv');v=matrix.to_numpy(float);limit=np.nanmax(abs(v));fig,ax=plt.subplots(figsize=(8,max(6,len(matrix)*.22)));im=ax.imshow(v,cmap='RdBu_r',vmin=-limit,vmax=limit,aspect='auto');ax.set_yticks(range(len(matrix)),matrix.index,fontsize=7);ax.set_xticks([0,1],matrix.columns);fig.colorbar(im,ax=ax,label='Paired minimum ES difference (×10⁻³)');ax.set_title('A: reporting only; B: fixed-parameter dynamics; C: limited refit',fontsize=9);save(fig,'Figure11')
 # Supplemental component evidence and seven-state history / conditional retrospective fit.
 fig,ax=plt.subplots(figsize=(8,4));q=assoc[(assoc.scope=='FULL_2011_2023')&assoc['mode'].eq('level')].iloc[3:];ax.axvline(0,color='.7');ax.scatter(q.rho,range(len(q)),c=COLORS[0]);ax.hlines(range(len(q)),q.loo_min,q.loo_max,color=COLORS[0]);ax.set_yticks(range(len(q)),q.state_b);ax.set_xlabel('G association; rho and leave-one-year range');save(fig,'Figure_S2')
 fig,axs=plt.subplots(1,2,figsize=(10,3.5))
 for i,c in enumerate(['G1','G2','G3']):axs[0].plot(f.year,f[c],label=c,color=COLORS[i])
 for i,c in enumerate(['WQ','H','ES']):axs[1].plot(f.year,f[c],label=c,color=COLORS[i])
 for ax in axs:ax.legend(ncol=3);ax.set_xlabel('Year')
 save(fig,'Figure_S3')
 fig,axs=plt.subplots(2,4,figsize=(12,6))
 for ax,state in zip(axs.flat,['SP','SC','NS','OS','BS','TF','SM']):
  z=hist.groupby('year')[state].quantile([.05,.5,.95]).unstack();ax.fill_between(z.index,z[.05],z[.95],alpha=.2,color=COLORS[0]);ax.plot(z.index,z[.5],color=COLORS[0],label='Model');ax.plot(f.year,f[state],'o-',color=COLORS[2],ms=3,label='Observed / derived');ax.axvline(2020.5,color='.6',ls='--');ax.set_title(state);ax.set_ylim(0,1)
 axs.flat[-1].axis('off');axs.flat[0].legend(fontsize=7);save(fig,'Figure_S4')
 spread=rd(OUT/'parameter_distribution_source_data.csv');loss=rd(OUT/'calibration_loss_profile_source_data.csv');fig,axes=plt.subplots(1,2,figsize=(10,5))
 for i,r in enumerate(spread.itertuples()):axes[0].plot([r.normalized_P5,r.normalized_P95],[i,i],color=COLORS[0],lw=3);axes[0].scatter(r.normalized_median,i,c=COLORS[0])
 axes[0].set_yticks(range(len(spread)),spread.parameter);axes[0].invert_yaxis();axes[0].set_xlabel('Position within numerical bounds');axes[0].set_title('Accepted set P5 / median / P95')
 for i,(name,z) in enumerate(loss.groupby('parameter')):axes[1].plot(z.grid_value,z.training_loss,label=name,color=COLORS[i])
 axes[1].set(xlabel='One parameter varied',ylabel='Training loss',title='Other parameters fixed');axes[1].legend(fontsize=8);save(fig,'Figure_S5')
 print('Figures 5–11 and S2–S4 generated from current run')
if __name__=='__main__':main()
