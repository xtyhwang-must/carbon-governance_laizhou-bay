from pathlib import Path
import yaml
CONTRACT_PATH=Path(__file__).resolve().parents[2]/'00_contract/baseline_contract.yaml'
CONTRACT=yaml.safe_load(CONTRACT_PATH.read_text(encoding='utf-8'))
PARAMETER_BOUNDS=CONTRACT['parameter_bounds']
PARAMETER_NAMES=list(PARAMETER_BOUNDS)
STRUCTURAL_PARAMETER_BOUNDS=CONTRACT['structural_parameter_bounds']
FIXED_PARAMETERS=CONTRACT['fixed_parameters']
STATE_NAMES=['G1','G2','G3','SP','SC','NS','OS','BS','TF','SM','PR','PRS','IM']
SYMBOL_MAP={'SC':'AC'}
TF_TO_SM_AREA_SCALE_RATIO=CONTRACT['habitat_scale_ratio']
CALIBRATION_CONFIG={'solver_method':'RK4_FIXED','solver_max_step':CONTRACT['numerics']['maximum_step_years'],'solver_rtol':1e-5,'solver_atol':1e-7}
