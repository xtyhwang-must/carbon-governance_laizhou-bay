"""以原有11个核心状态为主体的莱州湾蓝碳SES系统动力学模型。"""

from __future__ import annotations

from dataclasses import dataclass
from importlib import import_module
from typing import Mapping

import numpy as np
import pandas as pd
from scipy.integrate import solve_ivp

cfg = import_module("engine_config")
from engine_common import bounded, hill, logistic, logit

@dataclass(frozen=True)
class ModelMode:
    """结构开关，用于反馈消融和稳健性分析。"""

    adaptive_feedback: bool = True
    g_to_s: bool = True
    s_to_g: bool = True
    g_to_e: bool = True
    e_to_g: bool = True
    s_to_e: bool = True
    e_to_s: bool = True
    sc_implementation: bool = True
    governance_synergy: bool = True
    nonlinear_water: bool = True
    asymmetric_habitat: bool = True
    tf_sm_conversion: bool = True
    sc_gate_midpoint: float = 0.30
    sc_execution_floor: float = 0.12
    tf_sm_conversion_scale: float = 0.12

class AnnualForcing:
    """对年度外生序列进行连续时间线性插值。"""

    required_columns = [
        "year",
        "G1_TARGET",
        "G2_TARGET",
        "G3_TARGET",
        "PPT",
        "RUNOFF",
        "SST",
        "ETA_POTENTIAL",
        "POLICY_TAU",
        "FEEDBACK_STRENGTH",
        "SYNERGY_LEVER",
    ]

    def __init__(self, frame: pd.DataFrame):
        missing = sorted(set(self.required_columns) - set(frame.columns))
        if missing:
            raise ValueError(f"外生序列缺少字段: {missing}")
        numeric = frame[self.required_columns].apply(pd.to_numeric, errors='coerce')
        if not np.isfinite(numeric.to_numpy(float)).all() or numeric['year'].duplicated().any():
            raise ValueError('Forcing years must be unique and all forcing values finite')
        self.frame = numeric.sort_values("year").reset_index(drop=True)
        self.years = self.frame["year"].to_numpy(float)
        self._values = {column:self.frame[column].to_numpy(float)
                        for column in self.required_columns if column != "year"}

    def at(self, time: float) -> dict[str, float]:
        return {
            column: float(
                np.interp(
                    time,
                    self.years,
                    self._values[column],
                    left=float(self._values[column][0]),
                    right=float(self._values[column][-1]),
                )
            )
            for column in self.required_columns
            if column != "year"
        }

STRUCTURE_EXTRA_PARAMETERS = {
    'M0_RUN_SPECIFIC': (), 'M0_FIXED_REFERENCE': (),
    'M1_AC_INTERCEPT': ('alpha_AC',),
    'M2_AC_SM_INTERCEPTS': ('alpha_AC','alpha_SM'),
    'M3_AC_SM_TF_INTERCEPTS': ('alpha_AC','alpha_SM','alpha_TF'),
}

def parameter_names(structure: str) -> list[str]:
    if structure not in STRUCTURE_EXTRA_PARAMETERS:
        raise ValueError(f'Unknown structure {structure}')
    return list(cfg.PARAMETER_NAMES) + list(STRUCTURE_EXTRA_PARAMETERS[structure])

def parameter_dict(values: np.ndarray | Mapping[str, float], *, structure: str='M0_RUN_SPECIFIC') -> dict[str, float]:
    names=parameter_names(structure)
    if isinstance(values, Mapping):
        calibrated = {name: float(values[name]) for name in names}
        fixed = {
            name: float(values.get(name, default))
            for name, default in cfg.FIXED_PARAMETERS.items()
        }
        result={**fixed, **calibrated}
        if not np.isfinite(list(result.values())).all():raise ValueError('Nonfinite parameter')
        return result
    array = np.asarray(values, dtype=float)
    if array.shape != (len(names),) or not np.isfinite(array).all():
        raise ValueError("参数向量长度不正确。")
    return {
        **cfg.FIXED_PARAMETERS,
        **dict(zip(names, array)),
    }

def legacy_reporting_states(states: np.ndarray, aggregation: str = "geometric") -> dict:
    state = np.asarray(states, dtype=float)
    sp, sc, ns, os_, bs, tf, sm = (
        state[..., 3],
        state[..., 4],
        state[..., 5],
        state[..., 6],
        state[..., 7],
        state[..., 8],
        state[..., 9],
    )
    water_components = np.stack([1.0 - ns, 1.0 - os_, 1.0 - bs], axis=-1)
    habitat_components = np.stack([tf, sm], axis=-1)
    social_components = np.stack([1.0 - sp, sc], axis=-1)
    if aggregation == "arithmetic":
        wq = np.mean(water_components, axis=-1)
        habitat = np.mean(habitat_components, axis=-1)
        es = 0.5 * (wq + habitat)
        sr = np.mean(social_components, axis=-1)
    elif aggregation == "harmonic":
        wq = len(water_components.shape) and (
            3.0 / np.sum(1.0 / bounded(water_components), axis=-1)
        )
        habitat = 2.0 / np.sum(1.0 / bounded(habitat_components), axis=-1)
        es = 2.0 / (1.0 / bounded(wq) + 1.0 / bounded(habitat))
        sr = 2.0 / np.sum(1.0 / bounded(social_components), axis=-1)
    else:
        wq = np.exp(np.mean(np.log(bounded(water_components)), axis=-1))
        habitat = np.exp(np.mean(np.log(bounded(habitat_components)), axis=-1))
        es = np.sqrt(bounded(wq) * bounded(habitat))
        sr = np.sqrt(bounded(1.0 - sp) * bounded(sc))
    return {"WQ": wq, "H": habitat, "ES": es, "SR": sr}

def reporting_states(states, aggregation="geometric", es_aggregation="geometric", sr_aggregation="geometric"):
    from revised_core import reporting
    if aggregation.startswith("legacy_"):
        if es_aggregation != "geometric" or sr_aggregation != "geometric":
            raise ValueError("Do not combine legacy multilayer and single-layer reporting")
        return legacy_reporting_states(states, aggregation.removeprefix("legacy_"))
    if aggregation != "geometric":
        raise ValueError("Use es_aggregation/sr_aggregation, or explicit legacy_ prefix")
    return reporting(states, es=es_aggregation, sr=sr_aggregation)

def historical_forcing(input_frame: pd.DataFrame) -> AnnualForcing:
    if 'SYNERGY_LEVER' not in input_frame:
        raise ValueError('B1 model input lacks SYNERGY_LEVER')
    if 'synergy_share' in input_frame and not np.allclose(
        input_frame['synergy_share'].to_numpy(float),
        input_frame['SYNERGY_LEVER'].to_numpy(float),
        atol=1e-12, rtol=0, equal_nan=False,
    ):
        raise ValueError('B1 raw synergy_share and model SYNERGY_LEVER differ')
    if input_frame['SYNERGY_LEVER'].isna().any():
        raise ValueError('B1 SYNERGY_LEVER is incomplete')
    forcing = pd.DataFrame(
        {
            "year": input_frame["year"],
            "G1_TARGET": input_frame["G1"],
            "G2_TARGET": input_frame["G2"],
            "G3_TARGET": input_frame["G3"],
            "PPT": input_frame["PPT"],
            "RUNOFF": input_frame["RUNOFF"],
            "SST": input_frame["SST"],
            "ETA_POTENTIAL": input_frame["ETA_POTENTIAL"],
            "POLICY_TAU": 0.50,
            # 历史治理轨迹已经包含现实响应，不重复闭合PR→G。
            "FEEDBACK_STRENGTH": 0.0,
            "SYNERGY_LEVER": input_frame["SYNERGY_LEVER"],
        }
    )
    return AnnualForcing(forcing)

def initial_state(input_frame: pd.DataFrame, *, year: int) -> np.ndarray:
    """Select one stated observation year; never infer historical/future role from row order."""
    if not isinstance(year, (int, np.integer)):
        raise TypeError('initial_state requires an explicit integer year')
    required=['year',*cfg.STATE_NAMES]
    missing=set(required)-set(input_frame.columns)
    if missing:raise ValueError(f'Initial state columns missing: {sorted(missing)}')
    matches=input_frame.loc[pd.to_numeric(input_frame.year,errors='coerce').eq(year)]
    if len(matches)!=1:raise ValueError(f'Expected exactly one input row for {year}; found {len(matches)}')
    values=pd.to_numeric(matches.iloc[0][cfg.STATE_NAMES],errors='coerce').to_numpy(float)
    if not np.isfinite(values).all():raise ValueError(f'Non-finite initial state for {year}')
    if np.any((values<0)|(values>1)):raise ValueError(f'Initial state outside [0,1] for {year}')
    return bounded(values)

def _implementation_potentials(
    state: np.ndarray,
    forcing: Mapping[str, float],
    mode: ModelMode,
) -> tuple[float, float]:
    """返回操作性实施潜力与能力建设实施潜力。"""

    g3, sp, sc = state[2], state[3], state[4]
    if mode.sc_implementation:
        gate = float(hill(sc, mode.sc_gate_midpoint, 2.0))
        sc_factor = mode.sc_execution_floor + (
            1.0 - mode.sc_execution_floor
        ) * gate
        capacity_factor = 0.25 + 0.75 * gate
    else:
        sc_factor = 1.0
        capacity_factor = 1.0
    operations = (
        forcing["ETA_POTENTIAL"]
        * hill(g3, 0.45, 2.2)
        * sc_factor
        / (1.0 + 0.75 * sp)
    )
    capacity = (
        forcing["ETA_POTENTIAL"]
        * hill(g3, 0.45, 2.2)
        * capacity_factor
        / (1.0 + 0.50 * sp)
    )
    return (
        float(np.clip(operations, 0.0, 1.0)),
        float(np.clip(capacity, 0.0, 1.0)),
    )

def _actions(
    state: np.ndarray,
    forcing: Mapping[str, float],
    params: Mapping[str, float],
    mode: ModelMode,
) -> tuple[float, float, float, float, float]:
    g1, g2, g3, sp, sc = state[:5]
    operations_potential, capacity_potential = _implementation_potentials(
        state, forcing, mode
    )
    # IM是具有实施时滞的已实现操作能力；能力建设保留部分直接通道，
    # 避免低SC下IM与SC相互锁定。
    implementation_ops = float(np.clip(state[12], 0.0, 1.0))
    implementation_capacity = float(
        np.clip(0.50 * implementation_ops + 0.50 * capacity_potential, 0.0, 1.0)
    )
    synergy = float(np.cbrt(max(g1 * g2 * g3, 0.0)))
    synergy_multiplier = (
        1.0
        + params["k_synergy"]
        * forcing["SYNERGY_LEVER"]
        * synergy
        if mode.governance_synergy
        else 1.0
    )
    a1 = implementation_ops * float(hill(g1, 0.45, 2.1)) * synergy_multiplier
    a2 = implementation_ops * float(hill(g2, 0.45, 2.1)) * synergy_multiplier
    a3 = implementation_capacity * float(hill(g3, 0.45, 2.1))
    a1, a2, a3 = np.clip([a1, a2, a3], 0.0, 1.0)
    return (
        float(a1),
        float(a2),
        float(a3),
        implementation_ops,
        implementation_capacity,
    )

def _baseline_context(
    initial: np.ndarray,
    first_forcing: Mapping[str, float],
    params: Mapping[str, float],
    mode: ModelMode,
) -> dict[str, float]:
    report = reporting_states(initial)
    a1, a2, a3, _, _ = _actions(initial, first_forcing, params, mode)
    sp, sc, ns, os_, bs, tf, sm = initial[3:10]
    nd = np.mean(
        [first_forcing["PPT"], first_forcing["RUNOFF"], first_forcing["SST"]]
    )
    compound = np.cbrt(
        max(
            first_forcing["PPT"]
            * first_forcing["RUNOFF"]
            * first_forcing["SST"],
            1e-9,
        )
    )
    nutrient_driver = 0.58 * sp + 0.42 * first_forcing["RUNOFF"]
    oxygen_driver = (
        0.34 * sp
        + 0.23 * first_forcing["RUNOFF"]
        + 0.23 * bs
        + 0.20 * first_forcing["SST"]
    )
    bloom_trigger = (
        float(hill(ns, 0.48, 3.0))
        if mode.nonlinear_water
        else ns
    )
    bloom_driver = bloom_trigger * (
        0.50 * first_forcing["SST"] + 0.30 * os_ + 0.20 * first_forcing["RUNOFF"]
    )
    habitat_driver = 0.60 * sp + 0.40 * compound
    return {
        "G1": initial[0],
        "G2": initial[1],
        "G3": initial[2],
        "SP": sp,
        "SC": sc,
        "NS": ns,
        "OS": os_,
        "BS": bs,
        "TF": tf,
        "SM": sm,
        "PR": initial[10],
        "PRS": initial[11],
        "PRE": float(np.clip((3.0 * initial[10] - initial[11]) / 2.0, 0.0, 1.0)),
        "IM": initial[12],
        "WQ": float(report["WQ"]),
        "H": float(report["H"]),
        "ES": float(report["ES"]),
        "A1": a1,
        "A2": a2,
        "A3": a3,
        "ND": nd,
        "COMPOUND": compound,
        "NUTRIENT_DRIVER": nutrient_driver,
        "OXYGEN_DRIVER": oxygen_driver,
        "BLOOM_DRIVER": bloom_driver,
        "HABITAT_DRIVER": habitat_driver,
    }

def make_training_reference_context(input_frame: pd.DataFrame,
                                    params: np.ndarray | Mapping[str,float],
                                    *, structure: str,
                                    mode: ModelMode | None=None) -> dict[str,float]:
    """Freeze 2011 observed state/forcing, while allowing each vector's actions to differ."""
    mode=mode or ModelMode()
    state=initial_state(input_frame,year=2011)
    forcing=historical_forcing(input_frame).at(2011.)
    reference=_baseline_context(state,forcing,parameter_dict(params,structure=structure),mode)
    reference['REFERENCE_YEAR']=2011.0
    return reference

def rhs(
    time: float,
    raw_state: np.ndarray,
    params: Mapping[str, float],
    forcing: AnnualForcing,
    baseline: Mapping[str, float],
    mode: ModelMode,
    structure: str='M0_RUN_SPECIFIC',
) -> np.ndarray:
    state = bounded(np.asarray(raw_state, dtype=float))
    g1, g2, g3, sp, sc, ns, os_, bs, tf, sm, pr, prs, im = state
    exo = forcing.at(time)
    report = reporting_states(state)
    wq, habitat, es = (
        float(report["WQ"]),
        float(report["H"]),
        float(report["ES"]),
    )

    feedback_strength = exo["FEEDBACK_STRENGTH"] if mode.adaptive_feedback else 0.0
    # PRS与PR共同给出社会/生态风险来源的严格分解，避免关闭E→S时同时
    # 改写E→G，或关闭S→G时错误缩放整个总风险记忆。
    pre = float(np.clip((3.0 * pr - prs) / 2.0, 0.0, 1.0))
    feedback_shift = (
        feedback_strength
        * (
            (1.0 / 3.0)
            * ((prs - baseline["PRS"]) if mode.s_to_g else 0.0)
            + (2.0 / 3.0)
            * ((pre - baseline["PRE"]) if mode.e_to_g else 0.0)
        )
    )
    g_targets = np.clip(
        np.array(
            [
                exo["G1_TARGET"] + 0.13 * feedback_shift,
                exo["G2_TARGET"] + 0.17 * feedback_shift,
                exo["G3_TARGET"] + 0.21 * feedback_shift,
            ]
        ),
        0.01,
        0.99,
    )
    # G1-G3表示法律有效供给，只用短的数值平滑追踪年度目标；POLICY_TAU
    # 专门进入IM，避免政策生效延迟与执行延迟被重复施加。
    dg = (g_targets - state[:3]) / 0.18

    action_state = state.copy()
    if not mode.s_to_g:
        # 冻结社会压力与能力门控，仅关闭S→G的实施约束，不改变参数或外扰。
        action_state[3] = baseline["SP"]
        action_state[4] = baseline["SC"]
    operations_potential, _ = _implementation_potentials(
        action_state, exo, mode
    )
    dim = (
        operations_potential - im
    ) / max(exo["POLICY_TAU"], 0.25)
    a1, a2, a3, _, _ = _actions(action_state, exo, params, mode)
    nd = float(np.mean([exo["PPT"], exo["RUNOFF"], exo["SST"]]))
    compound = float(
        np.cbrt(max(exo["PPT"] * exo["RUNOFF"] * exo["SST"], 1e-9))
    )
    ecological_risk = float(
        ((1.0 - wq) + (1.0 - habitat)) / 2.0
    )
    risk = float((sp + 2.0 * ecological_risk) / 3.0)
    memory_tau = max(params["tau_risk"], 0.25)
    dpr = (risk - pr) / memory_tau
    dprs = (sp - prs) / memory_tau
    social_feedback_memory = (
        prs
        + 2.0 * (pre if mode.e_to_s else baseline["PRE"])
    ) / 3.0

    governance_to_social_a1 = (a1 - baseline["A1"]) if mode.g_to_s else 0.0
    governance_to_social_a3 = (a3 - baseline["A3"]) if mode.g_to_s else 0.0
    sp_signal = (
        logit(baseline["SP"])
        + params["k_pressure_feedback"]
        * (social_feedback_memory - baseline["PR"])
        + 0.30 * params["k_natural"] * (nd - baseline["ND"])
        + 0.25 * params["k_compound"] * (compound - baseline["COMPOUND"])
        - params["k_governance"] * governance_to_social_a1
        - 0.50 * params["k_adaptive"] * (sc - baseline["SC"])
    )
    sp_target = float(logistic(sp_signal))
    dsp = params["r_social"] * (sp_target - sp)

    sc_signal = (
        (params['alpha_AC'] if structure in ('M1_AC_INTERCEPT','M2_AC_SM_INTERCEPTS','M3_AC_SM_TF_INTERCEPTS') else logit(baseline["SC"]))
        + params["k_adaptive"] * governance_to_social_a3
        + 0.55
        * ((habitat - baseline["H"]) if mode.e_to_s else 0.0)
        - 0.78 * (sp - baseline["SP"])
        - 0.20 * params["k_compound"] * (compound - baseline["COMPOUND"])
    )
    sc_target = float(logistic(sc_signal))
    dsc = params["r_social"] * (sc_target - sc)

    ecology_sp = sp if mode.s_to_e else baseline["SP"]
    ecology_sc = sc if mode.s_to_e else baseline["SC"]
    nutrient_driver = 0.58 * ecology_sp + 0.42 * exo["RUNOFF"]
    governance_to_ecology_a1 = (a1 - baseline["A1"]) if mode.g_to_e else 0.0
    governance_to_ecology_a2 = (a2 - baseline["A2"]) if mode.g_to_e else 0.0
    ns_signal = (
        logit(baseline["NS"])
        + params["k_natural"]
        * (nutrient_driver - baseline["NUTRIENT_DRIVER"])
        + params["k_compound"] * (compound - baseline["COMPOUND"])
        - params["k_governance"] * governance_to_ecology_a1
    )
    ns_target = float(logistic(ns_signal))
    dns = params["r_water"] * (ns_target - ns)

    oxygen_driver = (
        0.34 * ecology_sp
        + 0.23 * exo["RUNOFF"]
        + 0.23 * bs
        + 0.20 * exo["SST"]
    )
    os_signal = (
        logit(baseline["OS"])
        + 0.82
        * params["k_natural"]
        * (oxygen_driver - baseline["OXYGEN_DRIVER"])
        + 0.52 * params["k_compound"] * (compound - baseline["COMPOUND"])
        - 0.78 * params["k_governance"] * governance_to_ecology_a1
    )
    os_target = float(logistic(os_signal))
    dos = params["r_water"] * (os_target - os_)

    bloom_trigger = (
        float(hill(ns, 0.48, 3.0))
        if mode.nonlinear_water
        else ns
    )
    bloom_driver = bloom_trigger * (
        0.50 * exo["SST"] + 0.30 * os_ + 0.20 * exo["RUNOFF"]
    )
    bs_signal = (
        logit(baseline["BS"])
        + params["k_bloom"] * (bloom_driver - baseline["BLOOM_DRIVER"])
        + 0.55 * params["k_compound"] * (compound - baseline["COMPOUND"])
        - 0.58 * params["k_governance"] * governance_to_ecology_a1
    )
    bs_target = float(logistic(bs_signal))
    dbs = params["r_water"] * (bs_target - bs)

    habitat_driver = 0.60 * ecology_sp + 0.40 * compound
    tf_signal = (
        (params['alpha_TF'] if structure=='M3_AC_SM_TF_INTERCEPTS' else logit(baseline["TF"]))
        + params["k_restore"] * governance_to_ecology_a2
        - params["k_natural"] * (habitat_driver - baseline["HABITAT_DRIVER"])
        + 0.22 * params["k_adaptive"] * (ecology_sc - baseline["SC"])
    )
    sm_signal = (
        (params['alpha_SM'] if structure in ('M2_AC_SM_INTERCEPTS','M3_AC_SM_TF_INTERCEPTS') else logit(baseline["SM"]))
        + 1.20 * params["k_restore"] * governance_to_ecology_a2
        - 0.82
        * params["k_natural"]
        * (habitat_driver - baseline["HABITAT_DRIVER"])
        + 0.30 * params["k_adaptive"] * (ecology_sc - baseline["SC"])
    )
    tf_target = float(logistic(tf_signal))
    sm_target = float(logistic(sm_signal))
    tf_rate = params["r_habitat"] * (
        1.70 if mode.asymmetric_habitat and tf_target < tf else 1.0
    )
    sm_rate = params["r_habitat"] * (
        1.55 if mode.asymmetric_habitat and sm_target < sm else 1.0
    )
    dtf = tf_rate * (tf_target - tf)
    dsm = sm_rate * (sm_target - sm)
    if mode.tf_sm_conversion:
        # TF和SM使用不同的冻结原始面积尺度。先以TF归一化单位定义转出，
        # 再按TF_scale/SM_scale换算SM归一化增量，使隐含km²面积守恒。
        # 该转换不守恒归一化指数和，也不代表碳储量守恒或新增碳储量。
        # 仅将有效生境行动中的一小部分解释为潮滩向盐沼转化；不再施加
        # 与治理无关的10%基础转化，也不允许年度转化率随G2跃升至70%。
        conversion_action = a2 if mode.g_to_e else baseline["A2"]
        conversion_rate = (
            mode.tf_sm_conversion_scale * float(conversion_action)
        )
        conversion_tf_units = conversion_rate * tf * (1.0 - sm)
        conversion_sm_units = (
            cfg.TF_TO_SM_AREA_SCALE_RATIO * conversion_tf_units
        )
        dtf -= conversion_tf_units
        dsm += conversion_sm_units

    derivative = np.array(
        [
            dg[0],
            dg[1],
            dg[2],
            dsp,
            dsc,
            dns,
            dos,
            dbs,
            dtf,
            dsm,
            dpr,
            dprs,
            dim,
        ],
        dtype=float,
    )
    # 数值积分越界时将导数推回不变域，避免用事后截断掩盖发散。
    derivative = np.where((raw_state <= 0.0) & (derivative < 0.0), 0.0, derivative)
    derivative = np.where((raw_state >= 1.0) & (derivative > 0.0), 0.0, derivative)
    return derivative

def simulate(
    params: np.ndarray | Mapping[str, float],
    forcing: AnnualForcing,
    times: np.ndarray,
    initial: np.ndarray,
    mode: ModelMode | None = None,
    aggregation: str = "geometric",
    max_step: float | None = None,
    method: str | None = None,
    rtol: float | None = None,
    atol: float | None = None,
    baseline_initial: np.ndarray | None = None,
    es_aggregation: str = "geometric",
    sr_aggregation: str = "geometric",
    structure: str = 'M0_RUN_SPECIFIC',
    reference_context: Mapping[str,float] | None = None,
) -> pd.DataFrame:
    mode = mode or ModelMode()
    p = parameter_dict(params,structure=structure)
    times = np.asarray(times, dtype=float)
    if times.ndim != 1 or len(times) < 2 or np.any(np.diff(times) <= 0):
        raise ValueError("输出时间必须为严格递增的一维数组。")
    first_forcing = forcing.at(float(times.min()))
    if structure=='M0_RUN_SPECIFIC':
        if reference_context is not None:raise ValueError('Run-specific control cannot accept fixed reference')
        reference_initial = initial if baseline_initial is None else baseline_initial
        baseline = _baseline_context(bounded(reference_initial),first_forcing,p,mode)
    else:
        if reference_context is None:raise ValueError(f'{structure} requires frozen training reference_context')
        if baseline_initial is not None:raise ValueError('Use reference_context, not baseline_initial')
        baseline={k:float(v) for k,v in reference_context.items()}
        if baseline.get('REFERENCE_YEAR')!=2011. or not np.isfinite(list(baseline.values())).all():
            raise ValueError('Invalid 2011 training reference_context')
    chosen_method = method or cfg.CALIBRATION_CONFIG["solver_method"]
    chosen_step = max_step or cfg.CALIBRATION_CONFIG["solver_max_step"]
    import os
    if chosen_method == 'RK4_FIXED' and os.environ.get('B1_SD_BACKEND','numba')=='numba':
        from fast_kernel import integrate,PARAMETER_KEYS,BASELINE_KEYS,MODE_KEYS,EXO_KEYS
        states=integrate(times,bounded(initial).astype(float),np.array([p.get(k,0.) for k in PARAMETER_KEYS]),
          np.array([baseline[k] for k in BASELINE_KEYS]),np.array([getattr(mode,k) for k in MODE_KEYS],float),structure,
          cfg.TF_TO_SM_AREA_SCALE_RATIO,forcing.years,forcing.frame[EXO_KEYS].to_numpy(float),chosen_step)
    elif chosen_method == "RK4_FIXED":
        current_time = float(times[0])
        current_state = bounded(initial).astype(float, copy=True)
        state_rows = [current_state.copy()]
        for target_time in times[1:]:
            interval = float(target_time - current_time)
            steps = max(1, int(np.ceil(interval / chosen_step)))
            step = interval / steps
            interval_start=current_time
            for step_index in range(steps):
                step_time=interval_start+step_index*step
                k1 = rhs(
                    step_time,
                    current_state,
                    p,
                    forcing,
                    baseline,
                    mode,
                    structure,
                )
                k2 = rhs(
                    step_time + 0.5 * step,
                    current_state + 0.5 * step * k1,
                    p,
                    forcing,
                    baseline,
                    mode,
                    structure,
                )
                k3 = rhs(
                    step_time + 0.5 * step,
                    current_state + 0.5 * step * k2,
                    p,
                    forcing,
                    baseline,
                    mode,
                    structure,
                )
                k4 = rhs(
                    step_time + step,
                    current_state + step * k3,
                    p,
                    forcing,
                    baseline,
                    mode,
                    structure,
                )
                current_state = current_state + (step / 6.0) * (
                    k1 + 2.0 * k2 + 2.0 * k3 + k4
                )
            current_time=float(target_time)
            state_rows.append(current_state.copy())
        states = np.vstack(state_rows)
    else:
        solution = solve_ivp(
            fun=lambda t, y: rhs(t, y, p, forcing, baseline, mode, structure),
            t_span=(float(times.min()), float(times.max())),
            y0=bounded(initial),
            t_eval=times,
            method=chosen_method,
            rtol=rtol or cfg.CALIBRATION_CONFIG["solver_rtol"],
            atol=atol or cfg.CALIBRATION_CONFIG["solver_atol"],
            max_step=chosen_step,
        )
        if not solution.success:
            raise RuntimeError(solution.message)
        states = solution.y.T
    if not np.isfinite(states).all():
        raise FloatingPointError("模拟产生NaN或Inf。")
    if (states < -1e-6).any() or (states > 1.000001).any():
        raise FloatingPointError("模拟状态超出不变域。")
    states = bounded(states)
    result = pd.DataFrame(states, columns=cfg.STATE_NAMES)
    result.insert(0, "year", times)
    derived = reporting_states(states, aggregation=aggregation, es_aggregation=es_aggregation, sr_aggregation=sr_aggregation)
    for name, values in derived.items():
        result[name] = values
    process_rows = []
    for time, state_row in zip(times, states):
        exo = forcing.at(float(time))
        action_state = state_row.copy()
        if not mode.s_to_g:
            action_state[3] = baseline["SP"]
            action_state[4] = baseline["SC"]
        implementation_potential, _ = _implementation_potentials(
            action_state,
            exo,
            mode,
        )
        a1, a2, a3, implementation, implementation_capacity = _actions(
            action_state,
            exo,
            p,
            mode,
        )
        report = reporting_states(state_row, aggregation=aggregation, es_aggregation=es_aggregation, sr_aggregation=sr_aggregation)
        pre_actual = float(
            np.clip(
                (3.0 * state_row[10] - state_row[11]) / 2.0,
                0.0,
                1.0,
            )
        )
        # RISK始终报告PR库存实际追踪的当期输入。E→S消融仅改变社会
        # 所感知的生态风险记忆，不应改写PR本身的诊断口径。
        risk = (
            state_row[3]
            + (1.0 - float(report["WQ"]))
            + (1.0 - float(report["H"]))
        ) / 3.0
        social_perceived_risk = (
            state_row[11]
            + 2.0 * (
                pre_actual if mode.e_to_s else baseline["PRE"]
            )
        ) / 3.0
        action_components = bounded(np.asarray([a1, a2, a3], dtype=float))
        process_rows.append(
            {
                "G": float(np.mean(state_row[:3])),
                "SYN": float(np.cbrt(max(np.prod(state_row[:3]), 0.0))),
                "I_eff": float(implementation),
                "I_cap": float(implementation_capacity),
                "I_pot": float(implementation_potential),
                "A1": float(a1),
                "A2": float(a2),
                "A3": float(a3),
                "GA": float(
                    np.exp(np.mean(np.log(action_components)))
                ),
                "RISK": float(risk),
                "SOCIAL_PERCEIVED_RISK": float(social_perceived_risk),
                "PRE": pre_actual,
            }
        )
    process = pd.DataFrame(process_rows)
    for column in process.columns:
        result[column] = process[column].to_numpy(float)
    result["SES"] = np.cbrt(
        bounded(result["GA"].to_numpy(float))
        * bounded(result["SR"].to_numpy(float))
        * bounded(result["ES"].to_numpy(float))
    )
    return result
