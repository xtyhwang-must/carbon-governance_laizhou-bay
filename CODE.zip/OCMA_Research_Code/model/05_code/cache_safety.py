"""Content-addressed, atomic chunk cache for independent OCMA repair runs."""
from __future__ import annotations
from pathlib import Path
import hashlib
import json
import os
import tempfile
import uuid
import pandas as pd

def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()

def signature(paths, parameters, *, code_version='B1_v1.0.0', root=None):
    """Hash all declared file contents and identity-changing scalar inputs."""
    base = Path(root).resolve() if root is not None else None
    paths=list(paths)
    if base is not None and (base/'05_code/engine/fast_kernel.py').exists():paths += [base/'05_code/engine/fast_kernel.py']
    files = {}
    for path in paths:
        resolved = Path(path).resolve()
        identity = resolved.relative_to(base).as_posix() if base is not None else str(resolved)
        files[identity] = sha256(resolved)
    material = {'files': files, 'parameters': parameters, 'code_version': code_version}
    key = hashlib.sha256(json.dumps(material, sort_keys=True, ensure_ascii=False,
                                    separators=(',', ':')).encode('utf-8')).hexdigest()
    return key, material

def atomic_json(path: Path, data):
    path = Path(path)
    if os.name=='nt' and not str(path).startswith('\\\\?\\'):path=Path('\\\\?\\'+str(path.resolve()))
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + f'.tmp.{uuid.uuid4().hex}')
    try:
        temporary.write_text(json.dumps(data, ensure_ascii=False, indent=2,
                                        sort_keys=True), encoding='utf-8')
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)

class ChunkCache:
    """A run generation becomes COMPLETE only after all chunks validate."""

    def __init__(self, base: Path, key: str, material: dict):
        self.path = Path(base) / f'run_{key}'
        if os.name=='nt' and not str(self.path).startswith('\\\\?\\'):self.path=Path('\\\\?\\'+str(self.path.resolve()))
        self.path.mkdir(parents=True, exist_ok=True)
        self.key = key
        self.material = material
        self.complete = self.path / 'COMPLETE.json'

    def chunk_paths(self, chunk_id):
        safe = str(chunk_id).replace('/', '_').replace('\\', '_')
        return self.path / f'chunk_{safe}.csv', self.path / f'chunk_{safe}.manifest.json'

    def load(self, chunk_id, expected_ids, required_columns):
        data_path, meta_path = self.chunk_paths(chunk_id)
        if not data_path.is_file() or not meta_path.is_file():
            return None
        try:
            meta = json.loads(meta_path.read_text(encoding='utf-8'))
            if meta['signature'] != self.key or meta['chunk_id'] != str(chunk_id) or meta.get('dependencies') != self.material:
                return None
            if meta['expected_ids'] != list(expected_ids) or sha256(data_path) != meta['sha256']:
                return None
            frame = pd.read_csv(data_path)
            if len(frame) != len(expected_ids) or not set(required_columns).issubset(frame):
                return None
            if frame['cache_row_id'].astype(str).tolist() != [str(x) for x in expected_ids]:
                return None
            return frame
        except (ValueError, KeyError, OSError, json.JSONDecodeError):
            return None

    def commit(self, chunk_id, frame, expected_ids, required_columns):
        expected = [str(x) for x in expected_ids]
        if len(frame) != len(expected) or not set(required_columns).issubset(frame):
            raise ValueError('Invalid chunk dimensions or columns')
        if frame['cache_row_id'].astype(str).tolist() != expected:
            raise ValueError('Chunk row identities differ from expected identities')
        data_path, meta_path = self.chunk_paths(chunk_id)
        temporary = data_path.with_name(data_path.name + f'.tmp.{uuid.uuid4().hex}')
        try:
            frame.to_csv(temporary, index=False, encoding='utf-8')
            staged = pd.read_csv(temporary)
            if len(staged) != len(expected) or staged['cache_row_id'].astype(str).tolist() != expected:
                raise ValueError('Staged chunk failed round-trip validation')
            os.replace(temporary, data_path)
            atomic_json(meta_path, {'signature': self.key, 'dependencies': self.material,
                                    'chunk_id': str(chunk_id),
                                    'expected_ids': expected, 'rows': len(frame),
                                    'sha256': sha256(data_path)})
        finally:
            temporary.unlink(missing_ok=True)

    def finalize(self, chunk_specs):
        """chunk_specs: iterable of (chunk_id, expected_ids, required_columns)."""
        verified = []
        for chunk_id, ids, columns in chunk_specs:
            value = self.load(chunk_id, ids, columns)
            if value is None:
                raise RuntimeError(f'Chunk {chunk_id} missing or invalid; not COMPLETE')
            verified.append(str(chunk_id))
        atomic_json(self.complete, {'signature': self.key, 'dependencies': self.material,
                                    'chunks': verified, 'status': 'COMPLETE'})
