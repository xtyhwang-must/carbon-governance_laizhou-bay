"""Same-input B1 retrospective evaluation, paired scenarios and factorial effects."""
from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import math
import os
import sys
from functools import lru_cache
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'05_code/engine'),str(ROOT/'05_code')]
import engine_config as cfg
import sd_model as model
from revised_core import validate_metric,observation_weights
from cache_safety import ChunkCache,signature,atomic_json

IN=ROOT/'03_indicators/model_input_B1.csv'
CAL=ROOT/'06_runs/B1_v1_1/calibration'
OUT=ROOT/'06_runs/B1_v1_1'
REG=ROOT/'04_model/scenario_registry.csv'
LEV=ROOT/'04_model/scenario_lever_audit.csv'
STOCK=ROOT/'02_policy/reconstructed/policy_stock_by_year_B1.csv'
CORE=['SP','SC','NS','OS','BS','TF','SM']
REPORT=CORE+['SR','WQ','H','ES']
MATCH=['parameter_set_id','forcing_draw_id','initial_state_hash']
FACTORS=['G1','G2','G3','eta','tau','feedback','synergy']

def sha_bytes(data):return hashlib.sha256(data).hexdigest()
def sha_file(path):return sha_bytes(Path(path).read_bytes())
def load():
    frame=pd.read_csv(IN).sort_values('year').reset_index(drop=True)
    assert frame.year.tolist()==list(range(2011,2024)) and frame.input_complete.all()
    ens=pd.read_csv(CAL/'accepted_parameter_ensemble.csv')
    if ens.empty:raise RuntimeError('No accepted parameter set under fixed gates')
    assert ens.parameter_set_id.is_unique and ens[cfg.PARAMETER_NAMES].notna().all().all()
    return frame,ens

def initialize(frame,year):return model.initial_state(frame,year=year)
def init_hash(initial):return sha_bytes(np.asarray(initial,float).tobytes())
def load_settings():
    audit=pd.read_csv(LEV)
    assert not audit.duplicated(['scenario_id','lever']).any()
    result={}
    for s,g in audit.groupby('scenario_id'):
        result[s]={r.lever:r.raw_future if r.lever in ['G1','G2','G3'] else r.model_future for r in g.itertuples(index=False)}
    assert set(result)==set('S'+str(i) for i in range(7))
    return result

def climate_path(frame, shock=True):
    rng=np.random.default_rng(20260725)
    history=frame[['PPT','RUNOFF','SST']].reset_index(drop=True)
    rows=[]
    while len(rows)<7:
        start=int(rng.integers(0,len(history)-2))
        rows.extend(history.iloc[start:start+3].to_dict('records'))
    path=pd.DataFrame(rows[:7]);path.insert(0,'year',np.arange(2024,2031))
    history=history.copy();history['COMPOUND']=(history.PPT*history.RUNOFF*history.SST)**(1/3)
    worst=history.nlargest(3,'COMPOUND')[['PPT','RUNOFF','SST']].to_numpy(float)
    if shock:
        for j,year in enumerate([2026,2027,2028]):
            path.loc[path.year.eq(year),['PPT','RUNOFF','SST']]=worst[j]
    return path

def cross_spec_one(args):
    pid,params,frame,settings,climates=args
    initial=initialize(frame,2023);rows=[]
    for spec,climate in climates.items():
        metrics={}
        for s in ['S4','S6']:
            forcing,_,_=scenario_forcing(frame,settings[s],climate)
            trajectory=model.simulate(params,forcing,np.arange(2023,2031,dtype=float),initial)
            metrics[s]=(float(trajectory.iloc[-1].ES),float(trajectory[trajectory.year.between(2026,2030)].ES.min()))
        rows.append({'parameter_set_id':pid,'forcing_spec':spec,'D_ES_2030':metrics['S4'][0]-metrics['S6'][0],
           'D_min_ES_2026_2030':metrics['S4'][1]-metrics['S6'][1],
           'tolerance_distinguishable':abs(metrics['S4'][0]-metrics['S6'][0])>5e-4})
    return rows

def projection_constants():
    stocks=pd.read_csv(STOCK)
    quant=pd.read_csv(ROOT/'02_policy/reconstructed/interface_quantiles_B1.csv').set_index('interface')
    result={}
    for ch in ['G1','G2','G3']:
        result[ch]=(float(stocks.loc[(stocks.year.eq(2023))&(stocks.channel.eq(ch)),'active_valid_policy_stock'].iloc[0]),
                    float(stocks.loc[(stocks.year.between(2021,2023))&(stocks.channel.eq(ch)),'new_effective_admissions'].median()),
                    float(quant.loc[ch,'P50']),float(quant.loc[ch,'P75']),
                    stocks.loc[stocks.year.between(2024,2030)&stocks.channel.eq(ch)].sort_values('year').active_valid_policy_stock.to_numpy(float))
    return result

def scenario_forcing(frame,setting,climate,projection=None):
    K=cfg.CONTRACT['policy']['K']
    future=climate.copy()
    constants=projection_constants() if projection is None else projection
    for ch in ['G1','G2','G3']:
        stock_2023,flow,q50,q75,registered_future=constants[ch]
        multiplier=1+.45*(setting[ch]-q50)/max(q75-q50,1e-9)
        # New hypothetical policy flow has no observed exit fact; no artificial expiry.
        raw=registered_future+np.arange(1,8)*flow*multiplier
        future[ch+'_TARGET']=raw/(raw+K[ch])
    future['ETA_POTENTIAL']=float(setting['eta'])
    future['POLICY_TAU']=float(setting['tau'])
    future['FEEDBACK_STRENGTH']=float(setting['feedback'])
    future['SYNERGY_LEVER']=float(setting['synergy'])
    last=frame.loc[frame.year.eq(2023)]
    if len(last)!=1:raise ValueError('Scenario requires exactly one 2023 input row')
    last=last.iloc[0]
    first={'year':2023,'G1_TARGET':last.G1,'G2_TARGET':last.G2,'G3_TARGET':last.G3,
           'PPT':last.PPT,'RUNOFF':last.RUNOFF,'SST':last.SST,'ETA_POTENTIAL':last.ETA_POTENTIAL,
           'POLICY_TAU':.5,'FEEDBACK_STRENGTH':0.,'SYNERGY_LEVER':last.SYNERGY_LEVER}
    forcing=pd.concat([pd.DataFrame([first]),future[list(first)]],ignore_index=True)
    return model.AnnualForcing(forcing),future,forcing

def one_scenario(args):
    pid,params,frame,settings,climate=args
    initial=initialize(frame,2023);ih=init_hash(initial)
    rows=[];metrics=[]
    for scenario,setting in settings.items():
        forcing,future,_=scenario_forcing(frame,setting,climate)
        result=model.simulate(params,forcing,np.arange(2023,2031,dtype=float),initial)
        result=result[result.year.ge(2024)].copy()
        result.insert(0,'initial_state_hash',ih);result.insert(0,'forcing_draw_id','CLIM_20260725_001')
        result.insert(0,'parameter_set_id',pid);result.insert(0,'scenario',scenario)
        rows.append(result)
        shock=result[result.year.between(2026,2030)]
        terminal=result[result.year.eq(2030)].iloc[0]
        metrics.append({'parameter_set_id':pid,'forcing_draw_id':'CLIM_20260725_001',
          'initial_state_hash':ih,'scenario':scenario,
          'min_ES_2026_2030':float(shock.ES.min()),'ES_2030':float(terminal.ES),
          'SR_2030':float(terminal.SR),'min_SR_2024_2030':float(result.SR.min()),
          'state_min':float(result[cfg.STATE_NAMES].min().min()),'state_max':float(result[cfg.STATE_NAMES].max().max()),
          'forcing_hash':sha_bytes(forcing.frame.to_csv(index=False).encode())})
    return pd.concat(rows,ignore_index=True),pd.DataFrame(metrics)

def evaluate_one(args):
    pid,params,frame=args
    prediction=model.simulate(params,model.historical_forcing(frame),frame.year.to_numpy(float),initialize(frame,2011))
    prediction.insert(0,'parameter_set_id',pid)
    held=frame[frame.year.ge(2021)]
    predict=prediction[prediction.year.ge(2021)]
    metrics=[]
    for state in CORE:
        for mode in ['weighted','exclude_estimated']:
            w=observation_weights(held.year,state,mode)
            d=validate_metric(held[state],predict[state],held.year,frame.loc[frame.year.le(2020),state],w)
            metrics.append({'parameter_set_id':pid,'state':state,'estimated_2023_treatment':mode,**d})
    return prediction,metrics

def evaluation():
    frame,ens=load();folder=OUT/'evaluation';folder.mkdir(parents=True,exist_ok=True)
    args=[(r.parameter_set_id,{n:float(getattr(r,n)) for n in cfg.PARAMETER_NAMES},frame) for r in ens.itertuples(index=False)]
    preds=[];metrics=[]
    with ProcessPoolExecutor(max_workers=4) as pool:
        futs=[pool.submit(evaluate_one,a) for a in args]
        for i,f in enumerate(as_completed(futs),1):
            p,m=f.result();preds.append(p);metrics.extend(m)
            if i%100==0 or i==len(futs):print(f'evaluation={i}/{len(futs)}',flush=True)
    pred=pd.concat(preds,ignore_index=True)
    pred.to_csv(folder/'historical_ensemble_trajectories.csv',index=False,encoding='utf-8-sig')
    metric_frame=pd.DataFrame(metrics)
    metric_frame.to_csv(folder/'holdout_state_metrics_by_parameter.csv',index=False,encoding='utf-8-sig')
    metric_frame.groupby(['state','estimated_2023_treatment'])[['MAE','RMSE','NRMSE']].median().reset_index().to_csv(
        folder/'holdout_state_summary.csv',index=False,encoding='utf-8-sig')
    env=pred.groupby('year')[CORE+['SR','WQ','H','ES']].quantile([.05,.5,.95]).unstack(-1)
    env.columns=[f'{a}_P{int(b*100)}' for a,b in env.columns]
    env.reset_index().to_csv(folder/'pure_parameter_envelope.csv',index=False,encoding='utf-8-sig')
    base=[]
    for s in CORE:
        obs=frame[s].to_numpy(float)
        for name,forecast in [('persistence',np.repeat(obs[9],3)),('training_linear_trend',obs[9]+np.arange(1,4)*(obs[9]-obs[0])/9)]:
            d=validate_metric(obs[10:13],forecast,frame.year.to_numpy()[10:13],obs[:10],
                              observation_weights(frame.year.to_numpy()[10:13],s,'weighted'))
            base.append({'benchmark':name,'state':s,**d})
    pd.DataFrame(base).to_csv(folder/'simple_baselines.csv',index=False,encoding='utf-8-sig')
    residual_sigma={}
    for s in CORE:
        train=pred[pred.year.le(2020)].merge(frame[['year',s]],on='year',suffixes=('_pred','_obs'))
        residual_sigma[s]=float(np.std((train[s+'_obs']-train[s+'_pred']).to_numpy(float),ddof=1))
    # State-specific residual extensions are separately labelled, not pure parameter intervals.
    expanded=env.reset_index().copy()
    for s in CORE:
        expanded[s+'_residual_P5']=np.clip(expanded[s+'_P5']-1.645*residual_sigma[s],0,1)
        expanded[s+'_residual_P95']=np.clip(expanded[s+'_P95']+1.645*residual_sigma[s],0,1)
    expanded.to_csv(folder/'residual_extended_envelope_separate.csv',index=False,encoding='utf-8-sig')
    coverage=[]
    joined=expanded.merge(frame[['year']+CORE],on='year',validate='one_to_one')
    for s in CORE:
        for treatment in ['weighted','exclude_estimated']:
            held=joined[joined.year.ge(2021)].copy()
            weights=observation_weights(held.year,s,treatment)
            for kind,lo,hi in [('pure_parameter',s+'_P5',s+'_P95'),
                               ('residual_extended_separate',s+'_residual_P5',s+'_residual_P95')]:
                hit=held[s].between(held[lo],held[hi],inclusive='both').to_numpy(float)
                valid=weights>0
                coverage.append({'state':s,'interval_kind':kind,'estimated_2023_treatment':treatment,
                    'n_years':int(valid.sum()),'weighted_coverage':float(np.average(hit[valid],weights=weights[valid])),
                    'predictive_reliability_established':False})
    pd.DataFrame(coverage).to_csv(folder/'holdout_coverage.csv',index=False,encoding='utf-8-sig')
    atomic_json(folder/'evaluation_status.json',{'complete':True,'parameter_sets':len(ens),'holdout_years':[2021,2022,2023],
        'residual_extension_sigma_by_state':residual_sigma,'pure_parameter_envelope_is_predictive_interval':False,
        '2023_habitat_weight':.35,'input_sha256':sha_file(IN),
        'ensemble_sha256':sha_file(CAL/'accepted_parameter_ensemble.csv'),
        'model_code_sha256':sha_file(ROOT/'05_code/engine/sd_model.py'),
        'analysis_code_sha256':sha_file(Path(__file__)),
        'protocol_id':'B1_TRAIN_P95_P5_HOLDOUT_WEIGHTED_V1',
        'author_review_status':'PENDING'})

def scenarios():
    frame,ens=load();folder=OUT/'scenarios';folder.mkdir(parents=True,exist_ok=True)
    settings=load_settings();climate=climate_path(frame)
    climate.to_csv(folder/'common_climate_draw_001.csv',index=False,encoding='utf-8-sig')
    initial=initialize(frame,2023);(folder/'initial_state_2023.json').write_text(json.dumps(dict(zip(cfg.STATE_NAMES,map(float,initial))),indent=2),encoding='utf-8')
    # Every chunk is keyed to actual vectors and every forcing dependency.
    files=[IN,CAL/'accepted_parameter_ensemble.csv',REG,LEV,STOCK,ROOT/'02_policy/reconstructed/interface_quantiles_B1.csv',
        ROOT/'00_contract/baseline_contract.yaml',ROOT/'05_code/engine/sd_model.py',Path(__file__),folder/'common_climate_draw_001.csv']
    key,material=signature(files,{'parameter_vectors':ens[cfg.PARAMETER_NAMES].to_numpy(float).tolist(),
        'initial_state':initial.tolist(),'forcing_draw_count':1,'scenario_ids':sorted(settings),
        'integration_step':.05},code_version=cfg.CONTRACT['version'],root=ROOT)
    cache=ChunkCache(folder/'cache',key,material)
    tasks=[];specs=[]
    for r in ens.itertuples(index=False):
        pid=r.parameter_set_id;params={n:float(getattr(r,n)) for n in cfg.PARAMETER_NAMES}
        ids=[f'{pid}:{s}:{y}' for s in sorted(settings) for y in range(2024,2031)]
        chunk=cache.load(pid,ids,['cache_row_id','scenario','ES','SR','year'])
        specs.append((pid,ids,['cache_row_id','scenario','ES','SR','year']))
        if chunk is None:tasks.append((pid,params,frame,settings,climate))
    with ProcessPoolExecutor(max_workers=4) as pool:
        futures=[pool.submit(one_scenario,t) for t in tasks]
        for i,f in enumerate(as_completed(futures),1):
            trajectory,metrics=f.result();pid=trajectory.parameter_set_id.iloc[0]
            trajectory=trajectory.sort_values(['scenario','year']).reset_index(drop=True)
            trajectory.insert(0,'cache_row_id',[f'{pid}:{s}:{int(y)}' for s,y in zip(trajectory.scenario,trajectory.year)])
            ids=next(x[1] for x in specs if x[0]==pid)
            cache.commit(pid,trajectory,ids,['cache_row_id','scenario','ES','SR','year'])
            if i%50==0 or i==len(futures):print(f'scenario chunks={i}/{len(futures)}',flush=True)
    cache.finalize(specs)
    trajectories=pd.concat([cache.load(pid,ids,cols) for pid,ids,cols in specs],ignore_index=True)
    trajectories.to_csv(folder/'scenario_trajectories_long.csv',index=False,encoding='utf-8-sig')
    metric=[]
    for keys,g in trajectories.groupby(MATCH+['scenario']):
        g=g.sort_values('year');shock=g[g.year.between(2026,2030)];end=g[g.year.eq(2030)].iloc[0]
        metric.append(dict(zip(MATCH+['scenario'],keys))|{'min_ES_2026_2030':shock.ES.min(),'ES_2030':end.ES,
            'SR_2030':end.SR,'min_SR_2024_2030':g.SR.min(),'state_min':g[cfg.STATE_NAMES].min().min(),
            'state_max':g[cfg.STATE_NAMES].max().max()})
    metrics=pd.DataFrame(metric);metrics.to_csv(folder/'scenario_metrics_by_parameter.csv',index=False,encoding='utf-8-sig')
    pairs=[]
    for a,b in [('S4','S0'),('S6','S0'),('S4','S6'),('S5','S0')]:
        ga=metrics[metrics.scenario.eq(a)].drop(columns='scenario');gb=metrics[metrics.scenario.eq(b)].drop(columns='scenario')
        match=ga.merge(gb,on=MATCH,validate='one_to_one',suffixes=('_a','_b'))
        assert len(match)==len(ens)
        for r in match.itertuples(index=False):
            row={k:getattr(r,k) for k in MATCH}|{'contrast':a+'-'+b}
            for k in ['min_ES_2026_2030','ES_2030','SR_2030','min_SR_2024_2030']:
                row['D_'+k]=getattr(r,k+'_a')-getattr(r,k+'_b')
            pairs.append(row)
    paired=pd.DataFrame(pairs);paired.to_csv(folder/'paired_differences.csv',index=False,encoding='utf-8-sig')
    paired.groupby('contrast')[[x for x in paired if x.startswith('D_')]].agg(['median',lambda x:x.quantile(.05),lambda x:x.quantile(.95)]).to_csv(folder/'paired_summary.csv',encoding='utf-8-sig')
    spec_sample=ens if len(ens)<=30 else ens.sample(n=30,random_state=20261032)
    climates={'primary_compound':climate,'same_blocks_no_compound':climate_path(frame,shock=False)}
    cross=[]
    with ProcessPoolExecutor(max_workers=4) as pool:
        futures=[pool.submit(cross_spec_one,(r.parameter_set_id,{n:float(getattr(r,n)) for n in cfg.PARAMETER_NAMES},frame,settings,climates)) for r in spec_sample.itertuples(index=False)]
        for f in as_completed(futures):cross.extend(f.result())
    cross=pd.DataFrame(cross)
    cross.to_csv(folder/'cross_spec_robustness.csv',index=False,encoding='utf-8-sig')
    cross_pivot=cross.pivot(index='parameter_set_id',columns='forcing_spec',values='D_ES_2030')
    both_positive=float(((cross_pivot['primary_compound']>0)&(cross_pivot['same_blocks_no_compound']>0)).mean())
    summary=metrics.groupby('scenario')[['min_ES_2026_2030','ES_2030','SR_2030','min_SR_2024_2030']].agg(['median',lambda x:x.quantile(.05),lambda x:x.quantile(.95)])
    summary.columns=[a+'_'+b for a,b in summary.columns]
    summary.reset_index().to_csv(folder/'scenario_summary.csv',index=False,encoding='utf-8-sig')
    ranks=metrics.groupby('scenario').ES_2030.median().sort_values(ascending=False)
    ranking=[]
    for position,(scenario,value) in enumerate(ranks.items(),1):
        ranking.append({'scenario':scenario,'strict_median_ES2030_rank':position,'median_ES2030':value,
          'tolerance_ES':5e-4,'S4_minus_S6_fraction_above_tolerance':float((paired.loc[paired.contrast.eq('S4-S6'),'D_ES_2030']>5e-4).mean()),
          'cross_spec_robustness':'S4_vs_S6_compound_vs_no_compound_30_parameter_subset',
          'S4_above_S6_in_both_specs_fraction':both_positive})
    pd.DataFrame(ranking).to_csv(folder/'ranking_evidence.csv',index=False,encoding='utf-8-sig')
    social=metrics[MATCH+['scenario','min_SR_2024_2030']].copy()
    s0=social[social.scenario.eq('S0')][MATCH+['min_SR_2024_2030']].rename(columns={'min_SR_2024_2030':'S0_min_SR'})
    social=social.merge(s0,on=MATCH,validate='many_to_one');social['passes_S0_min_SR']=social.min_SR_2024_2030.ge(social.S0_min_SR)
    social.to_csv(folder/'social_screen.csv',index=False,encoding='utf-8-sig')
    pd.DataFrame([{'year':year,'scenario':s,**{ch:float(scenario_forcing(frame,settings[s],climate)[1].loc[lambda d:d.year.eq(year),ch+'_TARGET'].iloc[0]) for ch in ['G1','G2','G3']}} for s in sorted(settings) for year in range(2024,2031)]).to_csv(folder/'governance_projection.csv',index=False,encoding='utf-8-sig')
    atomic_json(folder/'scenario_status.json',{'complete':True,'parameter_draws':len(ens),'climate_draws':1,'paired_scenarios':7,
      'matched_cells':len(metrics),'cross_spec_parameter_sets':len(spec_sample),
      'S4_above_S6_both_climate_specs_fraction':both_positive,
      'cache_signature':key,'input_sha256':sha_file(IN),
      'ensemble_sha256':sha_file(CAL/'accepted_parameter_ensemble.csv'),
      'climate_sha256':sha_file(folder/'common_climate_draw_001.csv'),
      'initial_state_hash':init_hash(initial),'model_code_sha256':sha_file(ROOT/'05_code/engine/sd_model.py'),
      'analysis_code_sha256':sha_file(Path(__file__)),
      'protocol_id':'B1_PAIRED_S0_S6_COMMON_CLIMATE_001',
      'author_review_status':'PENDING'})

def factorial_one(args):
    pid,params,frame,climate,start,end,factors=args
    initial=initialize(frame,2023);base=load_settings()[start];target=load_settings()[end]
    values={};rows=[]
    for mask in range(1<<len(factors)):
        setting=base.copy()
        for j,factor in enumerate(factors):
            if mask&(1<<j):setting[factor]=target[factor]
        forcing,_,_=scenario_forcing(frame,setting,climate)
        result=model.simulate(params,forcing,np.arange(2023,2031,dtype=float),initial)
        shock=result[result.year.between(2026,2030)]
        values[mask]={'ES_2030':float(result.iloc[-1].ES),'min_ES_2026_2030':float(shock.ES.min()),
                      'SR_2030':float(result.iloc[-1].SR)}
    for metric in ['ES_2030','min_ES_2026_2030','SR_2030']:
        total=values[(1<<len(factors))-1][metric]-values[0][metric]
        shapley={}
        for j,factor in enumerate(factors):
            contribution=0.
            for mask in range(1<<len(factors)):
                if mask&(1<<j):continue
                k=mask.bit_count();weight=1/(len(factors)*math.comb(len(factors)-1,k))
                contribution+=weight*(values[mask|(1<<j)][metric]-values[mask][metric])
            shapley[factor]=contribution
            rows.append({'parameter_set_id':pid,'forcing_draw_id':'CLIM_20260725_001','initial_state_hash':init_hash(initial),
               'comparison':end+'-'+start,'metric':metric,'factor':factor,'shapley':contribution,'total_paired_difference':total,
               'endpoint_base':values[0][metric],'endpoint_target':values[(1<<len(factors))-1][metric]})
        if abs(sum(shapley.values())-total)>1e-10:raise AssertionError('Shapley closure')
    return rows

def attribution():
    frame,ens=load();folder=OUT/'attribution';folder.mkdir(parents=True,exist_ok=True)
    scenario_metrics=pd.read_csv(OUT/'scenarios/scenario_metrics_by_parameter.csv')
    climate=pd.read_csv(OUT/'scenarios/common_climate_draw_001.csv')
    # A deterministic stratified sample of the accepted set bounds factorial compute.
    chosen=ens if len(ens)<=30 else ens.sample(n=30,random_state=20261031)
    comparisons=[('S0','S4',FACTORS),('S6','S4',['G3','tau','feedback'])]
    tasks=[]
    for start,end,factors in comparisons:
        for r in chosen.itertuples(index=False):
            tasks.append((r.parameter_set_id,{n:float(getattr(r,n)) for n in cfg.PARAMETER_NAMES},frame,climate,start,end,factors))
    rows=[]
    with ProcessPoolExecutor(max_workers=4) as pool:
        futures=[pool.submit(factorial_one,t) for t in tasks]
        for i,f in enumerate(as_completed(futures),1):
            rows.extend(f.result())
            if i%10==0 or i==len(futures):print(f'factorial cells={i}/{len(futures)}',flush=True)
    detail=pd.DataFrame(rows)
    # Endpoint identity must match main scenarios for each exact parameter/forcing/initial tuple.
    for (pid,comp,metric),g in detail.groupby(['parameter_set_id','comparison','metric']):
        end,start=comp.split('-')
        main=scenario_metrics[(scenario_metrics.parameter_set_id.eq(pid))&(scenario_metrics.scenario.isin([start,end]))].set_index('scenario')
        assert len(main)==2
        for field,scenario in [('endpoint_base',start),('endpoint_target',end)]:
            if abs(float(g[field].iloc[0])-float(main.loc[scenario,metric]))>1e-10:raise AssertionError('factorial endpoint mismatch')
        if abs(g.shapley.sum()-g.total_paired_difference.iloc[0])>1e-10:raise AssertionError('factorial closure')
    detail.to_csv(folder/'matched_shapley_by_parameter.csv',index=False,encoding='utf-8-sig')
    detail.groupby(['comparison','metric','factor']).shapley.agg(['median',lambda x:x.quantile(.05),lambda x:x.quantile(.95)]).reset_index().to_csv(folder/'shapley_summary.csv',index=False,encoding='utf-8-sig')
    atomic_json(folder/'attribution_status.json',{'complete':True,'parameter_sets':len(chosen),'climate_draws':1,
       'comparisons':['S4-S0','S4-S6'],'all_endpoints_match_main':True,'closure_tolerance':1e-10,
       'input_sha256':sha_file(IN),'ensemble_sha256':sha_file(CAL/'accepted_parameter_ensemble.csv'),
       'climate_sha256':sha_file(OUT/'scenarios/common_climate_draw_001.csv'),
       'model_code_sha256':sha_file(ROOT/'05_code/engine/sd_model.py'),
       'analysis_code_sha256':sha_file(Path(__file__)),
       'protocol_id':'B1_MATCHED_FACTORIAL_SHAPLEY_V1',
       'author_review_status':'PENDING'})

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('stage',choices=['evaluate','scenarios','attribution'])
    stage=parser.parse_args().stage
    {'evaluate':evaluation,'scenarios':scenarios,'attribution':attribution}[stage]()
