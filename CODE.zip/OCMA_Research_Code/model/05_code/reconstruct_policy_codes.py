"""Rule-assisted, source-anchored RULE_ASSISTED reconstruction of the 68-policy corpus.

These are new analytic codes, not recovered human codes or author validation.
The decisions use target/action co-occurrence and bounded heading context; no
old machine G/T labels or manuscript result targets are read here.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import re

import pandas as pd

ROOT=Path(__file__).resolve().parents[1]
POL=ROOT/'02_policy/reconstructed'
VERSION='B1_RULE_ASSISTED_CONTEXTUAL_OBJECT_ACTION_V1'

OBJECTS={
 'G1':['入海排污口','近岸海域','陆源污染','海洋污染','水污染','排污口','污水','废水','养殖尾水','养殖污染','农业面源','化肥','畜禽养殖','污染物','污染源','围填海','海岸带开发','岸线开发','海洋垃圾','船舶污染','海水水质','水环境质量','河流入海','海湾水质','海域生态环境'],
 'G2':['滨海湿地','海岸湿地','盐沼','潮滩','滩涂','海草床','红树林','自然岸线','岸线保护','海岸带','海岛生态','海洋生态','海域生态','栖息地','湿地','生态保护红线','自然保护地','海岸侵蚀','生境','海洋牧场','海洋碳汇','蓝碳'],
 'G3':['海洋环境监测','近岸海域监测','海水水质监测','海域监测','海洋监测','海岸带监测','入海排污口监测','海洋生态监测','海洋灾害预警','海洋信息','海域信息','海岸带信息','协同治理','联合监管','部门协调','信息共享','监测预警','风险预警','监测网络','海洋环境应急'],
}
MARINE_CONTEXT=['海洋','海域','近岸','滨海','海岸','渤海','莱州湾','潮滩','滩涂','盐沼','海岛','海湾','水产养殖','海水养殖','渔业','入海']
ACTION=['应当','负责','加强','完善','建立','开展','实施','推进','整改','防治','控制','修复','保护','监测','预警','应急','处置','治理','减少','削减','禁止','限制','监管','督察','考核','问责','制定','建设','实行','落实','组织','推动','指导','排查','整治','清理','审批','许可','评估','调查','保障','严禁','不得','必须','会同','协同','联合','设置','划定','恢复','维护','完成','加快','规范','确定','加强对']
FUNCTION_ACTION={
 'G1':['控制','治理','防治','减少','削减','排查','整治','清理','禁止','限制','监管','审批','达标','处理','减量','规范','严格','不得','严禁','收集','处置'],
 'G2':['保护','修复','恢复','维护','建设','划定','管控','禁止','限制','治理','整治','实施','规划','建立','保育','禁止侵占'],
 'G3':['监测','预警','评估','调查','普查','信息','数据','协调','联合','协同','联动','共享','应急','督察','检查','考核','建立','完善','监管','发布','通报'],
}
INSTRUMENTS={
 'T1':['禁止','不得','必须','应当','审批','许可','严格','查处','处罚','标准','执法','管控','条例','监督','监管','限制','严禁','考核','问责'],
 'T2':['资金','财政','补贴','补助','生态补偿','税收','奖补','投入','奖励','基金','融资','专项经费'],
 'T3':['工程','建设','设施','修复','整治','处理厂','排污管网','项目实施','生态廊道'],
 'T4':['监测','预警','评估','公报','信息','调查','普查','监控','数据','统计','通报','报告','预测'],
 'T5':['联合','会同','协调','协同','牵头','部门','联动','共享','统筹','跨区域','合作'],
 'T6':['公众','社会组织','社区','参与','志愿','征求意见','听证','举报','宣传教育','居民'],
}
NAV=['首页','当前位置','热门搜索','[打印]','字号:','免责声明','网站导航','友情链接','ICP备','目录................................']

def matches(text,terms):
    return [term for term in terms if term in text]

def is_heading(text):
    return len(text)<100 and bool(re.match(r'^(?:第[一二三四五六七八九十百]+[章节]|[一二三四五六七八九十]+[、.．]|[（(][一二三四五六七八九十]+[）)]|附[件录])',text))

def decision(text,heading,title,local_marine):
    compact=re.sub(r'\s+','',text)
    if len(compact)<8 or not re.search(r'[\u4e00-\u9fff]',compact):
        return False,{}, {},'TOO_SHORT_OR_NON_CHINESE','NONE',[]
    if any(x in compact for x in NAV) or re.search(r'\.{4,}|…{3,}',compact) or re.match(r'^(?:目录|目\s*录|附图\d+|第\d+页|[—-]\d+[—-])',compact):
        return False,{}, {},'NAV_OR_TOC','NONE',[]
    if is_heading(compact):
        return False,{}, {},'HEADING_CONTEXT_ONLY','NONE',[]
    if re.match(r'^[《«][^。；;]{0,110}[》»](?:[（(]?\d{4}年[^。；;]*)?$',compact):
        return False,{}, {},'CITED_DOCUMENT_TITLE_NOT_ACTION','NONE',[]
    if (compact.startswith(('为深入','为了','为更好','随着')) and
        not matches(compact,['应当','必须','不得','禁止','由市','由县','各部门要','各地要'])) or compact.endswith('具有重要意义。'):
        return False,{}, {},'BACKGROUND_OR_PURPOSE_NOT_DUTY','NONE',[]
    if re.match(r'^(?:【(?:发布日期|实施日期|发布部门|信息来源)|发文机关|文号|来源:|责任编辑)',compact):
        return False,{}, {},'METADATA_NOT_ACTION','NONE',[]
    if any(x in compact for x in ['本条例所称','本办法所称','是指']) and not any(x in compact for x in ['应当','禁止','负责','不得']):
        return False,{}, {},'DEFINITION_ONLY','NONE',[]
    action=matches(compact,ACTION)
    if not action:
        return False,{}, {},'NO_GOVERNANCE_ACTION','NONE',[]
    object_hits={g:matches(compact,terms) for g,terms in OBJECTS.items()}
    context_source='UNIT'
    strong_marine=bool(matches(compact,MARINE_CONTEXT))
    if not any(object_hits.values()):
        if heading and matches(heading,MARINE_CONTEXT):
            context_source='HEADING'
        else:
            return False,{}, {},'NO_RELEVANT_TARGET_OBJECT','NONE',[]
        object_hits={g:matches(heading+' '+title,terms) for g,terms in OBJECTS.items()}
    # Broader inland pollution words require a coastal policy context. They
    # otherwise risk turning generic air/industrial controls into bay actions.
    weak_g1={'污水','废水','化肥','污染物','污染源','水污染','农业面源','畜禽养殖'}
    if object_hits['G1'] and set(object_hits['G1']).issubset(weak_g1) and not (strong_marine or local_marine):
        object_hits['G1']=[]
    codes={}
    for g,objects in object_hits.items():
        if objects:
            hits=matches(compact,FUNCTION_ACTION[g])
            if hits or (context_source!='UNIT' and len(action)>=1):
                codes[g]=1
    if 'G2' in codes and not matches(compact,['保护','修复','恢复','维护','生态','禁止','限制','管控','保育','湿地','海草床','盐沼']):
        del codes['G2']
    # G3 requires a governance-information action, not mere text describing
    # an institution; a heading alone cannot supply that action.
    if 'G3' in codes and not matches(compact,FUNCTION_ACTION['G3']):
        del codes['G3']
    if not codes:
        return False,{}, {},'OBJECT_WITHOUT_MATCHED_FUNCTION_ACTION',context_source,action
    instruments={t:1 for t,terms in INSTRUMENTS.items() if matches(compact,terms)}
    if context_source!='UNIT':reason='CONTEXTUAL_OBJECT_'+context_source
    elif len(codes)>1:reason='MULTI_FUNCTION_EXPLICIT_ACTION'
    else:reason='DIRECT_OBJECT_AND_ACTION'
    return True,codes,instruments,reason,context_source,action

def main():
    units=pd.read_csv(POL/'text_units_B1.csv',keep_default_na=False)
    audit=pd.read_csv(POL/'text_source_audit.csv').set_index('policy_id')
    admission=pd.read_csv(ROOT/'01_sources/policy/admission_68.csv').set_index('policy_id')
    rows=[];heading=''
    for pid,group in units.groupby('policy_id',sort=False):
        heading=''
        title=str(admission.loc[pid,'政策标题'])
        local_marine=bool(matches(title,MARINE_CONTEXT)) or str(admission.loc[pid,'层级']) not in ['国家']
        for item in group.itertuples(index=False):
            text=str(item.exact_evidence_text)
            if is_heading(text):heading=text
            valid,g,t,reason,context,actions=decision(text,heading,title,local_marine)
            ambiguity='NONE'
            if valid and context!='UNIT':ambiguity='CONTEXTUAL_TARGET_REQUIRES_AUTHOR_REVIEW'
            elif valid and len(g)>1:ambiguity='MULTI_FUNCTION_REQUIRES_AUTHOR_REVIEW'
            original={'original_qualification':pd.NA}
            original.update({'original_'+name:pd.NA for name in [*OBJECTS,*INSTRUMENTS]})
            rows.append({**item._asdict(),**original,
                         'b1_qualified':bool(valid),
                         **{'b1_'+name:int(name in g) for name in OBJECTS},
                         **{'b1_'+name:int(name in t) for name in INSTRUMENTS},
                         'decision_reason':reason,
                         'matched_action_terms':'|'.join(actions[:12]),
                         'context_anchor':heading if context=='HEADING' else (title if context=='TITLE' else ''),
                         'coding_origin':'RULE_ASSISTED_SOURCE_RECONSTRUCTION',
                         'coding_rule_version':VERSION,
                         'ambiguity_status':ambiguity,
                         'alternative_qualified_if_context_unsupported':False if context!='UNIT' else pd.NA,
                         'author_review_status':'PENDING',
                         'source_body_status':'TARGET_TITLE_HEAD_PRESENT' if bool(audit.loc[pid,'title_head_present']) else 'TARGET_TITLE_VARIANT_NEEDS_REVIEW'})
    coded=pd.DataFrame(rows)
    assert coded.policy_id.nunique()==68 and coded.unit_id.is_unique
    assert coded['b1_qualified'].sum()>0
    assert coded.loc[~coded.b1_qualified,['b1_G1','b1_G2','b1_G3']].eq(0).all().all()
    # Verify every evidence excerpt equals its saved clean-text interval.
    for pid,g in coded.groupby('policy_id'):
        body=(ROOT/audit.loc[pid,'clean_text_relative_path']).read_text(encoding='utf-8')
        bad=g.apply(lambda x:body[int(x.clean_start):int(x.clean_end)]!=x.exact_evidence_text,axis=1)
        if bad.any():raise AssertionError(f'{pid}: {int(bad.sum())} invalid clean-text anchors')
    coded.to_csv(POL/'coded_clauses_B1.csv',index=False,encoding='utf-8-sig')
    counts=coded.loc[coded.b1_qualified].groupby('policy_id')[['b1_G1','b1_G2','b1_G3']].sum()
    shares=[]
    for pid in admission.index:
        values=counts.loc[pid] if pid in counts.index else pd.Series({'b1_G1':0,'b1_G2':0,'b1_G3':0})
        n=float(values.sum())
        shares.append({'policy_id':pid,'publication_year':int(admission.loc[pid,'publication_year']),
                       'qualified_action_units':int(coded.loc[coded.policy_id.eq(pid),'b1_qualified'].sum()),
                       'G_assignment_total':int(n),
                       **{g+'_share':float(values['b1_'+g]/n) if n>0 else 0.0 for g in OBJECTS},
                       'G0_no_observable_target_action':int(n==0),
                       'source_sha256':audit.loc[pid,'body_source_sha256'],
                       'coding_origin':'RULE_ASSISTED_SOURCE_RECONSTRUCTION','author_review_status':'PENDING'})
    pshare=pd.DataFrame(shares)
    assert len(pshare)==68 and (pshare[[g+'_share' for g in OBJECTS]].sum(axis=1).round(10).isin([0.0,1.0])).all()
    pshare.to_csv(POL/'policy_function_shares_B1.csv',index=False,encoding='utf-8-sig')
    summary=coded.groupby(['policy_id','decision_reason']).size().rename('units').reset_index()
    summary.to_csv(POL/'coding_reason_audit.csv',index=False,encoding='utf-8-sig')
    coded.loc[coded.b1_qualified,['policy_id','unit_id','source_location','exact_evidence_text','context_anchor','decision_reason','ambiguity_status']].to_csv(POL/'author_positive_evidence_index.csv',index=False,encoding='utf-8-sig')
    coded.loc[coded.ambiguity_status.ne('NONE'),['policy_id','unit_id','source_location','exact_evidence_text','decision_reason','ambiguity_status','alternative_qualified_if_context_unsupported']].to_csv(POL/'author_ambiguity_index.csv',index=False,encoding='utf-8-sig')
    print(json.dumps({'policies':68,'new_units':len(coded),'qualified_units':int(coded.b1_qualified.sum()),
                      'policies_with_G':int((pshare.G_assignment_total>0).sum()),
                      'ambiguous_units':int(coded.ambiguity_status.ne('NONE').sum())},ensure_ascii=False))

if __name__=='__main__':main()
