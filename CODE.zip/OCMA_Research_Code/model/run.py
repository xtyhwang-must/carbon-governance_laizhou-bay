"""Run a research calculation using input folders beside this script."""
import argparse
from pathlib import Path
import subprocess
import sys

STAGES = {'inputs': 'build_evidence.py', 'policy': 'part2_ht_bridge.py', 'ses': 'part2_ses.py', 'compare': 'compare_structures.py', 'calibrate': 'formal_calibration.py', 'evaluate': 'evaluation.py', 'scenarios': 'scenarios.py', 'attribution': 'attribution.py', 'mechanisms': 'mechanisms.py', 'surface': 'response_surface.py', 'robustness': 'robustness.py', 'figures': 'figures.py', 'indicator-figures': 'part2_figures.py', 'sensitivity': 'part2_additional_sensitivity.py'}

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--stage', choices=STAGES, required=True)
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    subprocess.run([sys.executable, str(root / '05_code' / STAGES[args.stage])], cwd=root, check=True)

if __name__ == '__main__':
    main()
