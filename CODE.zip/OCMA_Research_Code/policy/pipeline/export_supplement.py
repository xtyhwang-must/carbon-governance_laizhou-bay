"""Real immutable-source appendix export. Synthetic performance is prohibited."""
from common import *
from zipfile import ZipFile
import xml.etree.ElementTree as ET
import html

def export(ctx,out):
 require(ctx.identity=='REAL','SYNTHETIC_TEST_ONLY cannot enter formal supplement export')
 prep=ctx.artifact('prepare');reg=ctx.artifact('build-registry');ass=ctx.artifact('assemble-candidate');tr=ctx.artifact('train',required=False)
 cat=read(prep/'corpus.csv');human=read(reg/'registry_snapshot.csv');sample=read(prep/'linkage.csv');ev=read(ass/'field_evidence.csv');state=load(ass/'candidate_status.json')
 original=ctx.workspace/'00_reference/supplementary material.docx';require(original.exists(),'Actual supplement template missing')
 ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
 with ZipFile(original) as z:root=ET.fromstring(z.read('word/document.xml'))
 text='\n'.join(''.join(t.text or '' for t in p.findall('.//w:t',ns)) for p in root.findall('.//w:p',ns))
 tables=[int(x) for x in re.findall(r'Table\s+S(\d+)',text)];figures=[int(x) for x in re.findall(r'Fig(?:ure)?\.?\s+S(\d+)',text)]
 tn=max([6]+tables)+1;fn=max([5]+figures)+1
 style=root.find('.//w:tbl/w:tr',ns);(out/'reference_table_header_style.xml').write_text(ET.tostring(style,encoding='unicode'),encoding='utf-8')
 rows=[dict(section='Corpus',item='Candidate units',n=len(cat)),dict(section='Corpus',item='Policies',n=cat.policy_id.nunique()),dict(section='Human',item='Distinct reviewed units',n=len(human)),dict(section='Human',item='Current development view',n=int(human.training_allowed.eq('True').sum()))]
 rows += [dict(section='Human role',item=k,n=int(v)) for k,v in human.groupby('role').size().items()]
 rows += [dict(section='Existing 200 sample',item=k,n=int(v)) for k,v in sample.groupby('split').size().items()]
 rows += [dict(section='Field evidence (not independent reviews)',item=k,n=int(v)) for k,v in ev.groupby('status').size().items()]
 rows += [dict(section='Current candidate',item='Complete units',n=state['complete_rows']),dict(section='Current candidate',item='Unresolved units',n=state['total_rows']-state['complete_rows'])]
 for r in rows:r['status']='DRAFT_REAL_STATUS'
 csvout(out/f'Table_S{tn}A_DRAFT_REAL_STATUS.csv',rows)
 table=pd.DataFrame(rows).to_html(index=False,escape=True,border=0)
 (out/f'Table_S{tn}A_DRAFT_REAL_STATUS.html').write_text('<!doctype html><meta charset="utf-8"><title>Policy coding real status</title><style>body{font-family:"Times New Roman",serif;font-size:10.5pt;color:#1f2937;max-width:900px;margin:30px auto}table{border-collapse:collapse;width:100%;border-top:1pt solid #1f2937;border-bottom:1pt solid #1f2937}th{border-bottom:.5pt solid #1f2937;text-align:center}td,th{padding:5px 9px}td:last-child{font-size:9pt}h1{font-size:16pt}</style><h1>Policy coding real execution status</h1><p>DRAFT_REAL_STATUS. Not a final manuscript performance table. Field counts are not independent human reviews.</p>'+table,encoding='utf-8')
 mapping=[dict(item=f'Table S{tn}A',status='DRAFT_REAL_STATUS',file=f'Table_S{tn}A_DRAFT_REAL_STATUS.csv',scope='Real corpus and evidence composition')]
 if tr:
  lock=load(tr/'model_lock.json');require(lock['identity']=='REAL','Synthetic model rejected')
  for name,target in [('limited_development_results.csv',f'Table_S{tn}B_specifications.csv'),('development_metrics.csv',f'Table_S{tn}B_labelwise.csv')]:shutil.copyfile(tr/name,out/target)
  mapping.append(dict(item=f'Table S{tn}B',status='DEVELOPMENT_OOF_NOT_INDEPENDENT',file=f'Table_S{tn}B_labelwise.csv',scope='OOF thresholds and model selection share development data'))
 else:mapping.append(dict(item=f'Table S{tn}B',status='NOT_RUN',file='',scope='No real new training; no performance table generated'))
 auditrows=[]
 for key,path in ctx.audit_events():
  r=load(path/'audit_result.json');require(r['identity']=='REAL','Synthetic audit rejected')
  approvals=[q for _,q in ctx.accepted_pools() if (q/'audit_quality.json').exists() and (path/'audit_quality.json').exists() and sha(q/'audit_quality.json')==sha(path/'audit_quality.json')]
  r['accepted']=bool(approvals);r['accepted_auto_field_n']=len(read(approvals[0]/'accepted_fields.csv')) if approvals else 0
  auditrows.append(dict(event=key,**r))
 csvout(out/f'Table_S{tn}C_audit_status.csv',auditrows,columns=None if auditrows else ['event','identity','quality_pass','accepted','pool_n','audit_n'])
 mapping += [dict(item=f'Table S{tn}C',status='REAL_AUDIT_RESULTS' if auditrows else 'NOT_RUN',file=f'Table_S{tn}C_audit_status.csv',scope='Pool-scoped only; empty file means not run'),dict(item=f'Figure S{fn}',status='READY_FOR_REAL_INPUT' if tr else 'NOT_RUN',file='',scope='No synthetic precision/recall figure')]
 csvout(out/'table_figure_mapping.csv',mapping)
 (out/'figure_captions_EN.md').write_text(f'Figure S{fn}. Label-wise detection errors and precision/recall in the development OOF predictions. Conditional head and end-to-end results must be distinguished. OOF data used for threshold and specification selection are developmental; they do not establish whole-corpus accuracy. Rare-label support and abstentions are reported.\n\nCurrent status: '+('REAL_TRAINING_AVAILABLE' if tr else 'NOT_RUN — no real new training; no figure exported.')+'\n',encoding='utf-8')
 shutil.copyfile(ctx.code/'plot_s6.py',out/'plot_s6.py')
 jsonout(out/'supplement_manifest.json',dict(identity='REAL',status='DRAFT_REAL_STATUS',source_template=str(original),source_template_sha256=sha(original),existing_table_numbers=tables,existing_figure_numbers=figures,numbering_note='S7 and S6 are unused in the checked reference; reserve requested figure number 6, no overwrite',registry_sha256=sha(reg/'registry_snapshot.csv'),candidate_sha256=sha(ass/'C2_candidate.csv'),model_sha256=sha(tr/'diagnostic_model.joblib') if tr else None,real_training_artifact=str(tr) if tr else None,files=filelist(out),synthetic_performance_used=False,formal_manuscript_ready=False))
