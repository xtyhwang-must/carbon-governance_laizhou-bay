"""Real human events, immutable registry snapshots and scoped source/rule/action decisions."""
from common import *
import math
from scipy.stats import t

def baseline_event(row,label,codebook_hash,identity):
 value=str(row['human_'+label])
 e=dict(unit_id=row['unit_id'],field=label,value=value,batch_id=row.get('batch_id','BASELINE'),reviewer=row.get('reviewer',''),review_time=row.get('review_time',''),source_file_sha256=row.get('original_workbook_sha256',''),signature_sha256=row.get('signature_sha256',''),source_hash=row['source_hash'],rule_version=codebook_hash,role=row['role'],split=row['split'],import_result='VALID_BASELINE_RECONCILED',identity=identity,correction_of='',original_evidence=row.get('evidence_record_sha256',''))
 e['event_id']=digest(e);return e

def prepare(ctx,out):
 cfg=ctx.cfg;corpus=read(ctx.input('corpus'));human=read(ctx.input('human'));sample=read(ctx.input('sample'));link=read(ctx.input('linkage'))
 require(corpus.unit_id.is_unique and human.unit_id.is_unique and sample.unit_id.is_unique,'Duplicate original IDs')
 require(set(human.unit_id)<=set(corpus.unit_id) and set(sample.unit_id)<=set(corpus.unit_id),'Original scope mismatch')
 require(not set(sample.unit_id)&set(human.unit_id),'Audit sample overlaps completed original reviews')
 require(set(sample.unit_id)==set(link.unit_id),'Audit sample/linkage identity mismatch')
 require(not cfg['part2_enabled'],'SD disabled')
 if 'frozen_manifest' in cfg['inputs']:
  originals=out/'baseline_original_evidence';originals.mkdir();shutil.copyfile(ctx.input('frozen_manifest'),out/'frozen_source_index.json')
  for r in load(ctx.input('frozen_manifest')):
   p=ctx.workspace/'05_revision_work/R1_20261026/01_coding'/r['path']
   require(p.is_file() and sha(p)==r['sha256'],'Frozen evidence changed: '+str(p))
   if p.suffix.lower()=='.xlsx' or p.name.startswith('author_chat_amendments'):shutil.copyfile(p,originals/(r['sha256'][:8]+'_'+p.name))
 # Actual source bytes, not title similarity, establish the existence/version check.
 checks=[]
 for r in corpus.drop_duplicates('source_clean_path').itertuples():
  p=Path(r.source_clean_path);exists=p.is_file();actual=sha(p) if exists else ''
  require(exists and actual==r.source_clean_sha256,'Missing/changed actual policy source: '+r.policy_id)
  text=p.read_text(encoding='utf-8-sig')
  checks.append(dict(policy_id=r.policy_id,source_path=str(p),expected_sha256=r.source_clean_sha256,actual_sha256=actual,bytes_verified=True,source_identity='ACTUAL_SOURCE_BYTES_NOT_AUTHOR_SEMANTIC_APPROVAL'))
 csvout(out/'source_checks.csv',checks)
 for k,n in [('corpus','corpus.csv'),('human','baseline_human.csv'),('sample','sample.csv'),('linkage','linkage.csv'),('v3_scores','v3_scores.csv'),('v3_lock','v3_lock.json'),('codebook','codebook.md'),('contract','training_contract.json'),('reference_ids','reference_ids.csv')]:
  shutil.copyfile(ctx.input(k),out/n)
 for k in ['source_cards','rule_cards','group_proposals','amendments']:
  if k in cfg['inputs']:shutil.copyfile(ctx.input(k),out/(k+ctx.input(k).suffix))
 execution_contract=load(out/'training_contract.json');execution_contract['diagnostic_fallback']='If all fail, retain maximum diagnostic end-to-end macroF1; tie H-BAL,H-UNBAL,H-ALLDOMAIN then C=1; never deployment';execution_contract['scope_exclusion']='Unresolved source/rule IDs excluded only within their scope';jsonout(out/'training_contract.json',execution_contract)
 lock=load(out/'v3_lock.json')
 require(sha(out/'v3_scores.csv')==lock['predictions_sha256'],'Frozen V3 score file hash mismatch')
 events=[baseline_event(r,k,sha(out/'codebook.md'),ctx.identity) for r in human.to_dict('records') for k in LABELS]
 csvout(out/'human_review_events.csv',events)
 from issue_scope import build_issue_scope
 build_issue_scope(ctx,out,corpus)
 # Editable proposal templates contain no automatic signature or label approval.
 proposals=[]
 if (out/'source_cards.csv').exists():
  for r in read(out/'source_cards.csv').itertuples():
   ids=corpus.loc[corpus.policy_id.eq(r.policy_id),'unit_id'].tolist()
   proposals.append(dict(decision_id='SOURCE_'+r.policy_id,type='SOURCE_VERSION',unit_ids=json.dumps(ids),value='',rule_text='',action_unit_id='',representative_id='',scope_sha256=digest(sorted(ids)),source_binding=digest(corpus[corpus.unit_id.isin(ids)][['unit_id','source_hash','source_clean_sha256']].sort_values('unit_id').to_dict('records')),recommendation='CHECK_EXACT_TARGET_VERSION; BYTE_HASH_VERIFIED; TITLE_VARIANT_ALONE_NOT_ERROR',basis='source_checks.csv and original source_version_cards',status='PROPOSAL_ONLY'))
 if (out/'rule_cards.csv').exists():
  for r in read(out/'rule_cards.csv').itertuples():
   ids=[r.unit_id];proposals.append(dict(decision_id=r.card_id,type='SEMANTIC_RULE',unit_ids=json.dumps(ids),value='',rule_text='',action_unit_id='',representative_id='',scope_sha256=digest(ids),source_binding=scope_binding(corpus,ids),recommendation=r.suggested_interpretation,basis='rule_cards.csv; existing human judgment retained',status='PROPOSAL_ONLY'))
 if (out/'group_proposals.csv').exists():
  for gid,g in read(out/'group_proposals.csv').groupby('equivalence_group_id_v4'):
   ids=sorted(g.unit_id);proposals.append(dict(decision_id='GROUP_'+gid,type='EXACT_GROUP_SCOPE',unit_ids=json.dumps(ids),value='',rule_text='',action_unit_id='',representative_id='',scope_sha256=digest(ids),source_binding=scope_binding(corpus,ids),recommendation='CONFIRM_EXACT_SCOPE_ONLY_IF_MEANING_AND_REPRESENTATIVE_JUDGMENT_VALID',basis='group_proposals.csv',status='PROPOSAL_ONLY'))
 csvout(out/'decision_proposals.csv',proposals,columns=['decision_id','type','unit_ids','value','rule_text','action_unit_id','representative_id','scope_sha256','source_binding','recommendation','basis','status'])
 mapping=corpus[['policy_id','unit_id','parent_clause_id','parent_member_count']].copy();mapping['action_unit_id']='';mapping['counting_status']='PENDING_EXPLICIT_COUNTING_RULE';mapping['reason']='Shared parent does not itself define one action'
 csvout(out/'action_unit_mapping_proposed.csv',mapping)
 jsonout(out/'prepare_status.json',dict(identity=ctx.identity,original_human_n=len(human),baseline_field_events=len(events),existing_sample_n=len(sample),nonblank_sample=int(sample.eligibility_choice.ne('').sum()),part2_started=False))
 jsonout(out/'snapshot_manifest.json',dict(identity=ctx.identity,input_hashes={k:sha(ctx.input(k)) for k in cfg['inputs']},original_human_count=len(human)))

def scope_binding(corpus,ids):
 return digest(corpus[corpus.unit_id.isin(ids)][['unit_id','source_hash','source_clean_sha256']].sort_values('unit_id').to_dict('records'))

def ratio(num,den,frame):
 w=frame.design_weight.astype(float).to_numpy();denom=float(w@den)
 if denom==0:return dict(estimate=None,lower95=None,upper95=None,interval_status='UNDEFINED_DENOMINATOR')
 est=float(w@num/denom);res=num-est*den;var=0.;df=0
 for _,ix in frame.groupby('policy_id').indices.items():
  n=len(ix);N=int(frame.iloc[ix[0]].stratum_N);require(n==int(frame.iloc[ix[0]].stratum_n),'Partial stratum not a full probability audit')
  if n<2 and N>n:return dict(estimate=est,lower95=None,upper95=None,interval_status='SINGLETON_STRATUM')
  if n>1:var+=N*N*(1-n/N)*np.var(res[ix],ddof=1)/n;df+=n-1
 se=math.sqrt(max(var,0))/denom
 if est in [0,1] or not se:return dict(estimate=est,lower95=None,upper95=None,interval_status='BOUNDARY_NO_CERTAINTY_CLAIM')
 q=t.ppf(.975,df);return dict(estimate=est,lower95=max(0,est-q*se),upper95=min(1,est+q*se),interval_status='FINITE_POLICY_DESIGN_LINEARIZATION')

def ingest_return(ctx,out,review,signature,registry_before=None):
 prep=ctx.artifact('prepare');original=read(prep/'sample.csv').set_index('unit_id');link=read(prep/'linkage.csv');x=read_review(review);s=load(signature)
 signed(s,'CONFIRM_ACTUAL_HUMAN_RETURN',ctx.identity)
 correction=s.get('scope')=='EXPLICIT_HUMAN_CORRECTION'
 require(s['review_sha256']==sha(review),'Return/signature mismatch')
 if correction:
  require(registry_before is not None,'A trusted registry snapshot is required for corrections');prior=read(registry_before/'registry_snapshot.csv');prior_fields=read(registry_before/'human_field_evidence.csv').set_index(['unit_id','field'])
  require(s['registry_sha256']==sha(registry_before/'registry_snapshot.csv'),'Correction not bound to trusted previous registry')
  corpus=read(prep/'corpus.csv');original=corpus[corpus.unit_id.isin(set(prior.unit_id))].rename(columns={'exact_evidence_text':'text'}).set_index('unit_id');link=prior[['unit_id','policy_id','split','role']]
 else:require(s['sample_sha256']==sha(prep/'sample.csv'),'Sample signature mismatch')
 require(x.unit_id.is_unique and x.unit_id.ne('').all(),'Blank or duplicate returned ID')
 lock=load(prep/'v3_lock.json');require(s['model_sha256']==lock['model_sha256'],'Frozen V3 binding mismatch')
 original_return_name='original_return'+Path(review).suffix.lower();shutil.copyfile(review,out/original_return_name);shutil.copyfile(signature,out/'original_signature.json')
 csvout(out/'protected_text_display_mapping.csv',[dict(unit_id=r['unit_id'],field=k,display_value=r.get(k,''),source_value=r.get(k,''),transformation='IDENTITY_NO_TRIM_OR_ESCAPE',value_sha256=digest(r.get(k,''))) for r in x.to_dict('records') for k in ['text','context','source_location']])
 valid=[];errors=[]
 for r in x.to_dict('records'):
  uid=r['unit_id']
  try:
   require(uid in original.index,'Unknown sample ID')
   for k in ['policy_id','text','context','source_location','source_hash']:require(r.get(k,'')==original.loc[uid,k],'Protected '+k+' changed')
   choice=r.get('eligibility_choice','').upper();require(choice in ['ELIGIBLE','INELIGIBLE'],'Missing/undetermined human judgment')
   vals={k:r.get('human_'+k,'') for k in LABELS[1:]}
   if choice=='INELIGIBLE':
    require(all(v in ['', '0'] for v in vals.values()),'Human ineligible conflicts with positive GT');vals={k:'0' for k in vals}
   else:require(all(v in ['0','1'] for v in vals.values()),'Eligible row needs explicit GT')
   valid.append(dict(unit_id=uid,policy_id=r['policy_id'],human_eligibility='1' if choice=='ELIGIBLE' else '0',**{'human_'+k:v for k,v in vals.items()},source_hash=r['source_hash']))
  except ValueError as e:errors.append(dict(unit_id=uid,reason=str(e)))
 for uid in sorted(set(original.index)-set(x.unit_id)):errors.append(dict(unit_id=uid,reason='NOT_RETURNED'))
 csvout(out/'unresolved.csv',errors,columns=['unit_id','reason'])
 if not valid:
  jsonout(out/'import_result.json',dict(valid_n=0,complete=False,identity=ctx.identity));return
 v=pd.DataFrame(valid).merge(link,on=['unit_id','policy_id'],validate='one_to_one')
 scores=read(prep/'v3_scores.csv').set_index('unit_id').loc[v.unit_id];ys=v[['human_'+k for k in LABELS]].astype(int).to_numpy()
 ps=np.column_stack([scores['score_'+k].astype(float).to_numpy()>=lock['thresholds'][k] for k in LABELS]).astype(int);ps[:,1:]*=ps[:,0:1]
 rows=[];weighted=[];complete=not correction and len(v)==len(original) and not errors
 for j,k in enumerate(LABELS):
  rows.append(dict(label=k,identity='ACTUAL_RESPONDERS_DESCRIPTION',**answered_metrics(ys[:,j],ps[:,j])))
  if complete:
   y=ys[:,j];p=ps[:,j];tp=y*p;fp=(1-y)*p;fn=y*(1-p)
   for name,n,d in [('precision',tp,p),('recall',tp,y),('F1',2*tp,2*tp+fp+fn),('false_omission',fn,1-p)]:
    weighted.append(dict(label=k,metric=name,**ratio(n,d,v)))
 if correction:
  for item in rows:item['identity']='EXPLICIT_RULE_CORRECTION_RESPONDERS_NOT_ORIGINAL_REFERENCE_EVALUATION'
 csvout(out/'frozen_V3_responder_evaluation.csv',rows)
 if complete:csvout(out/'frozen_V3_probability_audit.csv',weighted)
 # Evaluation exists before any event receives future development qualification.
 audit_sha=sha(out/'frozen_V3_responder_evaluation.csv');events=[]
 corrections=s.get('corrections',{})
 for r in v.to_dict('records'):
  for k in LABELS:
   e=dict(unit_id=r['unit_id'],field=k,value=r['human_'+k],batch_id=s['batch_id'],reviewer=s['reviewer'],review_time=s['signed_at'],source_file_sha256=sha(out/original_return_name),signature_sha256=sha(out/'original_signature.json'),source_hash=r['source_hash'],rule_version=sha(prep/'codebook.md'),role=r['role'] if correction else 'EXISTING_PROBABILITY_SAMPLE',split=r['split'],import_result='VALID_AFTER_FROZEN_V3_EVALUATION',identity=ctx.identity,correction_of=corrections.get(r['unit_id']+'|'+k,''),original_evidence=audit_sha)
   if correction and (r['unit_id'],k) in prior_fields.index and prior_fields.loc[(r['unit_id'],k),'value']!=e['value']:
    require(e['correction_of']==prior_fields.loc[(r['unit_id'],k),'evidence_id'],'Changed label needs exact previous field event')
   e['event_id']=digest(e);events.append(e)
 csvout(out/'human_review_events.csv',events)
 jsonout(out/'import_result.json',dict(identity=ctx.identity,valid_n=len(v),complete=complete,development_n=int(v.split.eq('DEVELOPMENT').sum()),heldout_n=int(v.split.ne('DEVELOPMENT').sum()),evaluation_before_events=True,review_sha256=sha(review),signature_sha256=sha(signature)))

def ingest_decisions(ctx,out,decisions,signature):
 prep=ctx.artifact('prepare');cat=read(prep/'corpus.csv');d=read_review(decisions);s=load(signature)
 signed(s,'APPROVE_SCOPED_CODING_DECISIONS',ctx.identity);require(s['decisions_sha256']==sha(decisions),'Decision signature mismatch')
 require(d.decision_id.is_unique,'Duplicate decision IDs');results=[]
 for r in d.to_dict('records'):
  ids=json.loads(r['unit_ids']);require(ids and len(ids)==len(set(ids)) and set(ids)<=set(cat.unit_id),'Unknown/duplicate decision scope')
  require(r['scope_sha256']==digest(sorted(ids)) and r['source_binding']==scope_binding(cat,ids),'Decision scope/source changed')
  require(r['type'] in ['SOURCE_VERSION','SEMANTIC_RULE','EXACT_GROUP_SCOPE','ACTION_COUNTING_BOUNDARY','ACTION_COUNTING_RULE','EXTRACTION_SCOPE'],'Unknown decision type')
  require(r['value'] in ['CONFIRM','REJECT','UNRESOLVED'],'Explicit decision required')
  if r['value']=='CONFIRM':
   require(r['rule_text'].strip(),'Concrete signed rule required')
   if r['type']=='EXACT_GROUP_SCOPE':
    g=cat.set_index('unit_id').loc[ids];require(len(g[['policy_version_id','source_hash','exact_evidence_text','context','parent_clause_text']].drop_duplicates())==1,'Not strict semantic equivalence')
    require(r['representative_id'] in ids,'Representative outside group')
   if r['type']=='ACTION_COUNTING_BOUNDARY':
    require(r.get('action_unit_id') and cat.set_index('unit_id').loc[ids,'policy_id'].nunique()==1,'Action mapping needs ID and one policy')
  r.update(reviewer=s['reviewer'],signed_at=s['signed_at'],signature_sha256=sha(signature),decision_file_sha256=sha(decisions),identity=ctx.identity)
  r['decision_event_id']=digest(r);results.append(r)
 shutil.copyfile(decisions,out/('original_decisions'+Path(decisions).suffix.lower()));shutil.copyfile(signature,out/'original_signature.json');csvout(out/'decision_events.csv',results)

def live_merge_events(events):
 """Resolve final explicit eligibility before merging its derived child fields.
 Review dates can precede export/import; an obsolete negative parent must never
 suppress a later-imported genuine field with the same zero or a positive value.
 Original events remain in the append-only history.
 """
 records=events.to_dict('records');parents={}
 for r in records:
  if r['field']!='eligibility':continue
  old=parents.get(r['unit_id'])
  if old and old['value']!=r['value'] and r.get('correction_of')!=old['event_id']:continue
  if not old or old['value']!=r['value'] or r.get('correction_of'):parents[r['unit_id']]=r
 for r in records:
  if r.get('import_result')=='RULE_DERIVABLE_FROM_SIGNED_INELIGIBLE' and not __import__('group_readiness').live_event(r,parents.get(r['unit_id'],{})):continue
  yield r

def build_registry(ctx,out):
 prep=ctx.artifact('prepare');cat=read(prep/'corpus.csv');refids=set(read(prep/'reference_ids.csv').unit_id);pieces=[read(prep/'human_review_events.csv')];receipts=[]
 for key,p in ctx.events('ingest-return') + ctx.events('ingest-adjudication'):
  if (p/'human_review_events.csv').exists():pieces.append(read(p/'human_review_events.csv'))
  receipts.append(load(p/'import_result.json'))
 events=pd.concat(pieces,ignore_index=True).drop_duplicates('event_id')
 events['review_time_utc']=events.review_time.map(normalized_time)
 events['_baseline']=events.import_result.ne('VALID_BASELINE_RECONCILED').astype(int);events=events.sort_values(['_baseline','review_time_utc','event_id'],kind='stable').drop(columns=['_baseline'])
 current={};conflicts=[]
 # Baseline first, then signed chronological append. Explicit corrections must bind prior event.
 for r in live_merge_events(events):
  key=(r['unit_id'],r['field']);old=current.get(key)
  if old and old['value']!=r['value']:
   if r.get('correction_of')!=old['event_id']:conflicts.append(dict(unit_id=key[0],field=key[1],old_event=old['event_id'],new_event=r['event_id'],reason='UNBOUND_HUMAN_CONFLICT'));continue
  if old and r.get('correction_of')==old['event_id']:
   conflicts=[c for c in conflicts if (c['unit_id'],c['field'])!=key]
  current[key]=r if not old or old['value']!=r['value'] or r.get('correction_of') else old
 conflictkeys={(r['unit_id'],r['field']) for r in conflicts}
 rows=[];fields=[]
 for uid,g in cat.groupby('unit_id',sort=False):
  vals={};ok=True
  for k in LABELS:
   e=current.get((uid,k));bad=(uid,k) in conflictkeys
   if e and e.get('import_result')=='RULE_DERIVABLE_FROM_SIGNED_INELIGIBLE':
    parent=current.get((uid,'eligibility'),{})
    if not __import__('group_readiness').live_event(e,parent):e=None
   vals['human_'+k]=e['value'] if e and not bad else ''
   if e and not bad:fields.append(dict(unit_id=uid,field=k,value=e['value'],status='HUMAN_ADJUDICATED',value_origin=__import__('group_readiness').zero_origin(e,k),parent_evidence_id=e.get('parent_event_id','') if e.get('import_result')=='RULE_DERIVABLE_FROM_SIGNED_INELIGIBLE' else '',evidence_id=e['event_id'],source_hash=e['source_hash'],rule_version=e['rule_version']))
   else:ok=False
  if any(vals.values()):
   orig=current.get((uid,'eligibility'),{});split=g.iloc[0].split
   rows.append(dict(unit_id=uid,policy_id=g.iloc[0].policy_id,policy_family_id=g.iloc[0].policy_family_id,cv_group=g.iloc[0].cv_group,split=split,role=orig.get('role',''),complete=ok,training_allowed=bool(ok and split=='DEVELOPMENT' and uid not in refids and all(current.get((uid,k),{}).get('role') not in ['C2_ONLY','AUDIT_ONLY','POOL_AUDIT_ONLY_NOT_TRAINING'] for k in LABELS)),**vals))
 registry=pd.DataFrame(rows)
 # Semantic decisions do not silently relabel; only clear affected scope and version the rule ledger.
 decisions=[read(p/'decision_events.csv') for _,p in ctx.events('ingest-decisions')]
 dec=pd.concat(decisions,ignore_index=True).fillna('').drop_duplicates('decision_event_id') if decisions else pd.DataFrame(columns=['decision_event_id','type','value','unit_ids','decision_id'])
 all_decisions=dec.copy()
 if len(dec):
  dec['signed_at_utc']=dec.signed_at.map(normalized_time);dec=dec.sort_values(['signed_at_utc','decision_event_id'],kind='stable').drop_duplicates('decision_id',keep='last')
 csvout(out/'decision_events_all.csv',all_decisions)
 source_pending,rule_pending=pending_scope(prep,cat,dec);blocked=source_pending|rule_pending
 registry['scope_unresolved']=registry.unit_id.isin(blocked)
 registry['training_allowed']=registry.training_allowed&~registry.scope_unresolved
 eligible=registry[registry.training_allowed].copy()
 devunits=cat[cat.split.eq('DEVELOPMENT')&~cat.unit_id.isin(blocked)].copy()
 csvout(out/'human_registry_events.csv',events);csvout(out/'registry_snapshot.csv',registry);csvout(out/'human_field_evidence.csv',fields);csvout(out/'human_conflicts.csv',conflicts,columns=['unit_id','field','old_event','new_event','reason'])
 csvout(out/'development_labels.csv',eligible);csvout(out/'development_corpus.csv',devunits);csvout(out/'evaluation_labels_NOT_FOR_TRAINING.csv',registry[~registry.training_allowed])
 csvout(out/'decision_registry.csv',dec);csvout(out/'scope_exclusions.csv',[dict(unit_id=u,reason='UNRESOLVED_SOURCE_OR_SEMANTIC_SCOPE') for u in sorted(blocked)],columns=['unit_id','reason'])
 sample=read(prep/'sample.csv');sampleids=set(sample.unit_id);combined=registry[registry.unit_id.isin(sampleids)&registry.complete]
 complete_audit=set(combined.unit_id)==sampleids and bool(sampleids)
 if complete_audit:
  frame=combined.merge(read(prep/'linkage.csv')[['unit_id','stratum_N','stratum_n','design_weight']],on='unit_id',validate='one_to_one');sc=read(prep/'v3_scores.csv').set_index('unit_id').loc[frame.unit_id];lk=load(prep/'v3_lock.json');yy=frame[['human_'+k for k in LABELS]].astype(int).to_numpy();pp=np.column_stack([sc['score_'+k].astype(float).ge(lk['thresholds'][k]).to_numpy() for k in LABELS]).astype(int);pp[:,1:]*=pp[:,0:1];audit=[]
  for j,k in enumerate(LABELS):
   a=yy[:,j];b=pp[:,j];tp=a*b;fp=(1-a)*b;fn=a*(1-b)
   for name,num,den in [('precision',tp,b),('recall',tp,a),('F1',2*tp,2*tp+fp+fn),('false_omission',fn,1-b)]:audit.append(dict(label=k,metric=name,**ratio(num,den,frame)))
  csvout(out/'frozen_V3_combined_probability_audit.csv',audit)
 from issue_scope import signatures
 effective=signatures(out,prep,eligible,devunits,dec,complete_audit)
 jsonout(out/'codebook_addendum.json',dict(base_codebook_sha256=sha(prep/'codebook.md'),effective_rule_version=effective,confirmed_semantic_rules=dec[dec.type.eq('SEMANTIC_RULE')&dec.value.eq('CONFIRM')].to_dict('records'),labels_not_automatically_rewritten=True))
 jsonout(out/'registry_manifest.json',dict(identity=ctx.identity,registry_sha256=sha(out/'registry_snapshot.csv'),events_sha256=sha(out/'human_registry_events.csv'),development_labels_sha256=sha(out/'development_labels.csv'),development_corpus_sha256=sha(out/'development_corpus.csv'),baseline_n=len(read(prep/'baseline_human.csv')),actual_unique_human_n=len(registry),conflict_n=len(conflicts),complete_existing_sample_evaluated=complete_audit,training_eligible_n=len(eligible),scope_excluded_n=len(blocked),original_reference_training_n=int(eligible.unit_id.isin(refids).sum()),heldout_training_n=int(eligible.split.ne('DEVELOPMENT').sum()),policy_measurement_ready=False,effective_rule_version=effective) )
