"""Coding completion ledger, policy quality gates and honest partial/final release states."""
from common import *
from pool_audit import remaining_bound
from review_registry import scope_binding

def stage_composition(shares,policy_stage):
 require(policy_stage.policy_id.is_unique,'A policy must have one registered stage')
 z=policy_stage.merge(shares,on='policy_id',how='left',validate='one_to_one');rows=[]
 for stage,g in z.groupby('stage',sort=False):
  ready=g.measurement_ready.fillna('False').map(lambda x:boolean(str(x)))
  r=dict(stage=stage,total_policy_n=len(g),unresolved_policy_n=int((~ready).sum()),status='FORMAL' if ready.all() else 'INCOMPLETE_NOT_STAGE_ESTIMATE')
  for group,keys in [('G',LABELS[1:4]),('T',LABELS[4:])]:
   valid=ready & g[keys].fillna('').ne('').all(axis=1)
   r[group+'_defined_policy_n']=int(valid.sum());r[group+'_undefined_completed_policy_n']=int((ready&~valid).sum())
   for k in keys:r[k]=float(g.loc[valid,k].astype(float).mean()) if ready.all() and valid.any() else ''
  rows.append(r)
 return pd.DataFrame(rows)

def independent_stage_check(shares,policy_stage,stage_table):
 expected={}
 for r in policy_stage.to_dict('records'):expected.setdefault(r['stage'],[]).append(r['policy_id'])
 s=shares.set_index('policy_id');actual=stage_table.set_index('stage')
 for st,ids in expected.items():
  a=actual.loc[st];complete=all(boolean(str(s.loc[p,'measurement_ready'])) for p in ids)
  require(int(a.total_policy_n)==len(ids),'Stage policy denominator wrong')
  for ks in [LABELS[1:4],LABELS[4:]]:
   valid=[p for p in ids if boolean(str(s.loc[p,'measurement_ready'])) and all(s.loc[p,k]!='' for k in ks)]
   require(int(a[ks[0][0]+'_defined_policy_n'])==len(valid),'Defined policy count wrong')
   for k in ks:
    target=sum(float(s.loc[p,k]) for p in valid)/len(valid) if complete and valid else None
    require(a[k]=='' if target is None else np.isclose(float(a[k]),target,rtol=0,atol=1e-12),'Stage must be mean of policy shares, not pooled counts')
 return True

def quality_rows(cat,candidate,shares,fields,mapping):
 ci=candidate.set_index('unit_id');rows=[]
 for pol,g in cat.groupby('policy_id',sort=False):
  ids=set(g.unit_id);c=ci.loc[list(ids)];s=shares.set_index('policy_id').loc[pol];ev=fields[fields.unit_id.isin(ids)]
  unresolved=int((~c.complete.map(lambda x:boolean(str(x)))).sum());row=dict(policy_id=pol,stage=g.iloc[0].stage,candidate_units=len(g),complete_units=len(g)-unresolved,unresolved_units=unresolved,measurement_ready=s.measurement_ready,G_denominator=s.G_assignment_denominator,T_denominator=s.T_assignment_denominator,share_quality_accepted=False,quality_evidence='ACTUAL_FIELD_PROVENANCE_ONLY; NO_POLICY_WIDE_ERROR_BOUND',omission_risk='UNKNOWN_OUTSIDE_REVIEWED_UNITS',confusion_risk='NO_VALIDATED_POLICY_SPECIFIC_RATE',sensitivity_identity='CONSERVATIVE_LOGICAL_RANGE_NOT_CONFIDENCE_INTERVAL',additional_check='Resolve scoped sources, remaining fields, counting, then approve/apply quality contract')
  for status in ['HUMAN_ADJUDICATED','GROUP_REVIEW_CONFIRMED','AUTO_ACCEPTED_UNDER_VALIDATED_PROTOCOL','DERIVED_FROM_ACCEPTED_INELIGIBLE']:
   n=int(ev.status.eq(status).sum());row[status+'_fields']=n;row[status+'_fraction_all_required_fields']=n/(10*len(g))
  row['small_denominator_risk']='UNDEFINED' if not s.G_assignment_denominator or not s.T_assignment_denominator else 'REQUIRES_CHECK_NOT_FIXED_BY_GLOBAL_POOL_RATE'
  row['counting_sensitivity']='NOT_IDENTIFIED_WHILE_COUNTING_OR_LABELS_INCOMPLETE' if not boolean(str(s.measurement_ready)) else 'COMPARE_ASSIGNMENT_AND_EQUAL_ACTION_FILES'
  for k in LABELS[1:]:row[k+'_conservative_lower']=0.;row[k+'_conservative_upper']=1.
  rows.append(row)
 return rows

def build(ctx,out):
 prep=ctx.artifact('prepare');reg=ctx.artifact('build-registry');tr=ctx.artifact('train');pr=ctx.artifact('predict');ass=ctx.artifact('assemble-candidate')
 cat=read(prep/'corpus.csv');c=read(ass/'C2_candidate.csv');f=read(ass/'field_evidence.csv');human=read(reg/'registry_snapshot.csv');pred=read(pr/'corpus_predictions.csv').set_index('unit_id');shares=read(ass/'policy_level_shares.csv');mapping=read(ass/'action_unit_mapping.csv');mi=mapping.set_index('unit_id');ci=c.set_index('unit_id');lock=load(tr/'model_lock.json')
 require(cat.unit_id.is_unique and set(c.unit_id)==set(cat.unit_id),'Full corpus scope required')
 admission=ctx.workspace/'b1/01_sources/policy/admission_68.csv';ad=read(admission)
 require(ad.policy_id.is_unique and set(ad.policy_id)==set(cat.policy_id),'Admission/corpus mismatch')
 shutil.copyfile(admission,out/'policy_registry.csv')
 # Scope evidence checks are not equivalent to source completeness or author semantic approval.
 issues=read(prep/'issue_scope_audit.csv');sourcecards=read(prep/'source_cards.csv');scard=sourcecards.set_index('policy_id');sr=[];issue_by_uid={};cards=[]
 for i in issues.to_dict('records'):
  for uid in json.loads(i['affected_ids']):issue_by_uid.setdefault(uid,[]).append(i)
 for pol,g in cat.groupby('policy_id',sort=False):
  x=g.iloc[0];p=longpath(x.source_clean_path);txt=p.read_text(encoding='utf-8-sig');same=sha(p)==x.source_clean_sha256
  raw_count=0;off_count=0
  for r in g.itertuples():
   raw_count+=r.exact_evidence_text in txt
   try:off_count+=txt[int(r.clean_start):int(r.clean_end)]==r.exact_evidence_text
   except (ValueError,TypeError):pass
  card=scard.loc[pol].to_dict() if pol in scard.index else {};raw=ctx.workspace/'b1'/card.get('captured_source','_MISSING_');rawok=raw.is_file() and sha(raw)==card.get('captured_sha256');blocked=int(ci.loc[g.unit_id,'source_rule_resolved'].eq('False').sum())
  sr.append(dict(policy_id=pol,stage=x.stage,unit_n=len(g),clean_sha256=sha(p),clean_hash_matches=same,raw_carrier_hash_matches=rawok if card else 'NOT_A_FLAGGED_CARRIER',literal_text_found_n=raw_count,exact_offset_match_n=off_count,source_rule_pending_units=blocked,body_version_status='PENDING_SCOPED_RESOLUTION' if blocked else 'NO_CURRENT_CODING_BLOCK',future_inventory_metadata='DEFERRED_NOT_A_CODING_GATE',source_completeness_verified=False,semantic_author_approval=False,source_path=str(p),raw_path=str(raw) if card else ''))
  if card or blocked:
   cards.append('## '+pol+'\n\nExpected title: '+str(card.get('expected_title','See registered source'))+'\n\nCaptured body excerpt (technical evidence, not a new human label):\n\n'+txt[:1000]+'\n\nCarrier hash verified: '+str(rawok)+'; exact target substrings '+str(raw_count)+'/'+str(len(g))+'; exact offsets '+str(off_count)+'/'+str(len(g))+'.\n\nOpen coding units: '+str(blocked)+'. A matching carrier/text hash does not prove attachment identity, complete extraction or semantic scope. Dates for future inventory remain deferred.\n')
 csvout(out/'policy_source_scope.csv',sr);(out/'source_scope_cards.md').write_text('# Source and extraction checks\n\n'+'\n'.join(cards),encoding='utf-8')
 # Only strict version/context-identical groups; no propagation without a real scoped approval.
 groupkeys=['policy_id','policy_version_id','source_hash','exact_evidence_text','context','parent_clause_text'];groups={};gp=[]
 for _,g in cat.groupby(groupkeys,dropna=False,sort=False):
  if len(g)<2:continue
  gid='EQ_'+digest(g[groupkeys].iloc[0].to_dict())[:20];rep=[uid for uid in g.unit_id if uid in set(human.unit_id)]
  for uid in g.unit_id:groups[uid]=gid;gp.append(dict(group_id=gid,unit_id=uid,policy_id=g.iloc[0].policy_id,possible_human_representative=rep[0] if rep else '',scope_sha256=digest(sorted(g.unit_id)),approved=False))
 csvout(out/'strict_equivalence_proposals.csv',gp,columns=['group_id','unit_id','policy_id','possible_human_representative','scope_sha256','approved'])
 # Feasibility screening is not sampling/acceptance. Restrict proposals to heads with usable developer threshold.
 pools=[];pool_members={};known={(r.unit_id,r.field) for r in f.itertuples()};blocked=set(c.loc[c.source_rule_resolved.eq('False'),'unit_id']);eligible_heads=[k for k in LABELS if lock['contracts'][k]['usable_threshold'] is not None];claims=max(1,len(eligible_heads)*2)
 for label in eligible_heads:
  for direction,cut,risk in [('POSITIVE',.9,.1),('NEGATIVE',.1,.02)]:
   score=pred['score_'+label].astype(float);mask=score.ge(cut) if direction=='POSITIVE' else score.le(cut);ids=[uid for uid in pred.index[mask] if (uid,label) not in known and uid not in blocked];N=len(ids);pid=label+'_'+direction+'_SCREEN';alpha=.05/claims
   if N:
    from pool_audit import enumerate_sample_sizes
    region=enumerate_sample_sizes(N,alpha,risk)
    n=next(r['n'] for r in region if r['passes'])
   else:n=0
   for uid in ids:pool_members[(uid,label)]=pid
   policies=cat.set_index('unit_id').loc[ids,'policy_id'].value_counts().to_dict() if ids else {}
   pools.append(dict(pool_id=pid,label=label,direction=direction,score_cut=cut,net_members=N,policy_distribution=json.dumps(policies),existing_evidence='DEVELOPMENT_ONLY_NOT_THIS_ACCEPTANCE_POOL_VALIDATION',method='SRSWOR_FINITE_POOL_AFTER_AUTHOR_PROTOCOL_APPROVAL',estimated_audit_n_zero_error_benchmark=n,potential_remaining_fields=N-n,planned_claims=claims,family_alpha=.05,risk_limit=risk,scope_quality_accepted=False,uncovered_other_units=len(cat)-N,note='Not sampled; no guaranteed saving; no per-policy error bound'))
 csvout(out/'pool_feasibility.csv',pools);jsonout(out/'pool_feasibility_contract.json',dict(status='SCREENING_NOT_APPROVED_PROTOCOL',cuts=[.9,.1],risk_positive=.1,risk_negative=.02,multiplicity_claims=claims,model_sha256=lock['model_sha256'],no_sample_exported=True))
 # Every required field gets a route; this is a BACKEND ledger, never a full human workbook.
 ledger=[];hi=human.set_index('unit_id')
 for r in cat.itertuples():
  cr=ci.loc[r.unit_id];issue=issue_by_uid.get(r.unit_id,[]);restriction=';'.join(i['issue_type'] for i in issue if boolean(i['blocks_coding']));gid=groups.get(r.unit_id,'')
  for k in LABELS:
   value=cr['C2_'+k];evidence=cr['evidence_'+k];status=cr['status_'+k];pool=pool_members.get((r.unit_id,k),'');actual=hi.loc[r.unit_id,'human_'+k] if r.unit_id in hi.index else ''
   if restriction and cr.source_rule_resolved=='False':route='SCOPED_SOURCE_OR_RULE_DECISION';action='Resolve policy/card scope; retain existing human judgment, do not re-label it'
   elif value in ['0','1'] and evidence:route='REUSE_ACCEPTED_FIELD';action='Reuse exact evidence; no repeat human entry'
   elif gid:route='STRICT_GROUP_SCOPE_PROPOSAL';action='Approve exact context/version scope and real representative before propagation'
   elif pool:route='POOL_FEASIBILITY_PENDING_APPROVAL';action='Approve frozen risk/protocol/member scope, obtain real audit; no automatic acceptance now'
   else:route='DIRECTED_FIELD_ADJUDICATION';action='Register only needed fields in a scoped policy batch; middle scores and failed heads remain unresolved'
   ledger.append(dict(policy_id=r.policy_id,unit_id=r.unit_id,field=k,current_value=value,evidence_id=evidence,field_status=status,source_rule_restriction=restriction,reusable_human_value=actual,equivalence_group=gid,proposed_pool=pool,route=route,next_action=action,dependency='SOURCE_SCOPE' if restriction else 'REAL_SCOPE_APPROVAL_OR_FIELD_JUDGMENT' if route!='REUSE_ACCEPTED_FIELD' else '',action_counting_status=mi.loc[r.unit_id,'counting_status'],affects_policy_share=True))
 le=pd.DataFrame(ledger);csvout(out/'part1_completion_ledger.csv',le)
 summary=le.groupby(['policy_id','route'],sort=False).agg(required_fields=('field','size'),unique_units=('unit_id','nunique')).reset_index();csvout(out/'policy_task_summary.csv',summary)
 tasks=[];repair=[]
 previous_decisions=read(reg/'decision_registry.csv').set_index('decision_id')
 for i in issues.to_dict('records'):
  if not boolean(i['blocks_coding']):continue
  if i['issue_id'] in previous_decisions.index:
   prior=previous_decisions.loc[i['issue_id']]
   if prior['value']=='CONFIRM':continue
   if prior['value']=='REJECT':
    repair.append(dict(issue_id=i['issue_id'],issue_type=i['issue_type'],affected_ids=i['affected_ids'],affected_units=i['affected_n'],author_decision='REJECT',actual_rule_text=prior['rule_text'],decision_event_id=prior['decision_event_id'],next_action='Targeted source/extraction/semantic repair; do not re-request the same completed decision; do not change labels',requires_new_evidence_before_resubmission=True))
    continue
  ids=json.loads(i['affected_ids']);g=cat[cat.unit_id.isin(ids)];kind={'CLAUSE_SEMANTIC_RULE':'SEMANTIC_RULE','EXTRACTION_FRAGMENT':'EXTRACTION_SCOPE'}.get(i['issue_type'],'SOURCE_VERSION')
  tasks.append(dict(decision_id=i['issue_id'],type=kind,unit_ids=i['affected_ids'],value='',rule_text='',action_unit_id='',representative_id='',scope_sha256=digest(sorted(ids)),source_binding=scope_binding(cat,ids),policy_id=';'.join(g.policy_id.unique()),affected_units=len(ids),human_judgments_to_reuse=int(g.unit_id.isin(human.unit_id).sum()),technical_check='See policy_source_scope.csv and source_scope_cards.md; no new label inference',suggestion=i['recommendation'],question='Confirm exact scoped interpretation or reject/retain unresolved; do not confirm just because hashes match',status='UNSIGNED_AUTHOR_DECISION_REQUIRED'))
 csvout(out/'author_scoped_decisions.csv',tasks,columns=['decision_id','type','unit_ids','value','rule_text','action_unit_id','representative_id','scope_sha256','source_binding','policy_id','affected_units','human_judgments_to_reuse','technical_check','suggestion','question','status'])
 csvout(out/'rejected_scope_repair_queue.csv',repair,columns=['issue_id','issue_type','affected_ids','affected_units','author_decision','actual_rule_text','decision_event_id','next_action','requires_new_evidence_before_resubmission'])
 shutil.copyfile(ass/'counting_rule_scope_proposals.csv',out/'author_counting_rule_proposals.csv');shutil.copyfile(ass/'action_counting_exceptions.csv',out/'counting_exceptions.csv')
 # Freeze research-use criteria before any new pool acceptance. Do not invent approval.
 contract=dict(version='PART1_SHARE_QUALITY_EVIDENCE_SEPARATION_2',status='AUTHOR_APPROVAL_REQUIRED',all_policies_retained=True,unresolved_policy_not_G0=True,all_label_and_count_evidence_required=True,policy_specific_residual_risk_required=True,sensitivity_alone_cannot_pass=True,uniform_policy_CI_requirement=False,auto_pool_risk_limits=dict(positive=.1,negative=.02),proposed_max_absolute_share_sensitivity=.05,tolerance_identity='PROPOSED_RESEARCH_TOLERANCE_NOT_APPROVED_OR_EMPIRICAL_PRIOR',no_global_pool_bound_as_policy_bound=True,rare_labels_need_separate_evidence=True,conditions_for_acceptance='Complete exact C2, independent arithmetic, actual field/pool evidence and documented omission/rare-label/small-denominator checks; sensitivity is separate, not an error bound; exact author approval remains required',default_if_evidence_missing='NOT_ACCEPTED')
 jsonout(out/'quality_contract.json',contract)
 qr=quality_rows(cat,c,shares,f,mapping)
 from share_quality import apply_assessments
 qr,quality_reviewed=apply_assessments(ctx,ass,out/'quality_contract.json',qr)
 csvout(out/'policy_share_quality_report.csv',qr)
 from share_quality import apply_group_assessments
 group_shares=apply_group_assessments(ctx,ass)
 csvout(out/'policy_group_shares.csv',group_shares)
 for r in qr:
  z=group_shares[group_shares.policy_id.eq(r['policy_id'])]
  if len(z)==2 and z.quality_accepted.map(boolean).all() and boolean(str(r['measurement_ready'])):
   r['share_quality_accepted']=True;r['quality_evidence']='BOTH_EXACT_POLICY_GROUP_QUALITY_ASSESSMENTS';quality_reviewed=True
 csvout(out/'policy_share_quality_report.csv',qr)
 shutil.copyfile(ass/'stage_group_composition.csv',out/'stage_group_composition.csv')
 group_wide=group_shares.pivot(index='policy_id',columns='group',values=['measurement_ready','quality_accepted']);group_wide.columns=['policy_'+g+'_'+('measurement_ready' if m=='measurement_ready' else 'quality_accepted') for m,g in group_wide.columns];csvout(out/'policy_group_readiness.csv',group_wide.reset_index())
 jsonout(out/'quality_acceptance_status.json',dict(any_valid_assessment=quality_reviewed,all_policies_accepted=all(r['share_quality_accepted'] for r in qr),basis='ACTUAL_FIELD_EVIDENCE_AND_POLICY_CHECKS;SENSITIVITY_SEPARATE_NOT_GLOBAL_PRECISION'))
 stage=cat[['policy_id','stage']].drop_duplicates();require(stage.policy_id.is_unique,'Stage assignment inconsistent');csvout(out/'policy_stage_registry.csv',stage)
 sc=stage_composition(shares,stage);independent_stage_check(shares,stage,sc);formal=sc.status.eq('FORMAL').all()
 csvout(out/('stage_composition.csv' if formal else 'stage_composition_PREVIEW.csv'),sc)
 statuses=[]
 for r in shares.to_dict('records'):
  ready=boolean(r['measurement_ready']);r['statistical_status']='UNRESOLVED_POLICY' if not ready else ('G0_NO_QUALIFYING_ACTION' if r['eligible_action_n']=='0' else 'DEFINED_POLICY_SHARES');statuses.append(r)
 csvout(out/'policy_statistical_status.csv',statuses)
 jsonout(out/'stage_verification.json',dict(independent_reaggregation_passed=True,formal_stage_complete=bool(formal),policy_count=len(stage),registered_stage_identity='CURRENT_FROZEN_CORPUS_STAGE',NA_not_zero=True))
 (out/'coding_method_current.md').write_text('''# research current coding method

Documentation addendum; original codebook is preserved. Current features are target character TF-IDF plus 0.3-weighted necessary context; titles/year/stage/administrative level are not features. No C0 supervision in the current human-only model. C1 is an uncalibrated machine suggestion, not ground truth. C2 may contain actual human judgments, explicitly approved strict equivalence propagation, independently audited and approved automatic fields, and zeros derived from accepted human/approved negative eligibility. A whole-file approval is not rowwise human review.

Development OOF selects thresholds and specification. Original 600 are previously viewed repeated references; 49 heldout units are post-lock diagnostics; neither enters training or feature fitting. Directed C2-only and audit roles are not automatically training roles. Missing values remain unknown. Diagnostic fallback thresholds are not usable quality-qualified thresholds.

G/T are multi-label; action identity differs from captured unit identity. Same parent, similar sentence or short identical phrase does not authorize merging or propagation. General counting requires exact author scope approval; ambiguous fragments/duplicates remain exceptions. Main shares use group assignments; prevalence and equal-action sensitivity are distinct. Stage summaries average defined policy shares equally, retain all admitted policies, and never replace unknown/undefined shares with zero.

This addendum changes documentation/ingestion roles, not the historical human label definitions. Future semantic changes require appended decisions/corrections and dependency invalidation. Current source hash checks do not establish body completeness. Future legal-date inventory metadata is deferred and cannot alone block coding. No SD work is authorized by this release.
''',encoding='utf-8')
 jsonout(out/'protocol_change_map.json',dict(documentation_only=['context feature explanation','role distinction','multi-label assignment denominators','diagnostic versus usable threshold'],new_implementation=['directed field ingestion','full completion gate','share quality proposal'],actual_label_definition_changed=False,current_training_input_changed=False,quality_contract_approved=False))
 (out/'AUTHOR_TASKS_README.md').write_text('''# 集中作者任务入口

无需重填已完成600、1200或200。先看 policy_task_summary.csv；全量 completion_ledger 只是后台台账。

1. source_scope_cards.md 和 policy_source_scope.csv 已集中给出实际正文与技术核查。只填写 author_scoped_decisions.csv 的 value（CONFIRM/REJECT/UNRESOLVED）和具体 rule_text。正文/通知附件、提取碎片与语义解释分别确认；不要因哈希相同就认可完整性。
2. author_counting_rule_proposals.csv 是范围固定的通用计数批准提案；只对接受的范围填写。counting_exceptions.csv 是需要边界判断的真实例外，不要求重填G/T。
3. pool_feasibility.csv 是净成员与最理想零错误样本量筛查，未抽样、未批准，不等于节省人工。质量合同 quality_contract.json 中0.05是待批准的份额敏感性容差，不是既有标准。
4. 新增标签通过 register-adjudication / ingest-adjudication，默认C2_ONLY；只有明确开发角色才能进入开发，留出永不训练。表格允许部分返回，空白保留未知。具体批次先注册范围再导出，不生成全库必审表。
5. 返回裁定表后通过 ingest-decisions 导入；签署须绑定文件哈希和具体范围。执行授权不能代替池接受或最终批准。

原600/49不能调参，机器建议不能当新人工。最终批准须绑定候选与含计量/质量的完整证据包哈希。当前缺真实裁定/验收，不能冻结可靠C2或发布正式份额。
''',encoding='utf-8')
 bundle=dict(identity=ctx.identity,candidate_sha256=sha(ass/'C2_candidate.csv'),base_evidence_sha256=sha(ass/'candidate_evidence_bundle.json'),model_sha256=lock['model_sha256'],codebook_sha256=sha(prep/'codebook.md'),files={n:sha(out/n) for n in ['policy_registry.csv','policy_source_scope.csv','policy_stage_registry.csv','policy_share_quality_report.csv','quality_contract.json','coding_method_current.md','stage_verification.json','policy_statistical_status.csv']},measurement_hashes={n:sha(ass/n) for n in ['action_unit_mapping.csv','action_unit_summary.csv','policy_level_shares.csv','action_prevalence.csv','equal_action_weight_sensitivity.csv','measurement_validation.json']},formal_stage_composition=bool(formal),actual_quality_acceptance=all(r['share_quality_accepted'] for r in qr))
 jsonout(out/'part1_evidence_bundle.json',bundle)
 jsonout(out/'part1_work_status.json',dict(corpus_n=len(cat),policy_n=len(ad),field_ledger_rows=len(le),human_n=len(human),complete_c2_rows=int(c.complete.eq('True').sum()),registered_source_tasks=len(tasks),rejected_scope_repairs=len(repair),strict_group_proposals=len(set(groups.values())),feasibility_pools=len(pools),formal_stage_output=bool(formal),PART1_COMPLETED=False,part2_started=False))

def acceptance_flags(implementation,trained,evidence,frozen,measurement,quality,reproduced,scope,approved,package,appendix):
 flags=dict(PIPELINE_IMPLEMENTATION_READY=bool(implementation),TRAINING_COMPLETED=bool(trained),C2_EVIDENCE_VALIDATED=bool(evidence),C2_LABELS_FROZEN=bool(frozen),POLICY_MEASUREMENT_READY=bool(measurement),POLICY_SHARE_QUALITY_ACCEPTED=bool(quality),REPRODUCIBILITY_CHECK_PASSED=bool(reproduced))
 flags['PART1_COMPLETED']=bool(all(flags.values()) and scope and approved and package and appendix)
 return flags

def finalize(ctx,out):
 ledger=ctx.artifact('part1-ledger');ass=ctx.artifact('assemble-candidate');st=load(ass/'candidate_status.json');bundle=load(ledger/'part1_evidence_bundle.json')
 assurance=ctx.root/'assurance';test=load(assurance/'implementation_tests.json') if (assurance/'implementation_tests.json').exists() else {};rep=load(assurance/'independent_replay.json') if (assurance/'independent_replay.json').exists() else {}
 pub=ctx.artifact('publish-part1',required=False);oldpub=ctx.artifact('publish',required=False);v=ctx.artifact('validate-candidate',required=False)
 test_state='NOT_FOUND' if not test else 'STALE_CODE' if test.get('code_sha256')!={p.name:sha(p) for p in ctx.code.glob('*.py')} else 'CURRENT_PASS' if test.get('passed') else 'ACTUAL_FAILURE'
 test_current=test_state=='CURRENT_PASS'
 # A copied candidate replay is a diagnostic check only; it cannot validate a nonexistent final release.
 formal_replay=ctx.artifact('reproduce-part1',required=False)
 formal_report=load(formal_replay/'independent_replay.json') if formal_replay else {}
 repro=bool(pub and formal_report.get('formal_release_recomputed') and formal_report.get('publication_manifest_sha256')==sha(pub/'publication_manifest.json'))
 quality=bool(pub and load(pub/'publication_manifest.json').get('POLICY_SHARE_QUALITY_ACCEPTED'))
 scope=len(read(ledger/'policy_registry.csv'))==len(read(ledger/'policy_statistical_status.csv'))==68
 appendix=bool(pub and (pub/'appendix/table_figure_mapping.csv').exists() and (pub/'appendix/Figure_S6.svg').exists())
 flags=acceptance_flags(test_current,bool(ctx.artifact('train',required=False)),bool(v),bool(pub or oldpub),st['POLICY_MEASUREMENT_READY'],quality,repro,scope,bool(pub),bool(pub),appendix)
 flags.update(implementation_test_status=test_state,implementation_test_scope=test.get('scope','UNKNOWN'),identity=ctx.identity,run_id=ctx.root.name,checks_generated_at=now(),candidate_sha256=bundle['candidate_sha256'],part1_bundle_sha256=sha(ledger/'part1_evidence_bundle.json'),corpus_scope_complete=scope,unresolved_c2_rows=st['total_rows']-st['complete_rows'],automatic_fields=st['actual_auto_fields'],real_approvals_not_inferred=True,diagnostic_replay=rep,blockers=[k for k,val in flags.items() if val is False],part2_started=False)
 jsonout(out/'PART1_ACCEPTANCE.json',flags)
 (out/'PART2_HANDOFF.md').write_text('# Part 1 handoff\n\nPART1_COMPLETED='+str(flags['PART1_COMPLETED'])+'. SD, annual inventory/governance and scenarios are not started. See the exact candidate ledger and quality evidence; no final policy shares may be imported while measurement/quality is false.\n',encoding='utf-8')

def publish(ctx,out,approval):
 ledger=ctx.artifact('part1-ledger');ass=ctx.artifact('assemble-candidate');v=load(ctx.artifact('validate-candidate')/'validation.json');a=load(approval)
 signed(a,'APPROVE_EXACT_PART1_C2_MEASUREMENT_AND_QUALITY',ctx.identity)
 require(a['candidate_sha256']==sha(ass/'C2_candidate.csv')==v['candidate_sha256'] and a['bundle_sha256']==sha(ledger/'part1_evidence_bundle.json'),'Exact part1 approval mismatch')
 require(v['POLICY_MEASUREMENT_READY'] and (ledger/'stage_composition.csv').exists(),'Labels alone cannot complete part1')
 # A claimed author acceptance cannot manufacture missing independent quality evidence.
 q=read(ledger/'policy_share_quality_report.csv');require(q.share_quality_accepted.map(boolean).all(),'Policy share quality evidence still insufficient')
 require(load(ledger/'quality_acceptance_status.json')['all_policies_accepted'],'Policy-specific quality assessment not approved/validated')
 from part1_release_bundle import make_bundle
 make_bundle(ctx,out,formal=True)
 shutil.copyfile(approval,out/'author_approval.json');shutil.copyfile(ctx.code/'standalone_replay.py',out/'standalone_replay.py')
 jsonout(out/'publication_manifest.json',dict(identity=ctx.identity,C2_LABELS_FROZEN=True,POLICY_MEASUREMENT_READY=True,POLICY_SHARE_QUALITY_ACCEPTED=True,PART1_COMPLETED=False,pending='Independent formal release replay and final acceptance',files=filelist(out)))

def reproduce(ctx,out):
 import subprocess,sys
 pub=ctx.artifact('publish-part1',required=False)
 if pub is None:
  from group_measurement_replay import reproduce_groups
  return reproduce_groups(ctx,out)
 manifest=load(pub/'publication_manifest.json')
 require(all((pub/n).is_file() and sha(pub/n)==h for n,h in manifest['files'].items()),'Publication files changed')
 independent=ctx.root/'formal_release_replay'/sha(pub/'publication_manifest.json')[:16]
 require(not independent.exists(),'Independent replay target exists; preserve it and use a new immutable run for a fresh replay')
 shutil.copytree(pub,independent)
 result=subprocess.run([sys.executable,str(independent/'standalone_replay.py'),'--root',str(independent)],cwd=independent,capture_output=True,text=True,encoding='utf-8')
 (out/'stdout.log').write_text(result.stdout,encoding='utf-8');(out/'stderr.log').write_text(result.stderr,encoding='utf-8')
 require(result.returncode==0,'Independent formal release replay failed')
 report=load(independent/'replay_result.json');require(report['formal_release_recomputed'],'A candidate replay cannot certify final release')
 report['publication_manifest_sha256']=sha(pub/'publication_manifest.json');jsonout(out/'independent_replay.json',report)
