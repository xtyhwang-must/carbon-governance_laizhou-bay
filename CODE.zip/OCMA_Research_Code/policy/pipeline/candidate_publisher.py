"""Independent file validation and immutable coding publication; no SD."""
from common import *
from pool_audit import validate_evidence, validate_human_audit
from assemble_candidate import DERIVATION_VERSION
import stat

def validate_policy_groups(ctx):
 """Independent group share arithmetic from frozen field values and approved mapping."""
 ass=ctx.artifact('assemble-candidate');c=read(ass/'C2_candidate.csv').set_index('unit_id');m=read(ass/'group_action_mapping.csv');p=read(ass/'policy_group_shares.csv');checked=0;fields=read(ass/'field_evidence.csv').set_index(['unit_id','field']);cat=read(ctx.artifact('prepare')/'corpus.csv').set_index('unit_id');dec=read(ctx.artifact('build-registry')/'decision_registry.csv').set_index('decision_event_id')
 for r in p.to_dict('records'):
  if not boolean(r['measurement_ready']):continue
  ks=LABELS[1:4] if r['group']=='G' else LABELS[4:];z=m[m.policy_id.eq(r['policy_id'])];ids=z.unit_id.tolist();require(all(c.loc[u,'eligibility_ready']=='True' and c.loc[u,r['group']+'_group_ready']=='True' and c.loc[u,'action_boundary_ready']=='True' for u in ids),'Incomplete policy/group scope')
  for uid in ids:
   for k in ['eligibility']+ks:
    e=fields.loc[(uid,k)];require(e.source_hash==cat.loc[uid,'source_hash'] and str(e.evidence_id),'Group field provenance mismatch')
    if e.status=='DERIVED_FROM_ACCEPTED_INELIGIBLE':require(fields.loc[(uid,'eligibility'),'value']=='0' and e.parent_evidence_id==fields.loc[(uid,'eligibility'),'evidence_id'],'Derived parent changed')
  actions={}
  for row in z.to_dict('records'):
   if c.loc[row['unit_id'],'C2_eligibility']=='0':continue
   require(row['action_unit_id'],'Missing positive action ID');require(row['decision_event_id'] in dec.index and dec.loc[row['decision_event_id'],'value']=='CONFIRM','Action lacks approved counting evidence');vec=tuple(int(c.loc[row['unit_id'],'C2_'+k]) for k in ks)
   if row['action_unit_id'] in actions:require(actions[row['action_unit_id']]==vec,'Group-specific action inconsistency')
   actions[row['action_unit_id']]=vec
  counts=[sum(v[i] for v in actions.values()) for i in range(len(ks))];den=sum(counts);require(int(r['assignment_denominator'])==den,'Group denominator mismatch')
  for k,num in zip(ks,counts):require(r[k]=='' if not den else abs(float(r[k])-num/den)<1e-12,'Group share mismatch')
  checked+=1
 return dict(checked_defined_or_zero_denominator_groups=checked,all_policy_groups=len(p),passed=True,not_quality_approval=True)

def validate(ctx,out,candidate=None,bundle=None):
 assembled=ctx.artifact('assemble-candidate');prep=ctx.artifact('prepare');reg=ctx.artifact('build-registry')
 cp=Path(candidate) if candidate else assembled/'C2_candidate.csv';bp=Path(bundle) if bundle else assembled/'candidate_evidence_bundle.json'
 watched=[cp,bp,assembled/'field_evidence.csv',reg/'registry_snapshot.csv',reg/'human_registry_events.csv',reg/'decision_registry.csv'];initial_hashes={str(p):sha(p) for p in watched}
 c=read(cp);b=load(bp);cat=read(prep/'corpus.csv').set_index('unit_id');e=read(assembled/'field_evidence.csv')
 require(len(c)>0 and c.unit_id.is_unique and c.unit_id.ne('').all() and set(c.unit_id)==set(cat.index),'Candidate must contain exact nonempty full corpus ID set')
 require(c.identity.eq(ctx.identity).all(),'Publication identity mismatch')
 require(b['registry_snapshot_sha256']==sha(reg/'registry_snapshot.csv') and b['human_events_sha256']==sha(reg/'human_registry_events.csv') and b['decision_registry_sha256']==sha(reg/'decision_registry.csv'),'Trusted version snapshot mismatch')
 require(b['corpus_sha256']==sha(prep/'corpus.csv') and b['codebook_sha256']==sha(prep/'codebook.md'),'Corpus/codebook changed')
 require(b['field_evidence_sha256']==sha(assembled/'field_evidence.csv') and b['mapping_sha256']==sha(assembled/'action_unit_mapping.csv'),'Field/mapping artifact changed')
 require(not e.duplicated(['unit_id','field']).any() and e.evidence_id.is_unique,'Duplicate evidence identity')
 ev=e.set_index(['unit_id','field']);byid=e.set_index('evidence_id')
 current_human=read(reg/'human_field_evidence.csv');current_human=current_human[~current_human.get('value_origin',pd.Series('',index=current_human.index)).eq('RULE_DERIVABLE_FROM_INELIGIBLE')].set_index(['unit_id','field'])
 human=read(reg/'human_registry_events.csv').set_index('event_id');dec=read(reg/'decision_registry.csv').set_index('decision_event_id')
 require(b['c2_human_snapshot_sha256']==sha(assembled/'C2_human_field_snapshot.csv') and b['c2_human_audit_events_sha256']==sha(assembled/'C2_human_audit_events.csv'),'C2 human extension changed')
 for key,info in b.get('human_audits',{}).items():
  path=Path(info['path']);require(ctx.valid(key) and info['dependency_hash']==digest(filelist(path)),'Actual human audit package changed')
  actual=validate_human_audit(ctx,path)
  for h in actual.to_dict('records'):
   uid=h['unit_id'];k=h['field'];eid=h['evidence_id']
   require(uid in cat.index and h['source_hash']==cat.loc[uid,'source_hash'] and h['rule_version']==b['codebook_sha256'],'Human audit source/rule invalid')
   if (uid,k) in current_human.index:
    require(current_human.loc[(uid,k),'value']==h['value'],'Unresolved human audit conflict');continue
   human.loc[eid]=pd.Series(dict(h,event_id=eid))
   current_human.loc[(uid,k),:]=pd.Series(h)
 require(set(read(assembled/'C2_human_field_snapshot.csv').evidence_id)==set(current_human.evidence_id),'C2 extension not independently reproduced')
 source_pending,rule_pending=pending_scope(prep,cat.reset_index(),dec.reset_index())
 effective_rules=load(reg/'registry_manifest.json')['effective_rule_version']
 require(not source_pending and not rule_pending,'Source/rule scope still unresolved')
 # Verify actual unique evidence packages once, then do only indexed field checks.
 source_cache={}
 for r in cat.drop_duplicates('source_clean_path').itertuples():
  f=Path(r.source_clean_path);require(f.is_file() and sha(f)==r.source_clean_sha256,'Actual source bytes invalid')
  source_cache[str(f)]=sha(f)
 poolcache={};groupcache={}
 for key,info in b['pools'].items():
  path=Path(info['path']);require(ctx.valid(key) and info['dependency_hash']==digest(filelist(path)),'Pool dependency signature invalid')
  poolcache[key]=validate_evidence(ctx,path).set_index(['unit_id','field'])
 for row in c.to_dict('records'):
  uid=row['unit_id'];require(row['policy_id']==cat.loc[uid,'policy_id'] and row['source_hash']==cat.loc[uid,'source_hash'],'Candidate identity/source mismatch')
  require(boolean(row['complete']) and boolean(row['source_rule_resolved']),'Unresolved record cannot freeze')
  for k in LABELS:
   value=row.get('C2_'+k);require(value in ['0','1'] and (uid,k) in ev.index,'Missing/illegal final field')
   r=ev.loc[(uid,k)];require(r.value==value and r.evidence_id==row['evidence_'+k] and r.status==row['status_'+k],'Candidate field/evidence mismatch')
   require(r.source_hash==cat.loc[uid,'source_hash'] and r.current_rules_version==effective_rules,'Evidence source/current rules mismatch')
   if r.status=='HUMAN_ADJUDICATED':
    require(r.evidence_id in human.index,'Not a registered actual human event')
    require((uid,k) in current_human.index and current_human.loc[(uid,k),'evidence_id']==r.evidence_id,'Superseded human judgment cannot be resurrected')
    h=human.loc[r.evidence_id];require(h.unit_id==uid and h.field==k and h.value==value and h.identity==ctx.identity,'Human evidence forged')
   elif r.status=='GROUP_REVIEW_CONFIRMED':
    gid=r.decision_event_id;require(gid in dec.index,'Group not confirmed')
    if gid not in groupcache:
     d=dec.loc[gid];ids=json.loads(d.unit_ids);require(d.type=='EXACT_GROUP_SCOPE' and d.value=='CONFIRM','Invalid group decision')
     require(len(cat.loc[ids,['policy_version_id','source_hash','exact_evidence_text','context','parent_clause_text']].drop_duplicates())==1,'Context/version group changed')
     groupcache[gid]=(set(ids),d.representative_id)
    ids,rep=groupcache[gid];require(uid in ids and r.parent_evidence_id in human.index,'Group membership/representative invalid')
    require((rep,k) in current_human.index and current_human.loc[(rep,k),'evidence_id']==r.parent_evidence_id,'Group parent human judgment superseded')
    h=human.loc[r.parent_evidence_id];require(h.unit_id==rep and h.field==k and h.value==value,'Group representative value mismatch')
    require(r.evidence_id==digest([gid,r.parent_evidence_id,uid,k]),'Group evidence hash invalid')
   elif r.status=='AUTO_ACCEPTED_UNDER_VALIDATED_PROTOCOL':
    require(r.pool_event in poolcache and (uid,k) in poolcache[r.pool_event].index,'No accepted pool field')
    pr=poolcache[r.pool_event].loc[(uid,k)];require(pr.value==value and pr.evidence_id==r.evidence_id,'Pool membership/value mismatch')
   elif r.status=='DERIVED_FROM_ACCEPTED_INELIGIBLE':
    require(k!='eligibility' and value=='0' and (uid,'eligibility') in ev.index,'Illegal derived field')
    parent=ev.loc[(uid,'eligibility')]
    require(parent.value=='0' and parent.evidence_id==r.parent_evidence_id and parent.status in ['HUMAN_ADJUDICATED','GROUP_REVIEW_CONFIRMED','AUTO_ACCEPTED_UNDER_VALIDATED_PROTOCOL'],'Invalid ineligible parent evidence')
    require(r.derivation_version==DERIVATION_VERSION and r.evidence_id==digest([parent.evidence_id,effective_rules,DERIVATION_VERSION,uid,k]),'Derived evidence binding invalid')
   else:raise ValueError('Unsupported/undecided field route')
  require(row['C2_eligibility']=='1' or all(row['C2_'+k]=='0' for k in LABELS[1:]),'Negative eligibility with positive GT conflict')
 require(all(sha(Path(p))==s for p,s in initial_hashes.items()),'Candidate/evidence changed during validation')
 # Detect mutation during the validation itself.
 require(all(sha(Path(p))==s for p,s in source_cache.items()),'Source changed during validation')
 require(all(digest(filelist(Path(info['path'])))==info['dependency_hash'] for info in b['pools'].values()),'Pool changed during validation')
 require(sha(cp)==sha(assembled/'C2_candidate.csv') and sha(bp)==sha(assembled/'candidate_evidence_bundle.json'),'Validate the exact assembled snapshot, not a self-declared variant')
 from measurement import verify
 for n,h in b['measurement_hashes'].items():require(sha(assembled/n)==h,'Measurement evidence changed')
 measured=verify(assembled,c,cat.reset_index(),dec.reset_index())
 require(measured==load(assembled/'measurement_validation.json'),'Measurement validation result mismatch')
 result=dict(identity=ctx.identity,validated=True,candidate_sha256=sha(cp),bundle_sha256=sha(bp),rows=len(c),field_n=len(c)*10,unique_pool_packages_checked=len(poolcache),unique_group_scopes_checked=len(groupcache),unique_sources_checked=len(source_cache),POLICY_MEASUREMENT_READY=measured['POLICY_MEASUREMENT_READY'],C2_LABELS_FROZEN=False,part2_started=False)
 jsonout(out/'validation.json',result)

def publish(ctx,out,approval):
 va=ctx.artifact('validate-candidate');assembled=ctx.artifact('assemble-candidate');report=load(va/'validation.json');a=load(approval)
 signed(a,'APPROVE_EXACT_C2_LABELS_AND_EVIDENCE',ctx.identity)
 require(a['candidate_sha256']==sha(assembled/'C2_candidate.csv')==report['candidate_sha256'] and a['bundle_sha256']==sha(assembled/'candidate_evidence_bundle.json')==report['bundle_sha256'],'Author approval is not bound to actual candidate/bundle')
 # Recheck dependencies/current state before writing immutable release copies.
 require(ctx.valid('validate-candidate'),'Validation invalidated')
 for name in ['C2_candidate.csv','field_evidence.csv','candidate_evidence_bundle.json','action_unit_mapping.csv','action_unit_summary.csv','policy_level_shares.csv','candidate_status.json','C2_human_audit_events.csv','C2_human_field_snapshot.csv','measurement_contract.json','measurement_validation.json','action_prevalence.csv','equal_action_weight_sensitivity.csv']:
  shutil.copyfile(assembled/name,out/name)
 shutil.copyfile(approval,out/'author_approval.json');shutil.copyfile(va/'validation.json',out/'validation.json')
 evidence=out/'evidence';evidence.mkdir();reg=ctx.artifact('build-registry');prep=ctx.artifact('prepare')
 for source,name in [(reg/'registry_snapshot.csv','registry_snapshot.csv'),(reg/'human_registry_events.csv','human_registry_events.csv'),(reg/'decision_registry.csv','decision_registry.csv'),(reg/'decision_events_all.csv','decision_events_all.csv'),(reg/'registry_manifest.json','registry_manifest.json'),(reg/'codebook_addendum.json','codebook_addendum.json'),(prep/'codebook.md','codebook.md'),(prep/'source_checks.csv','source_checks.csv'),(prep/'baseline_human.csv','baseline_human.csv')]:shutil.copyfile(source,evidence/name)
 if (prep/'baseline_original_evidence').exists():shutil.copytree(prep/'baseline_original_evidence',evidence/'baseline_original_evidence')
 for prefix in ['ingest-return','ingest-decisions','ingest-adjudication','ingest-audit','accept-pool']:
  for key,path in (ctx.audit_events() if prefix=='ingest-audit' else ctx.events(prefix)):shutil.copytree(path,evidence/key.replace(':','_'))
 jsonout(evidence/'snapshot_resolution_index.json',dict(original_bundle_preserved=True,original_registry_path=str(reg),local_registry='registry_snapshot.csv',copied_evidence_hashes=filelist(evidence)))
 manifest=dict(identity=ctx.identity,release_status='PARTIAL_LABEL_RELEASE',PART1_COMPLETED=False,C2_LABELS_FROZEN=True,POLICY_MEASUREMENT_READY=report['POLICY_MEASUREMENT_READY'],part2_started=False,part2_requires_separate_author_instruction=True,files=filelist(out),author_approval_is_not_all_rows_human_review=True)
 (out/'PART2_HANDOFF.md').write_text('# Coding handoff\n\nC2 labels frozen with field provenance. Policy measurement readiness: '+str(report['POLICY_MEASUREMENT_READY'])+'.\nNo annual stocks/G/eta/feedback/synergy or SD were computed. Explicit author instruction is required to start Part 2.\nIdentity: '+ctx.identity+'\n',encoding='utf-8')
 manifest['files']=filelist(out);jsonout(out/'publication_manifest.json',manifest)
 for p in out.rglob('*'):
  if p.is_file():p.chmod(stat.S_IREAD)
if __name__=='__main__':
 from coding_pipeline import main
 main()
