"""Assemble field provenance, derived zeros and independently approved action counting."""
from common import *
from pool_audit import validate_evidence, validate_human_audit

DERIVATION_VERSION='accepted-ineligible-v1'
def resolve_current_fields(ctx):
 prep=ctx.artifact('prepare');reg=ctx.artifact('build-registry');cat=read(prep/'corpus.csv');hm=read(reg/'human_field_evidence.csv');dec=read(reg/'decision_registry.csv');codebookhash=sha(prep/'codebook.md');effective_rules=load(reg/'registry_manifest.json')['effective_rule_version']
 sourceok={};rulesok={};action_decisions=[];group_decisions=[]
 for r in dec.to_dict('records'):
  if r['value']!='CONFIRM':continue
  ids=json.loads(r['unit_ids'])
  if r['type']=='SOURCE_VERSION':
   for uid in ids:sourceok[uid]=r['decision_event_id']
  if r['type']=='SEMANTIC_RULE':
   for uid in ids:rulesok[uid]=r['decision_event_id']
  if r['type']=='ACTION_COUNTING_BOUNDARY':action_decisions.append(r)
  if r['type']=='EXACT_GROUP_SCOPE':group_decisions.append(r)
 # Sources without open cards retain prior confirmed scope. Open cards need actual scoped decisions.
 source_pending,rule_pending=pending_scope(prep,cat,dec)
 pending=source_pending|rule_pending;catalog=cat.set_index('unit_id');fields={};conflicts=[];poolcache={};evidence=[]
 for r in hm[~hm.get('value_origin',pd.Series('',index=hm.index)).eq('RULE_DERIVABLE_FROM_INELIGIBLE')].to_dict('records'):fields[(r['unit_id'],r['field'])]=dict(r,parent_evidence_id='',derivation_version='',actual_identity=ctx.identity)
 auditcache={};audit_events=[]
 for key,path in ctx.audit_events():
  try:actual=validate_human_audit(ctx,path)
  except ValueError as ex:conflicts.append(dict(unit_id='',field='',reason='INVALID_HUMAN_AUDIT:'+str(ex)));continue
  auditcache[key]=dict(path=str(path),dependency_hash=digest(filelist(path)))
  for r in actual.to_dict('records'):
   audit_events.append(r);uid=r['unit_id'];k=r['field'];old=fields.get((uid,k))
   require(uid in catalog.index and r['source_hash']==catalog.loc[uid,'source_hash'] and r['rule_version']==codebookhash,'Audit human source/rule changed')
   if old:
    if old['value']!=r['value']:conflicts.append(dict(unit_id=uid,field=k,reason='HUMAN_AUDIT_CONFLICT_REQUIRES_EXPLICIT_CORRECTION'))
    continue
   fields[(uid,k)]=dict(r,parent_evidence_id='',derivation_version='',actual_identity=ctx.identity,value_origin='HUMAN_EXPLICIT_ZERO' if r['value']=='0' else 'EXPLICIT_HUMAN_FIELD')
 human_snapshot=list(fields.values())
 # Strict groups do not reduce the original corpus IDs or original sample identities.
 for d in group_decisions:
  ids=json.loads(d['unit_ids']);g=catalog.loc[ids]
  require(len(g[['source_hash','policy_version_id','exact_evidence_text','context','parent_clause_text']].drop_duplicates())==1,'Group semantic scope changed')
  rep=d['representative_id']
  for k in LABELS:
   representative=fields.get((rep,k))
   if not representative or representative['status']!='HUMAN_ADJUDICATED':continue
   for uid in ids:
    if uid in pending:continue
    key=(uid,k);old=fields.get(key)
    if old:
     if old['value']!=representative['value']:conflicts.append(dict(unit_id=uid,field=k,reason='GROUP_VS_HUMAN_CONFLICT'))
     continue
    fields[key]=dict(unit_id=uid,field=k,value=representative['value'],status='GROUP_REVIEW_CONFIRMED',evidence_id=digest([d['decision_event_id'],representative['evidence_id'],uid,k]),source_hash=catalog.loc[uid,'source_hash'],rule_version=codebookhash,parent_evidence_id=representative['evidence_id'],decision_event_id=d['decision_event_id'],derivation_version='',actual_identity=ctx.identity)
 for key,path in ctx.accepted_pools():
  if not (path/'accepted_fields.csv').exists():continue
  try:accepted=validate_evidence(ctx,path);poolcache[key]=dict(path=str(path),dependency_hash=digest(filelist(path)))
  except ValueError as e:conflicts.append(dict(unit_id='',field='',reason='INVALID_POOL:'+key+':'+str(e)));continue
  for r in accepted.to_dict('records'):
   uid=r['unit_id'];k=r['field'];old=fields.get((uid,k))
   if uid in pending:continue
   if old:
    if old['value']!=r['value']:conflicts.append(dict(unit_id=uid,field=k,reason='AUTO_VS_ACCEPTED_FIELD_CONFLICT'))
    continue
   fields[(uid,k)]=dict(r,parent_evidence_id='',derivation_version='',pool_event=key,actual_identity=ctx.identity)
 # Existing genuine GT positives are never overwritten by an accepted negative eligibility.
 blocked_derive=set()
 for uid in cat.unit_id:
  parent=fields.get((uid,'eligibility'))
  if not parent or parent['value']!='0' or uid in pending:continue
  positive=[k for k in LABELS[1:] if fields.get((uid,k),{}).get('value')=='1']
  if positive:
   blocked_derive.add(uid);conflicts.append(dict(unit_id=uid,field='eligibility',reason='ACCEPTED_NEGATIVE_WITH_REAL_POSITIVE_GT'));continue
  require(ctx.cfg['derive_ineligible_GT_zero'],'Codebook derivation disabled')
  for k in LABELS[1:]:
   # Preserve any explicit zero evidence; derive only otherwise unresolved fields.
   if (uid,k) not in fields:
    fields[(uid,k)]=dict(unit_id=uid,field=k,value='0',status='DERIVED_FROM_ACCEPTED_INELIGIBLE',evidence_id=digest([parent['evidence_id'],effective_rules,DERIVATION_VERSION,uid,k]),source_hash=catalog.loc[uid,'source_hash'],rule_version=effective_rules,parent_evidence_id=parent['evidence_id'],derivation_version=DERIVATION_VERSION,actual_identity=ctx.identity)
 return dict(prep=prep,reg=reg,cat=cat,dec=dec,codebookhash=codebookhash,effective_rules=effective_rules,pending=pending,catalog=catalog,fields=fields,conflicts=conflicts,poolcache=poolcache,auditcache=auditcache,audit_events=audit_events,human_snapshot=human_snapshot)

def assemble(ctx,out):
 state=resolve_current_fields(ctx)
 prep,reg,cat,dec,codebookhash,effective_rules,pending,catalog,fields,conflicts,poolcache,auditcache,audit_events=[state[k] for k in ['prep','reg','cat','dec','codebookhash','effective_rules','pending','catalog','fields','conflicts','poolcache','auditcache','audit_events']]
 csvout(out/'C2_human_audit_events.csv',audit_events,columns=['unit_id','field','value','status','source_hash','rule_version','role','reviewer','review_time','source_file_sha256','signature_sha256','protocol_sha256','identity','evidence_id'])
 csvout(out/'C2_human_field_snapshot.csv',state['human_snapshot'])
 conflictunits={r['unit_id'] for r in conflicts if r['unit_id']}
 candidate=[];missing=[]
 for uid in cat.unit_id:
  row=dict(unit_id=uid,policy_id=catalog.loc[uid,'policy_id'],source_hash=catalog.loc[uid,'source_hash'],source_rule_resolved=uid not in pending,identity=ctx.identity);statuses=[]
  for k in LABELS:
   e=fields.get((uid,k));row['C2_'+k]=e['value'] if e else '';row['evidence_'+k]=e['evidence_id'] if e else '';row['status_'+k]=e['status'] if e else 'UNRESOLVED';statuses.append(row['status_'+k])
   if not e:missing.append(dict(unit_id=uid,field=k,reason='NO_ACCEPTED_FIELD_EVIDENCE'))
  complete='UNRESOLVED' not in statuses and uid not in pending and uid not in conflictunits
  row['complete']=complete;row['record_status']='UNRESOLVED' if not complete else ('AUTO_ACCEPTED_UNDER_VALIDATED_PROTOCOL' if 'AUTO_ACCEPTED_UNDER_VALIDATED_PROTOCOL' in statuses or any(fields.get((uid,k),{}).get('parent_evidence_id')==fields.get((uid,'eligibility'),{}).get('evidence_id') and fields.get((uid,'eligibility'),{}).get('status')=='AUTO_ACCEPTED_UNDER_VALIDATED_PROTOCOL' for k in LABELS[1:]) else ('GROUP_REVIEW_CONFIRMED' if 'GROUP_REVIEW_CONFIRMED' in statuses else 'HUMAN_ADJUDICATED'))
  candidate.append(row)
 for field in fields.values():field['current_rules_version']=effective_rules
 csvout(out/'C2_candidate.csv',candidate);csvout(out/'field_evidence.csv',list(fields.values()));csvout(out/'unresolved_fields.csv',missing,columns=['unit_id','field','reason']);csvout(out/'conflicts.csv',conflicts,columns=['unit_id','field','reason'])
 from measurement import generate
 mv=generate(ctx,out,cat,pd.DataFrame(candidate),dec);measurement_ready=mv['POLICY_MEASUREMENT_READY'];c=pd.DataFrame(candidate).set_index('unit_id')
 from measurement import generate_groups as export_groups
 export_groups(ctx,out,cat,pd.DataFrame(candidate),pd.DataFrame(list(fields.values())),dec,pd.DataFrame(conflicts,columns=['unit_id','field','reason']))
 jsonout(out/'candidate_evidence_bundle.json',dict(identity=ctx.identity,registry_artifact=str(reg),registry_manifest_sha256=sha(reg/'registry_manifest.json'),registry_snapshot_sha256=sha(reg/'registry_snapshot.csv'),human_events_sha256=sha(reg/'human_registry_events.csv'),decision_registry_sha256=sha(reg/'decision_registry.csv'),codebook_sha256=codebookhash,corpus_sha256=sha(prep/'corpus.csv'),field_evidence_sha256=sha(out/'field_evidence.csv'),mapping_sha256=sha(out/'action_unit_mapping.csv'),measurement_hashes={n:sha(out/n) for n in ['action_unit_summary.csv','policy_level_shares.csv','action_prevalence.csv','equal_action_weight_sensitivity.csv','measurement_contract.json','measurement_validation.json']},pools=poolcache,human_audits=auditcache,c2_human_snapshot_sha256=sha(out/'C2_human_field_snapshot.csv'),c2_human_audit_events_sha256=sha(out/'C2_human_audit_events.csv')))
 jsonout(out/'candidate_status.json',dict(identity=ctx.identity,labels_complete=bool(c.complete.all()),complete_rows=int(c.complete.sum()),total_rows=len(c),conflicts=len(conflicts),derived_fields=sum(r['status']=='DERIVED_FROM_ACCEPTED_INELIGIBLE' for r in fields.values()),actual_group_fields=sum(r['status']=='GROUP_REVIEW_CONFIRMED' for r in fields.values()),actual_auto_fields=sum(r['status']=='AUTO_ACCEPTED_UNDER_VALIDATED_PROTOCOL' for r in fields.values()),C2_LABELS_FROZEN=False,POLICY_MEASUREMENT_READY=measurement_ready,part2_started=False))
if __name__=='__main__':
 from coding_pipeline import main
 main(forced='assemble-candidate')
