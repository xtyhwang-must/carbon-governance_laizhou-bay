"""Self-contained reading and fixed-parameter replay package; status is never implied by copying."""
from common import *

def make_bundle(ctx,out,formal=False):
 out=longpath(out);out.mkdir(parents=True,exist_ok=True);ass=ctx.artifact('assemble-candidate');led=ctx.artifact('part1-ledger');tr=ctx.artifact('train');prep=ctx.artifact('prepare');reg=ctx.artifact('build-registry')
 for n in ['field_evidence.csv','action_unit_mapping.csv','action_unit_summary.csv','policy_level_shares.csv','action_prevalence.csv','equal_action_weight_sensitivity.csv']:shutil.copyfile(ass/n,out/n)
 shutil.copyfile(ass/'C2_candidate.csv',out/'policy_coding_C2.csv')
 for n in ['policy_registry.csv','policy_source_scope.csv','policy_stage_registry.csv','policy_share_quality_report.csv','coding_method_current.md','quality_contract.json','part1_evidence_bundle.json','policy_statistical_status.csv']:shutil.copyfile(led/n,out/n)
 stage_name='stage_composition.csv' if (led/'stage_composition.csv').exists() else 'stage_composition_PREVIEW.csv';shutil.copyfile(led/stage_name,out/stage_name)
 for n in ['diagnostic_model.joblib','model_lock.json','limited_development_results.csv','development_metrics.csv']:shutil.copyfile(tr/n,out/n)
 shutil.copyfile(ctx.code/'standalone_replay.py',out/'standalone_replay.py')
 cat=read(prep/'corpus.csv');pred=read(ctx.artifact('predict')/'corpus_predictions.csv').set_index('unit_id');sample=cat.groupby('policy_id',sort=True).head(1).head(12)
 rr=[]
 for r in sample.itertuples():rr.append(dict(unit_id=r.unit_id,text=r.exact_evidence_text,context=r.parent_context_model,**{'score_'+k:pred.loc[r.unit_id,'score_'+k] for k in LABELS}))
 csvout(out/'replay_model_inputs.csv',rr)
 evidence=out/'evidence';evidence.mkdir(exist_ok=True)
 for n in ['registry_snapshot.csv','human_registry_events.csv','decision_registry.csv','decision_events_all.csv','registry_manifest.json']:shutil.copyfile(reg/n,evidence/n)
 sources=out/'sources';sources.mkdir(exist_ok=True)
 for r in cat.drop_duplicates('source_clean_path').itertuples():shutil.copyfile(longpath(r.source_clean_path),sources/(r.policy_id+'.txt'))
 sc=read(out/'policy_source_scope.csv');sc['source_path']=sc.policy_id.map(lambda p:'sources/'+p+'.txt');sc['raw_path']='ORIGINAL_CARRIER_LOCATION_IN_WORKSPACE_AUDIT_NOT_USED_BY_REPLAY';csvout(out/'policy_source_scope.csv',sc)
 code=out/'code';code.mkdir(exist_ok=True)
 for p in ctx.code.glob('*.py'):shutil.copyfile(p,code/p.name)
 pin=ctx.root/'frozen_training_reuse.json'
 if pin.exists() and load(pin)['model_sha256']==sha(tr/'diagnostic_model.joblib'):
  binding=load(pin);original=ctx.root/binding['original_code_snapshot'];frozen=out/'original_training_code';frozen.mkdir(exist_ok=True)
  for n in ['train_limited.py','common.py']:shutil.copyfile(original/n,frozen/n)
  jsonout(out/'training_provenance.json',dict(model_sha256=sha(tr/'diagnostic_model.joblib'),model_was_not_refitted_for_postprocessing=True,original_training_code={n:sha(frozen/n) for n in ['train_limited.py','common.py']},current_postprocessing_code={p.name:sha(p) for p in code.glob('*.py')},identity='ORIGINAL_TRAINING_SEPARATE_FROM_CURRENT_IMPLEMENTATION'))
 else:
  jsonout(out/'training_provenance.json',dict(model_sha256=sha(tr/'diagnostic_model.joblib'),training_code=ctx.manifest['stages']['train']['code'],training_artifact_identity=ctx.manifest['stages']['train']['fingerprint'],identity='CURRENT_RETRAINED_MODEL',old_original_training_code_directory='HISTORICAL_CONTROL_ONLY_NOT_CURRENT_TRAINING'))
 appendix=ctx.root/'appendix'
 if appendix.exists():shutil.copytree(appendix,out/'appendix',dirs_exist_ok=True)
 js=dict(identity=ctx.identity,release_status='FORMAL_PART1_RELEASE' if formal else 'CANDIDATE_REPLAY_ONLY_NOT_FORMAL_RELEASE',model_sha256=sha(tr/'diagnostic_model.joblib'),formal_stage_file=stage_name=='stage_composition.csv',files={k:v for k,v in filelist(out).items() if k not in ['replay_manifest.json','replay_result.json','publication_manifest.json','author_approval.json','README.md','environment.json']},stage_file=stage_name,full_training_repeated=False)
 jsonout(out/'replay_manifest.json',js)
 (out/'README.md').write_text('# Portable coding replay\n\nStatus: '+js['release_status']+'.\n\nRun `python standalone_replay.py --root .` from this folder. This checks hashes, independently reconstructs policy/stage arithmetic (including unavailable states) and replays 12 fixed-parameter model cases. It never fits. Requires Python, numpy, scipy, pandas, scikit-learn and joblib compatible with environment.json. Code in code/ is preserved implementation, but the full development run uses the workspace configuration and complete development inputs; this package does not claim a full retraining replication.\n',encoding='utf-8')
 import sys,importlib.metadata
 jsonout(out/'environment.json',dict(python=sys.version,packages={p:importlib.metadata.version(p) for p in ['numpy','scipy','pandas','scikit-learn','joblib','matplotlib']}))
 return js
