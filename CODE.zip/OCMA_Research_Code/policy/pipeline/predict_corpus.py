"""Whole-corpus suggestions; never writes C2."""
from common import *
from train_limited import transform,threshold_outputs
import joblib
def predict(ctx,out):
 prep=ctx.artifact('prepare');tr=ctx.artifact('train');lock=load(tr/'model_lock.json');require(sha(tr/'diagnostic_model.joblib')==lock['model_sha256'],'Model changed')
 m=joblib.load(tr/'diagnostic_model.joblib');cat=read(prep/'corpus.csv');X=transform(m['vectorizers'],cat);s=np.full((len(cat),10),np.nan)
 for j,head in enumerate(m['models']):
  if head is not None:s[:,j]=head.predict_proba(X)[:,1]
 raw,hard=threshold_outputs(s,m['contracts']);usable_raw,usable_hard=threshold_outputs(s,m['contracts'],usable=True);result=cat[['unit_id','policy_id','source_hash','split']].copy()
 for j,k in enumerate(LABELS):
  result['score_'+k]=s[:,j];result['diagnostic_raw_'+k]=raw[:,j];result['diagnostic_hard_'+k]=hard[:,j]
  result['usable_threshold_'+k]=m['contracts'][k]['usable_threshold']
  result['usable_raw_'+k]=usable_raw[:,j];result['usable_hard_'+k]=usable_hard[:,j]
  result['development_usable_output_status_'+k]=m['contracts'][k]['status']
  result['diagnostic_metric_pass_'+k]=lock['label_usage_status'][k]['end_to_end']['metric_requirement_pass']
  result['applicability_'+k]='ALL_ALLOWED_HUMAN_TRAINING_DOMAIN_NOT_INDEPENDENT_CORPUS_VALIDATION' if j==0 or m['spec']=='H-ALLDOMAIN' else 'HUMAN_ELIGIBLE_ONLY_OUTSIDE_UNVALIDATED'
  result['formal_C2_'+k]=''
 result['postprocessing_code_sha256']=sha(Path(__file__));result['training_model_sha256']=lock['model_sha256']
 result['identity']=ctx.identity;result['automatic_pool_approval']=False;result['score_identity']='UNCALIBRATED_SCORE'
 csvout(out/'corpus_predictions.csv',result)
 proposals=[]
 for direction,threshold in [('POSITIVE',.9),('NEGATIVE',.1)]:
  members=result.loc[result.score_eligibility.ge(threshold) if direction=='POSITIVE' else result.score_eligibility.le(threshold),'unit_id'].tolist()
  proposals.append(dict(label='eligibility',direction=direction,score_cut=threshold,pool_n=len(members),identity=ctx.identity,model_sha256=lock['model_sha256'],approved=False,note='Proposal only; local audit can be considered even if global model fails'))
 jsonout(out/'local_pool_proposals.json',proposals)
if __name__=='__main__':
 from coding_pipeline import main
 main(forced='predict')
