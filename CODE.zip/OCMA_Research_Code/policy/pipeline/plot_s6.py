"""Real-data-only plotting entry. No figure is produced while training is NOT_RUN."""
import argparse,json,hashlib
from pathlib import Path
def main():
 p=argparse.ArgumentParser();p.add_argument('--manifest',required=True);p.add_argument('--output',required=True);a=p.parse_args();m=json.loads(Path(a.manifest).read_text(encoding='utf-8'))
 if m['identity']!='REAL' or not m.get('real_training_artifact'):raise SystemExit('NOT_RUN: real trained model required; synthetic performance prohibited')
 tr=Path(m['real_training_artifact']);assert hashlib.sha256((tr/'diagnostic_model.joblib').read_bytes()).hexdigest()==m['model_sha256']
 import pandas as pd,numpy as np,matplotlib.pyplot as plt
 lock=json.loads((tr/'model_lock.json').read_text(encoding='utf-8'));assert lock['identity']=='REAL';selected=lock['selected_diagnostic_model'];df=pd.read_csv(tr/'OOF_scores.csv');df=df[(df.spec==selected['spec'])&(df.C==selected['C'])];labels=['eligibility','G1','G2','G3','T1','T2','T3','T4','T5','T6'];rows=[]
 scores=df[['score_'+k for k in labels]].to_numpy();truth=df[['human_'+k for k in labels]].to_numpy();raw=np.full(scores.shape,np.nan)
 for j,k in enumerate(labels):
  cut=lock['contracts'][k]['diagnostic_threshold']
  if cut is not None:raw[:,j]=np.where(np.isfinite(scores[:,j]),scores[:,j]>=cut,np.nan)
 hard=raw.copy();hard[:,1:]*=raw[:,0:1]
 for j,k in enumerate(labels):
  y=truth[:,j];pred=hard[:,j];tp=int(((y==1)&(pred==1)).sum());fp=int(((y==0)&(pred==1)).sum());pos=int((y==1).sum())
  rows.append(dict(label=k,positive_n=pos,head_miss=int(((y==1)&(raw[:,j]==0)).sum()),gate_only_miss=int(((y==1)&(raw[:,j]==1)&(raw[:,0]==0)).sum()) if j else 0,abstained_positive=int(((y==1)&~np.isfinite(pred)).sum()),precision=tp/(tp+fp) if tp+fp else np.nan,overall_recall=tp/pos if pos else np.nan,scope='DEVELOPMENT_OOF_SELECTED_DIAGNOSTIC'))
 out=Path(a.output);out.mkdir(parents=True,exist_ok=True);z=pd.DataFrame(rows);z.to_csv(out/'Figure_S6_data.csv',index=False)
 plt.rcParams.update({'font.family':'DejaVu Sans','svg.fonttype':'none'});fig,axes=plt.subplots(1,2,figsize=(10,5),layout='constrained');z.plot.barh(x='label',y=['head_miss','gate_only_miss','abstained_positive'],stacked=True,ax=axes[0]);axes[0].set_xlabel('Positive cases missed or unanswered');axes[0].set_ylabel('Label');axes[0].legend(fontsize=8)
 axes[1].scatter(z.precision,z.label,label='Precision',marker='o');axes[1].scatter(z.overall_recall,z.label,label='Overall recall',marker='x');axes[1].set_xlim(0,1.02);axes[1].set_xlabel('Development OOF metric');axes[1].legend();fig.savefig(out/'Figure_S6.svg');fig.savefig(out/'Figure_S6.pdf');fig.savefig(out/'Figure_S6.png',dpi=300)
if __name__=='__main__':main()
