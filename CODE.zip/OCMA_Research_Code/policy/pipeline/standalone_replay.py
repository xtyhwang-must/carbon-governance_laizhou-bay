"""Portable fixed-parameter replay and independent policy/stage arithmetic. Never fits."""
import argparse,csv,json,hashlib
from pathlib import Path
import numpy as np

L=['eligibility','G1','G2','G3','T1','T2','T3','T4','T5','T6']
def rows(p):
 with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def digest_file(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def independent_counts(candidate,mapping,stage_registry):
 c={r['unit_id']:r for r in candidate};assert len(c)==len(candidate)
 assert {r['unit_id'] for r in mapping}==set(c) and len(mapping)==len(c)
 actions={};policies={};counted_ids={}
 for r in mapping:
  uid=r['unit_id'];v=c[uid];pol=v['policy_id'];policies.setdefault(pol,{'ready':True,'actions':set()})
  assert r['policy_id']==pol
  if str(v['complete']).lower()!='true':policies[pol]['ready']=False;continue
  if v['C2_eligibility']=='0':assert r['counting_status']=='NOT_COUNTED_INELIGIBLE' and r['action_unit_id']=='';continue
  if r['counting_status']!='COUNTED_ELIGIBLE' or not r['action_unit_id']:policies[pol]['ready']=False;continue
  aid=r['action_unit_id'];vector=tuple(v['C2_'+k] for k in L)
  assert all(x in ['0','1'] for x in vector) and vector[0]=='1'
  if aid in actions:assert actions[aid]==(pol,vector),'Cross-policy or inconsistent merged action'
  actions[aid]=(pol,vector);policies[pol]['actions'].add(aid)
 result=[]
 for pol,s in policies.items():
  vec=[actions[x][1] for x in s['actions']];r={'policy_id':pol,'measurement_ready':s['ready'],'eligible_action_n':len(vec) if s['ready'] else ''}
  for ks in [L[1:4],L[4:]]:
   den=sum(int(v[L.index(k)]) for v in vec for k in ks);r[ks[0][0]+'_assignment_denominator']=den if s['ready'] else ''
   for k in ks:r[k]=sum(int(v[L.index(k)]) for v in vec)/den if s['ready'] and den else ''
  result.append(r)
 p={r['policy_id']:r for r in result};st={}
 assert len({r['policy_id'] for r in stage_registry})==len(stage_registry) and set(p)=={r['policy_id'] for r in stage_registry}
 for r in stage_registry:st.setdefault(r['stage'],[]).append(r['policy_id'])
 stages=[]
 for stage,ids in st.items():
  complete=all(p[i]['measurement_ready'] for i in ids);r={'stage':stage,'total_policy_n':len(ids)}
  for ks in [L[1:4],L[4:]]:
   valid=[i for i in ids if p[i]['measurement_ready'] and all(p[i][k]!='' for k in ks)];r[ks[0][0]+'_defined_policy_n']=len(valid)
   for k in ks:r[k]=sum(p[i][k] for i in valid)/len(valid) if complete and valid else ''
  stages.append(r)
 return result,stages

def main(root):
 root=Path(root).resolve();manifest=json.loads((root/'replay_manifest.json').read_text(encoding='utf-8'))
 for name,h in manifest['files'].items():
  p=(root/name).resolve();assert p.is_relative_to(root) and digest_file(p)==h,'Missing/changed package file: '+name
 policy,stage=independent_counts(rows(root/'policy_coding_C2.csv'),rows(root/'action_unit_mapping.csv'),rows(root/'policy_stage_registry.csv'))
 actual={r['policy_id']:r for r in rows(root/'policy_level_shares.csv')}
 for r in policy:
  a=actual[r['policy_id']]
  for k,v in r.items():
   if k=='measurement_ready':assert (a[k].lower()=='true')==v
   elif k=='policy_id':assert a[k]==v
   elif v=='':assert a[k]==''
   else:assert np.isclose(float(a[k]),float(v),rtol=0,atol=1e-12),(r['policy_id'],k)
 actualstage={r['stage']:r for r in rows(root/manifest['stage_file'])}
 for r in stage:
  a=actualstage[r['stage']]
  for k,v in r.items():
   if k=='stage' or v=='':assert a[k]==v
   else:assert np.isclose(float(a[k]),float(v),rtol=0,atol=1e-12)
 import joblib
 from scipy.sparse import hstack
 model=joblib.load(root/'diagnostic_model.joblib');sample=rows(root/'replay_model_inputs.csv')
 X=hstack([model['vectorizers'][0].transform([r['text'] for r in sample]),model['vectorizers'][1].transform([r['context'] for r in sample])*.3],format='csr');maxerr=0.
 for j,k in enumerate(L):
  if model['models'][j] is None:continue
  got=model['models'][j].predict_proba(X)[:,1];exp=np.array([float(r['score_'+k]) for r in sample]);maxerr=max(maxerr,float(np.max(abs(got-exp))));assert np.allclose(got,exp,rtol=0,atol=1e-10)
 report=dict(identity='REAL_FIXED_PARAMETER_REPLAY',file_hashes_verified=True,policy_count=len(policy),stage_count=len(stage),defined_policy_count=sum(r['measurement_ready'] for r in policy),model_cases=len(sample),max_score_error=maxerr,full_training_repeated=False,source_package_status=manifest['release_status'],formal_release_recomputed=manifest['release_status']=='FORMAL_PART1_RELEASE',hidden_old_directory_dependencies=False)
 (root/'replay_result.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps(report))
 return report
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--root',default='.');a=p.parse_args();main(a.root)
