"""Signed policy-specific quality assessments; never substitute global model accuracy."""
from common import *

def sensitivity(count,den,q,error_actions):
 require(den>0 and error_actions>=0,'Defined denominator and nonnegative error budget needed')
 if error_actions==0:return count/den,count/den
 return max(0.,(count-error_actions)/(den+q*error_actions)),min(1.,(count+error_actions)/max(1,den-q*error_actions))

def evidence_quality_gate(fields, ids, review, validated_auto_ids=None, group=None):
 # A signed error budget is a sensitivity assumption, never quality evidence.
 needed={(uid,k) for uid in ids for k in (['eligibility']+(LABELS[1:4] if group=='G' else LABELS[4:]))} if group else {(uid,k) for uid in ids for k in LABELS}
 validated_auto_ids=set(validated_auto_ids or [])
 actual={(r.unit_id,r.field) for r in fields.itertuples() if str(r.evidence_id).strip() and (r.status in ['HUMAN_ADJUDICATED','GROUP_REVIEW_CONFIRMED','DERIVED_FROM_ACCEPTED_INELIGIBLE'] or r.status=='AUTO_ACCEPTED_UNDER_VALIDATED_PROTOCOL' and r.evidence_id in validated_auto_ids)}
 complete_human=needed<=actual
 findings=all(str(review.get(k,'')).strip() for k in ['review_findings','omission_check','rare_label_check','small_denominator_check','observed_error_check'])
 evidence_refs=str(review.get('evidence_ids','')).split(';')
 known=set(fields.evidence_id)
 bound=bool(evidence_refs) and all(x and x in known for x in evidence_refs)
 has_auto=fields.status.eq('AUTO_ACCEPTED_UNDER_VALIDATED_PROTOCOL').any()
 pool_impact=not has_auto or bool(str(review.get('policy_pool_impact_check','')).strip())
 return bool(complete_human and findings and bound and pool_impact),dict(complete_validated_field_coverage=complete_human,documented_policy_checks=findings,bound_actual_evidence=bound,policy_pool_impact_documented=pool_impact,sensitivity_is_quality_evidence=False)

def ingest(ctx,out,review,signature,assembly=None):
 if 'group' in read_review(review).columns:return ingest_group(ctx,out,review,signature,assembly)
 led=ctx.artifact('part1-ledger');ass=assembly or ctx.artifact('assemble-candidate');s=load(signature)
 signed(s,'CONFIRM_POLICY_SPECIFIC_SHARE_QUALITY_ASSESSMENT',ctx.identity)
 require(s['review_sha256']==sha(review) and s['candidate_sha256']==sha(ass/'C2_candidate.csv') and s['shares_sha256']==sha(ass/'policy_level_shares.csv') and s['mapping_sha256']==sha(ass/'action_unit_mapping.csv') and s['quality_contract_sha256']==sha(led/'quality_contract.json'),'Policy quality approval scope changed')
 require(s.get('approve_quality_contract') is True,'Research-use tolerance requires explicit approval')
 x=read_review(review);require(x.policy_id.is_unique,'Duplicate policy quality assessment')
 stats=read(led/'policy_statistical_status.csv').set_index('policy_id');c=read(ass/'C2_candidate.csv');f=read(ass/'field_evidence.csv');contract=load(led/'quality_contract.json');tol=contract['proposed_max_absolute_share_sensitivity'];results=[]
 for r in x.to_dict('records'):
  pol=r['policy_id'];require(pol in stats.index,'Unknown policy')
  require(boolean(stats.loc[pol,'measurement_ready']),'Cannot assess usable shares before counting/labels complete')
  require(r.get('decision') in ['ACCEPT_CONDITIONALLY','REJECT','UNRESOLVED'],'Explicit policy quality judgment required')
  ids=set(c.loc[c.policy_id.eq(pol),'unit_id']);fields=f[f.unit_id.isin(ids)]
  # The implemented human-review path supports conservative declared sensitivity, not a fabricated statistical error bound.
  noauto=not fields.status.eq('AUTO_ACCEPTED_UNDER_VALIDATED_PROTOCOL').any()
  require(r.get('basis')=='POLICY_SPECIFIC_HUMAN_REVIEW_CONSERVATIVE_SENSITIVITY' and r.get('review_findings','').strip() and r.get('error_budget_rationale','').strip(),'Document actual policy-specific review and conservative error budget')
  e=int(r['residual_error_actions']);require(e>=0,'Negative error budget')
  maxchange=0.;bounds={};defined=True
  for group,keys in [('G',LABELS[1:4]),('T',LABELS[4:])]:
   den=int(stats.loc[pol,group+'_assignment_denominator'])
   if den==0:defined=False;continue
   for k in keys:
    est=float(stats.loc[pol,k]);lo,hi=sensitivity(round(est*den),den,len(keys),e);bounds[k]=[lo,hi];maxchange=max(maxchange,est-lo,hi-est)
  validated_auto=set()
  if not noauto:
   from pool_audit import validate_evidence
   for _,path in ctx.accepted_pools():
    accepted_fields=validate_evidence(ctx,path)
    validated_auto.update(accepted_fields.evidence_id)
  evidence_ok,quality_checks=evidence_quality_gate(fields,ids,r,validated_auto)
  accepted=bool(r['decision']=='ACCEPT_CONDITIONALLY' and evidence_ok)
  results.append(dict(policy_id=pol,accepted=accepted,basis=r['basis'],quality_checks=json.dumps(quality_checks),sensitivity_within_proposed_tolerance=bool(maxchange<=tol),error_budget=e,max_absolute_sensitivity=maxchange,bounds=json.dumps(bounds),interval_identity='AUTHOR_REVIEWED_SENSITIVITY_NOT_CONFIDENCE_INTERVAL',review_findings=r['review_findings'],error_budget_rationale=r['error_budget_rationale'],reason='ACCEPTED_ON_COMPLETE_REAL_FIELD_EVIDENCE_AND_DOCUMENTED_POLICY_CHECKS' if accepted else 'MISSING_ACTUAL_POLICY_QUALITY_EVIDENCE_OR_REJECTED;DECLARED_BUDGET_CANNOT_PASS'))
 csvout(out/'quality_assessments.csv',results);shutil.copyfile(review,out/'actual_policy_quality_review.csv');shutil.copyfile(signature,out/'actual_signature.json')
 jsonout(out/'quality_binding.json',dict(candidate_sha256=s['candidate_sha256'],shares_sha256=s['shares_sha256'],mapping_sha256=s['mapping_sha256'],quality_contract_sha256=s['quality_contract_sha256'],review_sha256=sha(review),signature_sha256=sha(signature),identity=ctx.identity))

def apply_assessments(ctx,ass,contract_path,rows):
 idx={r['policy_id']:r for r in rows};valid=[]
 for _,path in ctx.events('ingest-share-quality'):
  b=load(path/'quality_binding.json')
  if b.get('identity')=='POLICY_GROUP_QUALITY':continue
  if b['candidate_sha256']!=sha(ass/'C2_candidate.csv') or b['shares_sha256']!=sha(ass/'policy_level_shares.csv') or b['mapping_sha256']!=sha(ass/'action_unit_mapping.csv') or b['quality_contract_sha256']!=sha(contract_path):continue
  for r in read(path/'quality_assessments.csv').to_dict('records'):
   if r['policy_id'] in idx:
    idx[r['policy_id']].update(share_quality_accepted=boolean(r['accepted']),quality_evidence='SIGNED_POLICY_SPECIFIC_REVIEW:'+b['signature_sha256'],residual_sensitivity=r['bounds'],quality_acceptance_identity=r['interval_identity'],additional_check=r['reason']);valid.append(path)
 return list(idx.values()),bool(valid)

def ingest_group(ctx,out,review,signature,assembly=None):
 ass=assembly or ctx.artifact('assemble-candidate');x=read_review(review);s=load(signature)
 signed(s,'CONFIRM_POLICY_GROUP_SHARE_QUALITY',ctx.identity)
 require(s['review_sha256']==sha(review),'Group quality review changed')
 require(not x.duplicated(['policy_id','group']).any(),'Duplicate policy/group')
 shares=read(ass/'policy_group_shares.csv').set_index(['policy_id','group']);c=read(ass/'C2_candidate.csv');f=read(ass/'effective_field_evidence.csv');results=[]
 for r in x.to_dict('records'):
  key=(r['policy_id'],r['group']);require(key in shares.index,'Unknown policy/group');p=shares.loc[key];binding=p.group_binding_sha256
  require(s.get('group_bindings',{}).get('|'.join(key))==binding,'Exact group evidence changed')
  require(boolean(p.measurement_ready) and p.undefined_reason=='DEFINED','Undefined/incomplete group shares cannot be accepted')
  ids=set(c.loc[c.policy_id.eq(key[0]),'unit_id']);ks=['eligibility']+(LABELS[1:4] if key[1]=='G' else LABELS[4:]);fields=f[f.unit_id.isin(ids)&f.field.isin(ks)]
  auto=set()
  if fields.status.eq('AUTO_ACCEPTED_UNDER_VALIDATED_PROTOCOL').any():
   from pool_audit import validate_evidence
   for _,a in ctx.accepted_pools():auto.update(validate_evidence(ctx,a).evidence_id)
  ok,checks=evidence_quality_gate(fields,ids,r,auto,key[1]);require(r.get('decision') in ['ACCEPT_CONDITIONALLY','REJECT','UNRESOLVED'],'Missing explicit group judgment')
  results.append(dict(policy_id=key[0],group=key[1],accepted=ok and r['decision']=='ACCEPT_CONDITIONALLY',group_binding_sha256=binding,quality_checks=json.dumps(checks),interpretation='CONDITIONAL_AUTHOR_ASSESSMENT_NOT_ZERO_ERROR_PROOF',review_findings=r.get('review_findings',''),evidence_ids=r.get('evidence_ids',''),risk_limits='Omission, rare classes, small denominators and actual pool errors require scoped interpretation; no uniform CI imposed'))
 csvout(out/'quality_assessments.csv',results);shutil.copyfile(review,out/'actual_policy_quality_review.csv');shutil.copyfile(signature,out/'actual_signature.json');jsonout(out/'quality_binding.json',dict(identity='POLICY_GROUP_QUALITY',review_sha256=sha(review),signature_sha256=sha(signature),group_bindings=s['group_bindings']))

def apply_group_assessments(ctx,ass):
 p=read(ass/'policy_group_shares.csv');p['quality_accepted']=False
 for _,path in ctx.events('ingest-share-quality'):
  binding=load(path/'quality_binding.json')
  if binding.get('identity')!='POLICY_GROUP_QUALITY':continue
  for r in read(path/'quality_assessments.csv').to_dict('records'):
   mask=p.policy_id.eq(r['policy_id'])&p.group.eq(r['group'])&p.group_binding_sha256.eq(r['group_binding_sha256'])&p.measurement_ready.eq('True')&p.undefined_reason.eq('DEFINED')
   p.loc[mask,'quality_accepted']=boolean(r['accepted'])
 return p

def publish_group(ctx,out,approval):
 from candidate_publisher import validate_policy_groups
 validation=validate_policy_groups(ctx);jsonout(out/'independent_group_arithmetic.json',validation)
 ass=ctx.artifact('assemble-candidate');p=apply_group_assessments(ctx,ass);s=load(approval);signed(s,'APPROVE_EXACT_POLICY_GROUP_RELEASE',ctx.identity);rows=[]
 for key,binding in s['group_bindings'].items():
  policy,group=key.split('|');z=p[p.policy_id.eq(policy)&p.group.eq(group)&p.group_binding_sha256.eq(binding)]
  require(len(z)==1 and boolean(z.iloc[0].quality_accepted),'Group quality not accepted for exact scope');rows.append(z.iloc[0].to_dict())
 require(rows,'No groups requested');csvout(out/'released_policy_group_shares.csv',rows);shutil.copyfile(approval,out/'actual_approval.json');jsonout(out/'release_manifest.json',dict(identity='SCOPED_GROUP_INTERMEDIATE_RELEASE',group_bindings=s['group_bindings'],files=filelist(out),C2_LABELS_FROZEN=False,PART1_COMPLETED=False,part2_started=False))
