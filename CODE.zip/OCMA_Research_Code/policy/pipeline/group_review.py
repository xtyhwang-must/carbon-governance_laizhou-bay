"""One scoped missing-field interface; every return is C2-only and explicit."""
from common import *
from group_readiness import effective_field_evidence
import argparse,html

def normalized_return(payload,contract):
 require(payload['contract_sha256']==contract['contract_sha256'],'Review contract mismatch')
 expected={r['unit_id']:r for r in contract['rows']};seen=set();values=[];boundaries=[]
 for row in payload['rows']:
  uid=row['unit_id'];require(uid in expected and uid not in seen,'Unknown/duplicate unit');seen.add(uid);r=expected[uid]
  answers=row.get('answers',{});require(set(answers)<=set(r['missing_fields']),'Existing fields cannot be overwritten')
  for k,v in answers.items():
   require(v in ['','0','1','UNRESOLVED'],'Invalid answer')
   if v in ['0','1']:values.append(dict(unit_id=uid,field=k,value=v,zero_origin='HUMAN_EXPLICIT_ZERO' if v=='0' else 'EXPLICIT_HUMAN_FIELD'))
  selected=row.get('T_selected',[]);require(len(selected)==len(set(selected)) and set(selected)<=set(r['missing_fields'])&set(LABELS[4:]),'Invalid T selections')
  complete=row.get('T_complete_checked',False);require(isinstance(complete,bool),'Explicit T completeness boolean required')
  for k in set(r['missing_fields'])&set(LABELS[4:]):
   if k in answers and answers[k] in ['0','1']:continue
   if k in selected or complete:values.append(dict(unit_id=uid,field=k,value='1' if k in selected else '0',zero_origin='EXPLICIT_HUMAN_FIELD' if k in selected else 'HUMAN_COMPLETE_GROUP_UNSELECTED'))
  if row.get('confirm_single_action') is True:
   require(r['boundary_needed'],'Boundary already completed')
   eligibility=answers.get('eligibility',r['known'].get('eligibility',''))
   require(eligibility=='1','Single-action approval needs actual eligible judgment')
   boundaries.append(uid)
 require(len(values)==len({(r['unit_id'],r['field']) for r in values}),'Duplicate answer field')
 return values,boundaries

def export(ctx,out,policy_ids=None,groups='ALL',reading_budget=None,quality_summary=None):
 out.mkdir(parents=True,exist_ok=True);ass=ctx.artifact('assemble-candidate');c=read(ass/'C2_candidate.csv').set_index('unit_id');cat=read(ctx.artifact('prepare')/'corpus.csv').set_index('unit_id');f=effective_field_evidence(ctx);fi=f.set_index(['unit_id','field'])
 require(groups in ['G','T','ALL'],'Select G, T or ALL')
 requested=policy_ids or list(cat.policy_id.unique());require(set(requested)<=set(cat.policy_id),'Unknown policy selection')
 require(reading_budget is None or reading_budget>0,'Positive reading budget required')
 target=['eligibility']+(LABELS[1:4] if groups=='G' else LABELS[4:] if groups=='T' else LABELS[1:]);rows=[];requests=[]
 for pid in requested:
  for uid in cat.index[cat.policy_id.eq(pid)]:
   r=cat.loc[uid];known={k:fi.loc[(uid,k),'value'] for k in LABELS if (uid,k) in fi.index};missing=[k for k in target if k not in known];boundary=c.loc[uid,'action_boundary_ready']!='True' and known.get('eligibility')!='0';source=c.loc[uid,'source_rule_resolved']=='True'
   if not missing and not boundary and source:continue
   if reading_budget is not None and len(rows)>=reading_budget:continue
   row=dict(unit_id=uid,policy_id=r.policy_id,text=r.exact_evidence_text,context=r.context,source_location=r.source_location,source_hash=r.source_hash,known=known,missing_fields=missing,boundary_needed=boundary,source_ready=source,purpose='POLICY_GROUP_'+groups,model_suggestions_shown=False)
   recovery=ctx.root/'minimal_execution_repair_20261028/DY_source_recovery.json'
   if recovery.exists():
    rec=load(recovery)
    if uid==rec['target_unit_id'] and boundary:
     row.update(reconstructed_text=rec['restored_text'],action_proposal=dict(rule_text=rec['decision_required'],source_recovery_sha256=sha(recovery),covered_unit_ids=[x['unit_id'] for x in rec['segments']],action_unit_id='ACT_'+digest(['SOURCE_RESTORED',uid,sha(recovery)])[:24]))
   rows.append(row)
   for k in missing:requests.append(dict(unit_id=uid,field=k,role='C2_ONLY'))
 small=requested

 data=dict(identity='MISSING_FIELDS_ONLY_C2_ONLY',rows=rows,small_policy_counts={p:int(cat.policy_id.eq(p).sum()) for p in small},selected_groups=groups,reading_budget=reading_budget,model_sha256=sha(ctx.artifact('train')/'diagnostic_model.joblib'),existing_evidence_sha256=sha(ass/'field_evidence.csv'));data['quality_summaries']=load(quality_summary) if quality_summary else [];data['contract_sha256']=digest(data);jsonout(out/'group_review_contract.json',data);csvout(out/'missing_field_requests.csv',requests)
 from coding_pipeline import execute
 sid='GROUP_MISSING_'+data['contract_sha256'][:16];result=execute(ctx,'register-adjudication',input=str(out/'missing_field_requests.csv'),pool_id=sid) if requests else dict(state='BOUNDARY_OR_SOURCE_ONLY_NO_ADJUDICATION');require(result['state'] in ['COMPLETED','BOUNDARY_OR_SOURCE_ONLY_NO_ADJUDICATION'],'Review registration failed');jsonout(out/'registered_scope.json',dict(scope_id=sid,contract_sha256=data['contract_sha256']))
 csvout(out/'review_unit_index.csv',[dict(unit_id=r['unit_id'],policy_id=r['policy_id'],known=json.dumps(r['known']),missing_fields=';'.join(r['missing_fields']),boundary_needed=r['boundary_needed'],source_ready=r['source_ready'],purpose=r['purpose']) for r in rows])
 payload=json.dumps(data,ensure_ascii=False).replace('</','<\\/')
 page='''<!doctype html><meta charset="utf-8"><title>第一部分：集中补缺字段</title><style>body{font:16px sans-serif;max-width:1100px;margin:auto;line-height:1.6}article{border:1px solid #ccc;padding:16px;margin:16px 0}.known{background:#eee;padding:8px}pre{white-space:pre-wrap}select{margin:8px}label{display:inline-block;margin:7px}input,button{font-size:16px}</style><h1>只补尚缺字段</h1><p>既有字段只读；空白不接受。G3为监测、预警、反馈或组织协调。T1规制，T2经济，T3工程，T4信息，T5协调，T6公众参与。仅按目标原文及必要上下文判断，不把邻近行动移入目标。</p><p>T多选仅在勾选“六类均已检查”后，未选的待审T才记为真实整组判断的0；未勾选时只保存选中的阳性，其他未知。单行动边界勾选仅指该目标确为一个完整独立行动，不代表同parent可以合并。读不清或是碎片请留空并备注。该表不批准自动池或最终C2。</p><p>真实审核者 <input id="who"> 完成时间（ISO含时区）<input id="when" placeholder="实际时间 +08:00"></p><button onclick="save()">保存本次已完成部分</button><main id="main"></main><script>const d=DATA;const esc=x=>String(x??'').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;');document.getElementById('main').innerHTML=(d.quality_summaries||[]).map((q,i)=>`<article><h2>${esc(q.policy_id)} ${esc(q.group)}组采用</h2><pre>${esc(JSON.stringify(q.facts,null,2))}</pre><p>${esc(q.limits)}</p><label><input type="checkbox" id="q${i}">在上述证据和限制下批准此精确G组采用，并授权该范围中间发布（不代表全库C2完成或再次逐条审核）</label></article>`).join('')+d.rows.map((r,i)=>`<article><b>${i+1}. ${esc(r.unit_id)}</b><div class="known">已有判断（不重填）：${esc(JSON.stringify(r.known))}</div><pre>${esc(r.reconstructed_text||r.text)}</pre>${r.reconstructed_text?`<p>恢复正文；原单元仍保留。确认仅指此完整修改条款以当前ID计一次，覆盖原片段，不重复计数。</p><pre>${esc(r.text)}</pre>`:''}<details><summary>上下文与来源</summary><pre>${esc(r.context)}\n${esc(r.source_location)}</pre></details>${r.missing_fields.filter(k=>!k.startsWith('T')).map(k=>`<label>${k}<select id="v${i}_${k}"><option value="">未填写</option><option value="1">1 符合</option><option value="0">0 不符合</option><option value="UNRESOLVED">无法判断</option></select></label>`).join('')}${r.missing_fields.filter(k=>k.startsWith('T')).map(k=>`<label><input type="checkbox" id="t${i}_${k}">${k}</label>`).join('')}${r.missing_fields.some(k=>k.startsWith('T'))?`<p><label><input type="checkbox" id="tc${i}">我已检查六类T（含只读已有项），对本次待审项未选类别明确判0</label></p>`:''}${r.boundary_needed?`<p><label><input type="checkbox" id="b${i}">确认本目标是一个完整独立行动（仅合格时填写）</label></p>`:''}${!r.source_ready?`<p><label><input type="checkbox" id="s${i}">确认所示精确正文与来源/版本范围可以采用（不改变标签）</label></p>`:''}<p>备注 <input id="n${i}" style="width:80%"></p></article>`).join('');function save(){let reviewer=document.getElementById('who').value,signed_at=document.getElementById('when').value;if(!reviewer||!signed_at){alert('填写真实审核者及实际含时区时间');return}const result={contract_sha256:d.contract_sha256,reviewer,signed_at,statement:'CONFIRM_ACTUAL_MISSING_FIELDS_AND_SELECTED_ACTION_BOUNDARIES',quality_decisions:(d.quality_summaries||[]).filter((q,i)=>document.getElementById('q'+i).checked).map(q=>({policy_id:q.policy_id,group:q.group,group_binding_sha256:q.group_binding_sha256,statement:'CONFIRM_POLICY_GROUP_SHARE_QUALITY',authorize_group_release:true})),rows:d.rows.map((r,i)=>({unit_id:r.unit_id,answers:Object.fromEntries(r.missing_fields.filter(k=>!k.startsWith('T')).map(k=>[k,document.getElementById('v'+i+'_'+k).value])),T_selected:r.missing_fields.filter(k=>k.startsWith('T')&&document.getElementById('t'+i+'_'+k).checked),T_complete_checked:document.getElementById('tc'+i)?.checked||false,confirm_single_action:document.getElementById('b'+i)?.checked||false,confirm_source_scope:document.getElementById('s'+i)?.checked||false,notes:document.getElementById('n'+i).value}))};let a=document.createElement('a');a.href=URL.createObjectURL(new Blob([JSON.stringify(result,null,2)],{type:'application/json;charset=utf-8'}));a.download='group_missing_fields_RETURN.json';a.click()}</script>'''.replace('DATA',payload)
 (out/'AUTHOR_GROUP_REVIEW.html').write_text(page,'utf-8');jsonout(out/'workload.json',dict(unique_readings=len(rows),missing_field_inputs=len(requests),G_fields=sum(r['field'].startswith('G') for r in requests),T_fields=sum(r['field'].startswith('T') for r in requests),boundary_tasks=sum(r['boundary_needed'] for r in rows),source_tasks=sum(not r['source_ready'] for r in rows),reviewed_fields_reasked=0,small_policy_counts=data['small_policy_counts'],actual_human_newly_completed=0));return data

def ingest_return(ctx,pack,review):
 from coding_pipeline import execute
 from review_registry import scope_binding
 data=load(pack/'group_review_contract.json');payload=load(review);scope=load(pack/'registered_scope.json');sid=scope['scope_id'];require(payload['contract_sha256']==data['contract_sha256']==scope['contract_sha256'],'Original scope mismatch')
 raw_hash=sha(review);base=ctx.root/'actual_group_returns'/raw_hash[:20];base.mkdir(parents=True,exist_ok=True);checkpoint=base/'checkpoint.json'
 if checkpoint.exists():
  pin=load(checkpoint);require(pin['raw_sha256']==raw_hash and pin['scope_id']==sid,'Checkpoint content/scope mismatch')
 else:
  # Pin immutable bytes before any mutation; dependency validity can change after import.
  train=ctx.artifact('train',required=False)
  if train is None:
   # Recover a partially submitted batch from manifest outputs, without fitting.
   stage=ctx.manifest['stages'].get('train',{});train=ctx.root/stage.get('artifact','MISSING');require(stage.get('state')=='COMPLETED' and all((train/n).exists() and sha(train/n)==h for n,h in stage['outputs'].items()),'Frozen model unavailable or changed')
  registry=ctx.root/ctx.manifest['stages']['build-registry']['artifact']
  pin=dict(raw_sha256=raw_hash,scope_id=sid,contract_sha256=data['contract_sha256'],model_path=str(train/'diagnostic_model.joblib'),model_sha256=sha(train/'diagnostic_model.joblib'),training_signature=sha(registry/'training_signature.json'),fields_submitted=False,boundaries_submitted=False,completed=False)
  historical=ctx.root/'actual_182_return_20261028/original_return.json'
  if historical.exists() and sha(historical)==raw_hash:
   # This exact raw return has already been consumed with explicit later corrections.
   correction=ctx.root/'actual_182_return_20261028/latest_author_correction.json'
   require(correction.exists(),'Historical return needs its actual correction chain')
   pin.update(fields_submitted=True,boundaries_submitted=True,historical_adoption=True,latest_correction_sha256=sha(correction))
  atomic_json(checkpoint,pin)
 require(sha(Path(pin['model_path']))==pin['model_sha256'],'Pinned model bytes changed')
 if pin.get('completed'):return dict(directory=str(base),reused=True,completed=True)
 if not (base/'actual_return.json').exists():shutil.copyfile(review,base/'actual_return.json')
 if not pin['fields_submitted'] or not pin['boundaries_submitted']:
  signed_payload=dict(payload)
  if re.fullmatch(r'\d{8}',str(signed_payload.get('signed_at',''))):signed_payload['signed_at']=datetime.strptime(signed_payload['signed_at'],'%Y%m%d').date().isoformat()
  signed(signed_payload,'CONFIRM_ACTUAL_MISSING_FIELDS_AND_SELECTED_ACTION_BOUNDARIES',ctx.identity);values,boundaries=normalized_return(payload,data);expected={r['unit_id']:r for r in data['rows']};sources_to_confirm=[r['unit_id'] for r in payload['rows'] if r.get('confirm_source_scope') is True and not expected[r['unit_id']]['source_ready']];require(values or boundaries or sources_to_confirm or payload.get('quality_decisions'),'Empty return cannot complete anything')
  # Recover downstream dependency state only. Never call train.
  if ctx.artifact('build-registry',required=False) is None:
   r=execute(ctx,'build-registry');require(r['state']=='COMPLETED','Registry recovery failed')
  if values and not pin['fields_submitted']:
   plan=ctx.artifact('register-adjudication:'+sid);template=read(plan/'adjudication_review.csv').set_index(['unit_id','field']);rows=[]
   for v in values:
    r=template.loc[(v['unit_id'],v['field'])].to_dict();r.update(v);rows.append(r)
   if not (base/'actual_fields.csv').exists():csvout(base/'actual_fields.csv',rows)
   sig=base/'signature.json'
   if not sig.exists():jsonout(sig,dict(identity=ctx.identity,statement='CONFIRM_ACTUAL_DIRECTED_ADJUDICATION',reviewer=payload['reviewer'],signed_at=signed_payload['signed_at'],scope_sha256=sha(plan/'scope.json'),review_sha256=sha(base/'actual_fields.csv'),original_return_sha256=raw_hash,batch_id='GROUP_'+raw_hash[:20]))
   d=dict(pool_id=sid,review=str(base/'actual_fields.csv'),signature=str(sig));r=execute(ctx,'ingest-adjudication',**d);require(r['state']=='COMPLETED','Field import failed');jsonout(ctx.root/'inbox/adjudications'/('GROUP_'+raw_hash[:20]+'.json'),d)
  pin['fields_submitted']=True;atomic_json(checkpoint,pin)
  if (boundaries or sources_to_confirm) and not pin['boundaries_submitted']:
   cat=read(ctx.artifact('prepare')/'corpus.csv');rows=[];expected={r['unit_id']:r for r in data['rows']}
   for uid in boundaries:
    proposal=expected[uid].get('action_proposal',{})
    rows.append(dict(decision_id='GROUP_BOUNDARY_'+digest(uid)[:16],type='ACTION_COUNTING_BOUNDARY',unit_ids=json.dumps([uid]),value='CONFIRM',rule_text=proposal.get('rule_text','Author explicitly confirmed target as one complete independent action; no parent merge'),action_unit_id=proposal.get('action_unit_id','ACT_'+digest(['EXPLICIT_SINGLE',uid])[:24]),representative_id='',scope_sha256=digest([uid]),source_binding=scope_binding(cat,[uid]),source_recovery_sha256=proposal.get('source_recovery_sha256',''),covered_unit_ids=json.dumps(proposal.get('covered_unit_ids',[]))))
   for uid in sources_to_confirm:rows.append(dict(decision_id='GROUP_SOURCE_'+digest(uid)[:16],type='SOURCE_VERSION',unit_ids=json.dumps([uid]),value='CONFIRM',rule_text='Actual author accepted exact displayed source/version scope; labels unchanged',action_unit_id='',representative_id='',scope_sha256=digest([uid]),source_binding=scope_binding(cat,[uid])))
   if not (base/'decisions.csv').exists():csvout(base/'decisions.csv',rows)
   sig=base/'decision_signature.json'
   if not sig.exists():jsonout(sig,dict(identity=ctx.identity,statement='APPROVE_SCOPED_CODING_DECISIONS',reviewer=payload['reviewer'],signed_at=signed_payload['signed_at'],decisions_sha256=sha(base/'decisions.csv'),actual_return_sha256=raw_hash))
   d=dict(decisions=str(base/'decisions.csv'),signature=str(sig));r=execute(ctx,'ingest-decisions',**d);require(r['state']=='COMPLETED','Boundary import failed');jsonout(ctx.root/'inbox/decisions'/('GROUP_'+raw_hash[:20]+'.json'),d)
  pin['boundaries_submitted']=True;atomic_json(checkpoint,pin)
 r=execute(ctx,'build-registry');require(r['state']=='COMPLETED','Registry rebuild failed')
 require(sha(ctx.artifact('build-registry')/'training_signature.json')==pin['training_signature'],'C2-only import changed training inputs; automatic fitting stopped')
 require(sha(Path(pin['model_path']))==pin['model_sha256'],'Frozen model changed')
 require(ctx.artifact('train',required=False) is not None,'Frozen training artifact not reusable after registry rebuild; inspect dependency without fitting')
 r=execute(ctx,'assemble-candidate');require(r['state']=='COMPLETED','Assembly failed')
 apply_quality_decisions(ctx,base,payload,data)
 for stage in ['part1-ledger','finalize-part1']:
  r=execute(ctx,stage);require(r['state']=='COMPLETED',stage+' failed')
 pin.update(completed=True,not_retrained=True);atomic_json(checkpoint,pin);jsonout(base/'receipt.json',pin);return dict(directory=str(base),reused=False,completed=True)

def apply_quality_decisions(ctx,base,payload,contract):
 from coding_pipeline import execute
 decisions=payload.get('quality_decisions',[])
 if not decisions:return
 for sub in ['share_quality','group_publish']:(ctx.root/'inbox'/sub).mkdir(parents=True,exist_ok=True)
 registered={(q['policy_id'],q['group']):q for q in contract.get('quality_summaries',[])}
 for d in decisions:
  key=(d['policy_id'],d['group']);require(key in registered and d['statement']=='CONFIRM_POLICY_GROUP_SHARE_QUALITY','Quality scope not registered')
  q=registered[key];require(d['group_binding_sha256']==q['group_binding_sha256'],'Quality binding changed')
  review=base/('quality_'+key[0]+'_'+key[1]+'.csv');sig=review.with_suffix('.signature.json')
  row=dict(q['quality_review'],policy_id=key[0],group=key[1],decision='ACCEPT_CONDITIONALLY')
  if not review.exists():csvout(review,[row])
  if not sig.exists():jsonout(sig,dict(identity=ctx.identity,statement='CONFIRM_POLICY_GROUP_SHARE_QUALITY',reviewer=payload['reviewer'],signed_at=(datetime.strptime(payload['signed_at'],'%Y%m%d').date().isoformat() if re.fullmatch(r'\d{8}',str(payload['signed_at'])) else payload['signed_at']),review_sha256=sha(review),group_bindings={'|'.join(key):q['group_binding_sha256']},original_return_sha256=sha(base/'actual_return.json')))
  args=dict(review=str(review),signature=str(sig));r=execute(ctx,'ingest-share-quality',**args);require(r['state']=='COMPLETED','Quality import failed');jsonout(ctx.root/'inbox/share_quality'/('GROUP_'+digest(key)[:16]+'.json'),args)
  for stage in ['assemble-candidate','part1-ledger']:
   r=execute(ctx,stage);require(r['state']=='COMPLETED','Quality refresh failed')
  if d.get('authorize_group_release') is True:
   approval=review.with_suffix('.release.json')
   if not approval.exists():jsonout(approval,dict(identity=ctx.identity,statement='APPROVE_EXACT_POLICY_GROUP_RELEASE',reviewer=payload['reviewer'],signed_at=(datetime.strptime(payload['signed_at'],'%Y%m%d').date().isoformat() if re.fullmatch(r'\d{8}',str(payload['signed_at'])) else payload['signed_at']),group_bindings={'|'.join(key):q['group_binding_sha256']},original_return_sha256=sha(base/'actual_return.json')))
   args=dict(approval=str(approval));r=execute(ctx,'publish-group',**args);require(r['state']=='COMPLETED','Scoped group publication failed');jsonout(ctx.root/'inbox/group_publish'/('GROUP_'+digest(key)[:16]+'.json'),args)

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('command',choices=['export','import']);p.add_argument('--workspace',required=True);p.add_argument('--run-id',required=True);p.add_argument('--pack',required=True);p.add_argument('--review');p.add_argument('--policy-ids',nargs='*');p.add_argument('--groups',choices=['G','T','ALL'],default='ALL');p.add_argument('--reading-budget',type=int);p.add_argument('--quality-summary');a=p.parse_args();ctx=Context(a.workspace,a.run_id)
 if a.command=='export':export(ctx,longpath(a.pack),a.policy_ids,a.groups,a.reading_budget,a.quality_summary)
 else:print(ingest_return(ctx,longpath(a.pack),longpath(a.review)))
