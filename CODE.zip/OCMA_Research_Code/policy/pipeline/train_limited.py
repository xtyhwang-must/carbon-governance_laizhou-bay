"""Bounded human-only training; consumes development-only registry views."""
from common import *
import joblib
import warnings
from sklearn.exceptions import ConvergenceWarning
from scipy.sparse import hstack
from sklearn.model_selection import GroupKFold
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression

def weights(y,mask,balanced,anchor):
 w=np.zeros(len(y),float);counts=[int((mask&(y==c)).sum()) for c in [0,1]]
 if not all(counts):return w,False
 if balanced:
  for c in [0,1]:w[mask&(y==c)]=anchor/(2*counts[c])
 else:w[mask]=anchor/int(mask.sum())
 require(np.isclose(w.sum(),anchor),'Loss normalization failed');return w,True

def fit_features(corpus):
 a=TfidfVectorizer(analyzer='char',ngram_range=(2,4),min_df=2,max_df=.99,max_features=40000,sublinear_tf=True,dtype=np.float32)
 b=TfidfVectorizer(analyzer='char',ngram_range=(2,4),min_df=2,max_df=.99,max_features=15000,sublinear_tf=True,dtype=np.float32)
 a.fit(corpus.exact_evidence_text);b.fit(corpus.parent_context_model)
 return (a,b)
def transform(vec,data):return hstack([vec[0].transform(data.exact_evidence_text),vec[1].transform(data.parent_context_model)*.3],format='csr')
def fit_heads(X,Z,labels,spec,C,anchor,cache=None,counters=None):
 out=np.full((Z.shape[0],len(LABELS)),np.nan);models=[];audit=[]
 for j,k in enumerate(LABELS):
  mask=np.ones(len(labels),bool) if j==0 or spec=='H-ALLDOMAIN' else labels[:,0]==1
  w,ok=weights(labels[:,j],mask,spec!='H-UNBAL',anchor);m=None;failure='' if ok else 'MISSING_CLASS'
  if ok:
   keep=w>0;m=LogisticRegression(C=C,solver='liblinear',max_iter=500,random_state=20261027)
   key=(k,C,digest(labels[:,j].tolist()),digest(w.tolist()))
   if cache is not None and j==0 and key in cache:
    m=cache[key]
    if m is None:failure='CACHED_NONCONVERGENCE'
   else:
    with warnings.catch_warnings(record=True) as ws:
     warnings.simplefilter('always',ConvergenceWarning)
     m.fit(X[keep],labels[keep,j],sample_weight=w[keep])
    if any(issubclass(v.category,ConvergenceWarning) for v in ws) or m.n_iter_[0]>=500:failure='NONCONVERGENCE';m=None
    if counters is not None:counters['physical_head_fits']+=1
    if cache is not None and j==0:cache[key]=m
   if counters is not None:counters['logical_trainable_heads']+=1
   if m is not None:out[:,j]=m.predict_proba(Z)[:,1]
   else:ok=False
  models.append(m)
  for c in [0,1]:audit.append(dict(label=k,target=c,real_support=int((mask&(labels[:,j]==c)).sum()),actual_mass=float(w[labels[:,j]==c].sum()),total_mass=float(w.sum()),anchor=anchor,trainable=ok,failure_reason=failure,weak_mass=0,domain='ALL_ALLOWED_HUMAN' if j==0 or spec=='H-ALLDOMAIN' else 'HUMAN_ELIGIBLE'))
 return out,models,audit

def threshold_status(y,score,label,policies,contract):
 score=np.asarray(score,float);ys=np.asarray(y,int);cuts=np.unique(score[np.isfinite(score)]);rows=[]
 for cut in cuts:
  pred=np.where(np.isfinite(score),(score>=cut).astype(float),np.nan);m=answered_metrics(ys,pred)
  pn=len(set(np.asarray(policies)[ys==1]));ok=quality(m,label,pn,contract)
  F2=5*m['tp']/(5*m['tp']+4*m['fn']+m['fp']) if 5*m['tp']+4*m['fn']+m['fp'] else 0.
  rows.append(dict(threshold=float(cut),feasible=ok,positive_policies=pn,F2=F2,**m))
 good=[r for r in rows if r['feasible']]
 best=max(good,key=lambda r:(r['F2'],r['F1'],r['threshold'])) if good else (max(rows,key=lambda r:((r['answered_recall']+r['specificity'])/2 if label=='eligibility' else r['F1'],r['F2'],r['threshold'])) if rows else None)
 return dict(usable_threshold=best['threshold'] if good else None,diagnostic_threshold=best['threshold'] if best else None,status='DEVELOPMENT_THRESHOLD_ONLY' if good else 'NO_FEASIBLE_DEVELOPMENT_THRESHOLD'),rows
def threshold_outputs(scores,contracts,usable=False):
 # usable=False preserves frozen diagnostic semantics; usable=True abstains unsupported heads.
 out=np.full(scores.shape,np.nan)
 for j,k in enumerate(LABELS):
  cut=contracts[k]['usable_threshold' if usable else 'diagnostic_threshold']
  if cut is not None:
   ok=np.isfinite(scores[:,j]);out[ok,j]=(scores[ok,j]>=cut).astype(float)
 hard=out.copy()
 for j in range(1,len(LABELS)):
  mask=np.isfinite(out[:,0])&np.isfinite(out[:,j]);hard[:,j]=np.nan;hard[mask,j]=out[mask,0]*out[mask,j]
 return out,hard

def train(ctx,out):
 prep=ctx.artifact('prepare');reg=ctx.artifact('build-registry');rm=load(reg/'registry_manifest.json')
 if ctx.cfg['require_complete_existing_sample_before_training'] and not rm['complete_existing_sample_evaluated']:
  raise Waiting('Existing probability sample has no complete actual return/evaluation; do not retrain original labels')
 contract=load(prep/'training_contract.json');require(contract['C']==[1,3] and contract['folds']==3 and contract['max_fold_specifications']==18,'Unregistered search expansion')
 h=read(reg/'development_labels.csv');u=read(reg/'development_corpus.csv')
 require(sha(reg/'development_labels.csv')==rm['development_labels_sha256'] and sha(reg/'development_corpus.csv')==rm['development_corpus_sha256'],'Development view changed')
 require(h.split.eq('DEVELOPMENT').all() and u.split.eq('DEVELOPMENT').all() and not rm['original_reference_training_n'] and not rm['heldout_training_n'],'Training leakage')
 # No full human registry/reference labels are read in this module.
 cols=['unit_id','exact_evidence_text','parent_context_model','parent_clause_text','norm','cross_split_long_duplicate']
 h=h.merge(u[cols],on='unit_id',validate='one_to_one');h=h[~h.cross_split_long_duplicate.map(boolean)].reset_index(drop=True)
 require(h.cv_group.nunique()>=3,'Insufficient family groups')
 y=h[['human_'+k for k in LABELS]].astype(int).to_numpy();folds=np.zeros(len(h),int)
 for f,(_,ix) in enumerate(GroupKFold(3).split(h,groups=h.cv_group),1):folds[ix]=f
 specs=[(s,C) for s in ['H-BAL','H-UNBAL','H-ALLDOMAIN'] for C in [1,3]]
 oofs={x:np.full((len(h),10),np.nan) for x in specs};wa=[];members=[];featureaudit=[];counters=dict(physical_head_fits=0,logical_trainable_heads=0)
 for f in [1,2,3]:
  va=h.iloc[np.flatnonzero(folds==f)];groups=set(va.cv_group);texts=set(va.norm);parents={norm(t) for t in va.parent_clause_text if len(norm(t))>=40}
  allowed=u[~u.cv_group.isin(groups)&~u.norm.isin(texts)&~u.cross_split_long_duplicate.map(boolean)&~u.parent_clause_text.map(norm).isin(parents)]
  ht=h[(folds!=f)&h.unit_id.isin(allowed.unit_id)]
  require(len(ht)>0 and not set(ht.cv_group)&groups,'Fold isolation failure')
  ready=ctx.artifact('training-readiness',required=False);fkey=digest(allowed[['unit_id','exact_evidence_text','parent_context_model']].sort_values('unit_id').to_dict('records'))
  cachemeta=load(ready/'feature_cache_manifest.json').get(str(f)) if ready and (ready/'feature_cache_manifest.json').exists() else None
  if cachemeta and cachemeta['feature_input_signature']==fkey and cachemeta.get('vectorizer_sha256') and sha(ready/cachemeta['file'])==cachemeta['vectorizer_sha256']:vec=joblib.load(ready/cachemeta['file'])
  else:
   try:vec=fit_features(allowed)
   except ValueError as ex:
    if not any(t in str(ex).lower() for t in ['empty vocabulary','no terms remain','max_df corresponds']):raise
    featureaudit.append(dict(fold=f,status='EMPTY_VOCABULARY_NAN',error=str(ex)))
    continue
  X=transform(vec,ht);Z=transform(vec,va);yy=ht[['human_'+k for k in LABELS]].astype(int).to_numpy()
  featureaudit.append(dict(fold=f,feature_hash=digest([vec[0].vocabulary_,vec[0].idf_.tolist(),vec[1].vocabulary_,vec[1].idf_.tolist()]),feature_rows=len(allowed),human_rows=len(ht),validation_n=len(va),same_features_for_all_six_specs=True))
  for role,data in [('FEATURE_FIT',allowed),('SUPERVISION',ht),('VALIDATION',va)]:
   members.extend(dict(fold=f,role=role,unit_id=r.unit_id,policy_id=r.policy_id,cv_group=r.cv_group) for r in data.itertuples())
  shared_head_cache={}
  for spec,C in specs:
   s,_,audit=fit_heads(X,Z,yy,spec,C,len(ht),shared_head_cache,counters);oofs[(spec,C)][folds==f]=s
   wa.extend(dict(spec=spec,C=C,fold=str(f),**r) for r in audit)
 comparisons=[];allmetrics=[];allgrids=[];oofrows=[];contracts={}
 for spec,C in specs:
  score=oofs[(spec,C)];cs={}
  for j,k in enumerate(LABELS):
   mask=np.ones(len(h),bool) if j==0 or spec=='H-ALLDOMAIN' else y[:,0]==1
   cs[k],grid=threshold_status(y[mask,j],score[mask,j],k,h.loc[mask,'policy_id'].to_numpy(),contract)
   allgrids.extend(dict(spec=spec,C=C,label=k,threshold_domain='ALL_ALLOWED_HUMAN' if j==0 or spec=='H-ALLDOMAIN' else 'HUMAN_ELIGIBLE',**r) for r in grid)
  contracts[(spec,C)]=cs;raw,hard=threshold_outputs(score,cs);eligible_ok=cs['eligibility']['usable_threshold'] is not None;endf1=[]
  for j,k in enumerate(LABELS):
   for domain,mask,p in [('RAW_ALL',np.ones(len(h),bool),raw[:,j]),('CONDITIONAL_HUMAN_ELIGIBLE',y[:,0]==1 if j else np.ones(len(h),bool),raw[:,j]),('END_TO_END',np.ones(len(h),bool),hard[:,j])]:
    m=answered_metrics(y[mask,j],p[mask]);ok=quality(m,k,h.loc[mask&(y[:,j]==1),'policy_id'].nunique(),contract)
    allmetrics.append(dict(spec=spec,C=C,label=k,domain=domain,metric_requirement_pass=ok,end_to_end_status=bool(eligible_ok and ok) if domain=='END_TO_END' else False,conditional_head_status=ok if domain=='CONDITIONAL_HUMAN_ELIGIBLE' else False,applicability_domain='ALL_ALLOWED_HUMAN_TRAINING_NOT_WHOLE_CORPUS_VALIDATION' if j==0 or spec=='H-ALLDOMAIN' else 'HUMAN_ELIGIBLE_ONLY',auto_pool_approval=False,**m))
    if j and domain=='END_TO_END':endf1.append(m['F1'])
  comparisons.append(dict(spec=spec,C=C,eligibility_feasible=eligible_ok,end_to_end_GT_macroF1=float(np.mean(endf1)),identity='DEVELOPMENT_SELECTION_NOT_INDEPENDENT_VALIDATION'))
  q=h[['unit_id','policy_id']].copy();q['spec']=spec;q['C']=C;q['fold']=folds
  for j,k in enumerate(LABELS):q['human_'+k]=y[:,j];q['score_'+k]=score[:,j]
  oofrows.append(q)
 # Registered diagnostic fallback uses same end-to-end ordering; never grants deployment.
 rank={'H-BAL':0,'H-UNBAL':1,'H-ALLDOMAIN':2};feasible=[r for r in comparisons if r['eligibility_feasible']]
 chosen=sorted(feasible or comparisons,key=lambda r:(-r['end_to_end_GT_macroF1'],rank[r['spec']],r['C']))[0];spec=chosen['spec'];C=chosen['C']
 # Preserve completed comparisons even if the final feature fit cannot run.
 csvout(out/'limited_development_results.csv',comparisons);csvout(out/'development_metrics.csv',allmetrics);csvout(out/'threshold_search.csv',allgrids);csvout(out/'OOF_scores.csv',pd.concat(oofrows,ignore_index=True));csvout(out/'class_weight_audit.csv',wa);csvout(out/'training_membership.csv',members);csvout(out/'feature_audit.csv',featureaudit)
 allowed=u[~u.cross_split_long_duplicate.map(boolean)]
 try:vec=fit_features(allowed)
 except ValueError as ex:
  if not any(t in str(ex).lower() for t in ['empty vocabulary','no terms remain','max_df corresponds']):raise
  jsonout(out/'final_fit_failure.json',dict(reason='EMPTY_FINAL_VOCABULARY',message=str(ex),model_created=False,completed_fold_results_preserved=True))
  raise Waiting('Empty final vocabulary; completed OOF results retained; no model produced','FAILED')
 X=transform(vec,h)
 _,models,audit=fit_heads(X,X[:1],y,spec,C,len(h),None,counters);wa.extend(dict(spec=spec,C=C,fold='FINAL',**r) for r in audit)
 model=dict(identity=ctx.identity,vectorizers=vec,models=models,labels=LABELS,spec=spec,C=C,contracts=contracts[(spec,C)],training_ids=h.unit_id.tolist(),feature_fit_ids=allowed.unit_id.tolist(),registry_sha256=sha(reg/'registry_snapshot.csv'),contract_sha256=sha(prep/'training_contract.json'))
 joblib.dump(model,out/'diagnostic_model.joblib',compress=3)
 csvout(out/'limited_development_results.csv',comparisons);csvout(out/'development_metrics.csv',allmetrics);csvout(out/'threshold_search.csv',allgrids);csvout(out/'OOF_scores.csv',pd.concat(oofrows,ignore_index=True));csvout(out/'class_weight_audit.csv',wa);csvout(out/'training_membership.csv',members);csvout(out/'feature_audit.csv',featureaudit)
 jsonout(out/'model_lock.json',dict(identity=ctx.identity,selected_diagnostic_model=chosen,eligibility_development_qualified=bool(feasible),label_usage_status={k:dict(threshold_status=contracts[(spec,C)][k]['status'],conditional=[r for r in allmetrics if r['spec']==spec and r['C']==C and r['label']==k and r['domain']=='CONDITIONAL_HUMAN_ELIGIBLE'][0],end_to_end=[r for r in allmetrics if r['spec']==spec and r['C']==C and r['label']==k and r['domain']=='END_TO_END'][0]) for k in LABELS},model_sha256=sha(out/'diagnostic_model.joblib'),contracts=contracts[(spec,C)],fold_specifications=18,final_refits=1,**counters,automatic_pool_approval=False,development_informed_by_prior_reference_failure=True,reference600_used=False,training_registry_sha256=sha(reg/'registry_snapshot.csv'),part2_started=False))
def entry():
 from coding_pipeline import main
 main(forced='train')
if __name__=='__main__':entry()

def readiness(ctx,out):
 prep=ctx.artifact('prepare');reg=ctx.artifact('build-registry');h=read(reg/'development_labels.csv');u=read(reg/'development_corpus.csv');rm=load(reg/'registry_manifest.json');rows=[];feature_cache={}
 h=h.merge(u[['unit_id','norm','parent_clause_text','cross_split_long_duplicate']],on='unit_id',validate='one_to_one');h=h[~h.cross_split_long_duplicate.map(boolean)].reset_index(drop=True)
 if h.cv_group.nunique()>=3:
  for fold,(_,ix) in enumerate(GroupKFold(3).split(h,groups=h.cv_group),1):
   v=h.iloc[ix];groups=set(v.cv_group);parents={norm(t) for t in v.parent_clause_text if len(norm(t))>=40};allowed=u[~u.cv_group.isin(groups)&~u.norm.isin(set(v.norm))&~u.cross_split_long_duplicate.map(boolean)&~u.parent_clause_text.map(norm).isin(parents)];ht=h[h.unit_id.isin(allowed.unit_id)]
   vocab_status='CHECKED_NONEMPTY';vocab_error='';sizes=[0,0]
   try:
    vec=fit_features(allowed);sizes=[len(v.vocabulary_) for v in vec];fn='fold_'+str(fold)+'_vectorizers.joblib';joblib.dump(vec,out/fn,compress=3);feature_cache[str(fold)]=dict(file=fn,vectorizer_sha256=sha(out/fn),feature_input_signature=digest(allowed[['unit_id','exact_evidence_text','parent_context_model']].sort_values('unit_id').to_dict('records')))
   except ValueError as ex:
    if not any(t in str(ex).lower() for t in ['empty vocabulary','no terms remain','max_df corresponds']):raise
    vocab_status='EMPTY_OR_INVALID_VOCABULARY';vocab_error=str(ex)
   for spec in ['H-BAL','H-UNBAL','H-ALLDOMAIN']:
    for k in LABELS:
     z=ht if k=='eligibility' or spec=='H-ALLDOMAIN' else ht[ht.human_eligibility.eq('1')];y=z['human_'+k];pos=int(y.eq('1').sum());neg=int(y.eq('0').sum())
     rows.append(dict(fold=fold,spec=spec,label=k,positive_n=pos,negative_n=neg,positive_families=z.loc[y.eq('1'),'cv_group'].nunique(),negative_families=z.loc[y.eq('0'),'cv_group'].nunique(),loss_anchor=len(ht),expected_status='TRAINABLE' if pos and neg else 'UNTRAINABLE_NAN',feature_rows=len(allowed),empty_target_n=int(allowed.exact_evidence_text.str.strip().eq('').sum()),empty_context_n=int(allowed.parent_context_model.str.strip().eq('').sum()),vocabulary_check=vocab_status,vocabulary_error=vocab_error,target_vocabulary_n=sizes[0],context_vocabulary_n=sizes[1],positive_weight_mass=(len(ht)/2 if spec!='H-UNBAL' else len(ht)*pos/(pos+neg)) if pos and neg else 0,negative_weight_mass=(len(ht)/2 if spec!='H-UNBAL' else len(ht)*neg/(pos+neg)) if pos and neg else 0))
 jsonout(out/'feature_cache_manifest.json',feature_cache)
 csvout(out/'training_readiness_report.csv',rows)
 csvout(out/'development_class_family_counts.csv',[dict(label=k,positive_n=int(h['human_'+k].eq('1').sum()),negative_n=int(h['human_'+k].eq('0').sum()),families=h.cv_group.nunique()) for k in LABELS])
 csvout(out/'development_family_counts.csv',h.groupby('cv_group').size().reset_index(name='human_n'))
 shutil.copyfile(reg/'scope_exclusions.csv',out/'excluded_scope.csv')
 jsonout(out/'readiness.json',dict(identity=ctx.identity,training_signature=load(reg/'training_signature.json'),complete_sample=rm['complete_existing_sample_evaluated'],allowed_human_n=len(h),precheck_only_no_model_fitted=True,feature_vectorizers_fitted=True,classifiers_fitted=False,empty_vocabulary_folds=[str(r['fold']) for r in rows if r['vocabulary_check']!='CHECKED_NONEMPTY'],part2_started=False))
