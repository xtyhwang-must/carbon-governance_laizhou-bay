"""Local finite-pool SRSWOR proposals, real approvals, audit imports and evidence."""
from common import *
from scipy.stats import hypergeom

def exact_max_errors(N,n,e,alpha):
 require(0<n<=N and 0<=e<=n and 0<float(alpha)<1,'Invalid finite audit counts')
 lo=e;hi=N-n+e
 while lo<hi:
  mid=(lo+hi+1)//2
  if hypergeom.cdf(e,N,mid,n)>=float(alpha):lo=mid
  else:hi=mid-1
 return lo

def exact_bounds(N,n,e,alpha):
 M=exact_max_errors(N,n,e,alpha)
 return dict(M_U=M,whole_pool_error_upper=M/N,remaining_error_upper=(M-e)/(N-n) if n<N else None,remaining_n=N-n,identity='EXACT_HYPERGEOMETRIC_INVERSION_NOT_LOGICAL_ZERO_RISK')

def enumerate_sample_sizes(N,alpha,risk_limit,errors=0,legacy=True):
 ns=np.arange(max(1,errors),N+1);lo=np.full(len(ns),errors,dtype=int);hi=N-ns+errors
 while np.any(lo<hi):
  mid=(lo+hi+1)//2;ok=hypergeom.cdf(errors,N,mid,ns)>=float(alpha);lo=np.where(ok,mid,lo);hi=np.where(ok,hi,mid-1)
 rows=[]
 for n,M in zip(ns,lo):
  b=(max(1,max(int(M),errors+1)-errors) if legacy else int(M)-errors)/(N-int(n)) if n<N else None
  rows.append(dict(n=int(n),errors=errors,remaining_error_upper=b,passes=bool(n==N or b<=risk_limit)))
 return rows

def design_operating_characteristic(N,n,true_errors,alpha,risk_limit,legacy=True):
 accepted=[]
 for e in range(min(n,true_errors)+1):
  b=remaining_bound(N,n,e,alpha) if legacy else exact_bounds(N,n,e,alpha)['remaining_error_upper']
  if n==N or b<=risk_limit:accepted.append(e)
 return dict(N=N,n=n,true_errors=true_errors,accepted_error_counts=accepted,acceptance_probability=float(sum(hypergeom.pmf(e,N,true_errors,n) for e in accepted)),design_only=True)

def decision_semantic_digest(decisions):
 relevant=decisions[decisions.type.isin(['SOURCE_VERSION','SEMANTIC_RULE','EXTRACTION_SCOPE','EXACT_GROUP_SCOPE'])]
 columns=['decision_id','decision_event_id','type','value','unit_ids','rule_text','representative_id','scope_sha256','source_binding']
 return digest(relevant.reindex(columns=columns,fill_value='').fillna('').sort_values('decision_id').to_dict('records'))

def decision_binding(reg,protocol=None):
 # Preserve legacy exact bindings; new pools exclude unrelated counting approvals.
 if protocol is not None and protocol.get('decision_binding_identity')!='CODING_SCOPE_ONLY_V2':return sha(reg/'decision_registry.csv')
 return decision_semantic_digest(read(reg/'decision_registry.csv'))

def error_bound(N,n,e,alpha):
 # Historical additional floors retained for old protocol identity; not the exact core.
 require(0<n<=N and 0<=e<=n and 0<alpha<1,'Invalid finite audit counts')
 if n==N:return e/N
 lo=e;hi=N-n+e
 while lo<hi:
  m=(lo+hi+1)//2
  if hypergeom.cdf(e,N,m,n)>=alpha:lo=m
  else:hi=m-1
 return max(lo,e+1)/N if n<N else lo/N

def remaining_bound(N,n,e,alpha):
 if n==N:return 0.
 return max(1,round(error_bound(N,n,e,alpha)*N)-e)/(N-n)

# Named compatibility interfaces: these floors are additional design choices.
legacy_error_bound=error_bound
legacy_remaining_bound=remaining_bound

def plan(ctx,out,definition,approval=None,pool_id=None,protocol_sha256=None):
 prep=ctx.artifact('prepare');pr=ctx.artifact('predict');tr=ctx.artifact('train');reg=ctx.artifact('build-registry')
 require(pool_id and re.fullmatch(r'[A-Za-z0-9_-]+',pool_id),'Explicit pool_id required')
 d=load(definition);require(d['label'] in LABELS and d['direction'] in ['POSITIVE','NEGATIVE'],'Invalid audit claim')
 require(d['design']=='SRSWOR_FINITE_POOL' and int(d.get('look_number',1))==1,'New independent audit required for repeated looks')
 require(0<float(d['family_alpha'])<=.05 and int(d['planned_claims'])>=1,'Joint claim registration required')
 require(float(d['risk_limit'])<=(.1 if d['direction']=='POSITIVE' else .02),'Pool quality requirement may not be relaxed')
 # Approved membership is frozen: later audit judgments do not silently resample its roster.
 ledgerpath=ctx.root/'audit_family_registry.json'
 if approval and ledgerpath.exists() and pool_id in load(ledgerpath)['pools']:
  registered=load(ledgerpath)['pools'][pool_id];require(protocol_sha256==registered['protocol_sha256'],'Registered pool protocol mismatch')
  for history in reversed(ctx.manifest['history']):
   if history['stage']!='plan-audit:'+pool_id or history['state']!='COMPLETED':continue
   previous=ctx.root/history['artifact']
   if not (previous/'protocol.json').exists() or sha(previous/'protocol.json')!=protocol_sha256:continue
   require(filelist(previous)==history['outputs'],'Frozen pool plan changed')
   old=load(previous/'protocol.json');require(old['definition_sha256']==sha(definition) and old['model_sha256']==sha(tr/'diagnostic_model.joblib') and old['codebook_sha256']==sha(prep/'codebook.md') and old['registry_sha256']==sha(reg/'registry_snapshot.csv') and old['source_decisions_sha256']==decision_binding(reg,old),'Approved pool dependencies changed')
   authorization=load(approval);signed(authorization,'APPROVE_EXACT_LOCAL_POOL_PROTOCOL',ctx.identity);require(authorization['protocol_sha256']==protocol_sha256,'Wrong pool approval')
   for item in previous.iterdir():
    if item.is_file():shutil.copyfile(item,out/item.name)
   return
  raise ValueError('Registered plan artifact missing; cannot rebuild a different sample under old approval')
 predictions=read(pr/'corpus_predictions.csv');human=read(reg/'registry_snapshot.csv')
 accepted=set(human.loc[human['human_'+d['label']].isin(['0','1']),'unit_id'])
 blocked=set(read(reg/'scope_exclusions.csv').unit_id);decisions=read(reg/'decision_registry.csv');hi=human.set_index('unit_id')
 for decision in decisions[decisions.type.eq('EXACT_GROUP_SCOPE')&decisions.value.eq('CONFIRM')].to_dict('records'):
  rep=decision['representative_id']
  if rep in hi.index and hi.loc[rep,'human_'+d['label']] in ['0','1']:accepted.update(json.loads(decision['unit_ids']))
 accepted|=blocked
 # Reuse actual audit judgments fieldwise; never treat automatic pool labels as new human truth.
 source_index=predictions.set_index('unit_id')
 for _,artifact in ctx.audit_events():
  actual=validate_human_audit(ctx,artifact)
  for row in actual.itertuples():
   applicable=row.field==d['label'] or (row.field=='eligibility' and row.value=='0' and d['label']!='eligibility')
   if applicable and row.unit_id in source_index.index and row.source_hash==source_index.loc[row.unit_id,'source_hash'] and row.rule_version==sha(prep/'codebook.md'):accepted.add(row.unit_id)
 scores=pd.to_numeric(predictions['score_'+d['label']],errors='coerce')
 mask=scores.ge(float(d['score_cut'])) if d['direction']=='POSITIVE' else scores.le(float(d['score_cut']))
 members=predictions[mask&~predictions.unit_id.isin(accepted)][['unit_id','policy_id','source_hash']].sort_values('unit_id')
 csvout(out/'pool_members.csv',members)
 lock=load(tr/'model_lock.json');N=len(members)
 if 'sample_n' in d:n=min(int(d['sample_n']),N);planning='EXPLICIT_SAMPLE_SIZE'
 elif N:
  alpha=float(d['family_alpha'])/int(d['planned_claims'])
  designs=enumerate_sample_sizes(N,alpha,float(d['risk_limit']))
  n=next(r['n'] for r in designs if r['passes']);csvout(out/'sample_size_acceptance_region.csv',designs);planning='ZERO_ERROR_BENCHMARK_ONLY_NOT_GUARANTEED_ACCEPTANCE'
 else:n=0;planning='EMPTY_POOL'
 require(n>=0 and (not N or n>0),'Invalid proposed sample size')
 proto=dict(identity=ctx.identity,pool_id=pool_id,family_id=d['family_id'],definition_sha256=sha(definition),model_sha256=lock['model_sha256'],model_contracts=lock['contracts'],codebook_sha256=sha(prep/'codebook.md'),registry_sha256=sha(reg/'registry_snapshot.csv'),source_decisions_sha256=decision_binding(reg),decision_binding_identity='CODING_SCOPE_ONLY_V2',members_sha256=sha(out/'pool_members.csv'),label=d['label'],direction=d['direction'],score_cut=d['score_cut'],pool_n=N,sample_n=n,seed=int(d['seed']),design=d['design'],family_alpha=float(d['family_alpha']),planned_claims=int(d['planned_claims']),alpha=float(d['family_alpha'])/int(d['planned_claims']),risk_limit=float(d['risk_limit']),look_number=1,claim_scope=d['claim_scope'],full_corpus_success_claim=False)
 proto['sample_size_planning']=planning
 jsonout(out/'protocol.json',proto);shutil.copyfile(definition,out/'original_definition.json')
 if not approval:raise Waiting('Approve exact protocol SHA256 before sample export','WAITING_FOR_APPROVAL')
 a=load(approval);signed(a,'APPROVE_EXACT_LOCAL_POOL_PROTOCOL',ctx.identity)
 require(a['protocol_sha256']==protocol_sha256==sha(out/'protocol.json'),'Pool protocol/model/range changed')
 require(N>0,'Empty pool has no acceptance claim')
 register_family(ctx,proto,sha(out/'protocol.json'),members,approval)
 shutil.copyfile(approval,out/'protocol_approval.json')
 selected=np.random.default_rng(proto['seed']).choice(N,n,replace=False);sample=members.iloc[np.sort(selected)].copy()
 cat=read(prep/'corpus.csv').set_index('unit_id')
 sample['text']=cat.loc[sample.unit_id,'exact_evidence_text'].to_numpy();sample['context']=cat.loc[sample.unit_id,'context'].to_numpy()
 sample['truth']='';sample['notes']='';csvout(out/'audit_review.csv',sample)
 # Blind review omits scores; protocol/range known only in backend.
 jsonout(out/'audit_status.json',dict(identity=ctx.identity,approved_protocol=True,actual_judgments=0,accepted=False))

def ingest(ctx,out,review,signature,acceptance=None,pool_id=None,protocol_sha256=None):
 planpath=ctx.artifact('plan-audit:'+pool_id);require(sha(planpath/'protocol.json')==protocol_sha256,'Wrong explicit pool protocol');prep=ctx.artifact('prepare');tr=ctx.artifact('train');reg=ctx.artifact('build-registry')
 for name in ['protocol.json','protocol_approval.json','pool_members.csv','audit_review.csv']:shutil.copyfile(planpath/name,out/('plan_'+name))
 protocol=load(planpath/'protocol.json');papproval=load(planpath/'protocol_approval.json');m=read(planpath/'pool_members.csv');original=read(planpath/'audit_review.csv').set_index('unit_id')
 require(sha(tr/'diagnostic_model.joblib')==protocol['model_sha256'] and sha(prep/'codebook.md')==protocol['codebook_sha256'] and sha(reg/'registry_snapshot.csv')==protocol['registry_sha256'] and decision_binding(reg,protocol)==protocol['source_decisions_sha256'],'Audit pool dependencies changed')
 x=read_review(review);s=load(signature);signed(s,'CONFIRM_ACTUAL_POOL_AUDIT',ctx.identity)
 require(s['review_sha256']==sha(review) and sha(planpath/'protocol.json') in ([s['protocol_sha256']] if s.get('protocol_sha256') else s.get('protocol_sha256s',[])),'Audit signature binding mismatch')
 require(datetime.fromisoformat(s['signed_at'])>datetime.fromisoformat(papproval['signed_at']),'Judgments must follow protocol approval')
 require(x.unit_id.is_unique,'Duplicate audit IDs')
 if not set(x.unit_id)<=set(original.index):require(len(s.get('protocol_sha256s',[]))>1,'Extra audit IDs require a signed joint audit scope')
 x=x[x.unit_id.isin(set(original.index))].copy()
 for r in x.to_dict('records'):
  for k in ['policy_id','source_hash','text','context']:require(r.get(k,'')==original.loc[r['unit_id'],k],'Audit protected field changed')
 require(not set(x.unit_id)&set(load_training_ids(tr)),'Audit records consumed by training')
 truth_column='truth_'+protocol['label'] if 'truth_'+protocol['label'] in x else 'truth'
 require(truth_column in x,'Missing actual judgment for claimed field')
 x=x.copy();x['truth']=x[truth_column]
 complete=set(x.unit_id)==set(original.index) and x.truth.isin(['0','1']).all()
 human_events=[]
 for row in x[x.truth.isin(['0','1'])].itertuples():
  event=dict(unit_id=row.unit_id,field=protocol['label'],value=row.truth,status='HUMAN_ADJUDICATED',source_hash=row.source_hash,rule_version=protocol['codebook_sha256'],role='POOL_AUDIT_ONLY_NOT_TRAINING',reviewer=s['reviewer'],review_time=s['signed_at'],source_file_sha256=sha(review),signature_sha256=sha(signature),protocol_sha256=sha(planpath/'protocol.json'),identity=ctx.identity)
  event['evidence_id']=digest(event);human_events.append(event)
 csvout(out/'human_audit_events.csv',human_events,columns=['unit_id','field','value','status','source_hash','rule_version','role','reviewer','review_time','source_file_sha256','signature_sha256','protocol_sha256','identity','evidence_id'])
 original_review_name='actual_review'+Path(review).suffix.lower();shutil.copyfile(review,out/original_review_name);shutil.copyfile(signature,out/'actual_signature.json')
 if not complete:
  jsonout(out/'audit_result.json',dict(identity=ctx.identity,accepted=False,complete=False,reason='PARTIAL_OR_UNDETERMINED_NOT_PROBABILITY_ACCEPTANCE'));return
 claimed='1' if protocol['direction']=='POSITIVE' else '0';errors=int(x.truth.ne(claimed).sum());upper=error_bound(len(m),len(x),errors,protocol['alpha']);auto_upper=remaining_bound(len(m),len(x),errors,protocol['alpha']);passed=auto_upper<=protocol['risk_limit']
 result=dict(identity=ctx.identity,original_review_name=original_review_name,protocol_sha256=sha(planpath/'protocol.json'),review_sha256=sha(review),signature_sha256=sha(signature),pool_n=len(m),audit_n=len(x),errors=errors,error_upper=upper,auto_remaining_error_upper=auto_upper,actual_human_judgment_n=len(x),auto_remaining_n=len(m)-len(x),precision_lower=1-upper if claimed=='1' else None,false_omission_upper=upper if claimed=='0' else None,quality_pass=passed,complete=True,accepted=False,whole_corpus_reliability=False)
 jsonout(out/'audit_quality.json',result)
 # Actual error results exist before acceptance approval; independent population risk report always exported.
 unresolved=len(read(prep/'corpus.csv'))-len(read(reg/'registry_snapshot.csv').query("complete == 'True'"))
 jsonout(out/'scope_risk_report.json',dict(identity=ctx.identity,unresolved_rows=unresolved,full_corpus_omission_unknown=True,rare_label_support_not_proven_by_other_pool=True,policy_measurement_ready=False,claim_scope=protocol['claim_scope']))
 if passed and acceptance:
  a=load(acceptance);signed(a,'ACCEPT_EXACT_VALIDATED_POOL',ctx.identity)
  require(a['audit_quality_sha256']==sha(out/'audit_quality.json') and a['protocol_sha256']==sha(planpath/'protocol.json'),'Acceptance approval changed')
  shutil.copyfile(acceptance,out/'actual_acceptance.json');result['accepted']=True
  csvout(out/'accepted_fields.csv',[dict(unit_id=r.unit_id,field=protocol['label'],value=claimed,status='AUTO_ACCEPTED_UNDER_VALIDATED_PROTOCOL',protocol_sha256=sha(planpath/'protocol.json'),audit_quality_sha256=sha(out/'audit_quality.json'),model_sha256=protocol['model_sha256'],source_hash=r.source_hash,rule_version=protocol['codebook_sha256'],evidence_id=digest([sha(planpath/'protocol.json'),sha(out/'audit_quality.json'),sha(acceptance),r.unit_id,protocol['label']])) for r in m[~m.unit_id.isin(set(x.unit_id))].itertuples()],columns=['unit_id','field','value','status','protocol_sha256','audit_quality_sha256','model_sha256','source_hash','rule_version','evidence_id'])
 jsonout(out/'audit_result.json',result)
 # Quality failure is a completed audit outcome, not a program failure.
 if passed and not acceptance:raise Waiting('Actual audit passed risk bound; use accept-pool with exact result hash','WAITING_FOR_APPROVAL')

def load_training_ids(tr):
 import joblib
 return joblib.load(tr/'diagnostic_model.joblib')['training_ids']
def validate_evidence(ctx,artifact):
 """Validate each unique pool once per candidate validation; hashes bind all dependencies."""
 a=Path(artifact);r=load(a/'audit_result.json');require(boolean(r['accepted']) and boolean(r['complete']),'Pool not accepted')
 protocol=load(a/'plan_protocol.json');verify_family(ctx,protocol,sha(a/'plan_protocol.json'));members=read(a/'plan_pool_members.csv');roster=read(a/'plan_audit_review.csv')
 prep=ctx.artifact('prepare');tr=ctx.artifact('train');reg=ctx.artifact('build-registry')
 require(sha(a/'plan_pool_members.csv')==protocol['members_sha256'],'Pool membership hash changed')
 require(protocol['model_sha256']==sha(tr/'diagnostic_model.joblib') and protocol['codebook_sha256']==sha(prep/'codebook.md'),'Model/codebook approval invalidated')
 require(protocol['registry_sha256']==sha(reg/'registry_snapshot.csv') and protocol['source_decisions_sha256']==decision_binding(reg,protocol),'Registry/source rules invalidated pool')
 pa=load(a/'plan_protocol_approval.json');signed(pa,'APPROVE_EXACT_LOCAL_POOL_PROTOCOL',ctx.identity)
 require(pa['protocol_sha256']==sha(a/'plan_protocol.json'),'Protocol approval invalidated')
 require(protocol['alpha']==protocol['family_alpha']/protocol['planned_claims'] and protocol['look_number']==1,'Joint/repeated claim invalid')
 draw=np.random.default_rng(protocol['seed']).choice(len(members),protocol['sample_n'],replace=False)
 require(set(roster.unit_id)==set(members.iloc[draw].unit_id),'Registered random sample changed')
 s=load(a/'actual_signature.json');signed(s,'CONFIRM_ACTUAL_POOL_AUDIT',ctx.identity)
 require(s['review_sha256']==sha(a/r['original_review_name']),'Actual audit changed')
 require(sha(a/'plan_protocol.json') in ([s['protocol_sha256']] if s.get('protocol_sha256') else s.get('protocol_sha256s',[])) and datetime.fromisoformat(s['signed_at'])>datetime.fromisoformat(pa['signed_at']),'Audit not independent of protocol registration')
 actual=read_review(a/r['original_review_name']);truth_column='truth_'+protocol['label'] if 'truth_'+protocol['label'] in actual else 'truth';require(truth_column in actual,'Missing pool judgment');actual['truth']=actual[truth_column];require(actual.unit_id.is_unique,'Duplicate audit IDs');extra=set(actual.unit_id)-set(roster.unit_id);require(not extra or len(s.get('protocol_sha256s',[]))>1,'Unregistered joint audit scope');actual=actual[actual.unit_id.isin(set(roster.unit_id))];require(actual.unit_id.is_unique and set(actual.unit_id)==set(roster.unit_id) and actual.truth.isin(['0','1']).all(),'Incomplete actual audit')
 require(not set(actual.unit_id)&set(load_training_ids(tr)),'Audit used for training')
 value='1' if protocol['direction']=='POSITIVE' else '0';errors=int(actual.truth.ne(value).sum())
 bound=error_bound(len(members),len(actual),errors,protocol['alpha'])
 auto_bound=remaining_bound(len(members),len(actual),errors,protocol['alpha']);require(auto_bound<=protocol['risk_limit'] and np.isclose(bound,r['error_upper']) and np.isclose(auto_bound,r['auto_remaining_error_upper']),'Pool risk recomputation failed')
 acceptance=load(a/'actual_acceptance.json');signed(acceptance,'ACCEPT_EXACT_VALIDATED_POOL',ctx.identity)
 require(acceptance['audit_quality_sha256']==sha(a/'audit_quality.json'),'Pool result approval invalid')
 q=load(a/'audit_quality.json');require(q['quality_pass'] and q['protocol_sha256']==acceptance['protocol_sha256'],'Pool approval wrong scope')
 accepted=read(a/'accepted_fields.csv')
 require(accepted.unit_id.is_unique and set(accepted.unit_id)==set(members.unit_id)-set(actual.unit_id) and accepted.field.eq(protocol['label']).all() and accepted.value.eq(value).all(),'Accepted field scope changed')
 require(accepted.model_sha256.eq(protocol['model_sha256']).all() and accepted.rule_version.eq(protocol['codebook_sha256']).all(),'Accepted field dependency changed')
 for row in accepted.itertuples():
  require(row.evidence_id==digest([sha(a/'plan_protocol.json'),sha(a/'audit_quality.json'),sha(a/'actual_acceptance.json'),row.unit_id,protocol['label']]),'Forged accepted field hash')
 return accepted
if __name__=='__main__':
 from coding_pipeline import main
 main()

def validate_human_audit(ctx,artifact):
 a=Path(artifact);protocol=load(a/'plan_protocol.json');sig=load(a/'actual_signature.json');signed(sig,'CONFIRM_ACTUAL_POOL_AUDIT',ctx.identity)
 files=[p for p in a.iterdir() if p.name.startswith('actual_review.')];require(len(files)==1,'Missing original audit file');raw=files[0]
 require(sig['review_sha256']==sha(raw),'Human audit source changed')
 require(sha(a/'plan_protocol.json') in ([sig['protocol_sha256']] if sig.get('protocol_sha256') else sig.get('protocol_sha256s',[])),'Human audit protocol binding mismatch')
 events=read(a/'human_audit_events.csv');rawdf=read_review(raw);require(rawdf.unit_id.is_unique,'Duplicate human audit response');review=rawdf.set_index('unit_id');roster=read(a/'plan_audit_review.csv').set_index('unit_id');truthcol='truth_'+protocol['label'] if 'truth_'+protocol['label'] in review else 'truth'
 require(events.unit_id.is_unique,'Duplicate actual audit human event')
 for row in events.to_dict('records'):
  require(row['reviewer']==sig['reviewer'] and row['review_time']==sig['signed_at'] and row['source_file_sha256']==sha(raw) and row['signature_sha256']==sha(a/'actual_signature.json') and row['protocol_sha256']==sha(a/'plan_protocol.json') and row['identity']==ctx.identity,'Human audit provenance mismatch')
  uid=row['unit_id'];require(uid in roster.index and uid in review.index and row['value']==review.loc[uid,truthcol] and row['field']==protocol['label'],'Audit human value not supported by actual response')
  for col in ['text','context','source_hash']:require(review.loc[uid,col]==roster.loc[uid,col],'Audit source/context changed')
  eid=row.pop('evidence_id');require(eid==digest(row),'Forged audit human event')
 return events

def register_family(ctx,proto,protocol_hash,members,approval):
 path=ctx.root/'audit_family_registry.json';ledger=load(path) if path.exists() else dict(families={},pools={})
 family=proto['family_id'];pid=proto['pool_id'];anchor={k:proto[k] for k in ['model_sha256','codebook_sha256','family_alpha','planned_claims']}
 if family in ledger['families']:require(ledger['families'][family]['anchor']==anchor,'Family model/rule/alpha budget changed')
 else:ledger['families'][family]=dict(anchor=anchor,pools=[])
 if pid in ledger['pools']:
  require(ledger['pools'][pid]['protocol_sha256']==protocol_hash,'Approved pool changed; independent amendment required, no silent replan');return
 for other in ledger['pools'].values():
  if other['model_sha256']==proto['model_sha256'] and other['label']==proto['label']:
   require(not set(other['members'])&set(members.unit_id),'Renaming/repeated overlapping pool cannot bypass registered audit')
 f=ledger['families'][family];require(len(f['pools'])<proto['planned_claims'],'Registered family claim budget exhausted')
 f['pools'].append(pid)
 ledger['pools'][pid]=dict(family_id=family,protocol_sha256=protocol_hash,alpha=proto['alpha'],look=1,label=proto['label'],model_sha256=proto['model_sha256'],codebook_sha256=proto['codebook_sha256'],members_sha256=proto['members_sha256'],members=members.unit_id.tolist(),approval_sha256=sha(approval))
 atomic_json(path,ledger)

def verify_family(ctx,protocol,protocol_hash):
 ledger=load(ctx.root/'audit_family_registry.json');p=ledger['pools'][protocol['pool_id']];f=ledger['families'][protocol['family_id']]
 require(p['protocol_sha256']==protocol_hash and p['members_sha256']==protocol['members_sha256'] and p['alpha']==protocol['alpha'] and p['look']==1,'Audit family binding invalid')
 require(len(f['pools'])<=f['anchor']['planned_claims'] and sum(ledger['pools'][x]['alpha'] for x in f['pools'])<=f['anchor']['family_alpha']+1e-12,'Family error budget exceeded')

def accept_pool(ctx,out,pool_id,batch_id,protocol_sha256,approval):
 key='ingest-audit:'+pool_id+':'+batch_id;require(ctx.valid(key),'Actual audit receipt missing or invalid');source=ctx.root/ctx.manifest['stages'][key]['artifact']
 q=load(source/'audit_quality.json');require(q['quality_pass'] and q['complete'],'Actual pool risk test failed')
 a=load(approval);signed(a,'ACCEPT_EXACT_VALIDATED_POOL',ctx.identity)
 require(a['protocol_sha256']==protocol_sha256==sha(source/'plan_protocol.json') and a['audit_quality_sha256']==sha(source/'audit_quality.json'),'Pool acceptance bound to wrong actual result')
 for p in source.iterdir():
  if p.is_file() and p.name!='waiting.json':shutil.copyfile(p,out/p.name)
 shutil.copyfile(approval,out/'actual_acceptance.json');proto=load(out/'plan_protocol.json');verify_family(ctx,proto,protocol_sha256)
 members=read(out/'plan_pool_members.csv');review=validate_human_audit(ctx,out);claimed='1' if proto['direction']=='POSITIVE' else '0'
 csvout(out/'accepted_fields.csv',[dict(unit_id=r.unit_id,field=proto['label'],value=claimed,status='AUTO_ACCEPTED_UNDER_VALIDATED_PROTOCOL',protocol_sha256=protocol_sha256,audit_quality_sha256=sha(out/'audit_quality.json'),model_sha256=proto['model_sha256'],source_hash=r.source_hash,rule_version=proto['codebook_sha256'],evidence_id=digest([protocol_sha256,sha(out/'audit_quality.json'),sha(approval),r.unit_id,proto['label']])) for r in members[~members.unit_id.isin(set(review.unit_id))].itertuples()],columns=['unit_id','field','value','status','protocol_sha256','audit_quality_sha256','model_sha256','source_hash','rule_version','evidence_id'])
 result=load(out/'audit_result.json');result['accepted']=True;jsonout(out/'audit_result.json',result);validate_evidence(ctx,out)
