"""research coding-only CLI. All commands execute actual modules with explicit paths."""
from common import *
import argparse
import review_registry as rr
from train_limited import train,readiness
from predict_corpus import predict
from pool_audit import plan,ingest,accept_pool
from assemble_candidate import assemble
from candidate_publisher import validate,publish

COMMANDS=['publish-group','status','prepare','ingest-return','ingest-decisions','build-registry','train','predict','plan-audit','ingest-audit','assemble-candidate','validate-candidate','publish','resume','make-signature','accept-pool','training-readiness','export_supplement','register-adjudication','ingest-adjudication','part1-ledger','finalize-part1','publish-part1','ingest-share-quality','reproduce-part1']
def execute(ctx,command,**kwargs):
 ctx._vcache={}
 if command=='status':return ctx.status()
 if command=='publish-group':
  if ctx.artifact('assemble-candidate',required=False) is None:execute(ctx,'assemble-candidate')
  if ctx.artifact('part1-ledger',required=False) is None:execute(ctx,'part1-ledger')
  from share_quality import publish_group
  approval=Path(kwargs['approval']);return ctx.stage('publish-group:'+sha(approval)[:20],['assemble-candidate','ingest-share-quality:*'],[approval],lambda out:publish_group(ctx,out,approval),immutable_event=True)
 if command=='ingest-share-quality':
  from share_quality import ingest as ingest_quality
  review=Path(kwargs['review']);sig=Path(kwargs['signature']);key='ingest-share-quality:'+digest([sha(review),sha(sig)])[:24]
  if ctx.artifact(key,required=False):return dict(stage=key,state='COMPLETED',reused=True,artifact=ctx.manifest['stages'][key]['artifact'])
  if ctx.artifact('assemble-candidate',required=False) is None:
   r=execute(ctx,'assemble-candidate');require(r['state']=='COMPLETED','Assembly not ready for quality import')
  assembly=ctx.artifact('assemble-candidate')
  # Capture immutable evidence before the new quality event invalidates assembly dependencies.
  return ctx.stage(key,['prepare'],[review,sig,assembly/'policy_group_shares.csv',assembly/'field_evidence.csv'],lambda out:ingest_quality(ctx,out,review,sig,assembly),immutable_event=True)
 if command=='register-adjudication':
  from adjudication import register
  q=Path(kwargs['input']);sid=kwargs['pool_id']
  key='register-adjudication:'+sid
  existing=ctx.artifact(key,required=False)
  if existing:
   require(load(existing/'scope.json')['request_sha256']==sha(q),'Scope ID already registered to different request')
   return dict(stage=key,state='COMPLETED',reused=True,artifact=str(existing.relative_to(ctx.root)))
  return ctx.stage(key,['prepare','build-registry','train','predict'],[q],lambda out:register(ctx,out,q,sid),immutable_event=True)
 if command=='ingest-adjudication':
  from adjudication import ingest as ingest_adjudication
  review=Path(kwargs['review']);sig=Path(kwargs['signature']);sid=kwargs['pool_id'];key='ingest-adjudication:'+digest([sha(review),sha(sig)])[:24]
  existing=ctx.artifact(key,required=False)
  if existing:
   require(load(existing/'registered_scope.json')['scope_id']==sid,'Existing batch bound to another scope')
   return dict(stage=key,state='COMPLETED',reused=True,artifact=str(existing.relative_to(ctx.root)))
  previous=ctx.artifact('build-registry',required=False)
  if previous is None:
   execute(ctx,'build-registry');previous=ctx.artifact('build-registry')
  return ctx.stage(key,['prepare','register-adjudication:'+sid],[review,sig,previous/'human_field_evidence.csv'],lambda out:ingest_adjudication(ctx,out,sid,review,sig,previous),immutable_event=True)
 if command in ['part1-ledger','finalize-part1','publish-part1','ingest-share-quality','reproduce-part1']:
  import part1_completion as pc
  if command=='part1-ledger':return ctx.stage(command,['prepare','build-registry','train','predict','assemble-candidate','ingest-audit:*','accept-pool:*','ingest-share-quality:*'],[],lambda out:pc.build(ctx,out))
  if command=='publish-part1':
   approval=Path(kwargs['approval']);return ctx.stage(command,['part1-ledger','validate-candidate'],[approval],lambda out:pc.publish(ctx,out,approval))
  if command=='reproduce-part1':return ctx.stage(command,['publish-part1','assemble-candidate'],[],lambda out:pc.reproduce(ctx,out))
  assurance=ctx.root/'assurance';sources=list(assurance.glob('*.json')) if assurance.exists() else []
  return ctx.stage(command,['part1-ledger','validate-candidate','publish','publish-part1','reproduce-part1','train'],sources,lambda out:pc.finalize(ctx,out))
 if command=='make-signature':
  from signature_proposals import proposal
  return proposal(ctx,kwargs['kind'],kwargs.get('input'),kwargs.get('output'),kwargs.get('pool_id'),kwargs.get('protocol_sha256'))
 if command=='prepare':
  sources=[ctx.input(k) for k in ctx.cfg['inputs']]
  corpus=read(ctx.input('corpus'));sources+=list(map(Path,corpus.source_clean_path.unique()))
  return ctx.stage('prepare',[],sources,lambda out:rr.prepare(ctx,out))
 if command=='ingest-return':
  review=Path(kwargs['review']);sig=Path(kwargs['signature']);key='ingest-return:'+digest([sha(review),sha(sig)])[:24]
  if ctx.artifact(key,required=False):return dict(stage=key,state='COMPLETED',reused=True,artifact=ctx.manifest['stages'][key]['artifact'])
  previous=ctx.artifact('build-registry',required=False) if load(sig).get('scope')=='EXPLICIT_HUMAN_CORRECTION' else None
  sources=[review,sig]+([previous/'registry_snapshot.csv',previous/'human_field_evidence.csv'] if previous else [])
  return ctx.stage(key,['prepare'],sources,lambda out:rr.ingest_return(ctx,out,review,sig,previous),immutable_event=True)
 if command=='ingest-decisions':
  decision=Path(kwargs['decisions']);sig=Path(kwargs['signature']);key='ingest-decisions:'+digest([sha(decision),sha(sig)])[:24]
  if ctx.artifact(key,required=False):return dict(stage=key,state='COMPLETED',reused=True,artifact=ctx.manifest['stages'][key]['artifact'])
  return ctx.stage(key,['prepare'],[decision,sig],lambda out:rr.ingest_decisions(ctx,out,decision,sig),immutable_event=True)
 if command=='build-registry':return ctx.stage(command,['prepare','ingest-return:*','ingest-decisions:*','ingest-adjudication:*'],[],lambda out:rr.build_registry(ctx,out))
 if command=='training-readiness':return ctx.stage(command,['@training'],[],lambda out:readiness(ctx,out))
 if command=='export_supplement':
  from export_supplement import export
  return ctx.stage(command,['prepare','build-registry','assemble-candidate','train','ingest-audit:*','accept-pool:*'],[ctx.code/'plot_s6.py',ctx.workspace/'00_reference/supplementary material.docx'],lambda out:export(ctx,out))
 if command=='train':return ctx.stage(command,['@training'],[],lambda out:train(ctx,out))
 if command=='predict':return ctx.stage(command,['prepare','train'],[],lambda out:predict(ctx,out))
 if command=='plan-audit':
  pid=kwargs.get('pool_id');require(pid and re.fullmatch(r'[A-Za-z0-9_-]+',pid),'Explicit safe pool_id required');definition=Path(kwargs['input']);approval=Path(kwargs['approval']) if kwargs.get('approval') else None
  return ctx.stage('plan-audit:'+pid,['prepare','build-registry','train','predict'],[definition]+([approval] if approval else []),lambda out:plan(ctx,out,definition,approval,pid,kwargs.get('protocol_sha256')))
 if command=='ingest-audit':
  pid=kwargs.get('pool_id');bid=kwargs.get('batch_id');require(pid and bid and re.fullmatch(r'[A-Za-z0-9_-]+',pid) and re.fullmatch(r'[A-Za-z0-9_-]+',bid),'Explicit pool_id and batch_id required')
  review=Path(kwargs['review']);sig=Path(kwargs['signature']);key='ingest-audit:'+pid+':'+bid
  old=ctx.manifest['stages'].get(key)
  if old:require(old['sources'].get(str(review.resolve()))==sha(review) and old['sources'].get(str(sig.resolve()))==sha(sig),'Batch ID already bound to different content')
  return ctx.stage(key,['prepare','build-registry','train','plan-audit:'+pid],[review,sig],lambda out:ingest(ctx,out,review,sig,None,pid,kwargs.get('protocol_sha256')),immutable_event=True)
 if command=='accept-pool':
  pid=kwargs.get('pool_id');bid=kwargs.get('batch_id');approval=Path(kwargs['approval']);a=load(approval);key='accept-pool:'+str(pid)+':'+a['audit_quality_sha256']
  return ctx.stage(key,['ingest-audit:'+str(pid)+':'+str(bid),'train'],[approval],lambda out:accept_pool(ctx,out,pid,bid,kwargs.get('protocol_sha256'),approval),immutable_event=True)
 if command=='assemble-candidate':return ctx.stage(command,['prepare','build-registry','ingest-audit:*','accept-pool:*','ingest-share-quality:*'],[],lambda out:assemble(ctx,out))
 if command=='validate-candidate':
  candidate=kwargs.get('candidate');bundle=kwargs.get('bundle')
  return ctx.stage(command,['prepare','build-registry','assemble-candidate','train','ingest-audit:*','accept-pool:*'],[p for p in [candidate,bundle] if p],lambda out:validate(ctx,out,candidate,bundle))
 if command=='publish':
  approval=Path(kwargs['approval']);return ctx.stage(command,['prepare','build-registry','assemble-candidate','validate-candidate'],[approval],lambda out:publish(ctx,out,approval))
 if command=='resume':return resume(ctx)
 raise ValueError('Unknown command')
def resume(ctx):
 results=[execute(ctx,'prepare')]
 if results[-1]['state']!='COMPLETED':return results
 inbox=ctx.root/'inbox';inbox.mkdir(exist_ok=True)
 def items(sub):
  for p in sorted((inbox/sub).glob('*.json')) if (inbox/sub).exists() else []:
   d=load(p)
   for k in ['review','signature','decisions','input','approval','acceptance','pack']:
    if d.get(k):d[k]=str((p.parent/d[k]).resolve())
   yield d
 for d in items('returns'):results.append(execute(ctx,'ingest-return',**d))
 for d in items('decisions'):results.append(execute(ctx,'ingest-decisions',**d))
 results.append(execute(ctx,'build-registry'))
 for d in items('adjudications'):results.append(execute(ctx,'ingest-adjudication',**d))
 if (inbox/'adjudications').exists():results.append(execute(ctx,'build-registry'))
 # Coding continuation must never fit implicitly.
 if ctx.artifact('train',required=False) is None:raise Waiting('Frozen model invalid: inspect training signature; automatic retraining disabled')
 results.append(execute(ctx,'predict'))
 for d in items('group_returns'):
  from group_review import ingest_return as ingest_group_return
  results.append(dict(stage='group-return',state='COMPLETED',result=ingest_group_return(ctx,Path(d['pack']),Path(d['review']))))
 # Preserve completed audits; a coding-only resume never initiates a draw.
 for d in items('pools'):
  historical=[k for k,_ in ctx.audit_events() if k.startswith('ingest-audit:'+d['pool_id']+':')]
  if not historical:raise Waiting('Pool has no completed audit; new sampling requires explicit invocation')
 results.append(execute(ctx,'assemble-candidate'))
 # Incomplete candidate is a genuine waiting condition, not an attempted approval.
 ass=ctx.artifact('assemble-candidate',required=False)
 if ass and load(ass/'candidate_status.json')['labels_complete']:
  results.append(execute(ctx,'validate-candidate'))
  approval=inbox/'publish_approval.json'
  if approval.exists():results.append(execute(ctx,'publish',approval=str(approval)))
 if ctx.identity=='REAL':
  results.append(execute(ctx,'export_supplement'))
  quality_changed=False
  for d in items('share_quality'):
   r=execute(ctx,'ingest-share-quality',**d);results.append(r);quality_changed=quality_changed or not r.get('reused',False)
  if quality_changed:results.append(execute(ctx,'assemble-candidate'))
  results.append(execute(ctx,'part1-ledger'))
  for d in items('group_publish'):results.append(execute(ctx,'publish-group',**d))
  if (inbox/'part1_publish_approval.json').exists():
   results.append(execute(ctx,'publish-part1',approval=str(inbox/'part1_publish_approval.json')))
   results.append(execute(ctx,'reproduce-part1'))
  results.append(execute(ctx,'finalize-part1'))
 return results
def main(forced=None):
 p=argparse.ArgumentParser(description='Coding-only pipeline; no SD entry point')
 if not forced:p.add_argument('command',choices=COMMANDS)
 p.add_argument('--workspace',required=True);p.add_argument('--run-id',required=True);p.add_argument('--config')
 for k in ['review','signature','decisions','input','approval','acceptance','candidate','bundle','kind','output','pool_id','protocol_sha256','batch_id']:p.add_argument('--'+k.replace('_','-'),dest=k)
 a=p.parse_args();ctx=Context(a.workspace,a.run_id,a.config)
 try:
  r=execute(ctx,forced or a.command,**{k:getattr(a,k) for k in ['review','signature','decisions','input','approval','acceptance','candidate','bundle','kind','output','pool_id','protocol_sha256','batch_id']})
  print(json.dumps(r,ensure_ascii=False));failed=any(x.get('state')=='FAILED' for x in r) if isinstance(r,list) else r.get('state')=='FAILED'
  if failed:raise SystemExit(1)
 except (ValueError,KeyError,TypeError,FileNotFoundError) as e:
  print(json.dumps(dict(state='FAILED',error=str(e)),ensure_ascii=False));raise SystemExit(2)
if __name__=='__main__':main()
