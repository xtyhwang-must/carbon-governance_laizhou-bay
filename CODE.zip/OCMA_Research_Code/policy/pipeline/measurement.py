"""Policy composition, distinct prevalence and fractional-action sensitivity."""
from common import *
G=LABELS[1:4];T=LABELS[4:]
CONTRACT=dict(version='ASSIGNMENT_COMPOSITION_V2',main='within-policy group assignment counts / total group assignments',sensitivity='equal total weight per action within each nonempty group',policy_weighting='equal policy weights; undefined policies excluded, never zero-filled',zero_denominator='NA',ineligible='NOT_COUNTED_INELIGIBLE')

def generate_groups(ctx,out,cat,c,fields,dec,conflicts):
 from group_readiness import export
 return export(ctx,out,cat,c,fields,dec,conflicts)

def generate(ctx,out,cat,c,dec):
 ci=c.set_index('unit_id');ca=cat.set_index('unit_id');mapping={};conflicts=set();exceptions=[];general_candidates=[]
 for d in dec[dec.type.isin(['ACTION_COUNTING_BOUNDARY','ACTION_COUNTING_RULE']) & dec.value.eq('CONFIRM')].to_dict('records'):
  ids=json.loads(d['unit_ids'])
  for uid in ids:
   if not boolean(str(ci.loc[uid,'complete'])) or ci.loc[uid,'C2_eligibility']!='1':continue
   if d['type']=='ACTION_COUNTING_RULE':
    r=ca.loc[uid];txt=r.exact_evidence_text
    good=int(r.parent_member_count)==1 and len(txt.strip())>=20 and bool(re.search(r'[。；;.!！?？]$',txt.strip())) and len(cat[(cat.policy_id==r.policy_id)&(cat.exact_evidence_text==txt)])==1
    if not good:exceptions.append(dict(unit_id=uid,reason='FRAGMENT_MULTIPLE_PARENT_OR_DUPLICATE_NEEDS_EXPLICIT_BOUNDARY'));continue
    aid='ACT_'+digest([r.policy_id,r.policy_version_id,uid,txt])[:24]
   else:aid=d['action_unit_id']
   if uid in mapping and mapping[uid]['action_unit_id']!=aid:conflicts.add(uid)
   mapping[uid]=dict(unit_id=uid,policy_id=ca.loc[uid,'policy_id'],action_unit_id=aid,counting_status='COUNTED_ELIGIBLE',counting_rule=d['rule_text'],decision_event_id=d['decision_event_id'])
 rows=[]
 for uid in cat.unit_id:
  r=ci.loc[uid];negative=boolean(str(r.complete)) and r.C2_eligibility=='0'
  if negative:row=dict(unit_id=uid,policy_id=r.policy_id,action_unit_id='',counting_status='NOT_COUNTED_INELIGIBLE',counting_rule=CONTRACT['version'],decision_event_id='')
  else:row=mapping.get(uid,dict(unit_id=uid,policy_id=r.policy_id,action_unit_id='',counting_status='UNRESOLVED_COUNTING',counting_rule='',decision_event_id=''))
  if row['counting_status']=='UNRESOLVED_COUNTING' and boolean(str(r.complete)) and r.C2_eligibility=='1':
   cr=ca.loc[uid];txt=cr.exact_evidence_text
   clear=int(cr.parent_member_count)==1 and len(txt.strip())>=20 and bool(re.search(r'[。；;.!！?？]$',txt.strip())) and len(cat[(cat.policy_id==r.policy_id)&(cat.exact_evidence_text==txt)])==1
   if clear:general_candidates.append(uid)
   else:exceptions.append(dict(unit_id=uid,reason='CONFIRMED_ELIGIBLE_BOUNDARY_OR_DUPLICATE_EXCEPTION'))
  if uid in conflicts:
   row['counting_status']='CONFLICT';row['proposed_action_unit_id']=row['action_unit_id'];row['action_unit_id']='';exceptions.append(dict(unit_id=uid,reason='MULTIPLE_APPROVED_ACTION_IDS_CONFLICT'))
  rows.append(row)
 mp=pd.DataFrame(rows);actions=[]
 for aid,z in mp[mp.action_unit_id.ne('')].groupby('action_unit_id'):
  vals=ci.loc[z.unit_id];ok=z.policy_id.nunique()==1 and len(vals[['C2_'+k for k in LABELS]].drop_duplicates())==1 and vals.C2_eligibility.eq('1').all()
  if not ok:
   members=mp.action_unit_id.eq(aid);mp.loc[members,'proposed_action_unit_id']=aid;mp.loc[members,'counting_status']='MERGE_CONFLICT';mp.loc[members,'action_unit_id']=''
   exceptions.extend(dict(unit_id=uid,reason='MERGED_ACTION_LABEL_OR_POLICY_CONFLICT') for uid in z.unit_id);continue
  actions.append(dict(action_unit_id=aid,policy_id=z.iloc[0].policy_id,original_units=len(z),consistent=ok,**{k:vals.iloc[0]['C2_'+k] if ok else '' for k in LABELS}))
 ac=pd.DataFrame(actions,columns=['action_unit_id','policy_id','original_units','consistent']+LABELS);shares=[];prev=[];fraction=[];issues=[]
 for pol,units in cat.groupby('policy_id',sort=False):
  z=mp[mp.policy_id.eq(pol)];a=ac[ac.policy_id.eq(pol)];ready=ci.loc[units.unit_id,'complete'].map(lambda x:boolean(str(x))).all() and z.counting_status.isin(['COUNTED_ELIGIBLE','NOT_COUNTED_INELIGIBLE']).all() and (a.consistent.all() if len(a) else True)
  row=dict(policy_id=pol,measurement_ready=bool(ready),eligible_action_n=len(a) if ready else '',denominator='GROUP_ASSIGNMENT_COUNTS',zero_eligible_policy='UNDEFINED_NOT_ZERO' if ready and not len(a) else '')
  pr=dict(policy_id=pol);fr=dict(policy_id=pol)
  for group,ks in [('G',G),('T',T)]:
   x=a[ks].astype(int) if ready and len(a) else pd.DataFrame(columns=ks);den=int(x.to_numpy().sum()) if ready else None
   row[group+'_assignment_denominator']=den if den is not None else ''
   zero=int(x.sum(axis=1).eq(0).sum()) if len(x) else 0
   row[group+'_zero_label_actions']=zero if ready else ''
   if ready and len(a) and (not den or zero):issues.append(dict(policy_id=pol,group=group,reason='ELIGIBLE_ACTION_WITHOUT_GROUP_LABEL',actions=zero))
   for k in ks:
    row[k]=float(x[k].sum()/den) if ready and den else ''
    pr[k+'_action_prevalence']=float(x[k].mean()) if ready and len(x) else ''
    nonzero=x.sum(axis=1)>0 if len(x) else pd.Series(dtype=bool)
    fr[k]=float(x.loc[nonzero,k].div(x.loc[nonzero].sum(axis=1)).mean()) if ready and nonzero.any() else ''
   fr[group+'_nonempty_action_denominator']=int(nonzero.sum()) if ready else ''
  shares.append(row);prev.append(pr);fraction.append(fr)
 proposals=[]
 for pol,g in cat[cat.unit_id.isin(general_candidates)].groupby('policy_id'):
  ids=sorted(g.unit_id);proposals.append(dict(decision_id='GENERAL_COUNT_'+pol+'_'+digest(ids)[:12],type='ACTION_COUNTING_RULE',unit_ids=json.dumps(ids),value='',rule_text='Count complete unique single-parent eligible units once; exclude fragments and duplicate text',action_unit_id='',representative_id='',scope_sha256=digest(ids),source_binding=digest(g[['unit_id','source_hash','source_clean_sha256']].sort_values('unit_id').to_dict('records')) if 'source_hash' in g and 'source_clean_sha256' in g else '',status='UNSIGNED_SCOPE_PROPOSAL'))
 csvout(out/'counting_rule_scope_proposals.csv',proposals,columns=['decision_id','type','unit_ids','value','rule_text','action_unit_id','representative_id','scope_sha256','source_binding','status'])
 csvout(out/'action_unit_mapping.csv',mp);csvout(out/'action_unit_summary.csv',ac);csvout(out/'policy_level_shares.csv',shares);csvout(out/'action_prevalence.csv',prev);csvout(out/'equal_action_weight_sensitivity.csv',fraction)
 csvout(out/'action_counting_exceptions.csv',exceptions,columns=['unit_id','reason']);csvout(out/'measurement_issues.csv',issues,columns=['policy_id','group','reason','actions']);jsonout(out/'measurement_contract.json',CONTRACT)
 # Persist an independently computed report rather than trusting the generation boolean.
 result=verify(out,c,cat,dec);jsonout(out/'measurement_validation.json',result)
 return result

def verify(folder,c,cat,dec):
 """Independent counts and arithmetic; never calls generate to create expected values."""
 m=read(folder/'action_unit_mapping.csv');a=read(folder/'action_unit_summary.csv');s=read(folder/'policy_level_shares.csv');ci=c.set_index('unit_id');issues=[]
 require(m.unit_id.is_unique and set(m.unit_id)==set(cat.unit_id),'Measurement mapping coverage changed')
 require(a.action_unit_id.is_unique,'Duplicate counted action ID')
 require(set(s.policy_id)==set(cat.policy_id) and s.policy_id.is_unique,'Policy summary scope changed')
 d=dec.set_index('decision_event_id');expected={};policy_complete={}
 for pol,records in m.groupby('policy_id'):
  good=True
  for r in records.itertuples():
   h=ci.loc[r.unit_id]
   if not boolean(str(h.complete)):good=False;continue
   if h.C2_eligibility=='0':require(r.counting_status=='NOT_COUNTED_INELIGIBLE' and not r.action_unit_id,'Ineligible action counted');continue
   if r.counting_status!='COUNTED_ELIGIBLE' or not r.action_unit_id:good=False;continue
   require(r.decision_event_id in d.index and d.loc[r.decision_event_id,'value']=='CONFIRM','Unapproved counting')
   dr=d.loc[r.decision_event_id];require(r.unit_id in json.loads(dr.unit_ids),'Action outside approved scope')
   if dr.type=='ACTION_COUNTING_BOUNDARY':require(r.action_unit_id==dr.action_unit_id,'Boundary action changed')
   elif dr.type=='ACTION_COUNTING_RULE':
    cr=cat.set_index('unit_id').loc[r.unit_id];require(int(cr.parent_member_count)==1 and len(cr.exact_evidence_text.strip())>=20 and bool(re.search(r'[。；;.!！?？]$',cr.exact_evidence_text.strip())) and len(cat[(cat.policy_id==pol)&(cat.exact_evidence_text==cr.exact_evidence_text)])==1,'General rule applied to exception')
    require(r.action_unit_id=='ACT_'+digest([pol,cr.policy_version_id,r.unit_id,cr.exact_evidence_text])[:24],'Generated ID not stable')
   else:raise ValueError('Group label approval cannot approve counting')
   vec=tuple(h['C2_'+k] for k in LABELS)
   if r.action_unit_id in expected:require(expected[r.action_unit_id]==(pol,vec),'Incompatible merged action')
   expected[r.action_unit_id]=(pol,vec)
  policy_complete[pol]=good
 require(set(expected)==set(a.action_unit_id),'Counted actions missing/added')
 for r in a.itertuples():require(expected[r.action_unit_id]==(r.policy_id,tuple(getattr(r,k) for k in LABELS)),'Action summary altered')
 for r in s.to_dict('records'):
  pol=r['policy_id'];ready=policy_complete[pol];require(boolean(r['measurement_ready'])==ready,'Policy readiness altered')
  values=[v for p,v in expected.values() if p==pol]
  require(r['eligible_action_n']==(str(len(values)) if ready else ''),'Eligible denominator altered')
  for keys in [G,T]:
   den=sum(int(v[LABELS.index(k)]) for v in values for k in keys)
   require(r[keys[0][0]+'_assignment_denominator']==(str(den) if ready else ''),'Assignment denominator altered')
   for k in keys:
    target=sum(int(v[LABELS.index(k)]) for v in values)/den if ready and den else None
    require((r[k]=='' if target is None else np.isclose(float(r[k]),target,rtol=0,atol=1e-12)),'Policy composition arithmetic mismatch')
   if ready and any(not any(int(v[LABELS.index(k)]) for k in keys) for v in values):issues.append(pol+':'+keys[0][0]+':ZERO_GROUP_LABEL')
 return dict(verified=True,POLICY_MEASUREMENT_READY=all(policy_complete.values()) and not issues,issues=issues,policy_count=len(s),action_count=len(expected),method='INDEPENDENT_COUNTER_REAGGREGATION',identity='MEASUREMENT_VERIFICATION_NOT_LABEL_QUALITY')
