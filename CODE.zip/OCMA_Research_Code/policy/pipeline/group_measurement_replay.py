"""Independent fixed-field group replay; no training or full-release claim."""
if __name__!='__main__':
 from common import *

def reproduce_groups(ctx,out):
 import subprocess,sys
 ass=ctx.artifact('assemble-candidate');target=out/'group_replay';target.mkdir()
 for n in ['C2_candidate.csv','field_evidence.csv','group_action_mapping.csv','policy_group_shares.csv']:shutil.copyfile(ass/n,target/n)
 script=Path(__file__).with_name('group_measurement_replay.py');shutil.copyfile(script,target/script.name)
 result=subprocess.run([sys.executable,str(target/script.name),'--replay-root',str(target)],capture_output=True,text=True,encoding='utf-8')
 (out/'stdout.log').write_text(result.stdout,'utf-8');(out/'stderr.log').write_text(result.stderr,'utf-8');require(result.returncode==0,'Actual group replay failed')
 report=load(target/'group_replay_report.json');report.update(formal_release_recomputed=False,identity='CURRENT_GROUP_FIXED_FIELD_REPLAY_NOT_FULL_RELEASE',candidate_sha256=sha(ass/'C2_candidate.csv'));jsonout(out/'independent_replay.json',report)

# Keep standalone execution independent of project's calculation and generation modules.
if __name__=='__main__':
 import argparse,csv,json,hashlib
 from pathlib import Path
 p=argparse.ArgumentParser();p.add_argument('--replay-root',required=True);a=p.parse_args();root=Path(a.replay_root)
 def rows(n):
  with (root/n).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
 c={r['unit_id']:r for r in rows('C2_candidate.csv')};ev={(r['unit_id'],r['field']):r for r in rows('field_evidence.csv')};mapping=rows('group_action_mapping.csv');checked=[]
 for r in rows('policy_group_shares.csv'):
  if r['measurement_ready']!='True':continue
  labels=['G1','G2','G3'] if r['group']=='G' else ['T1','T2','T3','T4','T5','T6'];actions={}
  for m in mapping:
   if m['policy_id']!=r['policy_id']:continue
   u=m['unit_id'];assert c[u]['eligibility_ready']=='True' and c[u][r['group']+'_group_ready']=='True' and m['action_boundary_ready']=='True'
   for k in ['eligibility']+labels:assert (u,k) in ev and ev[(u,k)]['value']==c[u]['C2_'+k]
   if c[u]['C2_eligibility']=='0':continue
   aid=m['action_unit_id'];assert aid;v=tuple(int(c[u]['C2_'+k]) for k in labels);assert aid not in actions or actions[aid]==v;actions[aid]=v
  counts=[sum(v[i] for v in actions.values()) for i in range(len(labels))];den=sum(counts);assert den==int(r['assignment_denominator'])
  for k,n in zip(labels,counts):assert (r[k]=='' if den==0 else abs(float(r[k])-n/den)<1e-12)
  checked.append(dict(policy_id=r['policy_id'],group=r['group'],actions=len(actions),denominator=den,counts=dict(zip(labels,counts)),group_binding_sha256=r['group_binding_sha256']))
 report=dict(passed=True,checked_groups=checked,input_hashes={n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in ['C2_candidate.csv','field_evidence.csv','group_action_mapping.csv','policy_group_shares.csv']},new_training=False)
 (root/'group_replay_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),'utf-8');print(json.dumps(report,ensure_ascii=False))
