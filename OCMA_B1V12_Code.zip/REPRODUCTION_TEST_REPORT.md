# Actual reproduction and reporting verification

## Executed successfully in a new environment and independent directory

- Report:17 vector figures,Tables2–4,S1–S7,10-sheet workbook with saved-cell equality,editable table DOCX and51 OMML equations; native Word PDFs. No model import/ODE in report.
- Derived data:528 primary/106 nested second-coder inputs,32858 fixed units,68 policy HT totals/shares/covariance,four stage means and existing2000-draw policy Bootstrap. Annual stock identity,prepared-table model input and selected SES associations reproduced. Coder agreement was calculated only from paired independent fields.
- Fixed-vector replay:BEST,B12P0001,B12P0002;3 historical and21 scenario trajectories;24 coalition solves forB12P0001. Empty/full endpoints match replayed main scenarios exactly; per-vector Shapley closure passed.
- Fitted classifier deserialized successfully in the fresh environment; no prediction replacement or retraining.
- Full-analysis:real command plan and core-file presence only; not executed.

Derived maximum errors:
```json
{
  "G_POLICY_HT_TOTALS.csv": 2.842170943040401e-14,
  "G_POLICY_HT_SHARES.csv": 1.1102230246251565e-16,
  "G_STAGE_HT_ESTIMATES.csv": 9.71445146547012e-17,
  "covariance": 0.0,
  "bootstrap": 4.996003610813204e-16,
  "03_indicators/model_input_B1.csv": 0.0,
  "02_policy/reconstructed/policy_stock_by_year_B1.csv": 0.0,
  "SES_associations": 1.1102230246251565e-16
}
```
Replay:
```json
{
  "vectors": [
    {
      "parameter_set_id": "BEST",
      "history_max_error": 8.326672684688674e-17,
      "scenario_max_error": null,
      "scenario_comparison": "no stored best-scenario reference; finite execution only"
    },
    {
      "parameter_set_id": "B12P0001",
      "history_max_error": 9.71445146547012e-17,
      "scenario_max_error": 1.1102230246251565e-16,
      "scenario_comparison": "frozen exact-ID reference"
    },
    {
      "parameter_set_id": "B12P0002",
      "history_max_error": 8.326672684688674e-17,
      "scenario_max_error": 8.326672684688674e-17,
      "scenario_comparison": "frozen exact-ID reference"
    }
  ],
  "coalition_max_error": 5.551115123125783e-17,
  "ODE_calls": 48,
  "historical_vectors": 3,
  "scenario_trajectories": 21,
  "coalitions": 24,
  "optimizer_calls": 0,
  "full_calibration_recomputed": false,
  "selection": "BEST plus first two frozen accepted IDs; attribution first accepted ID"
}
```

## Actual operation counts and debugging

Final independent replay:48 ODE integrations,0 optimizer calls. An earlier local replay also completed48 integrations before a reporting assignment error; that failed attempt is preserved and is not called a successful verification. An additional new-environment call failed at importing missingNumba before integration; dependencies were then corrected. Thus completed integrations across development, independent-directory verification and actual ZIP-unpacked verification:144, not zero. No new accepted vectors were generated.

Figure7 has108 distinct deletion calculations and9 full checks. Five report development and ZIP-verification runs reached this stage, so540 deletion evaluations and45 full checks were executed in total; these are repeat debugging evaluations of the same108 cases, not540 independent observations or expanded sensitivity analysis. Final Figure8 direction-marker and DOCX pagination updates used frozen results only.

## Visual and numerical scope

Figure7 three shared symmetric facets;Figure11 two panels with100 and12 distinct sets;FigureS8 retains26 ES rows and all four SR-only rows in Data. FigureS5 removes duplicated parameter distributions. Figure9/S7 retain S5 and consistent colors/line identities. Shaft widths inFigure8 remain proportional to actual magnitude; thin direction markers are independent. DOCX render:3 main-table pages,11 supplementary-table pages,4 methods pages; supplementary part continuations are explicit. Automated text bounds and actual rendered-page inspection performed. The workbook is newly authored from this payload, not copied fromR3.

BEST scenario curves were executed but have no stored BEST-specific scenario reference; only its historical curve and the two accepted-vector scenarios have frozen numerical comparisons. This is stated rather than treating finite execution as an equivalence test. Original carrier extraction, optional fullML training,all600 numerical replay and full optimization were not executed. Cross-platform testing was not performed. Report and derived-data tests do not raise scientific predictive-validity status.


Actual ZIP-unpacked verification repeated all three finite stages in a second physical directory; deterministic display payload and 39 content/geometry comparisons passed. A fresh environment installed earlier in this task was used, not the author's original virtual environment. Successful replay in each verification uses the same preselected three vectors, not newly selected parameters.
