# OCMA B1 V1.2 — final report and finite reproduction package

Release: `OCMA_B1V12_FINAL_20261029`. Accepted Part1 fixed-frame post-audit HT composition and frozen Part2 M3,12 parameters,main600 retained vectors. Report adaptation does not change formal numerical inputs or results.

Place the three ZIP contents side by side as `code/`, `data/`, `publication/`. On Windows PowerShell, from their common parent:

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r code/requirements-lock.txt
.\.venv\Scripts\python.exe code/reproduce.py --stage report --data-root ./data --output-root ./work
.\.venv\Scripts\python.exe code/reproduce.py --stage rebuild-derived --data-root ./data --output-root ./work
.\.venv\Scripts\python.exe code/reproduce.py --stage replay --data-root ./data --output-root ./replay_check
.\.venv\Scripts\python.exe code/reproduce.py --stage full-analysis --data-root ./data --output-root ./full_analysis_plan
```

`--config code/config/reproduction.json` is supported and the effective config is logged. Report renders all17 figures,three main tables,seven supplements,editable DOCX/PDF and XLSX; it has zeroODE/optimizer calls. Rebuild-derived reconstructs HT/covariance/stages/original2000 policy Bootstrap and prepared-data stocks/model inputs/selected SES associations. Replay integrates BEST and first two fixed accepted IDs, plus24 coalitions for the first accepted vector. Full-analysis only assembles the real original-stage commands and checks core dependencies; it does not execute optimization. Historical optional pipelines may need original licensed text/source inputs and source-binding refresh; full optimization was not tested here.

Independent testing used a newly installed Python3.10 environment in a physical directory outside the project, fresh processes, blank PYTHONPATH and disabled user site. Research-read guarding admitted only package/output roots, apart from installed environment assets. Microsoft Word was used for actual DOCX-to-PDF rendering. Other platforms are untested.

The final publication resources are under publication/figures, tables, supplementary_methods and captions. Old R3 reference copies and staging work directories may remain locally but are excluded from the three delivery ZIPs. code/provenance/numerical_source_snapshot contains the actual historical numerical code; code/part2 is the adapted compatibility code; code/reporting is the final display adapter. Do not confuse the latter with the original calibration implementation.

See REPRODUCTION_TEST_REPORT.md, DATA_CODE_AVAILABILITY_DRAFT.md and data/metadata/sharing_status.csv. No new calibration, classifier training, sampling, threshold optimization, full manuscript rewrite, external upload or DOI was performed. Scientific limits remain: weak retrospective skill; finite-set ranges; parameter boundary accumulation/weak identification; state-reset and gate sensitivity; fixed extracted-frame coverage; unknown T2; conditional relation proxies. The package is ready for text revision with these limits, not an automatic submission/forecast-validation claim.
