"""Index original DOCX prose, tables, OMML equations, and reviewer PDF locally."""
from pathlib import Path
import hashlib
import json
import xml.etree.ElementTree as ET
import zipfile
import pandas as pd
from pypdf import PdfReader

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / '01_sources/submission'
DEST = ROOT / '00_contract/source_extracts'
DEST.mkdir(parents=True, exist_ok=True)
W = '{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'
M = '{http://schemas.openxmlformats.org/officeDocument/2006/math}'


def extract_docx(name, label):
    path = SRC / name
    with zipfile.ZipFile(path) as z:
        root = ET.fromstring(z.read('word/document.xml'))
    lines, tables, formulas = [], [], []
    body = root.find(f'.//{W}body')
    p_idx, t_idx = 0, 0
    for block in body:
        if block.tag == W + 'p':
            p_idx += 1
            prose = ''.join(t.text or '' for t in block.iter(W+'t'))
            if prose.strip():
                lines.append({'paragraph_id': p_idx, 'text': prose})
            for j, math in enumerate(block.iter(M+'oMath'), 1):
                raw = ET.tostring(math, encoding='unicode')
                formulas.append({'formula_id': f'{label}_P{p_idx:04d}_M{j:02d}',
                                 'paragraph_id': p_idx, 'context': prose[:500],
                                 'omml_text': ''.join(math.itertext()),
                                 'omml_xml': raw,
                                 'omml_sha256': hashlib.sha256(raw.encode('utf-8')).hexdigest()})
        elif block.tag == W + 'tbl':
            t_idx += 1
            for ri, tr in enumerate(block.findall(W+'tr'), 1):
                cells = [''.join(t.text or '' for t in tc.iter(W+'t')) for tc in tr.findall(W+'tc')]
                tables.append({'table_id': t_idx, 'row': ri, 'cells_json': json.dumps(cells, ensure_ascii=False)})
                for j, math in enumerate(tr.iter(M+'oMath'), 1):
                    raw = ET.tostring(math, encoding='unicode')
                    formulas.append({'formula_id': f'{label}_T{t_idx:02d}_R{ri:02d}_M{j:02d}',
                                     'paragraph_id': '', 'context': ' | '.join(cells)[:500],
                                     'omml_text': ''.join(math.itertext()),
                                     'omml_xml': raw,
                                     'omml_sha256': hashlib.sha256(raw.encode('utf-8')).hexdigest()})
    pd.DataFrame(lines).to_csv(DEST / f'{label}_paragraphs.csv', index=False, encoding='utf-8-sig')
    pd.DataFrame(tables).to_csv(DEST / f'{label}_tables.csv', index=False, encoding='utf-8-sig')
    pd.DataFrame(formulas).to_csv(DEST / f'{label}_omml_formulas.csv', index=False, encoding='utf-8-sig')
    return {'paragraphs': len(lines), 'table_rows': len(tables), 'formula_objects': len(formulas)}


def main():
    status = {'manuscript': extract_docx('Manuscript.docx', 'manuscript'),
              'supplement': extract_docx('supplementary material.docx', 'supplement')}
    reader = PdfReader(SRC / 'OCMA-D-26-02928-reviews.pdf')
    reviews = [{'page': i+1, 'text': page.extract_text() or ''} for i, page in enumerate(reader.pages)]
    pd.DataFrame(reviews).to_csv(DEST / 'reviews_pages.csv', index=False, encoding='utf-8-sig')
    status['review_pages'] = len(reviews)
    (DEST / 'extraction_status.json').write_text(json.dumps(status, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(status, ensure_ascii=False), flush=True)


if __name__ == '__main__':
    main()
