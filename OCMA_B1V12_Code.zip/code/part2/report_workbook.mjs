import fs from 'node:fs/promises';
import path from 'node:path';
import {Workbook,SpreadsheetFile} from '@oai/artifact-tool';
const out=process.argv[2];
const spec=JSON.parse(await fs.readFile(path.join(out,'tables_payload_R3.json'),'utf8'));
const wb=Workbook.create();const checks=[];const payload=[];
const groups=Map.groupBy(spec,x=>x.id);
const letter=n=>String.fromCharCode(65+n);
for (const [id,parts] of groups) {
 const name=id.replace('TableS','Table S').replace(/^Table(\d)/,'Table $1');const sh=wb.worksheets.add(name);sh.showGridLines=false;let r=2;let maxcols=0;const entries=[];
 const put=(row,col,values)=>{sh.getRangeByIndexes(row-1,col-1,values.length,values[0].length).values=values;for(let i=0;i<values.length;i++)for(let j=0;j<values[i].length;j++)entries.push({row:row+i,col:col+j,value:values[i][j]});};
 put(r,1,[[name+'. '+parts[0].title]]);sh.getRange(`A${r}`).format.font={name:'Times New Roman',size:12,bold:true};r+=2;
 for(const p of parts){
  if(p.part_title){put(r,1,[[p.part_title]]);sh.getRange(`A${r}`).format.font={bold:true};r+=2;}
  const top=r;maxcols=Math.max(maxcols,p.columns.length);put(r,1,[p.columns]);r++;
  const vals=p.rows.map(row=>row.map(x=>typeof x==='string' && /^[−-]?\d+\.\d+$/.test(x)?Number(x.replace('−','-')):x));put(r,1,vals);r+=vals.length;
  const full=sh.getRangeByIndexes(top-1,0,vals.length+1,p.columns.length);full.format.font={name:'Times New Roman',size:11};full.format.wrapText=true;full.format.verticalAlignment='center';full.format.horizontalAlignment='center';sh.getRangeByIndexes(top,0,vals.length,1).format.horizontalAlignment='left';full.format.rowHeight=36;
  sh.getRangeByIndexes(top-1,0,1,p.columns.length).format.font={bold:true};sh.getRangeByIndexes(top-1,0,1,p.columns.length).format.rowHeight=48;
  sh.getRangeByIndexes(top-1,0,1,p.columns.length).format.borders={top:{style:'thin',color:'#000000'},bottom:{style:'thin',color:'#000000'}};
  sh.getRangeByIndexes(r-2,0,1,p.columns.length).format.borders={bottom:{style:'thin',color:'#000000'}};
  for(let j=0;j<p.columns.length;j++)sh.getRange(`${letter(j)}:${letter(j)}`).format.columnWidth= id==='TableS1'?[16,28,24,35,50][j]:Math.max(16,(p.widths?.[j]??1/p.columns.length)*120);
  for(let i=0;i<vals.length;i++)for(let j=0;j<vals[i].length;j++)if(typeof vals[i][j]==='number'){const original=p.rows[i][j];const digits=typeof original==='string'&&original.includes('.')?original.split('.')[1].length:0;sh.getCell(top+i,j).setNumberFormat(digits?'0.'+'0'.repeat(digits):'0');}
  r+=1;
  // Notes are wrapped across the existing display width without an engineering metadata column.
  const chunks=p.note.match(/.{1,105}(?:\s|$)/g)??[p.note];for (const text of chunks){put(r,1,[[text.trim()]]);sh.getRange(`A${r}:${letter(p.columns.length-1)}${r}`).merge();sh.getRange(`A${r}`).format.font={name:'Times New Roman',size:10};sh.getRange(`A${r}`).format.rowHeight=18;r++;}r+=2;
 }
 sh.getRange(`A1:${letter(maxcols-1)}${r}`).format.font.name='Times New Roman';
 payload.push({sheet:name,entries,rows:r,cols:maxcols});
}
wb.recalculate();
for(const p of payload){
 const s=wb.worksheets.getItem(p.sheet);for(const e of p.entries){const got=s.getCell(e.row-1,e.col-1).values[0][0];if(got!==e.value)throw Error('Workbook values differ '+p.sheet+' '+e.row+','+e.col);}
 const blob=await wb.render({sheetName:p.sheet,range:`A1:${letter(p.cols-1)}${p.rows}`,scale:1,format:'png'});await fs.writeFile(path.join(out,'qa_previews',p.sheet.replaceAll(' ','_')+'_workbook.png'),new Uint8Array(await blob.arrayBuffer()));
 checks.push({sheet:p.sheet,actual_cells:p.entries.length,values_match:true,rendered:true});
}
const x=await SpreadsheetFile.exportXlsx(wb);await x.save(path.join(out,'Publication_Tables.xlsx'));
await fs.writeFile(path.join(out,'WORKBOOK_EXPECTED_CELLS.json'),JSON.stringify(payload));
await fs.writeFile(path.join(out,'WORKBOOK_ARTIFACT_QA.json'),JSON.stringify(checks,null,2));
console.log('New workbook exported',payload.length,'sheets');
process.exit(0);
