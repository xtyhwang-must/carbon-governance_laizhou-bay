"""Run the historical strict-68 signal and collaboration kernels on B1 codes."""
from __future__ import annotations

import importlib.util
import json
from pathlib import Path
import sys
import types

import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parents[1]
POL=ROOT/'02_policy/reconstructed'
REF=ROOT/'00_handoff/historical_code_reference'


def load_legacy_kernels():
    # The immutable historical code imports its old absolute-path config at
    # module import. Inject a blank config only so its PURE kernels can be
    # called. We never call load_inputs(), main(), or write_manifest().
    if '00_config' not in sys.modules:sys.modules['00_config']=types.ModuleType('00_config')
    for name,file in [('common','sd_common.py'),('strict68_bridge','sd_01b_build_strict68_sd_bridge.py')]:
        spec=importlib.util.spec_from_file_location(name,REF/file)
        mod=importlib.util.module_from_spec(spec)
        sys.modules[name]=mod
        spec.loader.exec_module(mod)
    return sys.modules['common'],sys.modules['strict68_bridge']


def legacy_main():
    common,legacy=load_legacy_kernels()
    admission=pd.read_csv(ROOT/'01_sources/policy/admission_68.csv')
    codes=pd.read_csv(POL/'coded_clauses_B1.csv')
    shares=pd.read_csv(POL/'policy_function_shares_B1.csv')
    dates=pd.read_csv(POL/'policy_validity_decisions.csv')
    relations=pd.read_csv(POL/'relation_events_B1.csv')
    assert len(admission)==68 and len(shares)==len(dates)==68
    meta=admission[['policy_id','publication_year','政策标题']].rename(columns={'政策标题':'title'}).copy()
    meta['phase']=meta.publication_year.map(legacy.phase_for_year)
    meta['temporal_role']='formal_policy_source_reconstructed'
    meta['semantic_analysis_eligible']=1
    meta['text_evidence_grade']=admission.text_evidence_grade
    current=pd.read_csv(POL/'current_source_status.csv').set_index('policy_id') if (POL/'current_source_status.csv').exists() else None
    meta['text_complete']=meta.policy_id.map(current.full_policy_body_validated).fillna(False).astype(int) if current is not None else 0
    actions=codes.loc[codes.b1_qualified].copy()
    actions['action_unit_id']=actions.unit_id
    actions['source_location']=actions.source_location
    actions['evidence_text']=actions.exact_evidence_text
    actions['G_codes']=actions.apply(lambda r:';'.join(g for g in ['G1','G2','G3'] if r['b1_'+g]==1),axis=1)
    actions['T_codes']=actions.apply(lambda r:';'.join(t for t in ['T1','T2','T3','T4','T5','T6'] if r['b1_'+t]==1),axis=1)
    actions['publication_year']=actions.policy_id.map(meta.set_index('policy_id').publication_year)
    actions['phase']=actions.publication_year.map(legacy.phase_for_year)
    counts=actions.groupby('policy_id').size()
    actions['document_unit_weight']=actions.policy_id.map(lambda p:1.0/counts[p])
    actions['coding_scope']='B1_CODEX_SOURCE_RECONSTRUCTION_AUTHOR_CONFIRMED_FOR_USE'
    risk_evidence,risk_summary=legacy.build_risk_signal_trace(actions,meta)
    risk_evidence.to_csv(POL/'risk_signal_evidence_B1.csv',index=False,encoding='utf-8-sig')
    risk_summary.to_csv(POL/'risk_signal_policy_summary_B1.csv',index=False,encoding='utf-8-sig')
    ledger=shares.merge(dates[['policy_id','stock_start_year','future_exposure_end_year','stock_exit_transition_year','independent_stock_policy']],on='policy_id',validate='one_to_one')
    ledger=ledger.loc[ledger.independent_stock_policy].copy()
    ledger['stock_end_year']=ledger.future_exposure_end_year
    ledger['semantic_codable']=ledger.G_assignment_total.gt(0).astype(int)
    basic=legacy.build_basic_history(ledger,risk_summary)
    network=legacy.build_collaboration_history(ledger,relations)
    identity=legacy.stock_identity_errors(basic)
    if max(identity.values())>1e-9:raise AssertionError(identity)
    annual=basic.merge(network,on='year',validate='one_to_one')
    annual['eta_raw']=annual.active_explicit_governance_response_proxy_policy_share_all_formal
    annual['feedback_raw']=annual.active_explicit_feedback_signal_policy_share_all_formal
    annual['synergy_raw']=annual.stock_network_synergy_equal_event_share
    annual['synergy_share']=annual.synergy_raw
    for g,k in [('G1',6.608),('G2',6.605),('G3',7.936)]:
        annual[g]=annual[g+'_active_stock']/(annual[g+'_active_stock']+k)
    annual=annual.loc[annual.year.between(2011,2023)].reset_index(drop=True)
    scale,scale_spec=common.calibration_scaler(annual.eta_raw,annual.year.le(2020))
    annual['ETA_POTENTIAL']=scale.to_numpy(float)
    annual['SYNERGY_LEVER']=annual.synergy_raw
    if not np.allclose(annual.SYNERGY_LEVER,annual.synergy_share,atol=1e-12):raise AssertionError('synergy schema')
    annual.to_csv(POL/'annual_policy_interface_B1.csv',index=False,encoding='utf-8-sig')
    quant=[]
    for name in ['eta_raw','feedback_raw','synergy_raw','ETA_POTENTIAL','G1','G2','G3']:
        s=annual[name].astype(float)
        quant.append({'interface':name,'source_years':'2011-2023','P25':s.quantile(.25),'P50':s.quantile(.5),
                      'P75':s.quantile(.75),'min':s.min(),'max':s.max(),
                      'degenerate_P75_P50':bool(np.isclose(s.quantile(.75),s.quantile(.5)))})
    pd.DataFrame(quant).to_csv(POL/'interface_quantiles_B1.csv',index=False,encoding='utf-8-sig')
    spec={'version':'B1_v1.2.0_definition_consistent','source_lexicon_file':'00_handoff/historical_code_reference/sd_01b_build_strict68_sd_bridge.py',
          'source_lexicon_sha256':common.sha256_file(REF/'sd_01b_build_strict68_sd_bridge.py'),
          'eta_raw':'active explicit governance response policy count / active formal policy count',
          'eta_scaler':scale_spec,'feedback_raw':'active explicit feedback signal policy count / active formal policy count',
          'feedback_future_scale':'2011-2023 min-max support, not the general P5/P95 appendix description',
          'synergy_raw':'sqrt((joint active policy count / active formal policy count) * (vertical event weight / all formal relation event weight))',
          'synergy_model_mapping':'SYNERGY_LEVER=synergy_share=synergy_raw; no fitted stretch',
          'historical_feedback_strength':0.0,'stock_identity_errors':identity,
          'author_review_status':'CONFIRMED_BY_AUTHOR','implementation_proxy_is_observed_implementation':False,
          'confirmation_scope':'adopted frozen v1.1 source reconstruction; no original manual codes or clause-by-clause signature'}
    (POL/'interface_reconstruction_spec.json').write_text(json.dumps(spec,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'years':len(annual),'risk_evidence_rows':len(risk_evidence),
                      'eta_raw_range':[float(annual.eta_raw.min()),float(annual.eta_raw.max())],
                      'feedback_raw_range':[float(annual.feedback_raw.min()),float(annual.feedback_raw.max())],
                      'synergy_raw_range':[float(annual.synergy_raw.min()),float(annual.synergy_raw.max())],
                      'max_stock_identity_error':max(identity.values())},ensure_ascii=False))


def main():
    if (ROOT/'00_contract/part2_run.json').exists():
        from part2_ht_bridge import main as ht_main
        return ht_main()
    return legacy_main()

if __name__=='__main__':main()
