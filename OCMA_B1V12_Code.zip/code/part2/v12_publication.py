"""Evidence-scoped B1 v1.2 claims matrix and release-facing documentation."""
from __future__ import annotations
import json,sys
from pathlib import Path
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'05_code/engine'),str(ROOT/'05_code')]
import sd_model as model
from cache_safety import atomic_json

OUT=ROOT/'07_publication'
CAL=ROOT/'06_runs/formal_main/calibration'
EVAL=ROOT/'06_runs/formal_main/evaluation'
SCEN=ROOT/'06_runs/formal_main/scenarios'
ROB=ROOT/'06_runs/formal_main/robustness'
ATTR=ROOT/'06_runs/formal_main/attribution'

def read(path):return json.loads(Path(path).read_text(encoding='utf-8'))
def line(path):return Path(path).relative_to(ROOT).as_posix()

def legacy_main():
    OUT.mkdir(parents=True,exist_ok=True)
    selection=read(ROOT/'06_runs/structure_compare/model_selection.json')
    cal=read(CAL/'formal_calibration_status.json')
    evaluation=read(EVAL/'evaluation_status.json')
    scen=read(SCEN/'scenario_status.json')
    robustness=read(ROB/'robustness_status.json')
    attribution=read(ATTR/'attribution_status.json')
    qa_path=ROOT/'06_runs/formal_main/qa/qa_report.json'
    qa=read(qa_path) if qa_path.is_file() else {'all_checks_pass':False}
    replay_path=ROOT/'08_release/portable_replay_log.json'
    replay=read(replay_path) if replay_path.is_file() else {'portable_replay_pass':False}
    metrics=pd.read_csv(EVAL/'retrospective_state_summary.csv')
    benchmarks=pd.read_csv(EVAL/'simple_baselines.csv')
    coverage=pd.read_csv(EVAL/'pure_parameter_coverage.csv')
    main=pd.read_csv(SCEN/'scenario_summary.csv').set_index('scenario')
    pairs=pd.read_csv(SCEN/'all_pair_tolerance_summary.csv')
    robust=pd.read_csv(ROB/'specification_rankings.csv')
    sh=pd.read_csv(ATTR/'shapley_summary.csv')
    base=metrics[(metrics.state_role.eq('BASIC'))&(metrics['2023_estimate_treatment'].eq('weighted'))]
    comparison=[]
    for r in base.itertuples(index=False):
        standard=benchmarks[benchmarks.state.eq(r.state)]
        best=float(standard.RMSE.min())
        comparison.append({'state':r.state,'model_median_RMSE':float(r.RMSE),
            'best_simple_RMSE':best,'model_better_than_best_simple':bool(r.RMSE<best)})
    comparison=pd.DataFrame(comparison)
    comparison.to_csv(OUT/'model_vs_simple_baselines.csv',index=False,encoding='utf-8-sig')
    key=comparison.set_index('state').loc[['SC','SM']]
    keycover=coverage[(coverage.state.isin(['SC','SM']))&(coverage.treatment.eq('weighted'))]
    key_good=bool(key.model_better_than_best_simple.all() and keycover.weighted_coverage.gt(0).all())
    pathway_behavior_supported=bool(key_good and selection['empirical_structure_qualifies'])
    behavior=('LIMITED_DEVELOPMENT_SUPPORT' if key_good and selection['empirical_structure_qualifies']
        else 'NOT_ESTABLISHED_FOR_QUANTITATIVE_PATHWAY_WINNER')
    s4_first=bool(pd.notna(main.loc['S4','main_rank']) and main.loc['S4','main_rank']==1)
    s5_fails=not bool(main.loc['S5','main_screen_pass'])
    pair46=pairs[(pairs.scenario_a.eq('S4'))&(pairs.scenario_b.eq('S6'))&
        pairs.metric.eq('min_ES_2026_2030')]
    if len(pair46)!=1:raise ValueError('Missing matched S4-S6 minimum-ES comparison')
    contrast=float(pair46.median_a_minus_b.iloc[0])
    main_distinguishable=abs(contrast)>.0005
    n_specs=int(robust.specification_id.nunique())
    s4_robust=float((robust[robust.scenario.eq('S4')].main_rank==1).mean())
    claims=[]
    def add(claim,anchor,status,evidence,allowed,forbidden):
        claims.append({'claim_id':claim,'manuscript_anchor':anchor,'status':status,
            'same_version_evidence':evidence,'allowed_wording':allowed,
            'not_supported_or_required_update':forbidden})
    add('C01_GOVERNANCE_TREND','Results 4.1; Table 2',
        'DESCRIPTIVE_SUPPORTED','03_indicators/model_input_B1.csv; 02_policy/reconstructed/annual_policy_interface_B1.csv',
        'Describe the B1 source-reconstructed formal policy supply and its measured definition.',
        'Do not use submitted B0 values as B1 values or infer enacted implementation.')
    add('C02_NETWORK_STRUCTURE','Table 2 Panel B',
        'DESCRIPTIVE_SUPPORTED','07_publication/tables/Table_2_Panel_B_source.csv',
        'Report source-derived formal joint and vertical relation shares with denominator.',
        'Do not infer activation or causal collaboration quality from formal ties.')
    add('C03_PREDICTIVE_RELIABILITY','Results 4.3; Discussion',
        'NOT_SUPPORTED',line(EVAL/'retrospective_state_summary.csv')+'; '+line(EVAL/'simple_baselines.csv')+'; '+line(EVAL/'pure_parameter_coverage.csv'),
        'Report conditional retrospective error and simple-baseline comparisons.',
        'No validated probability prediction interval or general forecast reliability claim.')
    add('C04_S4_LEADING_PATHWAY','Results 4.4; Discussion',
        'CONDITIONAL_MODEL_SUPPORTED' if s4_first and pathway_behavior_supported else 'SENSITIVITY_ONLY',
        line(SCEN/'scenario_summary.csv')+'; '+line(ROB/'specification_rankings.csv'),
        'State the observed rank only under explicitly named B1 model and forcing specifications.',
        'Do not call S4 empirically superior or robust without tolerance and cross-specification support.')
    add('C05_S5_SOCIAL_SCREEN','Results 4.4',
        'CONDITIONAL_MODEL_SUPPORTED' if s5_fails else 'NOT_SUPPORTED',
        line(SCEN/'social_screen_summary.csv'),
        'Report the actual terminal-SR screen result with median and tolerance.',
        'Do not replace the terminal rule with minimum SR or claim a real social effect.')
    add('C06_S4_VS_S6','Results 4.4; Table 5',
        'CONDITIONAL_MODEL_SUPPORTED' if main_distinguishable and pathway_behavior_supported else 'SENSITIVITY_ONLY',
        line(SCEN/'all_pair_tolerance_summary.csv')+'; '+line(ROB/'specification_pair_tolerance.csv'),
        'Report matched difference and whether it exceeds the 0.0005 tolerance in each specification.',
        'A strict numeric rank alone does not establish a distinguishable winner.')
    add('C07_IMPLEMENTATION_SHAPLEY','Fig. 10; Supplement Table S6',
        'CONDITIONAL_MODEL_SUPPORTED' if attribution['all_endpoints_match'] and pathway_behavior_supported
            else 'SENSITIVITY_ONLY' if attribution['all_endpoints_match'] else 'NOT_SUPPORTED',
        line(ATTR/'shapley_by_parameter.csv')+'; '+line(ATTR/'endpoint_matches.csv'),
        'Describe four grouped model contributions under matched B1 inputs.',
        'Do not present a Shapley component as a measured causal mechanism.')
    add('C08_FEEDBACK_ABLATIONS','Mechanism figure and supplement',
        'SENSITIVITY_ONLY','06_runs/formal_main/mechanisms/ablation_effects_by_parameter.csv',
        'Report fixed-parameter directional and reciprocal ablation sensitivity.',
        'Do not splice old v1.1 ablation intervals or treat fixed-parameter stress tests as refitted forecasts.')
    add('C09_RESPONSE_SURFACE','Nonlinear response-surface figure',
        'SENSITIVITY_ONLY','06_runs/formal_main/mechanisms/response_surface/response_surface_summary.csv',
        'Report the registered 13 by 13 B1 S0-to-S4 and same-block disturbance grid.',
        'Do not call the revised P50-to-P75 lever amplitude the historical P50-to-P90 surface.')
    add('C10_2023_HABITAT','Methods and sensitivity appendix','SENSITIVITY_ONLY',
        '01_sources/indicators/habitat_2023_class_endpoint_sensitivity.csv; 06_runs/formal_main/robustness/robustness_metrics_by_vector.csv',
        'Keep the 2023 habitat bridge estimate identity and paired low/high endpoint sensitivity.',
        'Do not call 2023 TF/SM a direct same-product observation or blend by 0.35 in the state.')
    add('C11_SUBMISSION_NUMBERS','All old B0 scenario and mechanism numbers','NOT_SUPPORTED',
        '00_contract/baseline_vs_submission.csv; 00_reference_v1_1',
        'Replace with B1 same-version results if used in revision.',
        'Old scenario, screening, ranking and Shapley outputs cannot be mixed with B1 v1.2.')
    pd.DataFrame(claims).to_csv(OUT/'claims_use_matrix.csv',index=False,encoding='utf-8-sig')
    decision={'version':'B1_v1.2.0_definition_consistent','author_confirmation':'CONFIRMED_BY_AUTHOR',
        'coding_origin':'CODEX_SOURCE_RECONSTRUCTION','source_lineage_complete':bool(qa['all_checks_pass']),
        'source_limitations':['open expiry assumptions','2023 habitat bridge estimate',
            'provisional water-quality units','SST temporal support metadata'],
        'implementation_verified':bool(qa['all_checks_pass']),
        'computation_complete':bool(cal['complete'] and evaluation['complete'] and scen['complete'] and
            robustness['complete'] and attribution['complete']),
        'formal_structure_qualification':bool(selection['empirical_structure_qualifies']),
        'behavioral_adequacy':behavior,
        'scenario_claims_supported':'MODEL_CONDITIONAL_ONLY' if pathway_behavior_supported else 'QUANTITATIVE_WINNER_NOT_ESTABLISHED',
        'attribution_claims_supported':'MODEL_CONDITIONAL_ONLY' if pathway_behavior_supported
            else 'SENSITIVITY_ONLY_UNDER_AUDIT_CONTROL',
        'portable_replay_pass':bool(replay['portable_replay_pass']),
        'manuscript_ready':False,'selected_structure':cal['structure'],
        'accepted_parameter_sets':int(cal['propagated_count']),
        'candidate_sets':int(cal['candidate_count']),'climate_parameter_sets':int(robustness['sample_parameter_sets']),
        'joint_climate_draws':int(robustness['joint_climate_draws']),
        'S4_main_rank_first':s4_first,'S5_terminal_screen_fail':s5_fails,
        'S4_minus_S6_median_minES':contrast,'S4_minus_S6_minES_exceeds_tolerance':main_distinguishable,
        'S4_rank_first_fraction_of_reported_spec_draw_cells':s4_robust,
        'specification_count':n_specs,'validated_probability_interval_available':False}
    decision['release_class']=('COMPUTED_AUDIT_CONDITIONAL_EXPLORATION' if behavior.startswith('NOT_') or not selection['empirical_structure_qualifies']
        else 'REVISION_BASELINE_WITH_EXPLICIT_LIMITATIONS')
    atomic_json(OUT/'release_status.json',decision)
    (OUT/'baseline_release_decision.md').write_text('''# B1 v1.2 release decision\n\n'''+
        '\n'.join(f'- **{k}**: {v}' for k,v in decision.items())+
        '\n\nThe author adopted the frozen source reconstruction. This does not recover original manual coding. Manuscript readiness remains false because the selected audit-control structure fails behavioral adequacy and the manuscript and response letter have not been revised and checked against this version.\n',encoding='utf-8')
    (OUT/'model_specification.md').write_text(f'''# B1 v1.2 model specification\n\nSelected executable structure: `{cal['structure']}`. Selection status: `{selection['status']}`. The structure comparison used 2011–2016 to 2017–2018 and 2011–2018 to 2019–2020 training-internal development folds. Previously viewed 2021–2023 outcomes did not select the structure.\n\nThe seven calibrated basic states are SP, SC, NS, OS, BS, TF and SM. G1–G3 policy supply, PR/PRS risk memories and IM implementation capacity complete the 13-state system. The original nine parameter bounds and fixed constants are in `04_model/parameter_registry.csv`; the selected structure has {len(model.parameter_names(cal['structure']))} calibrated parameters. Structural alpha coefficients, if present, are new revision intercepts in target logits and are not recovered submitted-run parameters.\n\nHistory begins at the observed 2011 state and uses policy tau 0.5 year. Every future scenario and coalition begins at the observed/derived 2023 state, retains its parameter-specific 2011 training reference under fixed-reference structures, and shares paired climate and disturbance paths. Scenario tau is S0/S1/S2/S3/S6 2 years, S4 1 year, S5 3 years. The 2023 habitat evaluation weight 0.35 never modifies the state or initial conditions.\n\nThe equation registry, `05_code/engine/sd_model.py`, `00_contract/baseline_contract.yaml`, and `00_contract/structure_selection_protocol.yaml` define the exact equations, integration, loss, gates and decision sequence. Calibrated alpha support is numeric logit support, not empirical prior evidence.\n\nThe model predicts indices of ecological support and social resilience under defined policy and climate scenarios. ES is not carbon stock, flux or sequestration. Modelled implementation and synergy are source-based proxies rather than measured implementation effects.\n''',encoding='utf-8')
    (OUT/'model_limitations.md').write_text(f'''# B1 v1.2 limitations\n\n- The submitted joint parameter vectors and original human clause coding were not recovered. The adopted codes are rule-assisted CODEX source reconstruction, author-confirmed for this baseline.\n- Open-ended policy validity and some publication-date fallback rules are documented assumptions. The 2004 Shandong source and later amendments remain distinct version evidence.\n- Water-quality unit metadata and SST temporal support remain provisional in the captured source chain. The 2023 TF/SM bridge is estimated, with paired low/high sensitivity rather than a confidence interval.\n- The 2011–2020 calibration has only ten annual observations per state and is structurally weak for many interactions. The 2021–2023 assessment was previously viewed and is a development-after-viewing retrospective diagnostic.\n- Key-state behavioral adequacy: `{behavior}`. SC and SM errors and simple benchmarks are in `07_publication/model_vs_simple_baselines.csv`. Pure parameter P5–P95 ranges are descriptive set envelopes, not validated probability forecasts.\n- Scenario ranks, grouped Shapley, fixed-parameter ablations and the response surface are conditional on the model, input, parameter set and scenario assumptions; none identifies a real-world policy causal effect.\n''',encoding='utf-8')
    (OUT/'RUNNING_GUIDE.md').write_text('''# B1 v1.2 running guide\n\nUse a Python 3.10 environment with `requirements_B1.txt`. Run from this package root with relative paths; `05_code/run_v12.py` is a real executable stage runner. For example:\n\n```powershell\npython 05_code/run_v12.py --stage rebuild-inputs\npython 05_code/run_v12.py --stage compare\npython 05_code/run_v12.py --stage calibrate\npython 05_code/run_v12.py --stage evaluate\npython 05_code/run_v12.py --stage scenarios\npython 05_code/run_v12.py --stage robustness\npython 05_code/run_v12.py --stage attribution\npython 05_code/run_v12.py --stage mechanisms\npython 05_code/run_v12.py --stage surface\npython 05_code/run_v12.py --stage numerical\npython 05_code/run_v12.py --stage figures\npython 05_code/run_v12.py --stage tables\npython 05_code/run_v12.py --stage verify\npython 05_code/run_v12.py --stage release\n```\n\n`--stage calibrate` performs five-seed optimization and the registered 11,600-vector screen. `--stage all` performs all stages sequentially. The optional Word table builder requires `python-docx`; set `B1_DOCUMENT_PYTHON` to an interpreter with that package if the numeric Python environment lacks it. Cache blocks are content-addressed and can be resumed; a COMPLETE marker appears only after every block validates. The release replay reconstructs inputs and replays one fixed accepted vector, all seven scenarios, and 24 grouped coalitions. It does not repeat optimization.\n''',encoding='utf-8')
    (OUT/'HANDOFF.md').write_text(f'''# B1 v1.2 handoff\n\nSelected structure: `{cal['structure']}`; qualification: `{selection['status']}`. Formal calibration evaluated {cal['candidate_count']} candidate vectors and propagated {cal['propagated_count']} accepted vectors. Main scenarios and grouped attribution used the same parameter population. The climate stress test used {robustness['sample_parameter_sets']} parameters by {robustness['joint_climate_draws']} shared climate paths; other specifications are reported separately.\n\nBehavioral adequacy: `{behavior}`. S4 main rank first: `{s4_first}`; S5 terminal screen fail: `{s5_fails}`; median matched S4–S6 minimum-ES difference: `{contrast:.8f}` (distinguishability tolerance 0.0005). These are model-conditional outputs, not observed policy effects.\n\nFor exact values use the CSV files under `06_runs/formal_main/`. The `claims_use_matrix.csv` maps each manuscript claim to same-version evidence. The original manuscript, supplement, frozen B0 and frozen B1 v1.1 are not overwritten. Manuscript and reviewer response are not rewritten in this calculation release.\n\nThe next manuscript step is to replace every invalid old scenario/attribution number with B1 v1.2 evidence, describe the new target intercept/reference semantics if selected, and restrict prediction/ranking language according to the retrospective diagnostics.\n''',encoding='utf-8')
    (ROOT/'BASELINE_README.md').write_text(f'''# B1 v1.2 definition-consistent calculation baseline\n\nThis is a source-reconstructed, author-adopted B1 calculation. Formal structure: `{cal['structure']}`; {cal['propagated_count']} accepted vectors propagated. Release class: `{decision['release_class']}`. See `07_publication/baseline_release_decision.md`, `07_publication/claims_use_matrix.csv`, `07_publication/RUNNING_GUIDE.md`, and `06_runs/formal_main/qa/qa_report.json`.\n''',encoding='utf-8')
    # Add scenario checkpoints to the pre-existing input-only submission comparison.
    checkpoint=ROOT/'00_contract/baseline_vs_submission.csv';old=pd.read_csv(checkpoint)
    old=old[~old.indicator.astype(str).str.startswith('SCENARIO_')]
    scenario_rows=[]
    for sid,r in main.iterrows():
        for metric in ['min_ES_median','ES_2030_median','SR_2030_median']:
            scenario_rows.append({'indicator':'SCENARIO_'+sid,'checkpoint':metric,
                'manuscript':np.nan,'B0_digitized_or_target_guided':np.nan,
                'B1_source_based':r[metric],'B1_minus_manuscript':np.nan,'B1_minus_B0':np.nan,
                'B0_is_main_B1_ancestor':False,'use':'NEW_SAME_VERSION_B1_RESULT_NO_NUMERIC_SUBMISSION_TARGET_FIT'})
    pd.concat([old,pd.DataFrame(scenario_rows)],ignore_index=True).to_csv(checkpoint,index=False,encoding='utf-8-sig')
    print(json.dumps({'claims':len(claims),'release_class':decision['release_class'],
        'behavioral_adequacy':behavior,'portable_replay_pass':decision['portable_replay_pass']},ensure_ascii=False),flush=True)

def main():
    if (ROOT/'00_contract/part2_run.json').exists():
        from part2_release import main as current_main
        return current_main()
    return legacy_main()

if __name__=='__main__':main()

