"""Same-version historical ensemble and development-after-viewing retrospective audit."""
from __future__ import annotations
import hashlib,json,sys
from concurrent.futures import ProcessPoolExecutor,as_completed
from pathlib import Path
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'05_code/engine'),str(ROOT/'05_code')]
import engine_config as cfg
import sd_model as model
from revised_core import validate_metric,observation_weights,simple_baselines
from v12_modeling import STATES,reference_for,sha
from cache_safety import atomic_json

OUT=ROOT/'06_runs/formal_main/evaluation'
CAL=ROOT/'06_runs/formal_main/calibration'

def one(args):
    pid,params,structure,frame=args
    initial=model.initial_state(frame,year=2011)
    forcing=model.historical_forcing(frame)
    ref=reference_for(frame,forcing,initial,params,structure)
    pred=model.simulate(params,forcing,frame.year.to_numpy(float),initial,
       structure=structure,reference_context=ref)
    pred.insert(0,'parameter_set_id',pid)
    rows=[];obs=frame[frame.year.between(2021,2023)]
    simulation=pred[pred.year.between(2021,2023)]
    for state in STATES+['SR','WQ','H','ES']:
        for mode in ['weighted','unweighted','exclude_estimated']:
            weight=observation_weights(obs.year,state,mode)
            q=validate_metric(obs[state],simulation[state],obs.year,frame.loc[frame.year.le(2020),state],weight)
            valid=weight>0
            if not valid.any():continue
            errors=simulation[state].to_numpy(float)-obs[state].to_numpy(float)
            rows.append({'parameter_set_id':pid,'state':state,'state_role':'BASIC' if state in STATES else 'DERIVED',
              '2023_estimate_treatment':mode,'bias':float(np.average(errors[valid],weights=weight[valid])),
              'predicted_range':float(simulation[state].max()-simulation[state].min()),
              'observed_range':float(obs[state].max()-obs[state].min()),**q})
    return pred,rows

def main():
    OUT.mkdir(parents=True,exist_ok=True)
    frame=pd.read_csv(ROOT/'03_indicators/model_input_B1.csv').sort_values('year').reset_index(drop=True)
    status=json.loads((CAL/'formal_calibration_status.json').read_text(encoding='utf-8'))
    structure=status['structure'];names=model.parameter_names(structure)
    ensemble=pd.read_csv(CAL/'accepted_parameter_ensemble.csv')
    if ensemble.empty:raise RuntimeError('No accepted vectors; best-point diagnostic must be separate')
    jobs=[(r.parameter_set_id,{n:float(getattr(r,n)) for n in names},structure,frame)
          for r in ensemble.itertuples(index=False)]
    histories=[];metrics=[]
    with ProcessPoolExecutor(max_workers=8) as pool:
        for i,f in enumerate(as_completed([pool.submit(one,j) for j in jobs]),1):
            trajectory,rows=f.result();histories.append(trajectory);metrics.extend(rows)
            if i%100==0 or i==len(jobs):print(f'formal evaluation={i}/{len(jobs)}',flush=True)
    historical=pd.concat(histories,ignore_index=True)
    historical.to_csv(OUT/'historical_ensemble_trajectories.csv',index=False,encoding='utf-8-sig')
    metric=pd.DataFrame(metrics);metric.to_csv(OUT/'retrospective_metrics_by_parameter.csv',index=False,encoding='utf-8-sig')
    metric.groupby(['state_role','state','2023_estimate_treatment'])[['MAE','RMSE','NRMSE','bias','direction_numerator','direction_denominator']].median().reset_index().to_csv(
        OUT/'retrospective_state_summary.csv',index=False,encoding='utf-8-sig')
    report=STATES+['SR','WQ','H','ES']
    envelope=historical.groupby('year')[report].quantile([.05,.5,.95]).unstack(-1)
    envelope.columns=[f'{state}_P{int(q*100)}' for state,q in envelope.columns]
    envelope=envelope.reset_index();envelope.to_csv(OUT/'pure_parameter_envelope.csv',index=False,encoding='utf-8-sig')
    joined=envelope.merge(frame[['year']+report],on='year',validate='one_to_one')
    coverage=[];coverage_year=[]
    for state in report:
        for treatment in ['weighted','unweighted','exclude_estimated']:
            held=joined[joined.year.ge(2021)];weights=observation_weights(held.year,state,treatment)
            valid=weights>0;hit=held[state].between(held[state+'_P5'],held[state+'_P95']).to_numpy(float)
            distances=np.maximum.reduce([held[state+'_P5']-held[state],held[state]-held[state+'_P95'],np.zeros(len(held))])
            coverage.append({'state':state,'state_role':'BASIC' if state in STATES else 'DERIVED',
              'treatment':treatment,'n_years':int(valid.sum()),'covered_years':int(hit[valid].sum()),
              'weighted_coverage':float(np.average(hit[valid],weights=weights[valid])),
              'mean_envelope_width':float((held[state+'_P95']-held[state+'_P5']).mean()),
              'mean_distance_outside_envelope':float(distances[valid].mean()),
              'interval_role':'DESCRIPTIVE_PARAMETER_SET_RANGE_NOT_PREDICTIVE_INTERVAL'})
            for year,weight,inside,width,distance in zip(held.year,weights,hit,
                held[state+'_P95']-held[state+'_P5'],distances):
                coverage_year.append({'year':int(year),'state':state,
                    'state_role':'BASIC' if state in STATES else 'DERIVED',
                    'treatment':treatment,'evaluation_weight':float(weight),
                    'included_in_denominator':bool(weight>0),
                    'covered_numerator':int(inside) if weight>0 else 0,
                    'covered_denominator':int(weight>0),
                    'parameter_envelope_width':float(width),
                    'distance_outside_envelope':float(distance),
                    'interval_role':'DESCRIPTIVE_PARAMETER_SET_RANGE_NOT_PREDICTIVE_INTERVAL'})
    pd.DataFrame(coverage).to_csv(OUT/'pure_parameter_coverage.csv',index=False,encoding='utf-8-sig')
    pd.DataFrame(coverage_year).to_csv(OUT/'pure_parameter_coverage_by_year.csv',
        index=False,encoding='utf-8-sig')
    benchmarks=[]
    for state in report:
        obs=frame[state].to_numpy(float)
        for name,forecast in simple_baselines(frame.year.to_numpy()[:10],obs[:10],frame.year.to_numpy()[10:13]).items():
            q=validate_metric(obs[10:13],forecast,frame.year.to_numpy()[10:13],obs[:10],
                observation_weights(frame.year.to_numpy()[10:13],state,'weighted'))
            benchmarks.append({'benchmark':name,'state':state,'state_role':'BASIC' if state in STATES else 'DERIVED',**q})
    pd.DataFrame(benchmarks).to_csv(OUT/'simple_baselines.csv',index=False,encoding='utf-8-sig')
    residuals=[]
    for state in report:
        train=joined[joined.year.le(2020)]
        for r in train.itertuples(index=False):
            residuals.append({'year':int(r.year),'state':state,'observed_minus_ensemble_median':
                float(getattr(r,state)-getattr(r,state+'_P50')),
                'replicate_unit':'ONE_YEAR_NOT_PARAMETER_YEAR_INDEPENDENT_REPLICATE'})
    pd.DataFrame(residuals).to_csv(OUT/'training_year_median_residuals_descriptive.csv',index=False,encoding='utf-8-sig')
    result={'complete':True,'structure':structure,'parameter_sets':len(ensemble),
      'holdout_years':[2021,2022,2023],'holdout_status':'DEVELOPMENT_AFTER_PREVIOUSLY_VIEWED_RESULTS',
      'input_sha256':sha(ROOT/'03_indicators/model_input_B1.csv'),
      'ensemble_sha256':sha(CAL/'accepted_parameter_ensemble.csv'),
      'model_code_sha256':sha(ROOT/'05_code/engine/sd_model.py'),
      'analysis_code_sha256':sha(Path(__file__)),
      'contract_sha256':sha(ROOT/'00_contract/baseline_contract.yaml'),
      'initial_year':2011,'initial_vector':model.initial_state(frame,year=2011).tolist(),
      'historical_forcing_sha256':hashlib.sha256(
          model.historical_forcing(frame).frame.to_csv(index=False).encode()).hexdigest(),
      'evaluation_protocol':'2021_2023_training_2011_2020_P95_minus_P5_2023_estimated_weight_0p35',
      'parameter_envelope_is_predictive_interval':False,
      'validated_probability_interval_available':False,'author_confirmation':'CONFIRMED_BY_AUTHOR'}
    atomic_json(OUT/'evaluation_status.json',result)
    print(json.dumps(result,ensure_ascii=False),flush=True)

if __name__=='__main__':main()
