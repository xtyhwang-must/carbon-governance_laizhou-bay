"""Refresh source/code evidence hashes while retaining capture provenance."""
from __future__ import annotations
import hashlib,sys
from pathlib import Path
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]
FILE=ROOT/'00_contract/source_manifest.csv'
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def main():
    old=pd.read_csv(FILE,keep_default_na=False)
    if old.source_id.duplicated().any():raise ValueError('Duplicate source ID')
    rows=[];registered=set()
    for row in old.to_dict('records'):
        rel=row['relative_path'];registered.add(rel)
        path=ROOT/rel
        if not path.is_file():
            row['availability']='MISSING_SOURCE'
            row['confirmation_status']='MISSING_REFERENCE_FILE_NOT_A_B1_DATA_DEPENDENCY'
            rows.append(row);continue
        newhash=sha(path)
        if newhash!=row['sha256']:
            if rel.startswith('05_code/') or rel.startswith('00_contract/') or rel.startswith('03_indicators/'):
                if not row['source_sha256']:row['source_sha256']=row['sha256']
                row['sha256']=newhash;row['bytes']=path.stat().st_size
                row['version']='B1_v1.2.0_definition_consistent'
                row['availability']='ADAPTED_LOCAL_CODE' if rel.startswith('05_code/') else 'LOCAL_VERSIONED_OUTPUT'
                row['confirmation_status']='B1_V120_IMPLEMENTATION_OR_METADATA_REVISION'
            else:
                raise RuntimeError(f'Unexpected source capture changed: {rel}')
        rows.append(row)
    additions=[]
    files=list((ROOT/'05_code').glob('*.py'))+[
        ROOT/'00_contract/author_confirmation.json',
        ROOT/'00_contract/structure_selection_protocol.yaml',
        ROOT/'00_contract/implementation_diff.md',
        ROOT/'00_contract/structural_change_log.md',
        ROOT/'00_contract/OCMA_CODEX_B1_v120_full_execution.md']
    for path in files:
        rel=path.relative_to(ROOT).as_posix()
        if rel in registered:continue
        kind='PY' if path.suffix=='.py' else path.suffix.lstrip('.').upper()
        is_instruction=path.name=='OCMA_CODEX_B1_v120_full_execution.md'
        additions.append({'source_id':'B12_'+path.stem,'relative_path':rel,
            'sha256':sha(path),'source_sha256':'','bytes':path.stat().st_size,
            'version':'B1_v1.2.0_definition_consistent','material_type':'INSTRUCTION' if is_instruction else kind,
            'source_locator':('D:/下载/OCMA_CODEX_B1_v120_full_execution.md' if is_instruction else
                'local B1 v1.2 workspace implementation'),
            'evidence_locator':'full file','availability':'LOCAL_VERSIONED_OUTPUT' if not path.suffix=='.py' else 'ADAPTED_LOCAL_CODE',
            'confirmation_status':'AUTHOR_CURRENT_INSTRUCTION' if is_instruction else 'B1_V120_IMPLEMENTATION'})
    result=pd.concat([pd.DataFrame(rows),pd.DataFrame(additions)],ignore_index=True)
    if result.source_id.duplicated().any() or result.relative_path.duplicated().any():
        raise ValueError('Duplicate manifest identity')
    result.to_csv(FILE,index=False,encoding='utf-8-sig')
    print({'source_manifest_rows':len(result),'new_v12_rows':len(additions),
        'files_with_hash':int(result.sha256.ne('').sum())})

if __name__=='__main__':main()
