"""B1 source and numerical QA; missing numerical work never counts as a pass."""
from __future__ import annotations
import argparse,hashlib,json,sys
from pathlib import Path
import numpy as np
import pandas as pd
import yaml

ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'05_code/engine'),str(ROOT/'05_code')]
import engine_config as cfg
import sd_model as model
from revised_core import validate_metric
from test_cache_dependency import main as cache_test
from test_candidate_cache import main as candidate_cache_test

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main(input_only=False):
    rows=[]
    def check(name,ok,detail=''):
        rows.append({'check':name,'pass':bool(ok),'detail':str(detail)})
        if not ok:
            failure=ROOT/'06_runs/B1_v1_1';failure.mkdir(parents=True,exist_ok=True)
            pd.DataFrame(rows).to_csv(failure/'failed_check_log.csv',index=False,encoding='utf-8-sig')
            raise AssertionError(f'{name}: {detail}')
    c=yaml.safe_load((ROOT/'00_contract/baseline_contract.yaml').read_text(encoding='utf-8'))
    check('version',c['version']=='B1_v1.1.0_source_reconstructed')
    manifest=pd.read_csv(ROOT/'00_contract/source_manifest.csv').fillna('')
    for r in manifest.itertuples(index=False):
        if r.availability in ['COPIED_HASH_MATCH','ADAPTED_LOCAL_CODE']:
            p=(ROOT/r.relative_path).resolve()
            check('source_'+r.source_id,p.is_relative_to(ROOT.resolve()) and p.is_file() and sha(p)==r.sha256,r.relative_path)
    audit=pd.read_csv(ROOT/'02_policy/reconstructed/text_source_audit.csv')
    clauses=pd.read_csv(ROOT/'02_policy/reconstructed/coded_clauses_B1.csv')
    dates=pd.read_csv(ROOT/'02_policy/reconstructed/policy_validity_decisions.csv')
    date_evidence=pd.read_csv(ROOT/'02_policy/reconstructed/policy_time_evidence.csv')
    stock=pd.read_csv(ROOT/'02_policy/reconstructed/policy_stock_by_year_B1.csv')
    relations=pd.read_csv(ROOT/'02_policy/reconstructed/relation_events_B1.csv')
    check('68_source_bodies',len(audit)==68 and audit.policy_id.is_unique and audit.clean_text_sha256.notna().all())
    check('new_code_rows',len(clauses)>0 and clauses.unit_id.is_unique and clauses.policy_id.nunique()==68,len(clauses))
    texts={r.policy_id:(ROOT/r.clean_text_relative_path).read_text(encoding='utf-8') for r in audit.itertuples(index=False)}
    check('Hanting_target_body_boundary',audit.set_index('policy_id').loc['HT_2018_WETLAND_REPAIR_01','body_boundary']=='complete_plain_target_body_before_highlighted_search_results' and
          '<font color' not in texts['HT_2018_WETLAND_REPAIR_01'] and '&nbsp;' not in texts['HT_2018_WETLAND_REPAIR_01'])
    check('Shandong_2004_wrong_province_replaced',audit.set_index('policy_id').loc['EARLY-SHD-2004-25','body_source_relation']=='CAPTURED_FILE_WRONG_PROVINCE_REPLACED_BY_2004_SHANDONG_TEXT')
    check('all_exact_anchors',all(texts[r.policy_id][int(r.clean_start):int(r.clean_end)]==r.exact_evidence_text for r in clauses.itertuples(index=False)),len(clauses))
    source_hash=audit.set_index('policy_id').body_source_sha256.to_dict()
    check('coded_source_hash',all(r.source_hash==source_hash[r.policy_id] for r in clauses.itertuples(index=False)))
    labels=['b1_G1','b1_G2','b1_G3']+[f'b1_T{i}' for i in range(1,7)]
    check('code_domain_and_reasons',clauses[labels].isin([0,1]).all().all() and clauses.decision_reason.notna().all())
    original=[x for x in clauses if x.startswith('original_')]
    check('human_fields_blank',clauses[original].isna().all().all())
    check('CODEX_identity_pending',clauses.coding_origin.eq('CODEX_SOURCE_RECONSTRUCTION').all() and clauses.author_review_status.eq('PENDING').all())
    check('date_facts_separate_assumptions',len(dates)==68 and dates.policy_id.is_unique and dates.end_rule.eq('OPEN_ENDED_ASSUMED_THROUGH_2030').any())
    check('date_text_anchors',all(texts[r.policy_id][int(r.char_start):int(r.char_end)]==r.evidence_text and
          r.locator_coordinate_system=='normalized_clean_text_chars' for r in date_evidence.itertuples(index=False)),len(date_evidence))
    check('relation_source_events',not relations.empty and relations.policy_id.isin(audit.policy_id).all(),len(relations))
    check('stock_years',set(stock.year)==set(range(2000,2031)) and set(stock.channel)=={'G1','G2','G3'})
    for ch,g in stock.groupby('channel'):
        g=g.sort_values('year');x=g.active_valid_policy_stock.to_numpy(float)
        error=x[1:]-x[:-1]-g.new_effective_admissions.to_numpy(float)[1:]+g.exits_at_transition.to_numpy(float)[1:]
        check('stock_identity_'+ch,np.max(np.abs(error))<1e-9,float(np.max(np.abs(error))))
    interface=pd.read_csv(ROOT/'02_policy/reconstructed/annual_policy_interface_B1.csv')
    check('eta_count_denominator',np.allclose(interface.eta_raw,
          interface.active_explicit_governance_response_proxy_policy_count/interface.active_formal_policy_denominator))
    check('feedback_count_denominator',np.allclose(interface.feedback_raw,
          interface.active_explicit_feedback_signal_policy_count/interface.active_formal_policy_denominator))
    check('synergy_two_denominators',np.allclose(interface.synergy_raw,
          np.sqrt(interface.stock_network_joint_issue_policy_share*interface.stock_network_vertical_relation_weight_share)))
    mi=pd.read_csv(ROOT/'03_indicators/model_input_B1.csv')
    check('complete_input',mi.year.tolist()==list(range(2011,2024)) and mi.input_complete.all())
    check('synergy_schema',np.allclose(mi.SYNERGY_LEVER,mi.synergy_share,atol=1e-12) and np.allclose(mi.SYNERGY_LEVER,interface.SYNERGY_LEVER,atol=1e-12))
    lineage=pd.read_csv(ROOT/'03_indicators/indicator_lineage.csv')
    check('no_B0_lineage',not lineage.source_id.astype(str).str.contains('B0|digitiz|target_guided',case=False,regex=True).any())
    check('social_equations',np.allclose(mi.AC,mi.SC) and np.allclose(mi.SR,np.sqrt((1-mi.SP)*mi.AC)))
    check('ecological_equations',np.allclose(mi.WQ,((1-mi.NS)*(1-mi.OS)*(1-mi.BS))**(1/3)) and np.allclose(mi.H,np.sqrt(mi.TF*mi.SM)) and np.allclose(mi.ES,np.sqrt(mi.WQ*mi.H)))
    gate=mi.AC.to_numpy(float)**2/(.3**2+mi.AC.to_numpy(float)**2)
    g3=mi.G3.to_numpy(float)**2.2/(.45**2.2+mi.G3.to_numpy(float)**2.2)
    check('IM_initialization',np.allclose(mi.IM,np.clip(mi.ETA_POTENTIAL*g3*(.12+.88*gate)/(1+.75*mi.SP),.001,.999),atol=1e-12))
    sensitivity=ROOT/'06_runs/B1_v1_1/policy_input_sensitivity/annual_G_input_alternatives.csv'
    if sensitivity.exists():
        alt=pd.read_csv(sensitivity)
        primary=alt[alt.case.eq('MAIN_CODEX_RECONSTRUCTION')]
        expected=np.array([mi.loc[mi.year.eq(r.year),r.channel].iloc[0] for r in primary.itertuples(index=False)])
        check('ambiguity_main_input_matches',len(alt)==117 and np.allclose(primary.G_model_input,expected,atol=1e-10))
    check('bounded_input',mi[cfg.STATE_NAMES+['PPT','RUNOFF','SST']].ge(0).all().all() and mi[cfg.STATE_NAMES+['PPT','RUNOFF','SST']].le(1).all().all())
    check('2023_habitat_estimated',mi.loc[mi.year.eq(2023),'habitat_2023_estimated'].all() and not mi.loc[mi.year.lt(2023),'habitat_2023_estimated'].any())
    check('035_evaluation_only',c['ecology']['2023_evaluation_weight']==.35 and not c['ecology']['2023_initial_state_blend'])
    sc=pd.read_csv(ROOT/'04_model/scenario_registry.csv');lev=pd.read_csv(ROOT/'04_model/scenario_lever_audit.csv')
    check('seven_executable_scenarios',len(sc)==7 and sc.model_executable.all() and dict(zip(sc.scenario_id,sc.tau_years))==c['scenario_tau_years'])
    check('actual_quantile_levers',len(lev)==49 and lev.raw_baseline.notna().all() and lev.model_future.notna().all())
    check('nine_parameter_box',len(cfg.PARAMETER_NAMES)==9 and set(cfg.PARAMETER_NAMES)==set(c['parameter_bounds']))
    middle=np.array([(a+b)/2 for a,b in c['parameter_bounds'].values()])
    forcing=model.historical_forcing(mi);initial=model.initial_state(mi,year=2011)
    x=model.simulate(middle,forcing,np.arange(2011,2014,dtype=float),initial,max_step=.05)
    y=model.simulate(middle,forcing,np.arange(2011,2014,dtype=float),initial,max_step=.02)
    check('real_input_step_005_002',np.max(np.abs(x[cfg.STATE_NAMES].to_numpy()-y[cfg.STATE_NAMES].to_numpy()))<5e-5)
    denom=validate_metric([0,0],[0,0],[2021,2022],np.arange(10.))['calibration_P95_minus_P5']
    check('training_P95_P5_denominator',np.isclose(denom,8.1),denom)
    cache_test(ROOT/'06_runs/B1_v1_1/cache_dependency_test.csv')
    candidate_cache_test()
    check('cache_failure_modes',True)
    run=ROOT/'06_runs/B1_v1_1';cal_path=run/'calibration/calibration_status.json';scenario_path=run/'scenarios/scenario_status.json';attr_path=run/'attribution/attribution_status.json'
    if not input_only:
        check('complete_numerical_execution',cal_path.exists() and (run/'evaluation/evaluation_status.json').exists() and scenario_path.exists() and attr_path.exists())
    if cal_path.exists():
        cal=json.loads(cal_path.read_text(encoding='utf-8'))
        check('calibration_input_identity',cal['dependencies']['input']==sha(ROOT/'03_indicators/model_input_B1.csv'))
        check('calibration_code_config_identity',cal['dependencies']['this_code']==sha(ROOT/'05_code/numeric_calibration.py') and
              cal['dependencies']['model']==sha(ROOT/'05_code/engine/sd_model.py') and
              cal['dependencies']['contract']==sha(ROOT/'00_contract/baseline_contract.yaml'))
        cand=pd.read_csv(run/'calibration/candidate_screen_all.csv');accepted=pd.read_csv(run/'calibration/accepted_parameter_ensemble.csv')
        chunks=json.loads((run/'calibration/candidate_COMPLETE.json').read_text(encoding='utf-8'))
        check('candidate_chunks_complete',chunks['status']=='COMPLETE' and chunks['count']==len(cand) and
              sum(x['rows'] for x in chunks['chunks'])==len(cand) and
              all(sha(run/'calibration'/x['file'])==x['sha256'] for x in chunks['chunks']))
        check('actual_calibration',cal['complete'] and cal['five_seed_count']==5 and len(cand)==sum(c['calibration']['local_candidate_counts'])+c['calibration']['global_lhs_count'])
        check('accepted_count',len(accepted)==cal['propagated_count'] and accepted[cfg.PARAMETER_NAMES].notna().all().all())
        check('fixed_gates_respected',int(cand.accepted.sum())==cal['accepted_before_cap'] and
              accepted.loss.le(1.35*cal['best_loss']+.025+1e-12).all() and
              accepted.mean_nrmse.le(.52+1e-12).all() and accepted.trend_hit.ge(.43-1e-12).all() and
              len(accepted)<=600)
    if scenario_path.exists():
        info=json.loads(scenario_path.read_text(encoding='utf-8'))
        check('scenario_input_identity',info['input_sha256']==sha(ROOT/'03_indicators/model_input_B1.csv'))
        check('scenario_code_identity',info['analysis_code_sha256']==sha(ROOT/'05_code/numeric_analysis.py') and
              info['model_code_sha256']==sha(ROOT/'05_code/engine/sd_model.py'))
        complete=run/'scenarios/cache'/('run_'+info['cache_signature'])/'COMPLETE.json'
        check('scenario_cache_complete',complete.is_file() and
              len(json.loads(complete.read_text(encoding='utf-8'))['chunks'])==info['parameter_draws'])
        traj=pd.read_csv(run/'scenarios/scenario_trajectories_long.csv')
        check('actual_scenarios',info['complete'] and traj.scenario.nunique()==7 and len(traj)==49*info['parameter_draws'])
        check('scenario_bounds',traj[cfg.STATE_NAMES].ge(0).all().all() and traj[cfg.STATE_NAMES].le(1).all().all())
        paired=pd.read_csv(run/'scenarios/paired_differences.csv')
        check('actual_pairing',len(paired)==4*info['parameter_draws'] and paired[['parameter_set_id','forcing_draw_id','initial_state_hash','contrast']].notna().all().all())
        first_id=traj.parameter_set_id.iloc[0]
        sample=traj[traj.parameter_set_id.eq(first_id)]
        check('minimum_ES_pair_order',all(abs(float(paired.loc[(paired.parameter_set_id.eq(first_id))&(paired.contrast.eq(a+'-'+b)),'D_min_ES_2026_2030'].iloc[0])-
              (float(sample.loc[sample.scenario.eq(a)&sample.year.between(2026,2030),'ES'].min())-
               float(sample.loc[sample.scenario.eq(b)&sample.year.between(2026,2030),'ES'].min())))<1e-10
              for a,b in [('S4','S0'),('S6','S0'),('S4','S6'),('S5','S0')]))
        cross=pd.read_csv(run/'scenarios/cross_spec_robustness.csv')
        check('bounded_cross_spec_comparison',len(cross)==2*info['cross_spec_parameter_sets'] and
              set(cross.forcing_spec)=={'primary_compound','same_blocks_no_compound'} and
              cross.groupby('parameter_set_id').size().eq(2).all())
        from numeric_analysis import load_settings,scenario_forcing,initialize,init_hash
        check('scenario_2023_reset_identity',info['initial_state_hash']==init_hash(initialize(mi,2023)) and
              traj.initial_state_hash.eq(info['initial_state_hash']).all())
        check('common_scenario_forcing',traj.forcing_draw_id.nunique()==1 and
              traj.forcing_draw_id.eq('CLIM_20260725_001').all())
        best=json.loads((run/'calibration/best_parameter_set.json').read_text(encoding='utf-8'))['parameters']
        settings=load_settings();climate=pd.read_csv(run/'scenarios/common_climate_draw_001.csv')
        values={}
        for step in [.05,.02]:
            values[step]={}
            for s in ['S0','S4','S6']:
                f,_,_=scenario_forcing(mi,settings[s],climate)
                result=model.simulate(best,f,np.arange(2023,2031,dtype=float),model.initial_state(mi,year=2023),max_step=step)
                values[step][s]=(float(result.iloc[-1].ES),float(result[result.year.between(2026,2030)].ES.min()))
        errors=[]
        for a,b in [('S4','S0'),('S4','S6')]:
            for j in [0,1]:
                errors.append(abs((values[.05][a][j]-values[.05][b][j])-(values[.02][a][j]-values[.02][b][j])))
        check('real_pair_step_005_002',max(errors)<5e-5,max(errors))
    if attr_path.exists():
        detail=pd.read_csv(run/'attribution/matched_shapley_by_parameter.csv')
        check('actual_shapley_closure',all(abs(g.shapley.sum()-g.total_paired_difference.iloc[0])<1e-10 for _,g in detail.groupby(['parameter_set_id','comparison','metric'])))
        main=pd.read_csv(run/'scenarios/scenario_metrics_by_parameter.csv').set_index(['parameter_set_id','scenario'])
        check('shapley_endpoints_match_scenarios',all(
            abs(float(g.endpoint_base.iloc[0])-float(main.loc[(pid,comparison.split('-')[1]),metric]))<1e-10 and
            abs(float(g.endpoint_target.iloc[0])-float(main.loc[(pid,comparison.split('-')[0]),metric]))<1e-10
            for (pid,comparison,metric),g in detail.groupby(['parameter_set_id','comparison','metric'])))
    status={'version':c['version'],'checks':len(rows),'passed':all(x['pass'] for x in rows),
      'numerical_stages_present':{'calibration':cal_path.exists(),'scenarios':scenario_path.exists(),'attribution':attr_path.exists()},
      'author_review_status':'PENDING','submission_ready':False}
    run.mkdir(parents=True,exist_ok=True)
    (run/('input_qa_report.json' if input_only else 'baseline_qa_report.json')).write_text(json.dumps(status,ensure_ascii=False,indent=2),encoding='utf-8')
    pd.DataFrame(rows).to_csv(run/('test_log_input.csv' if input_only else 'test_log.csv'),index=False,encoding='utf-8-sig')
    print(json.dumps(status,ensure_ascii=False))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--input-only',action='store_true')
    main(p.parse_args().input_only)
