"""Registered 13-by-13 governance/disturbance surface on the selected B1 model."""
from __future__ import annotations
import hashlib,json,sys
from concurrent.futures import ProcessPoolExecutor,as_completed
from pathlib import Path
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'05_code/engine'),str(ROOT/'05_code')]
import engine_config as cfg
import sd_model as model
from numeric_analysis import load_settings,climate_path,scenario_forcing
from v12_modeling import reference_for
from cache_safety import ChunkCache,signature,atomic_json

CAL=ROOT/'06_runs/formal_main/calibration'
OUT=ROOT/'06_runs/formal_main/mechanisms/response_surface'
GRID=np.linspace(0.,1.,13)

def one(args):
    pid,params,structure,frame,settings,base_climate,full_climate=args
    initial=model.initial_state(frame,year=2023)
    hist=model.historical_forcing(frame)
    ref=reference_for(frame,hist,model.initial_state(frame,year=2011),params,structure)
    ih=hashlib.sha256(initial.tobytes()).hexdigest()
    rh=hashlib.sha256(json.dumps(ref,sort_keys=True).encode()).hexdigest() if ref is not None else 'RUN_SPECIFIC'
    rows=[]
    for i,g in enumerate(GRID):
        setting={k:float(settings['S0'][k]+g*(settings['S4'][k]-settings['S0'][k]))
            for k in settings['S0']}
        for j,d in enumerate(GRID):
            climate=base_climate.copy()
            for var in ['PPT','RUNOFF','SST']:
                climate[var]=base_climate[var]+d*(full_climate[var]-base_climate[var])
            forcing,_,f_frame=scenario_forcing(frame,setting,climate)
            pred=model.simulate(params,forcing,np.arange(2023,2031,dtype=float),initial,
                structure=structure,reference_context=ref)
            shock=pred[pred.year.between(2026,2030)];end=pred[pred.year.eq(2030)].iloc[0]
            rows.append({'cache_row_id':f'{pid}:{i:02d}:{j:02d}',
                'parameter_set_id':pid,'governance_grid_index':i,'disturbance_grid_index':j,
                'governance_intensity':float(g),'disturbance_intensity':float(d),
                'initial_state_hash':ih,'reference_context_sha256':rh,
                'forcing_sha256':hashlib.sha256(f_frame.to_csv(index=False).encode()).hexdigest(),
                'setting_json':json.dumps(setting,sort_keys=True),
                'min_ES_2026_2030':float(shock.ES.min()),
                'ES_2030':float(end.ES),'SR_2030':float(end.SR)})
    return pid,pd.DataFrame(rows)

def main():
    OUT.mkdir(parents=True,exist_ok=True)
    frame=pd.read_csv(ROOT/'03_indicators/model_input_B1.csv').sort_values('year').reset_index(drop=True)
    status=json.loads((CAL/'formal_calibration_status.json').read_text(encoding='utf-8'))
    structure=status['structure'];names=model.parameter_names(structure)
    ensemble=pd.read_csv(CAL/'accepted_parameter_ensemble.csv')
    if ensemble.empty:raise RuntimeError('No accepted vectors')
    subset=ensemble.iloc[np.unique(np.linspace(0,len(ensemble)-1,min(24,len(ensemble)),dtype=int))].copy()
    subset.to_csv(OUT/'surface_parameter_subset.csv',index=False,encoding='utf-8-sig')
    settings=load_settings()
    base=climate_path(frame,shock=False);full=climate_path(frame,shock=True)
    base.to_csv(OUT/'same_blocks_no_compound.csv',index=False)
    full.to_csv(OUT/'same_blocks_full_compound.csv',index=False)
    files=[ROOT/p for p in ['03_indicators/model_input_B1.csv','04_model/scenario_lever_audit.csv',
        '04_model/equation_registry.csv','04_model/parameter_registry.csv',
        '02_policy/reconstructed/policy_stock_by_year_B1.csv',
        '02_policy/reconstructed/interface_quantiles_B1.csv','00_contract/baseline_contract.yaml',
        '05_code/engine/sd_model.py','05_code/engine/engine_config.py',
        '05_code/engine/engine_common.py','05_code/numeric_analysis.py',
        '05_code/v12_modeling.py','05_code/v12_response_surface.py','05_code/cache_safety.py',
        '06_runs/formal_main/mechanisms/response_surface/surface_parameter_subset.csv',
        '06_runs/formal_main/mechanisms/response_surface/same_blocks_no_compound.csv',
        '06_runs/formal_main/mechanisms/response_surface/same_blocks_full_compound.csv',
        '06_runs/formal_main/scenarios/scenario_metrics_by_parameter.csv']]
    key,material=signature(files,{'structure':structure,'vectors':subset[names].to_numpy(float).tolist(),
        'governance_mapping':'linear_S0_to_S4_registered_lever_endpoints',
        'disturbance_mapping':'same_block_no_to_full_compound_2026_2028',
        'grid':GRID.tolist(),'initial_year':2023,'reference_year':2011,'solver_step':.05},
        code_version=cfg.CONTRACT['version'],root=ROOT)
    cache=ChunkCache(OUT/'cache',key,material)
    specs=[];jobs=[];required=['cache_row_id','governance_grid_index','disturbance_grid_index','ES_2030']
    for r in subset.itertuples(index=False):
        pid=r.parameter_set_id;ids=[f'{pid}:{i:02d}:{j:02d}' for i in range(13) for j in range(13)]
        specs.append((pid,ids,required))
        if cache.load(pid,ids,required) is None:
            jobs.append((pid,{n:float(getattr(r,n)) for n in names},structure,frame,settings,base,full))
    with ProcessPoolExecutor(max_workers=8) as pool:
        futures=[pool.submit(one,j) for j in jobs]
        for i,f in enumerate(as_completed(futures),1):
            pid,rows=f.result();ids=next(s[1] for s in specs if s[0]==pid)
            cache.commit(pid,rows,ids,required)
            if i%6==0 or i==len(futures):print(f'response surface vectors={i}/{len(futures)}',flush=True)
    cache.finalize(specs)
    raw=pd.concat([cache.load(*s) for s in specs],ignore_index=True)
    raw.to_csv(OUT/'response_surface_by_parameter.csv',index=False,encoding='utf-8-sig')
    main=pd.read_csv(ROOT/'06_runs/formal_main/scenarios/scenario_metrics_by_parameter.csv')
    checks=[]
    for gi,sid in [(0,'S0'),(12,'S4')]:
        surface=raw[raw.governance_grid_index.eq(gi)&raw.disturbance_grid_index.eq(12)]
        target=main[main.scenario.eq(sid)]
        joined=surface.merge(target,on='parameter_set_id',validate='one_to_one',suffixes=('_surface','_main'))
        if len(joined)!=len(subset):raise AssertionError('Surface endpoint parameter mismatch')
        error=max(float(np.max(np.abs(joined[f'{m}_surface']-joined[f'{m}_main'])))
            for m in ['min_ES_2026_2030','ES_2030','SR_2030'])
        checks.append({'scenario':sid,'max_abs_error':error,'pass':error<=1e-10})
        if error>1e-10:raise AssertionError(f'Surface endpoint does not match {sid}: {error}')
    pd.DataFrame(checks).to_csv(OUT/'surface_endpoint_matches.csv',index=False,encoding='utf-8-sig')
    rows=[]
    for (i,j),g in raw.groupby(['governance_grid_index','disturbance_grid_index']):
        row={'governance_grid_index':i,'disturbance_grid_index':j,
            'governance_intensity':float(GRID[i]),'disturbance_intensity':float(GRID[j]),
            'parameter_sets':len(g)}
        for metric in ['min_ES_2026_2030','ES_2030','SR_2030']:
            row[metric+'_P5']=float(g[metric].quantile(.05))
            row[metric+'_median']=float(g[metric].median())
            row[metric+'_P95']=float(g[metric].quantile(.95))
        rows.append(row)
    summary=pd.DataFrame(rows)
    pivot=summary.pivot(index='disturbance_grid_index',columns='governance_grid_index',
        values='min_ES_2026_2030_median').sort_index().sort_index(axis=1)
    dy,dx=np.gradient(pivot.to_numpy(float),GRID,GRID)
    gradients=pd.DataFrame(np.sqrt(dx*dx+dy*dy)).stack().reset_index()
    gradients.columns=['disturbance_grid_index','governance_grid_index','transition_gradient']
    summary=summary.merge(gradients,on=['disturbance_grid_index','governance_grid_index'],validate='one_to_one')
    summary['transition_zone_top10pct']=summary.transition_gradient.ge(summary.transition_gradient.quantile(.90))
    summary.to_csv(OUT/'response_surface_summary.csv',index=False,encoding='utf-8-sig')
    atomic_json(OUT/'response_surface_status.json',{'complete':True,'grid_points':169,
        'parameter_sets':len(subset),'simulation_cells':len(raw),
        'grid_origin':'historical_code_13x13_spacing; B1 registered S0-to-S4 lever endpoints',
        'not_original_P50_to_P90_lever_amplitude':True,
        'disturbance':'same_blocks_0_to_1_compound_override',
        'fixed_parameter_conditional_surface':True,'all_main_endpoints_match':True,
        'cache_signature':key})

if __name__=='__main__':main()
