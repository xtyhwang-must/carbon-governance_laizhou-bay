"""Six one-way and three reciprocal-link fixed-parameter ablations."""
from __future__ import annotations
import hashlib,json,sys
from concurrent.futures import ProcessPoolExecutor,as_completed
from pathlib import Path
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'05_code/engine'),str(ROOT/'05_code')]
import engine_config as cfg
import sd_model as model
from numeric_analysis import load_settings,scenario_forcing
from v12_modeling import reference_for
from cache_safety import ChunkCache,signature,atomic_json

CAL=ROOT/'06_runs/formal_main/calibration'
SCEN=ROOT/'06_runs/formal_main/scenarios'
ROB=ROOT/'06_runs/formal_main/robustness'
OUT=ROOT/'06_runs/formal_main/mechanisms'
MODES={
 'G_to_S':('g_to_s',),'S_to_G':('s_to_g',),'G_to_E':('g_to_e',),
 'E_to_G':('e_to_g',),'S_to_E':('s_to_e',),'E_to_S':('e_to_s',),
 'G_S_reciprocal':('g_to_s','s_to_g'),
 'G_E_reciprocal':('g_to_e','e_to_g'),
 'S_E_reciprocal':('s_to_e','e_to_s')}
METRICS=['min_ES_2026_2030','ES_2030','SR_2030']

def one(args):
    pid,params,structure,frame,climate,settings=args
    initial=model.initial_state(frame,year=2023)
    hist=model.historical_forcing(frame)
    init2011=model.initial_state(frame,year=2011)
    # Freeze the training-period reference once per parameter vector. An
    # ablation changes only its named link, not the historical reference.
    ref=reference_for(frame,hist,init2011,params,structure)
    refhash=hashlib.sha256(json.dumps(ref,sort_keys=True).encode()).hexdigest() if ref is not None else 'RUN_SPECIFIC'
    rows=[]
    for name,disabled in MODES.items():
        mode=model.ModelMode(**{k:False for k in disabled})
        for sid in ['S0','S4']:
            forcing,_,f_frame=scenario_forcing(frame,settings[sid],climate)
            p=model.simulate(params,forcing,np.arange(2023,2031,dtype=float),initial,
                mode=mode,structure=structure,reference_context=ref)
            sh=p[p.year.between(2026,2030)];end=p[p.year.eq(2030)].iloc[0]
            rows.append({'cache_row_id':f'{pid}:{name}:{sid}','parameter_set_id':pid,
                'disabled_link_spec':name,'disabled_fields':'|'.join(disabled),'scenario':sid,
                'forcing_draw_id':'CLIM_20260725_001',
                'initial_state_hash':hashlib.sha256(initial.tobytes()).hexdigest(),
                'reference_context_sha256':refhash,
                'forcing_sha256':hashlib.sha256(f_frame.to_csv(index=False).encode()).hexdigest(),
                'min_ES_2026_2030':float(sh.ES.min()),'ES_2030':float(end.ES),
                'SR_2030':float(end.SR),'annual_trajectory_json':p[['year']+cfg.STATE_NAMES+['SR','ES']].to_json(orient='records',double_precision=15)})
    return pid,pd.DataFrame(rows)

def main():
    OUT.mkdir(parents=True,exist_ok=True)
    frame=pd.read_csv(ROOT/'03_indicators/model_input_B1.csv').sort_values('year').reset_index(drop=True)
    status=json.loads((CAL/'formal_calibration_status.json').read_text(encoding='utf-8'))
    structure=status['structure'];names=model.parameter_names(structure)
    sample=pd.read_csv(ROB/'stratified_parameter_sample.csv')
    if sample.empty:raise RuntimeError('No robustness parameter sample')
    primary=pd.read_csv(SCEN/'scenario_metrics_by_parameter.csv')
    climate=pd.read_csv(SCEN/'common_climate_draw_001.csv');settings=load_settings()
    files=[ROOT/p for p in ['03_indicators/model_input_B1.csv','04_model/scenario_lever_audit.csv',
        '04_model/equation_registry.csv','04_model/parameter_registry.csv',
        '02_policy/reconstructed/policy_stock_by_year_B1.csv',
        '02_policy/reconstructed/interface_quantiles_B1.csv','00_contract/baseline_contract.yaml',
        '05_code/engine/sd_model.py','05_code/engine/engine_config.py',
        '05_code/engine/engine_common.py','05_code/numeric_analysis.py','05_code/v12_modeling.py',
        '05_code/v12_mechanisms.py','05_code/cache_safety.py',
        '06_runs/formal_main/robustness/stratified_parameter_sample.csv',
        '06_runs/formal_main/scenarios/common_climate_draw_001.csv',
        '06_runs/formal_main/scenarios/scenario_metrics_by_parameter.csv']]
    key,material=signature(files,{'structure':structure,'vectors':sample[names].to_numpy(float).tolist(),
        'mode_fields':{name:list(fields) for name,fields in MODES.items()},
        'initial_year':2023,'reference_year':2011,'step':.05},
        code_version=cfg.CONTRACT['version'],root=ROOT)
    cache=ChunkCache(OUT/'cache',key,material)
    specs=[];jobs=[];required=['cache_row_id','parameter_set_id','disabled_link_spec','scenario','ES_2030','annual_trajectory_json']
    for r in sample.itertuples(index=False):
        pid=r.parameter_set_id;ids=[f'{pid}:{name}:{sid}' for name in MODES for sid in ['S0','S4']]
        specs.append((pid,ids,required))
        if cache.load(pid,ids,required) is None:
            jobs.append((pid,{n:float(getattr(r,n)) for n in names},structure,frame,climate,settings))
    with ProcessPoolExecutor(max_workers=8) as pool:
        futures=[pool.submit(one,j) for j in jobs]
        for i,f in enumerate(as_completed(futures),1):
            pid,rows=f.result();ids=next(s[1] for s in specs if s[0]==pid)
            cache.commit(pid,rows,ids,required)
            if i%20==0 or i==len(futures):print(f'mechanism vectors={i}/{len(futures)}',flush=True)
    cache.finalize(specs)
    raw=pd.concat([cache.load(*s) for s in specs],ignore_index=True)
    yearly=[]
    for row in raw.itertuples():
        for x in json.loads(row.annual_trajectory_json):
            yearly.append(dict(parameter_set_id=row.parameter_set_id,disabled_link_spec=row.disabled_link_spec,scenario=row.scenario,**x))
    yearly=pd.DataFrame(yearly);yearly['G']=yearly[['G1','G2','G3']].mean(axis=1)
    yearly.to_csv(OUT/'ablation_annual_trajectories.csv',index=False,encoding='utf-8-sig')
    fullpaths=pd.read_csv(SCEN/'scenario_trajectories_long.csv');fullpaths['G']=fullpaths[['G1','G2','G3']].mean(axis=1)
    annual=[]
    for (pid,link,year),z in yearly[yearly.year.ge(2024)].groupby(['parameter_set_id','disabled_link_spec','year']):
        z=z.set_index('scenario');full=fullpaths[fullpaths.parameter_set_id.eq(pid)&fullpaths.year.eq(year)].set_index('scenario')
        for v in ['G','SR','ES']:
            annual.append(dict(parameter_set_id=pid,link=link,year=year,metric=v,effect=float((full.loc['S4',v]-full.loc['S0',v])-(z.loc['S4',v]-z.loc['S0',v]))))
    annual=pd.DataFrame(annual);annual.to_csv(OUT/'ablation_annual_effects.csv',index=False,encoding='utf-8-sig')
    joints=[]
    for (pid,year,v),z in annual.groupby(['parameter_set_id','year','metric']):
        q=z.set_index('link').effect
        for pair,a,b in [('G_S_reciprocal','G_to_S','S_to_G'),('G_E_reciprocal','G_to_E','E_to_G'),('S_E_reciprocal','S_to_E','E_to_S')]:
            joints.append(dict(parameter_set_id=pid,year=year,metric=v,pair=pair,nonadditivity=q[pair]-q[a]-q[b]))
    pd.DataFrame(joints).to_csv(OUT/'reciprocal_nonadditivity_annual.csv',index=False,encoding='utf-8-sig')
    raw.to_csv(OUT/'ablation_scenario_metrics.csv',index=False,encoding='utf-8-sig')
    main=primary[primary.parameter_set_id.isin(sample.parameter_set_id)]
    main_pivot=main.pivot(index='parameter_set_id',columns='scenario',values=METRICS)
    effects=[]
    for (pid,mode),g in raw.groupby(['parameter_set_id','disabled_link_spec']):
        part=g.set_index('scenario')
        for metric in METRICS:
            full=float(main_pivot.loc[pid,(metric,'S4')]-main_pivot.loc[pid,(metric,'S0')])
            reduced=float(part.loc['S4',metric]-part.loc['S0',metric])
            effects.append({'parameter_set_id':pid,'disabled_link_spec':mode,'metric':metric,
                'full_S4_minus_S0':full,'ablated_S4_minus_S0':reduced,
                'contribution_full_minus_ablated':full-reduced,
                'interpretation':'FIXED_PARAMETER_STRUCTURAL_ABLATION_NOT_CAUSAL_EFFECT'})
    effects=pd.DataFrame(effects)
    for metric in METRICS:
        values=(main_pivot[(metric,'S4')]-main_pivot[(metric,'S0')]).to_numpy(float)
        iqr=float(np.quantile(values,.75)-np.quantile(values,.25))
        effects.loc[effects.metric.eq(metric),'full_pair_IQR_denominator']=iqr
    effects['IQR_standardized_contribution']=effects.contribution_full_minus_ablated/effects.full_pair_IQR_denominator.replace(0,np.nan)
    effects.to_csv(OUT/'ablation_effects_by_parameter.csv',index=False,encoding='utf-8-sig')
    effects.groupby(['disabled_link_spec','metric'])[['contribution_full_minus_ablated','IQR_standardized_contribution']].median().reset_index().to_csv(
        OUT/'ablation_effect_summary.csv',index=False,encoding='utf-8-sig')
    atomic_json(OUT/'mechanism_status.json',{'complete':True,'parameter_sets':len(sample),
        'directional_ablations':6,'reciprocal_pair_ablations':3,
        'scenario_cells':len(raw),'IQR_denominator':'IQR of matched full S4-S0 differences across same selected parameters',
        'cache_signature':key,'fixed_parameter_not_refitted':True,
        'response_surface_computed_in_separate_stage':True})

if __name__=='__main__':main()
