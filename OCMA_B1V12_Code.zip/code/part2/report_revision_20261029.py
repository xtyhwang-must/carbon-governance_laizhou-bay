"""Single current report entry. Reads frozen results; never simulates or optimizes."""
from pathlib import Path
import os
if (Path(__file__).resolve().parent.parent/'SOURCE_INPUTS.csv').is_file():
    os.environ.setdefault('B1_REPORT_DIR',str(Path(__file__).resolve().parent.parent))
from report_r2 import main
if __name__=='__main__':main()
