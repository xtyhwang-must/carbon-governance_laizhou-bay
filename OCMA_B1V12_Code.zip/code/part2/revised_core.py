"""Revision kernels. No filesystem writes or implicit research data at import."""
import hashlib
import numpy as np
import pandas as pd
from scipy.stats import qmc, truncnorm

MATCH_KEYS = ['specification_id','parameter_set_id','forcing_draw_id','initial_state_hash']

def scale_reference(values, years, method='quantile'):
    v=np.asarray(values,float); years=np.asarray(years,int)
    ref=v[(years>=2011)&(years<=2020)]; ref=ref[np.isfinite(ref)]
    if not len(ref): raise ValueError('No calibration reference')
    lo,hi=np.quantile(ref,[.05,.95] if method=='quantile' else [0,1])
    if hi==lo: lo,hi=np.min(ref),np.max(ref)
    mapped=np.full_like(v,.5) if hi==lo else .02+.96*(v-lo)/(hi-lo)
    return np.clip(mapped,.02,.98),dict(lower=float(lo),upper=float(hi),reference='2011-2020',clipped_low=int(np.sum(mapped<.02)),clipped_high=int(np.sum(mapped>.98)),zero_reference_range=bool(hi==lo))

def top_mean(x,y,method='geometric'):
    x=np.asarray(x,float);y=np.asarray(y,float)
    if np.any(x<=0) or np.any(y<=0):raise ValueError('Positive bounded supports required')
    if method=='geometric': return np.sqrt(x*y)
    if method=='arithmetic': return (x+y)/2
    if method=='harmonic': return 2/(1/x+1/y)
    if method in ['weight_0.3','weight_0.7']:
        w=float(method.split('_')[1]); return x**w*y**(1-w)
    raise ValueError(method)

def reporting(states,es='geometric',sr='geometric'):
    s=np.asarray(states,float)
    sp,ac,ns,os,bs,tf,sm=[s[...,i] for i in range(3,10)]
    wq=((1-ns)*(1-os)*(1-bs))**(1/3);h=np.sqrt(tf*sm)
    return dict(WQ=wq,H=h,ES=top_mean(wq,h,es),SR=top_mean(1-sp,ac,sr))

def social_states(components,omit=None):
    """Already transformed variables; preserve agriculture as one SP layer."""
    x=components
    ag=[x[k] for k in ['grain','meat'] if k!=omit]
    pressure=[x[k] for k in ['population','industry'] if k!=omit]+[np.mean(ag,axis=0)]
    capacity=[x[k] for k in ['fiscal','education'] if k!=omit]
    sp=np.mean(pressure,axis=0); ac=np.mean(capacity,axis=0)
    return dict(SP=sp,AC=ac,SR=np.sqrt((1-sp)*ac))

def adjacent_differences(frame,columns):
    f=frame.sort_values('year').copy()
    out=f[['year']].copy();out['previous_year']=f.year.shift()
    out[columns]=f[columns].diff()
    return out.loc[f.year.diff().eq(1)].reset_index(drop=True)

def replace_habitat(initial,tf,sm):
    """Only the TF/SM substitution; full history-dependent risk rebuild is upstream."""
    if not(.02<=tf<=.98 and .02<=sm<=.98):raise ValueError('Invalid empirical endpoint')
    out=np.asarray(initial,float).copy();out[[8,9]]=[tf,sm];return out

def observation_weights(years,state,mode='weighted'):
    w=np.ones(len(years))
    if state in ['TF','SM','H','ES']:
        w[np.asarray(years)==2023]={'weighted':.35,'unweighted':1.,'exclude_estimated':0.}[mode]
    return w

def local_candidates(center,bounds,count,scale,seed):
    center=np.asarray(center,float); bounds=np.asarray(bounds,float)
    lo,hi=bounds.T;sd=(hi-lo)*scale
    if np.any(center<lo) or np.any(center>hi) or np.any(sd<=0):raise ValueError('Invalid bounded center or scale')
    u=qmc.LatinHypercube(d=len(center),seed=seed).random(count)
    u=np.maximum(u,np.nextafter(0.,1.))
    u=np.minimum(u,np.nextafter(1.,0.))
    return truncnorm.ppf(u,(lo-center)/sd,(hi-center)/sd,loc=center,scale=sd)

def select_accepted(candidates,names,best_loss,seed=20261029,cap=600):
    f=candidates.copy()
    f['rejection_reason']=''
    for mask,label in [(~np.isfinite(f.loss),'nonfinite_loss'),(f.loss>1.35*best_loss+.025,'loss'),(f.mean_nrmse>.52,'nrmse'),(f.trend_hit<.43,'direction'),(~np.isfinite(f.mean_nrmse)|~np.isfinite(f.trend_hit),'nonfinite_metrics')]:
        f.loc[mask,'rejection_reason']+=label+';'
    f['accepted']=f.rejection_reason.eq('')
    accepted=f[f.accepted].drop_duplicates(names).copy()
    if len(accepted)>cap:accepted=accepted.sample(n=cap,random_state=seed)
    return f,accepted

def paired_contrasts(frame,a,b):
    keys=MATCH_KEYS+['year']
    if frame[keys+['scenario']].isna().any().any():raise ValueError('Null matching key')
    if frame.duplicated(keys+['scenario']).any():raise ValueError('Nonunique draw-year key')
    left=frame[frame.scenario.eq(a)];right=frame[frame.scenario.eq(b)]
    both=left.merge(right,on=keys,how='outer',validate='one_to_one',suffixes=('_a','_b'),indicator=True)
    if not both._merge.eq('both').all():raise ValueError('Unmatched scenario trajectory')
    rows=[]
    for k,g in both.groupby(MATCH_KEYS,dropna=False):
        g=g.sort_values('year')
        if g.year.tolist()!=list(range(2024,2031)):raise ValueError('Missing annual scenario output')
        shock=g[g.year.between(2026,2030)]
        last=g[g.year.eq(2030)].iloc[0]
        rows.append(dict(zip(MATCH_KEYS,k))|{'contrast':a+'-'+b,'D_min':float(shock.ES_a.min()-shock.ES_b.min()),'D_ES2030':float(last.ES_a-last.ES_b),'D_SR2030':float(last.SR_a-last.SR_b),'minimum_annual_D_SR':float((g.SR_a-g.SR_b).min())})
    return pd.DataFrame(rows)

def validate_metric(obs,pred,years,calibration_values,weights=None):
    obs=np.asarray(obs,float);pred=np.asarray(pred,float);years=np.asarray(years,int)
    w=np.ones(len(obs)) if weights is None else np.asarray(weights,float)
    valid=np.isfinite(obs)&np.isfinite(pred)&(w>0)
    err=obs[valid]-pred[valid];wv=w[valid]
    if not valid.any():return {'MAE':np.nan,'RMSE':np.nan,'NRMSE':np.nan,'n':0,'direction_numerator':0,'direction_denominator':0}
    ref=np.asarray(calibration_values,float);ref=ref[np.isfinite(ref)]
    scale=float(np.quantile(ref,.95)-np.quantile(ref,.05)) if len(ref) else np.nan
    rmse=float(np.sqrt(np.average(err**2,weights=wv)))
    trans=valid[:-1]&valid[1:]&(np.diff(years)==1)
    hit=(np.sign(np.diff(obs))==np.sign(np.diff(pred)))&trans
    return dict(MAE=float(np.average(np.abs(err),weights=wv)),RMSE=rmse,NRMSE=rmse/scale if scale>0 else np.nan,n=int(valid.sum()),direction_numerator=int(hit.sum()),direction_denominator=int(trans.sum()),calibration_P95_minus_P5=scale,evaluation_protocol='B1_TRAIN_P95_P5_V1')

def parameter_diagnostics(frame,bounds):
    rows=[]
    for name,(lo,hi) in bounds.items():
        x=frame[name].to_numpy(float); near=np.minimum(x-lo,hi-x)/(hi-lo)<=.01
        rows.append(dict(parameter=name,n=len(x),exact_lower=float(np.mean(x==lo)),exact_upper=float(np.mean(x==hi)),near_bound=float(np.mean(near)),P5=float(np.quantile(x,.05)),P50=float(np.median(x)),P95=float(np.quantile(x,.95))))
    return pd.DataFrame(rows)

def cache_key(input_hashes,configuration,code_hash):
    import json
    return hashlib.sha256(json.dumps([input_hashes,configuration,code_hash],sort_keys=True).encode()).hexdigest()


def simple_baselines(train_years,train_values,test_years,lower=.001,upper=.999):
    years=np.asarray(train_years,float);x=np.asarray(train_values,float);future=np.asarray(test_years,float)
    if len(years)<2 or years[-1]<=years[0]:raise ValueError('Invalid baseline training support')
    slope=(x[-1]-x[0])/(years[-1]-years[0])
    return {'persistence':np.repeat(x[-1],len(future)),
            'training_endpoint_drift':np.clip(x[-1]+(future-years[-1])*slope,lower,upper)}
