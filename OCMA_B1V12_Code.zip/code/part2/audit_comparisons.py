"""Compare B1 source-based states to manuscript and isolated B0 references.

This audit never writes into or supplies model_input_B1.csv.
"""
from pathlib import Path
import json
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]


def write(frame, path):
    frame.to_csv(path,index=False,encoding='utf-8-sig',float_format='%.12g')


def main():
    trends = pd.read_csv(ROOT / '06_runs/B1_preflight/descriptive_trends_partial.csv').set_index('indicator')
    table = pd.read_csv(ROOT / '00_contract/source_extracts/manuscript_tables.csv')
    manuscript = {}
    for _, row in table.loc[table.table_id.eq(3) & table.row.isin([2,3,4])].iterrows():
        cells = json.loads(row.cells_json)
        name = 'G' if cells[0].startswith('Governance') else 'SR' if cells[0].startswith('Social') else 'ES'
        lohi = cells[4].split('[')
        slope = float(lohi[0])
        a,b = lohi[1].strip(']').split(',')
        manuscript[name] = {'2011':float(cells[1]),'2023':float(cells[2]),
                            'net_change':float(cells[3]),'theil_sen_slope':slope,
                            'leave_one_year_out_min':float(a),'leave_one_year_out_max':float(b)}
    assert set(manuscript) == {'G','SR','ES'}
    b0 = pd.read_csv(ROOT / '08_reference_B0/figure_compatibility_table3_audit.csv')
    b0_map = {(r.indicator,r.checkpoint):r.reconstructed_value for r in b0.itertuples()}
    rows=[]
    for indicator in ['G','SR','ES']:
        for key,value in manuscript[indicator].items():
            b1 = float(trends.loc[indicator,key]) if indicator in trends.index else np.nan
            b0val = b0_map.get((indicator,key),np.nan)
            rows.append({'indicator':indicator,'checkpoint':key,
                         'manuscript':value,'B0_digitized_or_target_guided':b0val,
                         'B1_source_based':b1,
                         'B1_minus_manuscript':b1-value if np.isfinite(b1) else np.nan,
                         'B1_minus_B0':b1-b0val if np.isfinite(b1) and np.isfinite(b0val) else np.nan,
                         'B0_is_main_B1_ancestor':False,
                         'use':'POST_BUILD_AUDIT_NOT_SPECIFICATION_SELECTION'})
    write(pd.DataFrame(rows), ROOT / '00_contract/baseline_vs_submission.csv')
    unresolved = [
        ('AUTHOR_REVIEW_OF_NEW_CODES','SUBMISSION_BLOCK','policy_coding_governance_interpretation',
         'All 68 policy texts were recoded as CODEX_SOURCE_RECONSTRUCTION; original human fields remain blank and author review is PENDING.',
         'Author reviews qualified and ambiguous clause index, version decisions and relation events before manuscript submission.'),
        ('POLICY_VERSION_AMENDMENTS','INTERPRETATION_LIMITATION','historical_G_stock',
         '2004 Shandong original text replaced a wrong-province captured page; later 2016/2018 amendments are archived but not time-varying clause recodings.',
         'Inspect amendment deltas and rerun B1 if governance shares materially change.'),
        ('OPEN_POLICY_ENDS','SENSITIVITY_LIMITATION','policy_stock_scenario_projection',
         'No explicit expiry facts were detected in the current extraction; the main reconstruction keeps open policies active through 2030.',
         'Author check expiry/repeal and carry a bounded duration sensitivity for revision.'),
        ('WATER_QUALITY_UNIT_METADATA','IMPORTANT','interpretation_and_full_raw_rebuild',
         'Prepared NS/OS/BS annual states carried provisional unit metadata status.',
         'Verify DIN/DIP/COD/DO/Chl-a/RNDia/red-tide source units, directions and annual station aggregation.'),
        ('HABITAT_2023_ESTIMATE','LIMITATION','2023_interpretation',
         '2023 TF/SM use CW-to-GWL bridge and two-county growth estimation, not direct same-product observation.',
         'Retain estimate flag, bridge diagnostics and 0.35 evaluation-only weight; no artificial initial blend.'),
        ('SST_SEASONAL_SUPPORT','IMPORTANT','forcing_interpretation',
         'SST copied from ecological core workbook; seasonal/annual sampling protocol not certified in this capture.',
         'Verify underlying SST extraction metadata before claiming a direct annual bay mean.'),
        ('ORIGINAL_ACCEPTED_PARAMETER_VECTORS','NONBLOCKING_FOR_NEW_B1','historical_comparison_only',
         'Submitted-run joint parameter vectors absent; B1 may recalibrate once its own input is complete.',
         'Do not reconstruct an ensemble from Table S4 marginal quantiles.'),
    ]
    write(pd.DataFrame([{'item_id':a,'criticality':b,'affected_stages':c,
                         'observed_gap':d,'minimal_resolution':e,'status':'OPEN'}
                        for a,b,c,d,e in unresolved]), ROOT / '00_contract/unresolved_items.csv')
    print(json.dumps({'comparison_rows':len(rows),'unresolved_items':len(unresolved),
                      'submission_blocks':sum(x[1]=='SUBMISSION_BLOCK' for x in unresolved)},ensure_ascii=False),flush=True)


if __name__ == '__main__':
    main()
