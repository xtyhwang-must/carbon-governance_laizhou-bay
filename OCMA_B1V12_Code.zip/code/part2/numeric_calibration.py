"""B1 source-reconstructed nine-parameter training and fixed-rule candidate screen."""
from __future__ import annotations

import hashlib
import json
import os
import sys
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

import numpy as np
import pandas as pd
import yaml
from scipy.optimize import differential_evolution, minimize
from scipy.stats import qmc

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT/'05_code/engine'), str(ROOT/'05_code')]
import engine_config as cfg
import sd_model as model
from revised_core import local_candidates, select_accepted

INPUT = ROOT/'03_indicators/model_input_B1.csv'
OUT = ROOT/'06_runs/B1_v1_1/calibration'
STATES = ['SP','SC','NS','OS','BS','TF','SM']
NAMES = cfg.PARAMETER_NAMES
BOUNDS = np.array([cfg.PARAMETER_BOUNDS[k] for k in NAMES],float)
CONTRACT = cfg.CONTRACT
CAL = None
FORCING = None
INITIAL = None
DENOM = None

def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def atomic_json(path,obj):
    temp=path.with_suffix(path.suffix+'.tmp')
    temp.write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8')
    os.replace(temp,path)

def context():
    global CAL,FORCING,INITIAL,DENOM
    frame=pd.read_csv(INPUT).sort_values('year').reset_index(drop=True)
    assert frame.year.tolist()==list(range(2011,2024)) and frame.input_complete.all()
    assert frame[STATES+cfg.STATE_NAMES+['ETA_POTENTIAL','SYNERGY_LEVER']].notna().all().all()
    CAL=frame.loc[frame.year.le(2020)].copy()
    FORCING=model.historical_forcing(frame)
    INITIAL=model.initial_state(frame,year=2011)
    DENOM=np.array([np.quantile(CAL[s],.95)-np.quantile(CAL[s],.05) for s in STATES])
    assert (DENOM>0).all()
    return frame

def evaluate(params,details=False):
    if CAL is None: context()
    try:
        pred=model.simulate(params,FORCING,CAL.year.to_numpy(float),INITIAL)
        o=CAL[STATES].to_numpy(float);p=pred[STATES].to_numpy(float)
        if not np.isfinite(p).all():raise FloatingPointError('nonfinite simulation')
        mse=np.mean((o-p)**2)
        hit=np.mean(np.sign(np.diff(o,axis=0))==np.sign(np.diff(p,axis=0)),axis=0)
        endpoint=(p[-1]-p[0]-o[-1]+o[0])**2
        # Historical compatible rule averages the endpoint and direction
        # terms as fourteen contributions (two per state).
        behavior=.5*np.mean(endpoint+.04*(1-hit))
        scaled=(np.asarray(params)-(BOUNDS[:,0]+BOUNDS[:,1])/2)/(BOUNDS[:,1]-BOUNDS[:,0])
        loss=float(mse+.18*behavior+.006*np.mean(scaled**2))
        if details:
            nrmse=np.sqrt(np.mean((o-p)**2,axis=0))/DENOM
            return {'loss':loss,'mean_nrmse':float(np.mean(nrmse)),
                    'trend_hit':float(np.mean(hit)),
                    'state_nrmse':dict(zip(STATES,map(float,nrmse))),
                    'state_trend_hit':dict(zip(STATES,map(float,hit)))}
        return loss
    except Exception:
        if details:return {'loss':1e6,'mean_nrmse':1e6,'trend_hit':0.0}
        return 1e6

def deps():
    return {name:sha(path) for name,path in {'input':INPUT,'model':ROOT/'05_code/engine/sd_model.py',
        'engine_common':ROOT/'05_code/engine/engine_common.py',
        'contract':ROOT/'00_contract/baseline_contract.yaml','this_code':Path(__file__),
        'core':ROOT/'05_code/revised_core.py'}.items()}

def fit_seed(seed):
    context();OUT.mkdir(parents=True,exist_ok=True)
    dependency=deps();path=OUT/f'fit_seed_{seed}.json'
    if path.exists():
        old=json.loads(path.read_text(encoding='utf-8'))
        if old.get('dependencies')==dependency and len(old.get('parameters',{}))==9:return old
    t=time.time();c=CONTRACT['calibration']
    de=differential_evolution(evaluate,bounds=BOUNDS.tolist(),seed=seed,
        maxiter=c['differential_evolution_maxiter'],popsize=c['differential_evolution_popsize'],
        tol=c['differential_evolution_tol'],polish=False,workers=1,updating='immediate')
    local=minimize(evaluate,de.x,method='Powell',bounds=BOUNDS.tolist(),
        options={'maxiter':c['powell_maxiter'],'xtol':c['powell_xtol'],'ftol':c['powell_ftol']})
    vec=np.asarray(local.x if evaluate(local.x)<evaluate(de.x) else de.x,float)
    result={'seed':seed,'parameters':dict(zip(NAMES,map(float,vec))),
        'diagnostics':evaluate(vec,True),'de_nfev':int(de.nfev),'powell_nfev':int(local.nfev),
        'de_success':bool(de.success),'powell_success':bool(local.success),
        'elapsed_seconds':time.time()-t,'dependencies':dependency,
        'identity':'B1_v1.1.0_CODEX_SOURCE_RECONSTRUCTION_AUTHOR_PENDING'}
    atomic_json(path,result)
    return result

def candidate_block(args):
    label,start,values,dependency=args
    context();OUT.mkdir(parents=True,exist_ok=True)
    path=OUT/f'candidate_{label}.csv';meta=OUT/f'candidate_{label}.meta.json'
    if path.exists() and meta.exists():
        old=json.loads(meta.read_text(encoding='utf-8'))
        if old.get('dependencies')==dependency and old.get('count')==len(values) and old.get('candidate_hash')==hashlib.sha256(values.tobytes()).hexdigest() and old.get('file_sha256')==sha(path) and old.get('complete') is True:
            prior=pd.read_csv(path)
            if len(prior)==len(values) and np.allclose(prior[NAMES].to_numpy(float),values,rtol=0,atol=1e-12):return str(path)
    rows=[]
    for i,v in enumerate(values):
        d=evaluate(v,True)
        rows.append({'candidate_id':start+i,'source_block':label,**dict(zip(NAMES,map(float,v))),
                     'loss':d['loss'],'mean_nrmse':d['mean_nrmse'],'trend_hit':d['trend_hit']})
    temp=path.with_suffix('.csv.tmp')
    pd.DataFrame(rows).to_csv(temp,index=False,encoding='utf-8-sig')
    check=pd.read_csv(temp)
    if len(check)!=len(values) or not np.isfinite(check[NAMES].to_numpy(float)).all():raise AssertionError('candidate block invalid')
    os.replace(temp,path)
    atomic_json(meta,{'dependencies':dependency,'count':len(values),'candidate_hash':hashlib.sha256(values.tobytes()).hexdigest(),
                      'file_sha256':sha(path),'complete':True})
    return str(path)

def main():
    frame=context();OUT.mkdir(parents=True,exist_ok=True)
    seeds=CONTRACT['seeds']['optimization'];fits=[]
    with ProcessPoolExecutor(max_workers=min(5,len(seeds))) as pool:
        futures={pool.submit(fit_seed,int(s)):s for s in seeds}
        for future in as_completed(futures):
            fit=future.result();fits.append(fit)
            print(f"fit seed={fit['seed']} loss={fit['diagnostics']['loss']:.7f} calls={fit['de_nfev']}+{fit['powell_nfev']}",flush=True)
    fits.sort(key=lambda x:x['diagnostics']['loss'])
    pd.DataFrame([{'seed':f['seed'],**f['diagnostics']|{'state_nrmse':json.dumps(f['diagnostics'].get('state_nrmse',{}))},
                   **f['parameters']} for f in fits]).to_csv(OUT/'five_seed_fit_summary.csv',index=False,encoding='utf-8-sig')
    best=fits[0];atomic_json(OUT/'best_parameter_set.json',best)
    center=np.array([best['parameters'][n] for n in NAMES])
    c=CONTRACT['calibration'];rng=qmc.LatinHypercube(d=9,seed=CONTRACT['seeds']['global_lhs'])
    blocks=[('global',qmc.scale(rng.random(c['global_lhs_count']),BOUNDS[:,0],BOUNDS[:,1]))]
    for j,(count,scale) in enumerate(zip(c['local_candidate_counts'],c['local_candidate_scales'])):
        blocks.append((f'local_{j+1}',local_candidates(center,BOUNDS,count,scale,CONTRACT['seeds']['global_lhs']+j+1)))
    tasks=[];start=0;dependency=deps()
    for name,arr in blocks:
        # Independent small blocks allow exact content checks and interrupted-run recovery.
        for k,part in enumerate(np.array_split(arr,max(1,int(np.ceil(len(arr)/300))))):
            label=f'{name}_{k:03d}';tasks.append((label,start,part,dependency));start+=len(part)
    paths=[]
    with ProcessPoolExecutor(max_workers=8) as pool:
        futures=[pool.submit(candidate_block,task) for task in tasks]
        for i,future in enumerate(as_completed(futures),1):
            paths.append(Path(future.result()))
            if i%8==0 or i==len(futures):print(f'candidate blocks={i}/{len(futures)}',flush=True)
    candidates=pd.concat([pd.read_csv(path) for path in sorted(paths)],ignore_index=True).sort_values('candidate_id')
    if len(candidates)!=start or candidates.candidate_id.tolist()!=list(range(start)):raise AssertionError('incomplete candidate set')
    atomic_json(OUT/'candidate_COMPLETE.json',{'dependencies':dependency,
        'chunks':[{ 'file':p.name,'sha256':sha(p),'rows':len(pd.read_csv(p))} for p in sorted(paths)],
        'count':len(candidates),'status':'COMPLETE'})
    candidates,accepted=select_accepted(candidates,NAMES,best['diagnostics']['loss'],
        seed=CONTRACT['seeds']['propagation_subsample'],cap=c['propagation_max'])
    candidates.to_csv(OUT/'candidate_screen_all.csv',index=False,encoding='utf-8-sig')
    accepted=accepted.copy();accepted.insert(0,'parameter_set_id',['B1P'+str(i).zfill(4) for i in range(1,len(accepted)+1)])
    accepted.to_csv(OUT/'accepted_parameter_ensemble.csv',index=False,encoding='utf-8-sig')
    model.simulate(best['parameters'],model.historical_forcing(frame),frame.year.to_numpy(float),model.initial_state(frame,year=2011)).to_csv(
        OUT/'best_prediction_2011_2023.csv',index=False,encoding='utf-8-sig')
    atomic_json(OUT/'calibration_status.json',{'complete':True,'five_seed_count':len(fits),'candidate_count':len(candidates),
        'accepted_before_cap':int(candidates.accepted.sum()),'propagated_count':len(accepted),
        'best_loss':best['diagnostics']['loss'],'best_mean_nrmse':best['diagnostics']['mean_nrmse'],
        'best_trend_hit':best['diagnostics']['trend_hit'],'dependencies':dependency,
        'author_review_status':'PENDING'})
    print(json.dumps({'candidate_count':len(candidates),'accepted':len(accepted),'best_loss':best['diagnostics']['loss']},ensure_ascii=False),flush=True)

if __name__=='__main__':main()
