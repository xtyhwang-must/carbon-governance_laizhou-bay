"""Five-seed formal fit, content-addressed candidate screen and explicit design sample."""
from __future__ import annotations
import argparse,hashlib,json,math,sys
from concurrent.futures import ProcessPoolExecutor,as_completed
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.stats import qmc
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'05_code/engine'),str(ROOT/'05_code')]
import engine_config as cfg
import sd_model as model
from cache_safety import ChunkCache,signature,atomic_json
from revised_core import local_candidates
from v12_modeling import fit_one,TrainingContext,reference_for,bounds,sha,STATES

OUT=ROOT/'06_runs/formal_main/calibration'
FRAME=ROOT/'03_indicators/model_input_B1.csv'

def chosen_structure():
    x=json.loads((ROOT/'06_runs/structure_compare/model_selection.json').read_text(encoding='utf-8'))
    return x['selected_structure'],x['status']

def full_budget():
    c=cfg.CONTRACT['calibration']
    return {'maxiter':c['differential_evolution_maxiter'],'popsize_per_dimension':c['differential_evolution_popsize'],
      'tol':c['differential_evolution_tol'],'Powell_maxiter':c['powell_maxiter'],
      'xtol':c['powell_xtol'],'ftol':c['powell_ftol']}

def formal_fit(structure):
    folder=ROOT/'06_runs/formal_main/fit_seeds';folder.mkdir(parents=True,exist_ok=True)
    budget=full_budget();seeds=cfg.CONTRACT['seeds']['optimization']
    tasks=[(structure,2020,int(s),budget,str(folder)) for s in seeds]
    records=[]
    with ProcessPoolExecutor(max_workers=5) as pool:
        for i,f in enumerate(as_completed([pool.submit(fit_one,t) for t in tasks]),1):
            r=f.result();records.append(r)
            print(f"formal fit={i}/5 seed={r['seed']} loss={r['diagnostics']['loss']:.6f}",flush=True)
    records.sort(key=lambda r:(r['diagnostics']['loss'],r['seed']))
    atomic_json(OUT/'best_parameter_set.json',records[0])
    pd.DataFrame([{'seed':r['seed'],'loss':r['diagnostics']['loss'],
      'mean_nrmse':r['diagnostics']['mean_nrmse'],'trend_hit':r['diagnostics']['trend_hit'],
      'DE_nfev':r['DE_nfev'],'Powell_nfev':r['Powell_nfev'],
      'DE_success':r['DE_success'],'Powell_success':r['Powell_success'],
      'objective_failures':r['objective_failures'],**r['parameters']} for r in records]).to_csv(
      OUT/'five_seed_fit_summary.csv',index=False,encoding='utf-8-sig')
    return records

def centers_from_fits(records,structure):
    names,box=bounds(structure);centers=[]
    for r in records:
        vector=np.array([r['parameters'][n] for n in names],float)
        normalized=(vector-box[:,0])/(box[:,1]-box[:,0])
        if all(np.linalg.norm(normalized-x['normalized'])>0.10 for x in centers):
            centers.append({'vector':vector,'normalized':normalized,'seed':r['seed'],'loss':r['diagnostics']['loss']})
        if len(centers)==3:break
    return centers

def generate_candidates(records,structure):
    names,box=bounds(structure);c=cfg.CONTRACT['calibration']
    rng=qmc.LatinHypercube(d=len(names),seed=cfg.CONTRACT['seeds']['global_lhs'])
    blocks=[('GLOBAL','ALL',qmc.scale(rng.random(c['global_lhs_count']),box[:,0],box[:,1]))]
    centers=centers_from_fits(records,structure)
    for round_id,(count,scale) in enumerate(zip(c['local_candidate_counts'],c['local_candidate_scales']),1):
        allocation=[count//len(centers)+int(j<count%len(centers)) for j in range(len(centers))]
        for j,(center,n) in enumerate(zip(centers,allocation)):
            values=local_candidates(center['vector'],box,n,scale,
                cfg.CONTRACT['seeds']['global_lhs']+100*round_id+j)
            blocks.append((f'LOCAL_{round_id}',f"seed_{center['seed']}",values))
    rows=[];vectors=[]
    for source,center_id,values in blocks:
        for v in values:
            cid=len(rows)
            rows.append({'candidate_id':cid,'source_type':source,'center_id':center_id})
            vectors.append(v)
    design=pd.DataFrame(rows);array=np.vstack(vectors)
    if len(array)!=c['global_lhs_count']+sum(c['local_candidate_counts']):raise AssertionError('Candidate budget mismatch')
    # LHS/truncated-normal vectors are continuous; exact duplicate vectors would distort counts.
    hashes=[hashlib.sha256(v.tobytes()).hexdigest() for v in array]
    if len(set(hashes))!=len(hashes):raise AssertionError('Duplicate candidate vector')
    design['parameter_vector_sha256']=hashes
    pd.DataFrame([{'center_id':f"seed_{x['seed']}",'training_loss':x['loss'],
      **dict(zip(names,x['vector']))} for x in centers]).to_csv(
        OUT/'local_center_design.csv',index=False,encoding='utf-8-sig')
    return design,array

def candidate_chunk(args):
    ids,meta,vectors,structure,cache_root,key,material=args
    frame=pd.read_csv(FRAME);context=TrainingContext(frame,structure,2020)
    cache=ChunkCache(Path(cache_root),key,material)
    block_id=f'{ids[0]:05d}_{ids[-1]:05d}'
    expected=[str(i) for i in ids]
    columns=['cache_row_id','candidate_id','parameter_vector_sha256','loss','mean_nrmse','trend_hit']
    prior=cache.load(block_id,expected,columns)
    if prior is not None:return block_id
    rows=[]
    for cid,m,v in zip(ids,meta,vectors):
        detail=context.evaluate(v,True)
        rows.append({'cache_row_id':str(cid),'candidate_id':cid,**m,
           **dict(zip(context.names,map(float,v))),
           'loss':detail['loss'],'mean_nrmse':detail['mean_nrmse'],
           'trend_hit':detail['trend_hit'],
           **{f'{s}_train_NRMSE':detail.get('state_nrmse',{}).get(s,np.nan) for s in STATES},
           **{f'{s}_train_bias':detail.get('state_bias',{}).get(s,np.nan) for s in STATES}})
    cache.commit(block_id,pd.DataFrame(rows),expected,columns)
    return block_id

def screen(records,structure):
    frame=pd.read_csv(FRAME);ctx=TrainingContext(frame,structure,2020)
    design,vectors=generate_candidates(records,structure)
    initial=ctx.initial
    refs=[]
    for vector in vectors:
        params=ctx.vector_dict(vector)
        ref=reference_for(frame,ctx.forcing,initial,params,structure)
        refs.append(hashlib.sha256(json.dumps(ref,sort_keys=True).encode()).hexdigest() if ref is not None else 'RUN_SPECIFIC_2011')
    design['reference_context_sha256']=refs
    code_files=['05_code/v12_formal_calibration.py','05_code/v12_modeling.py','05_code/engine/sd_model.py',
      '05_code/engine/engine_config.py','05_code/engine/engine_common.py','05_code/revised_core.py',
      '05_code/cache_safety.py','00_contract/baseline_contract.yaml',
      '00_contract/structure_selection_protocol.yaml','04_model/equation_registry.csv',
      '04_model/parameter_registry.csv','03_indicators/model_input_B1.csv']
    material_extra={'structure':structure,'initial_year':2011,'initial_vector':initial.tolist(),
      'reference_context_hashes':refs,'candidate_vector_hashes':design.parameter_vector_sha256.tolist(),
      'solver':'RK4_FIXED','step':.05,'protocol':'B1_V120_ORIGINAL_LOSS_AND_LEGACY_GATES'}
    key,material=signature([ROOT/p for p in code_files],material_extra,
        code_version=cfg.CONTRACT['version'],root=ROOT)
    cache_root=OUT/'candidate_cache';cache=ChunkCache(cache_root,key,material)
    tasks=[];specs=[]
    for start in range(0,len(vectors),300):
        stop=min(len(vectors),start+300);ids=list(range(start,stop))
        block=f'{ids[0]:05d}_{ids[-1]:05d}';expected=[str(i) for i in ids]
        cols=['cache_row_id','candidate_id','parameter_vector_sha256','loss','mean_nrmse','trend_hit']
        specs.append((block,expected,cols))
        tasks.append((ids,design.iloc[start:stop].drop(columns='candidate_id').to_dict('records'),
          vectors[start:stop],structure,str(cache_root),key,material))
    with ProcessPoolExecutor(max_workers=8) as pool:
        futures=[pool.submit(candidate_chunk,t) for t in tasks]
        for i,f in enumerate(as_completed(futures),1):
            f.result()
            if i%8==0 or i==len(futures):print(f'formal candidate blocks={i}/{len(futures)}',flush=True)
    cache.finalize(specs)
    all_candidates=pd.concat([cache.load(*s) for s in specs],ignore_index=True).sort_values('candidate_id')
    if len(all_candidates)!=len(vectors):raise AssertionError('Incomplete candidate population')
    best_loss=records[0]['diagnostics']['loss']
    all_candidates['loss_gate']=all_candidates.loss.le(1.35*best_loss+.025)
    all_candidates['NRMSE_gate']=all_candidates.mean_nrmse.le(.52)
    all_candidates['direction_gate']=all_candidates.trend_hit.ge(.43)
    all_candidates['legacy_acceptance']=all_candidates[['loss_gate','NRMSE_gate','direction_gate']].all(axis=1)
    all_candidates.to_csv(OUT/'candidate_screen_all.csv',index=False,encoding='utf-8-sig')
    accepted=all_candidates[all_candidates.legacy_acceptance].copy()
    accepted.to_csv(OUT/'all_legacy_accepted.csv',index=False,encoding='utf-8-sig')
    source=all_candidates.groupby(['source_type','center_id']).agg(candidates=('candidate_id','size'),
      accepted=('legacy_acceptance','sum'),loss_fail=('loss_gate',lambda x:int((~x).sum())),
      NRMSE_fail=('NRMSE_gate',lambda x:int((~x).sum())),
      direction_fail=('direction_gate',lambda x:int((~x).sum()))).reset_index()
    source.to_csv(OUT/'candidate_source_screen.csv',index=False,encoding='utf-8-sig')
    cap=cfg.CONTRACT['calibration']['propagation_max']
    if len(accepted)>cap:
        accepted['loss_tercile']=pd.qcut(accepted.loss,3,labels=['LOW','MID','HIGH'],duplicates='drop').astype(str)
        accepted['stratum']=accepted.source_type+'|'+accepted.loss_tercile
        groups=list(accepted.groupby('stratum',sort=True))
        weights=np.array([len(g) for _,g in groups],float);exact=cap*weights/weights.sum()
        allocation=np.floor(exact).astype(int)
        for j in np.argsort(-(exact-allocation))[:cap-allocation.sum()]:allocation[j]+=1
        rng=np.random.default_rng(cfg.CONTRACT['seeds']['propagation_subsample'])
        picked=[]
        for (label,g),n in zip(groups,allocation):
            if n:
                q=g.iloc[np.sort(rng.choice(len(g),size=n,replace=False))].copy()
                q['design_inclusion_probability']=n/len(g)
                picked.append(q)
        propagated=pd.concat(picked,ignore_index=True)
        selection_method='proportional_source_x_loss_tercile_strata_without_replacement'
    else:
        propagated=accepted.copy();propagated['design_inclusion_probability']=1.
        selection_method='all_accepted_no_cap'
    propagated=propagated.sort_values('candidate_id').reset_index(drop=True)
    propagated.insert(0,'parameter_set_id',[f'B12P{i:04d}' for i in range(1,len(propagated)+1)])
    propagated.to_csv(OUT/'accepted_parameter_ensemble.csv',index=False,encoding='utf-8-sig')
    return {'candidate_count':len(all_candidates),'accepted_before_cap':len(accepted),
      'propagated_count':len(propagated),'source_summary':source.to_dict('records'),
      'candidate_cache_signature':key,'selection_method':selection_method,'local_centers':int(len(pd.read_csv(OUT/'local_center_design.csv')))}

def main():
    OUT.mkdir(parents=True,exist_ok=True)
    structure,selection_status=chosen_structure()
    records=formal_fit(structure)
    result=screen(records,structure)
    ctx=TrainingContext(pd.read_csv(FRAME),structure,2020)
    accepted=pd.read_csv(OUT/'accepted_parameter_ensemble.csv')
    reference_rows=[]
    for r in accepted.itertuples(index=False):
        params={n:float(getattr(r,n)) for n in ctx.names}
        ref=reference_for(ctx.frame,ctx.forcing,ctx.initial,params,structure)
        reference_rows.append({'parameter_set_id':r.parameter_set_id,
            'reference_year':2011,'reference_context_sha256':
                hashlib.sha256(json.dumps(ref,sort_keys=True).encode()).hexdigest() if ref is not None else 'RUN_SPECIFIC',
            'reference_context_json':json.dumps(ref,sort_keys=True) if ref is not None else '',
            'actual_parameter_vector_json':json.dumps(params,sort_keys=True),
            'parameter_vector_sha256':r.parameter_vector_sha256})
    pd.DataFrame(reference_rows,columns=['parameter_set_id','reference_year','reference_context_sha256',
        'reference_context_json','actual_parameter_vector_json','parameter_vector_sha256']).to_csv(
        OUT/'accepted_reference_contexts.csv',index=False,encoding='utf-8-sig')
    vector=np.array([records[0]['parameters'][n] for n in ctx.names],float)
    ctx.predict(vector,2023).to_csv(OUT/'best_prediction_2011_2023.csv',index=False,encoding='utf-8-sig')
    status={'complete':True,'structure':structure,'structure_selection_status':selection_status,
      'five_seed_count':len(records),'best_training_loss':records[0]['diagnostics']['loss'],
      'best_training_mean_NRMSE':records[0]['diagnostics']['mean_nrmse'],
      'best_training_direction':records[0]['diagnostics']['trend_hit'],
      'author_confirmation':'CONFIRMED_BY_AUTHOR','legacy_gate_is_behavioral_adequacy':False,
      'input_sha256':sha(FRAME),'model_code_sha256':sha(ROOT/'05_code/engine/sd_model.py'),
      **result}
    atomic_json(OUT/'formal_calibration_status.json',status)
    atomic_json(OUT/'run_identity.json',{'version':cfg.CONTRACT['version'],
        'structure':structure,'input_sha256':sha(FRAME),
        'selected_structure_report_sha256':sha(ROOT/'06_runs/structure_compare/model_selection.json'),
        'model_code_sha256':sha(ROOT/'05_code/engine/sd_model.py'),
        'calibration_code_sha256':sha(Path(__file__)),
        'contract_sha256':sha(ROOT/'00_contract/baseline_contract.yaml'),
        'initial_year':2011,'initial_vector':ctx.initial.tolist(),
        'historical_forcing_sha256':hashlib.sha256(ctx.forcing.frame.to_csv(index=False).encode()).hexdigest(),
        'actual_best_parameter_vector':records[0]['parameters'],
        'evaluation_protocol':'fixed_2011_2020_P95_minus_P5_and_2021_2023_development_audit'})
    print(json.dumps({k:v for k,v in status.items() if k!='source_summary'},ensure_ascii=False),flush=True)

if __name__=='__main__':main()
