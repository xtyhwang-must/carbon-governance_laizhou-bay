"""Input-only sensitivity for registered ambiguous CODEX clause decisions."""
from pathlib import Path
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parents[1]
POL=ROOT/'02_policy/reconstructed'
OUT=ROOT/'06_runs/B1_v1_1/policy_input_sensitivity'
CHANNELS=['G1','G2','G3']
K={'G1':6.608,'G2':6.605,'G3':7.936}

def shares(coded):
    assignments=coded.groupby('policy_id')[['b1_'+x for x in CHANNELS]].sum()
    denom=assignments.sum(axis=1)
    return assignments.div(denom.replace(0,np.nan),axis=0).fillna(0).rename(columns=lambda x:x.replace('b1_',''))

def main():
    coded=pd.read_csv(POL/'coded_clauses_B1.csv')
    exposure=pd.read_csv(POL/'policy_exposure_2000_2030_B1.csv')
    exposure=exposure[exposure.year.between(2011,2023)&exposure.active.eq(True)&exposure.independent_stock_policy.eq(True)]
    cases={}
    cases['MAIN_CODEX_RECONSTRUCTION']=coded.copy()
    conservative=coded.copy()
    remove=conservative.ambiguity_status.eq('CONTEXTUAL_TARGET_REQUIRES_AUTHOR_REVIEW')
    conservative.loc[remove,['b1_'+x for x in CHANNELS]]=0
    cases['DROP_CONTEXTUAL_TARGET_ONLY']=conservative
    single=coded.copy()
    multiple=single.ambiguity_status.eq('MULTI_FUNCTION_REQUIRES_AUTHOR_REVIEW')
    for idx in single.index[multiple]:
        active=[x for x in CHANNELS if single.at[idx,'b1_'+x]==1]
        if len(active)>1:
            for x in active[1:]:single.at[idx,'b1_'+x]=0
    cases['MULTIFUNCTION_FIRST_G_ONLY']=single
    rows=[];policy_rows=[]
    for name,code in cases.items():
        sh=shares(code)
        for pid,r in sh.iterrows():policy_rows.append({'case':name,'policy_id':pid,**r.to_dict()})
        active=exposure[['policy_id','year']].merge(sh.reset_index(),on='policy_id',validate='many_to_one')
        for year,g in active.groupby('year'):
            for ch in CHANNELS:
                stock=float(g[ch].sum())
                rows.append({'case':name,'year':int(year),'channel':ch,'active_stock':stock,
                    'G_model_input':stock/(stock+K[ch]),'author_review_status':'PENDING',
                    'scope':'INPUT_ONLY_NO_RECALIBRATION_OR_OUTCOME_SENSITIVITY'})
    OUT.mkdir(parents=True,exist_ok=True)
    pd.DataFrame(policy_rows).to_csv(OUT/'policy_function_share_alternatives.csv',index=False,encoding='utf-8-sig')
    annual=pd.DataFrame(rows)
    main=annual[annual.case.eq('MAIN_CODEX_RECONSTRUCTION')][['year','channel','G_model_input']].rename(columns={'G_model_input':'main_G'})
    annual=annual.merge(main,on=['year','channel'],validate='many_to_one')
    annual['delta_G']=annual.G_model_input-annual.main_G
    annual.to_csv(OUT/'annual_G_input_alternatives.csv',index=False,encoding='utf-8-sig')
    annual.groupby(['case','channel']).delta_G.agg(['min','max','mean']).to_csv(OUT/'input_sensitivity_summary.csv',encoding='utf-8-sig')
    print({'cases':len(cases),'annual_rows':len(annual),'contextual_units_dropped':int(remove.sum()),
           'multifunction_units_single_labeled':int(multiple.sum())})

if __name__=='__main__':main()
