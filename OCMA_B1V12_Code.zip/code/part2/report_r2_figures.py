"""Pure Matplotlib views of frozen CSV results; no model imports or simulation."""
import json,math,shutil
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch,FancyBboxPatch,Circle,Arc,PathPatch,Rectangle
from matplotlib.path import Path as MPath
from matplotlib.colors import TwoSlopeNorm,ListedColormap,BoundaryNorm
from scipy.stats import spearmanr,gaussian_kde
import report_r2 as core

O=core.OUT;F=O/'figures';P=O/'plot_data';MAPROWS=[];Q=[];BOUNDS=[]
S=json.loads(core.STYLE.read_text('utf8'));C=S['scenario_colors'];SUB=S['subsystem_colors']

def check(name,ok,detail):
    Q.append(dict(check=name,passed=bool(ok),detail=str(detail)))
    if not ok:raise AssertionError(name+': '+str(detail))
def mapdata(fig,panel,keys,filter_rule,metric,order,population,years,units,interval='NONE'):
    for key in keys:
        p=core.source(key);MAPROWS.append(dict(artifact_id=fig,panel_id=panel,source_file=p.relative_to(O).as_posix() if p.is_relative_to(O) else str(p),source_hash=core.sha(p),run_id=core.RUN,filter_rule=filter_rule,metric_definition=metric,aggregation_order=order,parameter_population=population,year_range=years,display_unit=units,interval_identity=interval,output_file='figures/'+fig+'.pdf'))
def frame(height):return plt.figure(figsize=(S['width_mm']/25.4,height/25.4),facecolor='white')
def panel(ax,letter,title):
    ax.set_title(title,loc='left',fontsize=9,pad=8)
    text=ax.text2D if hasattr(ax,'text2D') else ax.text
    text(-.08,1.035,letter,transform=ax.transAxes,fontsize=11,fontweight='bold',ha='left',va='bottom')
def save(fig,name):
    fig.canvas.draw();renderer=fig.canvas.get_renderer();bad=[]
    unused_ticks=set()
    for a in fig.axes:
        axes=[(a.xaxis,a.get_xlim()),(a.yaxis,a.get_ylim())]
        if hasattr(a,'zaxis'):axes.append((a.zaxis,a.get_zlim()))
        for axis,lim in axes:
            lo,hi=sorted(lim)
            for tick in axis.get_major_ticks()+axis.get_minor_ticks():
                if tick.get_loc()<lo-1e-10 or tick.get_loc()>hi+1e-10:unused_ticks.update([tick.label1,tick.label2])
    for txt in fig.findobj(matplotlib.text.Text):
        if not txt.get_visible() or not txt.get_text():continue
        if txt in unused_ticks:continue
        b=txt.get_window_extent(renderer)
        if b.width>1 and b.height>1 and (b.x0 < -1 or b.y0 < -1 or b.x1>fig.bbox.width+1 or b.y1>fig.bbox.height+1):bad.append(txt.get_text())
    BOUNDS.append(dict(figure=name,text_outside_page=bad,page_width_mm=fig.get_figwidth()*25.4,page_height_mm=fig.get_figheight()*25.4))
    for ext in ['pdf','svg','png']:fig.savefig(F/(name+'.'+ext),dpi=S['dpi'],facecolor='white')
    plt.close(fig)
def short(x):return x.replace('_to_','→')

def figure3():
    fig=frame(115);ax=fig.add_axes([.035,.06,.93,.91]);ax.axis('off');ax.set(xlim=(0,1),ylim=(0,1))
    regions=[(.25,.61,.50,.37,SUB['G'],'Governance'),(.01,.13,.32,.42,SUB['S'],'Social'),(.65,.09,.34,.46,SUB['E'],'Ecological')]
    for x,y,w,h,col,label in regions:
        ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=.009',fc=col+'0D',ec=col,lw=.8));ax.text(x+.015,y+h-.04,label,color=col,fontsize=9,fontweight='bold')
    pos={'G1':(.34,.85),'G2':(.50,.85),'G3':(.66,.85),'IM':(.50,.73),'A1':(.34,.64),'A2':(.50,.64),'A3':(.66,.64),
      'SP':(.085,.40),'SC':(.25,.40),'PRS':(.085,.23),'SR':(.25,.23),
      'NS':(.71,.40),'OS':(.81,.40),'BS':(.91,.40),'WQ':(.81,.49),
      'TF':(.715,.22),'SM':(.90,.22),'H':(.78,.135),'ES':(.92,.135),
      'PR':(.44,.22),'PRE':(.49,.39)}
    states=set(['G1','G2','G3','IM','SP','SC','PRS','PR','NS','OS','BS','TF','SM'])
    nodes=[]
    for k,(x,y) in pos.items():
        role='STATE' if k in states else 'DERIVED'
        subsystem='G' if k in ['G1','G2','G3','IM','A1','A2','A3'] else 'S' if k in ['SP','SC','PRS','SR'] else 'E' if k in ['NS','OS','BS','TF','SM','WQ','H','ES'] else 'RISK'
        nodes.append(dict(node=k,x=x,y=y,role=role,subsystem=subsystem,equation='rhs' if role=='STATE' else '_actions' if k.startswith('A') else 'reporting_states or PR/PRS decomposition',label='SC (=AC)' if k=='SC' else k))
    edges=[]
    def edge(a,b,sign,label='',rad=0,eq='rhs',style='-'):
        x,y=pos[a];u,v=pos[b]
        internal=(a in ['G1','G2','G3','IM'] and b in ['A1','A2','A3']) or (a in ['SP','SC'] and b in ['PRS','SR']) or (a in ['NS','OS','BS','TF','SM','WQ','H'] and b in ['BS','WQ','SM','H','ES']) or (a in ['PR','PRS'] and b=='PRE') or (a=='SP' and b=='PR')
        if internal:
            arr=FancyArrowPatch((x,y),(u,v),arrowstyle='-|>',mutation_scale=7,lw=.65,color='#72818A',connectionstyle=f'arc3,rad={rad}',shrinkA=12,shrinkB=12,linestyle=style,zorder=1);ax.add_patch(arr)
            if label:ax.text((x+u)/2,(y+v)/2,label,fontsize=7.5,ha='center',color='#36454E',bbox=dict(fc='white',ec='none',pad=.25),zorder=2)
        edges.append(dict(source=a,target=b,local_sign=sign,display_label=label,equation=eq,interpretation='MODEL_DEFINED_LOCAL_RELATION_NOT_EMPIRICAL_CAUSAL_EFFECT',drawn=internal))
    for a,b in [('G1','A1'),('G2','A2'),('G3','A3'),('IM','A1'),('IM','A2'),('IM','A3')]:edge(a,b,'+','+' if a.startswith('G') else '',eq='_actions')
    edge('SC','IM','+','+ gate',.04,'_implementation_potentials');edge('SP','IM','-','− burden',-.15,'_implementation_potentials')
    edge('A1','SP','-','−',.14);edge('A3','SC','+','+',-.12)
    edge('A1','NS','-','− stress',.08);edge('A2','TF','+','+ target',.09);edge('A2','SM','+','+ target',-.03)
    edge('SP','PRS','+','+',0);edge('SP','SR','-','−',0);edge('SC','SR','+','+',0);edge('SP','NS','+','+ pressure',-.17)
    edge('SC','SM','+','+ support',-.22);edge('H','SC','+','+',.28)
    edge('NS','BS','+','+',0);edge('OS','WQ','-','−',0);edge('NS','WQ','-','',0);edge('BS','WQ','-','',0)
    edge('TF','SM','TRANSFER','TF→SM',.04,'rhs: conversion_tf_units / conversion_sm_units')
    edge('TF','H','+','',0);edge('SM','H','+','',0);edge('WQ','ES','+','',-.2);edge('H','ES','+','',0)
    edge('WQ','PR','-','− risk',-.12);edge('H','PR','-','',-.08)
    edge('SP','PR','+','',.15);edge('PR','PRE','+','+',0);edge('PRS','PRE','-','−',0)
    edge('PRE','G2','+','+ feedback',-.13);edge('PRS','G1','+','+ feedback',.30)
    def route(start,end,label,where,rad=0,source='',target='',eq='rhs'):
        ax.add_patch(FancyArrowPatch(start,end,arrowstyle='-|>',mutation_scale=8,lw=.85,color='#526D7E',connectionstyle=f'arc3,rad={rad}',zorder=2))
        ax.text(*where,label,ha='center',va='center',fontsize=7.5,color='#354C5B',bbox=dict(fc='white',ec='none',pad=1),zorder=3)
        edges.append(dict(source=source,target=target,local_sign='AS_LABELLED',display_label=label,equation=eq,interpretation='COMPOSITE_DISPLAY_ROUTE;DETAILED_EQUATION_EDGES_RETAINED_ABOVE',drawn=True))
    route((.31,.68),(.20,.54),'A1 − SP\nA3 + SC',(.20,.60),.10,'A1/A3','SP/SC')
    route((.10,.54),(.25,.80),'− SP burden\n+ SC gate',(.11,.72),-.15,'SP/SC','IM','_implementation_potentials')
    route((.75,.79),(.90,.55),'A1 − stress\nA2 + habitats',(.88,.69),-.16,'A1/A2','NS/OS/BS/TF/SM')
    route((.335,.47),(.65,.47),'SP + stress\nSC + habitats',(.49,.51),0,'SP/SC','ecological targets')
    route((.68,.115),(.30,.16),'H + SC',(.49,.09),-.23,'H','SC')
    route((.65,.24),(.475,.24),'− WQ/H\nto risk',(.56,.18),0,'WQ/H','PR')
    route((.44,.42),(.29,.75),'Risk + supply\nfeedback',(.34,.55),-.18,'PRS/PRE','G1/G2/G3')
    for r in nodes:
        x,y=pos[r['node']];col=SUB.get(r['subsystem'],'#65717C')
        if r['role']=='STATE':ax.add_patch(Circle((x,y),.029,fc='white',ec=col,lw=1.1,zorder=4))
        else:ax.add_patch(FancyBboxPatch((x-.03,y-.02),.06,.04,boxstyle='round,pad=.004',fc='white',ec=col,lw=.85,zorder=4))
        ax.text(x,y,r['label'],ha='center',va='center',fontsize=7.5,zorder=5)
    ax.text(.50,.025,'External forcing: precipitation · runoff · SST',ha='center',fontsize=8,color='#555555')
    ax.text(.50,-.008,'13 state nodes; rounded boxes: derived quantities. Composite routes summarize local pathways.\nStructural signs only; line width is not an effect magnitude.',ha='center',va='top',fontsize=7.5)
    core.csvout(pd.DataFrame(nodes),P/'Figure3_nodes.csv');core.csvout(pd.DataFrame(edges),P/'Figure3_edges.csv')
    check('Figure3 has13 state nodes',sum(n['role']=='STATE' for n in nodes)==13,len(states));save(fig,'Figure3')
    mapdata('Figure3','structure',['equations'],'M3 executed rhs / actions','local target/derivative signs','equation-defined; no effect weighting','13 states; derived quantities separate','MODEL','STRUCTURAL')

def figure4():
    q=core.data('part1_ternary');z=core.data('part1_stage');fig=frame(118)
    a=fig.add_axes([.055,.20,.44,.68]);b=fig.add_axes([.62,.22,.34,.63])
    h=np.sqrt(3)/2
    a.plot([0,1,.5,0],[0,0,h,0],color='#CCD2D7',lw=.55,zorder=1)
    for f in [.25,.5,.75]:
        a.plot([f/2,1-f/2],[h*f,h*f],color='#E5E8EA',lw=.35,zorder=0)
    colors=['#647C91','#AA8653','#5F9986','#94749B'];stages=list(z.stage.drop_duplicates())
    for stage,col in zip(stages,colors):
        v=q[q.stage==stage];a.scatter(v.x,v.y,s=25,fc=col,ec='white',lw=.6,zorder=4,clip_on=False,label=stage.replace('-','–'))
    a.set(xlim=(-.13,1.13),ylim=(-.15,h+.14));a.set_aspect('equal');a.axis('off')
    a.text(0,-.06,'G1',ha='center');a.text(1,-.06,'G2',ha='center');a.text(.5,h+.055,'G3',ha='center')
    a.legend(loc='lower center',bbox_to_anchor=(.5,-.28),ncol=2,fontsize=7.5);panel(a,'a','Policy function composition')
    for j,g in enumerate(['G1','G2','G3']):
        v=z[z.label==g].set_index('stage').loc[stages];x=np.arange(4)+(j-1)*.18
        b.errorbar(x,v.design_corrected_share,yerr=np.vstack([v.design_corrected_share-v.p025_normal_approx,v.p975_normal_approx-v.design_corrected_share]),fmt='o',ms=3,capsize=2,color=[SUB['G'],SUB['S'],SUB['E']][j],label=g,lw=.8)
    b.set_xticks(range(4),[x.replace('-','–') for x in stages],rotation=35,ha='right');b.set(ylabel='Equal-policy share',ylim=(0,1));b.legend(ncol=3,loc='upper right',fontsize=7.5);panel(b,'b','Stage estimates and design intervals')
    core.csvout(q,P/'Figure4a_coordinates.csv');check('Figure4 coordinates unchanged',np.allclose(q.x,q.G2_HT_share+.5*q.G3_HT_share) and np.allclose(q.y,h*q.G3_HT_share),'Exact boundary points; no jitter or epsilon')
    save(fig,'Figure4');mapdata('Figure4','a/b',['part1_ternary','part1_stage'],'all68 /4stages','frozen coordinates and Taylor design approximation','unchanged policy means; presentation only','68 policies;528/106 audit','FOUR_STAGES','share','AUDIT_DESIGN_TAYLOR_NOT_BOOTSTRAP')

def figure5():
    x=core.data('ses').sort_values('year');fig=frame(115);gs=fig.add_gridspec(2,1,height_ratios=[3,1],left=.105,right=.93,bottom=.13,top=.93,hspace=.39)
    a=fig.add_subplot(gs[0]);b=fig.add_subplot(gs[1]);cols=[SUB['G'],SUB['S'],SUB['E']]
    for state,col in zip(['G','SR','ES'],cols):
        a.plot(x.year,x[state],'-o',color=col,ms=3,lw=1.2,label=state)
    a.set(xlim=(2010.8,2023.2),ylim=(0,1),ylabel='Normalized historical indicator');a.set_xticks(x.year);a.tick_params(axis='x',rotation=45);a.legend(ncol=3,loc='upper left');panel(a,'a','Constructed annual indicators')
    diff=x[['G','SR','ES']].diff().iloc[1:].T.to_numpy();v=np.max(abs(diff));im=b.imshow(diff,aspect='auto',cmap='RdBu_r',vmin=-v,vmax=v)
    b.set_yticks(range(3),['G','SR','ES']);b.set_xticks(range(12),[f'{y-1}–{str(y)[-2:]}' for y in x.year.iloc[1:]],rotation=45,ha='right');b.tick_params(labelsize=7.5);panel(b,'b','Adjacent-year change, common scale')
    fig.colorbar(im,ax=b,location='right',fraction=.022,pad=.025,label='Δ state')
    core.csvout(x[['year','G','SR','ES']],P/'Figure5_levels.csv');core.csvout(pd.DataFrame(diff.T,columns=['G','SR','ES']).assign(year_end=x.year.iloc[1:].to_numpy()),P/'Figure5_changes.csv')
    check('Figure5 actual13 levels12 differences',len(x)==13 and diff.shape==(3,12),diff.shape);save(fig,'Figure5')
    mapdata('Figure5','a/b',['ses'],'2011–2023; annual differences only after sorting year','constructed G,SR,ES; adjacent-year difference','annual indicators then diff; shared zero scale','13 annual levels;12 differences;NOT parameter vectors','2011–2023','normalized 0–1 / annual change')

def figure6():
    x=core.data('ses').sort_values('year');fig=frame(153);axs=fig.subplots(2,3);fig.subplots_adjust(left=.10,right=.95,bottom=.10,top=.80,hspace=1.05,wspace=.55)
    ass=core.data('associations');stats=[];points=[]
    for j,(u,v) in enumerate([('G','SR'),('G','ES'),('SR','ES')]):
        for i,mode in enumerate(['level','annual_change']):
            a=axs[i,j];z=x[['year',u,v]].copy()
            if i:z[[u,v]]=z[[u,v]].diff();z=z.dropna()
            involved_ES='ES' in [u,v];estimated=(z.year==2023)&involved_ES
            a.scatter(z.loc[~estimated,u],z.loc[~estimated,v],s=15,color='#617582',alpha=.85)
            a.scatter(z.loc[estimated,u],z.loc[estimated,v],s=23,facecolor='white',edgecolor=SUB['E'],lw=1)
            for year in [2011,2022,2023]:
                if year in set(z.year):
                    r=z[z.year==year].iloc[0];a.annotate(str(year),(r[u],r[v]),xytext=(3,3),textcoords='offset points',fontsize=7.5)
            if i:a.axhline(0,color='.75',lw=.5);a.axvline(0,color='.75',lw=.5)
            rho=float(spearmanr(z[u],z[v]).statistic);z0=z[z.year!=2023];rho0=float(spearmanr(z0[u],z0[v]).statistic)
            a.text(0,1.22,f'All: ρ={rho:+.3f}, n={len(z)}\n−2023: ρ={rho0:+.3f}, n={len(z0)}',transform=a.transAxes,va='bottom',fontsize=7.5,clip_on=False)
            a.margins(.20);a.set_xlabel(('Δ ' if i else '')+u);a.set_ylabel(('Δ ' if i else '')+v);panel(a,chr(97+i*3+j),'Annual changes' if i else 'Same-year states');a.texts[-1].set_x(-.16)
            old=ass[(ass.scope=='FULL_2011_2023')&(ass['mode']==mode)&(ass.state_a==u)&(ass.state_b==v)].iloc[0]
            check('Figure6 matches frozen rho '+u+v+mode,abs(rho-old.rho)<1e-12,rho)
            stats.append(dict(panel=chr(97+i*3+j),state_a=u,state_b=v,mode=mode,rho=rho,n=len(z),rho_exclude2023=rho0,n_exclude2023=len(z0),LOYO_min=old.loo_min,LOYO_max=old.loo_max))
            for r in z.itertuples(index=False,name=None):points.append(dict(panel=chr(97+i*3+j),year=r[0],x=r[1],y=r[2]))
    core.csvout(pd.DataFrame(stats),P/'Figure6_statistics.csv');core.csvout(pd.DataFrame(points),P/'Figure6_points.csv');save(fig,'Figure6')
    mapdata('Figure6','a–f',['ses','associations'],'G/SR/ES pairs; levels and adjacent changes','Spearman rho; all / exclude2023','construct levels; diff first; pairwise finite cases','13/12 levels and12/11 changes','2011–2023','state / change','LOYO_RANGE_IN_CAPTION_NOT_CI')

def figure7():
    fig=frame(105);a=fig.add_axes([.20,.25,.64,.61]);q=core.data('g2_statistics');q=q[q.relationship=='G2-H'].copy()
    check('Figure7 nine G2H settings',len(q)==9,len(q));norm=plt.Normalize(-1,1);cmap=plt.get_cmap('RdBu_r')
    for r in q.itertuples():
        j=['ALL_ELIGIBLE','A_GRADE','LOCAL'].index(r.policy_scope);i=[5,10,20].index(r.coastal_band_km)
        a.scatter(j,i,s=1900*abs(r.rho),c=[cmap(norm(r.rho))],ec='white',lw=.5)
        a.text(j,i,f'{r.rho:.3f}',ha='center',va='center',fontsize=9)
    a.set(xlim=(-.6,2.6),ylim=(2.6,-.6));a.set_xticks(range(3),['All eligible','Grade A','Local']);a.set_yticks(range(3),['5 km','10 km reference','20 km']);a.tick_params(length=0);a.spines[['left','bottom']].set_visible(False)
    a.set_title('G2–H association, 2011–2022',pad=15)
    cb=fig.colorbar(plt.cm.ScalarMappable(norm=norm,cmap=cmap),ax=a,location='bottom',fraction=.055,pad=.17);cb.set_label('Spearman ρ; bubble area ∝ |ρ|');cb.set_ticks([-1,0,1])
    core.csvout(q,P/'Figure7_bubbles.csv');save(fig,'Figure7');mapdata('Figure7','matrix',['g2_statistics','g2_series'],'3 widths ×3 scopes','Spearman rho','frozen statistics','12 years','2011–2022','rho','LOYO_IN_TABLE_S5')

LINKS=['G_to_S','S_to_G','G_to_E','E_to_G','S_to_E','E_to_S']
def figure8():
    fig=frame(168);gs=fig.add_gridspec(2,2,width_ratios=[1,1.04],height_ratios=[1,1.05],left=.09,right=.90,bottom=.09,top=.94,wspace=.38,hspace=.51)
    a=fig.add_subplot(gs[0,0]);b=fig.add_subplot(gs[0,1]);c=fig.add_subplot(gs[1,0]);d=fig.add_subplot(gs[1,1],projection='3d',proj_type='ortho')
    raw=core.data('ablations');z=raw[(raw.metric=='ES_2030')&raw.disabled_link_spec.isin(LINKS)];q=z.groupby('disabled_link_spec').contribution_full_minus_ablated.median().reindex(LINKS)
    check('Figure8 six links100 matched vectors',len(q)==6 and z.parameter_set_id.nunique()==100,(len(q),z.parameter_set_id.nunique()))
    a.set(xlim=(-1.44,1.44),ylim=(-1.90,1.42),aspect='equal');a.axis('off');panel(a,'a','Directed ablation effects on ES2030')
    angles={'G':90,'S':210,'E':330};positions={}
    for name,ang in angles.items():
        a.add_patch(Arc((0,0),2,2,theta1=ang-43,theta2=ang+43,color=SUB[name],lw=10))
        theta=np.deg2rad(ang);a.text(1.23*np.cos(theta),1.23*np.sin(theta),name,ha='center',va='center',fontsize=10,fontweight='bold',color=SUB[name])
    maxv=max(abs(q));chordrows=[]
    for i,link in enumerate(LINKS):
        src,tgt=link.split('_to_')
        # Each direction uses different source/target ports; reciprocal paths cannot overlap exactly.
        ast=angles[src]+20
        aet=angles[tgt]-20
        p0=.94*np.array([np.cos(np.deg2rad(ast)),np.sin(np.deg2rad(ast))]);p1=.94*np.array([np.cos(np.deg2rad(aet)),np.sin(np.deg2rad(aet))])
        value=float(q[link]);lw=11*abs(value)/maxv
        # One global points-per-effect scale. Tiny chords retain their true width.
        a.add_patch(FancyArrowPatch(p0,p1,connectionstyle='arc3,rad=.14',arrowstyle='-|>',mutation_scale=7,lw=lw,color=S['negative_effect_color'] if value<0 else S['positive_effect_color'],alpha=.70))
        a.add_patch(FancyArrowPatch(p0,p1,connectionstyle='arc3,rad=.14',arrowstyle='-|>',mutation_scale=9,lw=.55,color='#38464E',alpha=.95,zorder=6))
        chordrows.append(dict(link=link,source=src,target=tgt,source_angle=ast,target_angle=aet,median=value,width_points=lw,n_parameters=z[z.disabled_link_spec==link].parameter_set_id.nunique()))
    # Explicit signed labels for all six, including almost invisible edges.
    a.text(-1.38,-1.10,'\n'.join(f'{short(k)} {q[k]*1000:+.3f}' for k in LINKS[:3]),fontsize=7.5,ha='left',va='top')
    a.text(.22,-1.10,'\n'.join(f'{short(k)} {q[k]*1000:+.3f}' for k in LINKS[3:]),fontsize=7.5,ha='left',va='top')
    a.text(0,-1.86,'Effect ×10⁻³; width ∝ |median|',ha='center',fontsize=7.5)
    annual=core.data('ablation_annual');annual=annual[(annual.metric=='ES')&annual.link.isin(LINKS)&annual.year.between(2024,2030)]
    heat=annual.groupby(['link','year']).effect.median().unstack().reindex(LINKS);v=np.max(abs(heat.to_numpy()))
    im=b.imshow(heat.to_numpy()*1000,cmap='RdBu_r',vmin=-v*1000,vmax=v*1000,aspect='auto');b.set_yticks(range(6),[short(x) for x in LINKS]);b.set_xticks(range(7),range(2024,2031),rotation=45,ha='right');b.tick_params(labelsize=7.5);panel(b,'b','Annual paired-effect medians')
    b.plot([1.55,4.45],[-.72,-.72],lw=3,color='#C7C9CF',clip_on=False);b.text(3,-1.02,'2026–2028 disturbance',ha='center',fontsize=7.5)
    bar=fig.colorbar(im,ax=b,fraction=.045,pad=.035);bar.ax.set_title('×10⁻³',fontsize=7.5,pad=5)
    joint=core.data('nonadditivity');joint=joint[(joint.metric=='ES')&(joint.year==2030)];js=[]
    c.axis('off');panel(c,'c','Joint nonadditivity J on ES2030')
    for i,pair in enumerate(['G_S_reciprocal','G_E_reciprocal','S_E_reciprocal']):
        vals=joint.loc[joint.pair==pair,'nonadditivity'];lo,md,hi=np.quantile(vals,[.05,.5,.95]);x=.15+.35*i
        aa,bb=pair.split('_')[:2]
        c.add_patch(Circle((x-.055,.69),.045,fc=SUB[aa],ec='none'));c.add_patch(Circle((x+.055,.69),.045,fc=SUB[bb],ec='none'))
        c.text(x-.055,.69,aa,ha='center',va='center',color='white',fontsize=8);c.text(x+.055,.69,bb,ha='center',va='center',color='white',fontsize=8);c.text(x,.69,'↔',ha='center',va='center',fontsize=8)
        c.text(x,.47,f'{md*1000:+.3f}',ha='center',fontsize=9,color=S['negative_effect_color'] if md<0 else S['positive_effect_color']);c.text(x,.28,f'[{lo*1000:+.3f},\n{hi*1000:+.3f}]',ha='center',fontsize=7.5)
        js.append(dict(pair=pair,P5=lo,median=md,P95=hi,n=len(vals)))
    c.text(.50,.06,'J = E_joint − E_a − E_b\nP5–P95 of matched100; ×10⁻³',ha='center',fontsize=7.5)
    surf=core.data('surface');g=surf.pivot(index='disturbance_intensity',columns='governance_intensity',values='min_ES_2026_2030_median').sort_index().sort_index(axis=1)
    check('Figure8 real24 by13x13 surface',g.shape==(13,13) and set(surf.parameter_sets)=={24},g.shape)
    X,Y=np.meshgrid(g.columns,g.index);Z=g.to_numpy();floor=Z.min()-.035
    d.plot_surface(X,Y,Z,cmap='viridis',linewidth=.25,edgecolor='#FFFFFF55',antialiased=True,rstride=1,cstride=1,vmin=Z.min(),vmax=Z.max())
    d.contour(X,Y,Z,zdir='z',offset=floor,cmap='viridis',levels=6,linewidths=.65,vmin=Z.min(),vmax=Z.max());d.set_zlim(floor,Z.max()+.005);d.view_init(elev=24,azim=-126)
    d.set(xlabel='S0→S4 combination',ylabel='Disturbance amplitude',zlabel='Minimum ES');d.xaxis.labelpad=0;d.yaxis.labelpad=0;d.zaxis.labelpad=1;d.tick_params(labelsize=7.5,pad=0);d.set_xticks([0,.5,1]);d.set_yticks([0,.5,1]);panel(d,'d','Computed 24-vector response surface')
    for axis in [d.xaxis,d.yaxis,d.zaxis]:axis.pane.set_facecolor((1,1,1,0));axis._axinfo['grid']['color']='#DDE3E8'
    core.csvout(pd.DataFrame(chordrows),P/'Figure8_chords.csv');core.csvout(heat.reset_index(),P/'Figure8_heatmap.csv');core.csvout(pd.DataFrame(js),P/'Figure8_joint_J.csv');core.csvout(surf,P/'Figure8_surface.csv')
    # Independent aggregation check from saved individual grid minima.
    original=core.data('surface_parameters').groupby(['governance_grid_index','disturbance_grid_index']).min_ES_2026_2030.median()
    ref=surf.set_index(['governance_grid_index','disturbance_grid_index']).min_ES_2026_2030_median
    check('Figure8 surface stored vector minima reproduce grid median',np.max(abs(original-ref))<1e-12,np.max(abs(original-ref)))
    save(fig,'Figure8')
    for pane,keys,metric,order,pop,interval in [('a',['ablations'],'ES2030 full-minus-ablated S4−S0','paired effect per vector then median','100 matched vectors','NONE'),('b',['ablation_annual'],'annual ES directional ablation','annual paired effect per vector then median','100 matched vectors','NONE'),('c',['nonadditivity'],'J = E_joint − E_a − E_b at2030','J per vector then quantiles','100 matched vectors','FINITE_SET_P5_P95'),('d',['surface','surface_parameters'],'minimum ES2026–2030','trajectory minimum per vector then grid median','24 vectors ×13×13 actual cells','FINITE_GRID_NOT_THRESHOLD')]:mapdata('Figure8',pane,keys,'six directions /three pairs /actual grid',metric,order,pop,'2024–2030','normalized ES',interval)

def figure9():
    fig=frame(103);a=fig.add_axes([.10,.15,.72,.76]);x=core.data('scenario_trajectories');qs=[]
    for scenario in sorted(x.scenario.unique()):
        g=x[x.scenario==scenario].groupby('year').ES.quantile([.05,.5,.95]).unstack();vals=g[.5].to_numpy();ls='--' if scenario=='S0' else '-' if scenario in ['S4','S6'] else ':' if scenario=='S5' else '-.'
        a.plot(g.index,vals,color=C[scenario],ls=ls,lw=1.9 if scenario in ['S4','S6'] else 1.1,marker='o',ms=2)
        for yr,r in g.iterrows():qs.append(dict(scenario=scenario,year=yr,P5=r[.05],median=r[.5],P95=r[.95]))
    med=pd.DataFrame(qs);end=med[med.year==2030].sort_values('median');label_y=end['median'].to_numpy().copy()
    fig.canvas.draw()
    yrange=a.get_ylim()[1]-a.get_ylim()[0];gap=(10/72*fig.dpi)/a.get_window_extent().height*yrange*1.15
    for i in range(1,len(label_y)):label_y[i]=max(label_y[i],label_y[i-1]+gap)
    label_y-=np.mean(label_y-end['median'].to_numpy())
    for y,r in zip(label_y,end.itertuples()):
        a.plot([2030,2030.6],[r.median,y],lw=.6,color=C[r.scenario],clip_on=False);a.text(2030.68,y,r.scenario,color=C[r.scenario],va='center',fontsize=8,clip_on=False)
    a.axvspan(2026,2028,color='#C6CED6',alpha=.20,zorder=0);a.set(xlim=(2023.8,2030.05),xlabel='Year',ylabel='Ecological support ES');a.set_xticks(range(2024,2031));panel(a,'','Seven scenario medians under common forcing')
    fig.text(.10,.035,'600 retained parameter vectors; P5–P95 ranges: Figure S7',fontsize=7.5)
    core.csvout(med,P/'Figure9_medians_and_ranges.csv');check('Figure9 all7 including S5',med.scenario.nunique()==7 and 'S5' in set(med.scenario),med.scenario.unique());save(fig,'Figure9')
    mapdata('Figure9','trajectory',['scenario_trajectories'],'allS0–S6; ES annual output','median ES by scenario/year','parameter median; straight segments; no smoothing','main600 vectors; one common climate path','2024–2030','ES','MAIN_MEDIANS_RANGES_IN_S7')

def swarm_offsets(values,scale=.22):
    # Deterministic category-axis avoidance; effect coordinates are never modified.
    v=np.asarray(values,float);lo,hi=np.min(v),np.max(v);span=hi-lo
    if span<1e-12:return np.linspace(-scale,scale,len(v))
    bins=np.floor((v-lo)/span*36).astype(int);out=np.zeros(len(v))
    for b in np.unique(bins):
        ix=np.where(bins==b)[0];rank=np.argsort(v[ix],kind='stable');seq=np.arange(len(ix));yy=((seq+1)//2)*np.where(seq%2==0,-1,1)
        yy=yy/max(1,np.max(abs(yy)))*scale;out[ix[rank]]=yy
    return out

def rain(ax,sets,labels,colors,density=True):
    summaries=[]
    for i,(v,label,col) in enumerate(zip(sets,labels,colors)):
        v=np.asarray(v,float);span=np.ptp(v);offset=swarm_offsets(v,.18)
        ax.scatter(v*1000,i+.12+offset*.42,s=1.1,color=col,alpha=.34,rasterized=False,lw=0)
        if density and span>1e-10 and np.std(v)>1e-11:
            grid=np.linspace(v.min(),v.max(),160);d=gaussian_kde(v)(grid);d=d/d.max()*.23
            ax.fill_between(grid*1000,i-.10,i-.10-d,color=col,alpha=.28,lw=.5)
        lo,md,hi=np.quantile(v,[.05,.5,.95]);ax.plot([lo*1000,hi*1000],[i-.05,i-.05],color=col,lw=1.6);ax.scatter(md*1000,i-.05,s=13,fc='white',ec=col,zorder=3)
        summaries.append(dict(label=label,n=len(v),P5=lo,median=md,P95=hi))
    ax.set_yticks(range(len(labels)),labels);ax.set_ylim(len(labels)-.52,-.55);ax.axvline(0,color='.55',lw=.6);ax.tick_params(axis='y',length=0,labelsize=7.5);return summaries

def figure10():
    fig=frame(158);axs=fig.subplots(2,2);fig.subplots_adjust(left=.22,right=.97,bottom=.10,top=.93,wspace=.65,hspace=.55)
    pairs=core.data('paired');order=['S4-S0','S6-S0','S4-S6','S5-S0'];summ=[]
    for a,field,letter,title in [(axs[0,0],'D_min_ES_2026_2030','a','Paired minimum ES'),(axs[0,1],'D_SR_2030','b','Paired terminal SR2030')]:
        vals=[pairs.loc[pairs.contrast==c,field].to_numpy() for c in order]
        summ += [dict(panel=letter,**r) for r in rain(a,vals,[s.replace('-','−') for s in order],[C['S4'],C['S6'],C['S4'],C['S5']])];panel(a,letter,title);a.set_xlabel('Paired difference ×10⁻³')
        if field=='D_SR_2030':a.axvline(-.5,color=C['S5'],ls='--',lw=.8);a.text(.98,.03,'SR screen: −0.5',transform=a.transAxes,ha='right',fontsize=7.5,color=C['S5'])
    sh=core.data('shapley');groups=[['policy_G1_G2_G3','response_eta_tau','feedback','synergy'],['G3','tau','feedback']];labels=[['G1/G2/G3 supply','eta/tau response','Feedback','Synergy proxy'],['G3','tau','Feedback']]
    used=[]
    for a,contrast,grp,lab,letter in zip(axs[1],['S4-S0','S4-S6'],groups,labels,['c','d']):
        q=sh[(sh.contrast==contrast)&(sh.metric=='min_ES_2026_2030')]
        check('Figure10 exact grouping '+contrast,set(q['group'])==set(grp),q['group'].unique())
        vals=[q.loc[q['group']==g,'contribution'].to_numpy() for g in grp];total=q.groupby('parameter_set_id').total_paired_delta.first();# Total remains in full source and new Table S7, not duplicated in c/d.
        sumrows=rain(a,vals,lab,['#547D9C','#B48B46','#669C87','#8A719F','#313F4C'][:len(vals)],density=False)
        summ += [dict(panel=letter,**r) for r in sumrows];panel(a,letter,contrast.replace('-','−')+' grouped Shapley');a.set_xlabel('Minimum ES contribution ×10⁻³')
        for g,v in zip(grp,vals):
            ids=total.index if g=='TRUE_TOTAL' else q.loc[q['group']==g,'parameter_set_id'].to_numpy()
            used.extend(dict(contrast=contrast,group=g,parameter_set_id=pid,value=float(y)) for pid,y in zip(ids,v))
    core.csvout(pd.DataFrame(summ),P/'Figure10_summary.csv');core.csvout(pd.DataFrame(used),P/'Figure10_shapley_display_values.csv');save(fig,'Figure10')
    mapdata('Figure10','a/b',['paired'],'four fixed contrasts; all600 vectors','minimum ES and terminal SR paired differences','trajectory minimum per scenario then subtract; quantiles last','600 matched vectors','2026–2030 minima /2030 SR','×10⁻³','FINITE_SET_P5_P95;DENSITY_DESCRIPTIVE')
    mapdata('Figure10','c/d',['shapley'],'minimum ES; original4/3 groups plus true total','grouped Shapley and per-vector true total','per-vector attribution; no median closure imposed','600 matched vectors per contrast','minimum2026–2030','×10⁻³','FINITE_SET_P5_P95')

def specification_matrix():
    both=pd.concat([core.data('robustness'),core.data('additional')],ignore_index=True);metrics=pd.concat([core.data('robustness_metrics'),core.data('reporting_metrics'),core.data('additional_metrics')],ignore_index=True)
    shortnames={'HISTORICAL_CONTINUATION_2023':'Historical continuation','STRUCTURE_NO_ADAPTIVE_FEEDBACK':'No adaptive feedback','STRUCTURE_NO_GOVERNANCE_SYNERGY':'No governance synergy','STRUCTURE_NO_IMPLEMENTATION_GATE':'No implementation gate','STRUCTURE_NO_TF_SM_CONVERSION':'No TF→SM conversion','CODER_SWAP_LIMITED_REFIT_POINT':'Coder swap: limited refit','POLICY_FLOW_RECENT_MEAN':'Recent policy inflow','SYMMETRIC_HABITAT':'Symmetric habitat rate','LINEAR_WATER':'Linear water response','CLIMATE_compound':'Joint climate + shock','CLIMATE_no_compound':'Joint climate, no shock'}
    rows=[]
    for name,g in both[both.metric=='min_ES_2026_2030'].groupby('specification_id',sort=True):
        kind='A' if name.startswith('REPORTING') else 'C' if 'REFIT' in name else 'B';n=g.n_matched.max();u=metrics[metrics.specification_id==name]
        label=shortnames.get(name,name.replace('REPORTING_','').replace('HABITAT_','Habitat ').replace('_',' '))
        row=dict(specification=name,group=kind,label=label,n_parameters=int(u.parameter_set_id.nunique()) if len(u) else int(n),n_climate_paths=int(u.forcing_draw_id.nunique()) if len(u) else 0,aggregation='MEDIAN_OF_ORIGINAL_DRAW_SPECIFIC_PAIR_MEDIANS')
        for title,a,b in [('S4-S0','S4','S0'),('S6-S0','S6','S0'),('S4-S6','S4','S6')]:
            x=g[(g.scenario_a==a)&(g.scenario_b==b)];sign=1
            if x.empty:x=g[(g.scenario_a==b)&(g.scenario_b==a)];sign=-1
            row[title]=float(np.median(x.median_a_minus_b)*sign) if len(x) else np.nan
        rows.append(row)
    return pd.DataFrame(rows).sort_values(['group','specification']).reset_index(drop=True)

def figure11():
    full=specification_matrix();matrix=full[~full.specification.str.startswith('REPORTING_SR_')].reset_index(drop=True)
    fig=frame(244);a=fig.add_axes([.51,.47,.37,.45]);v=matrix[['S4-S0','S6-S0','S4-S6']].to_numpy()*1000;lim=np.nanmax(abs(v));im=a.imshow(v,cmap='RdBu_r',vmin=-lim,vmax=lim,aspect='auto')
    a.set_yticks(range(len(matrix)),[]);a.set_xticks(range(3),['S4−S0','S6−S0','S4−S6']);a.tick_params(length=0)
    for i,r in enumerate(matrix.itertuples()):
        label=r.label.replace('REPORTING ','').replace('HISTORICAL ','').replace('Habitat ','Habitat: ').replace('CLIMATE ','Climate: ').replace('STRUCTURE ','')
        label={'Climate: BLOCK1':'Climate block 1 year','Climate: BLOCK5':'Climate block 5 years','CODER SWAP':'Coder swap','COMPOUND X0.8':'Compound ×0.8','COMPOUND X1.2':'Compound ×1.2','Habitat: LOWER':'Habitat lower','Habitat: UPPER':'Habitat upper','RISK TAU X0.5':'Risk delay ×0.5','RISK TAU X2':'Risk delay ×2','SYNERGY X0.8':'Synergy ×0.8','SYNERGY X1.2':'Synergy ×1.2'}.get(label,label)
        a.text(-3.94,i,r.group,ha='left',va='center',fontsize=7.5,clip_on=False)
        a.text(-3.48,i,label,ha='left',va='center',fontsize=7.2,clip_on=False)
        a.text(-1.12,i,str(r.n_parameters),ha='center',va='center',fontsize=7.3,clip_on=False)
        a.text(-.72,i,str(r.n_climate_paths),ha='center',va='center',fontsize=7.3,clip_on=False)
        for j in range(3):
            n=v[i,j];a.text(j,i,'NA' if np.isnan(n) else f'{n:+.2f}',ha='center',va='center',fontsize=7.5,color='white' if abs(n)>.67*lim else '#25333D')
        if i and matrix.group.iloc[i]!=matrix.group.iloc[i-1]:a.axhline(i-.5,color='black',lw=.6)
    for x,t in [(-3.94,'Type'),(-3.48,'Specification'),(-1.12,'n p'),(-.72,'n c')]:a.text(x,-1.3,t,ha='left' if x< -2 else 'center',fontsize=7.5,clip_on=False)
    fig.text(.06,.956,'a',fontweight='bold',fontsize=11);fig.text(.10,.956,'Specification sensitivity of minimum ES',fontsize=10)
    cb=fig.colorbar(im,cax=fig.add_axes([.52,.415,.35,.012]),orientation='horizontal');cb.set_label('Paired minimum ES difference ×10⁻³',fontsize=8)
    b=fig.add_axes([.12,.12,.34,.21]);q=core.data('initialization_pairs');q=q[(q.contrast=='S4-S6')&(q.metric=='min_ES_2026_2030')].sort_values('parameter_set_id')
    b.scatter(q.RESET*1000,q.CONTINUATION*1000,s=10,color=SUB['G'],alpha=.6);b.axhspan(-.5,.5,color='.85',alpha=.5);b.axhline(0,color='.5',lw=.6);b.axvline(0,color='.5',lw=.6);b.set(xlabel='RESET difference ×10⁻³',ylabel='Continuation difference ×10⁻³');panel(b,'b','Same 100 vectors, S4−S6')
    gate=core.data('gate_summary');gate=gate[(gate.metric=='min_ES_2026_2030')&(gate.contrast=='S4-S6')]
    for k,init in enumerate(['RESET','CONTINUATION']):
        c=fig.add_axes([.61,.245-k*.14,.32,.09]);g=gate[gate.initialization==init].sort_values('midpoint')
        c.axhspan(-.5,.5,color='.85',alpha=.45);c.axhline(0,color='.5',lw=.6)
        c.errorbar(range(3),g['median']*1000,yerr=np.vstack([g['median']-g.P5,g.P95-g['median']])*1000,fmt='o-',ms=3,lw=.9,capsize=2,color=SUB['G'] if k==0 else SUB['E'])
        c.set_xticks(range(3),['0.20','0.30','0.40']);c.set_xlim(-.3,2.3);c.set_ylabel('Δ ×10⁻³');c.set_title(init.title()+'; n = 12',fontsize=8,loc='left',pad=4);c.tick_params(labelsize=7.5)
        if k:c.set_xlabel('AC gate midpoint')
    fig.text(.56,.36,'c',fontweight='bold',fontsize=11);fig.text(.60,.36,'S4−S6, distinct 12 vectors',fontsize=9)
    fig.text(.06,.025,'A reporting only; B fixed parameters; C prior limited refit. n p: vectors; n c: climate paths.\nSR-only reporting checks remain in Data S4. Bottom panels use different matched subsets and y scales.',fontsize=7.5)
    core.csvout(full,P/'Figure11_all_specifications.csv');core.csvout(matrix,P/'Figure11_main_ES_specifications.csv');core.csvout(q,P/'Figure11_initialization_matched100.csv');core.csvout(gate,P/'Figure11_gate12.csv')
    save(fig,'Figure11');mapdata('Figure11','a',['robustness','additional'],'all ES-affecting specifications; SR-only retained Data S4','draw-specific paired medians','same frozen aggregation','actual vectors and climate paths separate','2026–2030','×10⁻³')
    mapdata('Figure11','b/c',['initialization_pairs','gate_summary'],'S4-S6 minimum ES','matched contrasts','100 scatter; separate12 P5/median/P95','100 vs12','2026–2030','×10⁻³','FINITE_PARAMETER_SET')

def captions():
    from report_r3_checks import captions as current_captions
    current_captions()

def render():
    F.mkdir(parents=True,exist_ok=True);P.mkdir(parents=True,exist_ok=True)
    plt.rcParams.update({'font.family':S['font'],'font.size':8,'axes.labelsize':8,'axes.titlesize':9,'xtick.labelsize':8,'ytick.labelsize':8,'legend.fontsize':8,'svg.fonttype':'none','pdf.fonttype':42,'axes.spines.top':False,'axes.spines.right':False,'axes.linewidth':.65,'legend.frameon':False})
    for fun in [figure3,figure4,figure5,figure6,figure7,figure8,figure9,figure10,figure11]:print('DRAW',fun.__name__,flush=True);fun()
    for n in range(2,8):
        for ext in ['pdf','svg','png']:
            original=core.R1/'figures'/f'Figure_S{n}.{ext}';target=F/f'Figure_S{n}.{ext}'
            if original.is_file():shutil.copy2(original,target)
            elif not target.is_file():raise FileNotFoundError('Portable plotting needs the bundled frozen supplement '+str(target))
        keys={2:['associations'],3:['ses'],4:['historical_ensemble','ses','simple_baselines'],5:['parameter_spread','loss_scans','saturation','sm_summary'],6:['sc_reconstruction','sc_decomposition','sc_aggregations'],7:['scenario_trajectories']}[n]
        mapdata('Figure_S'+str(n),'all',keys,'Exact R1 published supplemental export; no statistics changed','see frozen R1 panel/caption definitions','unchanged original aggregation','actual600 /diagnostic12 /input-only as applicable','2011–2023 or2024–2030','original units','FINITE_SET_OR_INPUT_DIAGNOSTIC_AS_LABELLED')
    for ext in ['pdf','svg','png']:
        shutil.copy2(core.PART1/('Figure_S1_updated.'+ext),F/('Figure_S1.'+ext))
    x=core.data('ses').sort_values('year');fig=frame(86);axs=fig.subplots(1,2);fig.subplots_adjust(left=.09,right=.97,bottom=.20,top=.86,wspace=.28)
    for a,cols,letter,title in [(axs[0],['G1','G2','G3'],'a','Governance components'),(axs[1],['WQ','H'],'b','Ecological components')]:
        for state,col in zip(cols,['#355D80','#268E80','#C87E61']):a.plot(x.year,x[state],color=col,lw=1.2,label=state)
        a.legend(ncol=len(cols),fontsize=8);a.set_xlabel('Year');a.set_ylabel('Constructed state');panel(a,letter,title)
    core.csvout(x[['year','G1','G2','G3','WQ','H']],P/'Figure_S3_components.csv');save(fig,'Figure_S3')
    for r in MAPROWS:
        if r['artifact_id']=='Figure_S3':r.update(filter_rule='G1/G2/G3,WQ/H only; total ES removed as duplicate of Figure5',metric_definition='frozen constructed component levels',aggregation_order='unchanged values; reporting-only deduplication')
    mapdata('Table2','all',['part1_table2','part1_bootstrap'],'frozen Part1 table','stage HT means and registered policy Bootstrap','policy-level resampling as frozen','68 policies in4stages','FOUR_STAGES','shares','POLICY_BOOTSTRAP_NOT_TAYLOR')
    core.csvout(pd.DataFrame(MAPROWS),O/'FIGURE_TABLE_DATA_MAP.csv');core.js(Q,O/'FIGURE_NUMERIC_QA.json');core.js(BOUNDS,O/'FIGURE_TEXT_BOUNDS.json')
    print('Rendered9main figures,6supplements reused; exact source map saved',flush=True)
