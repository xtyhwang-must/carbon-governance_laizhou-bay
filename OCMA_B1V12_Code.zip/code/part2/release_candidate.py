"""Package complete B1_v1.1 and independently replay after extraction."""
from __future__ import annotations
from datetime import datetime,timezone
import hashlib,json,subprocess,sys,tempfile,zipfile
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
RELEASE=ROOT/'07_release'
VERSION='B1_v1.1.0_source_reconstructed'

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def files():
    for path in ROOT.rglob('*'):
        if not path.is_file():continue
        rel=path.relative_to(ROOT)
        if rel.parts[0]=='07_release' or rel.name=='baseline_manifest.json':continue
        if '__pycache__' in rel.parts or path.suffix in ['.pyc','.tmp']:continue
        assert path.resolve().is_relative_to(ROOT.resolve())
        yield rel.as_posix(),path

def run(dest,command):
    result=subprocess.run([sys.executable,*command],cwd=dest,text=True,capture_output=True,timeout=180)
    return {'command':' '.join(command),'exit_code':result.returncode,
            'stdout':result.stdout[-4000:],'stderr':result.stderr[-4000:]}

def main():
    required=[ROOT/'06_runs/B1_v1_1'/p for p in ['calibration/calibration_status.json',
      'evaluation/evaluation_status.json','scenarios/scenario_status.json',
      'attribution/attribution_status.json','baseline_qa_report.json']]
    if not all(p.is_file() for p in required):raise RuntimeError('Full B1 stages not complete')
    RELEASE.mkdir(parents=True,exist_ok=True)
    entries=[{'relative_path':rel,'sha256':sha(path),'bytes':path.stat().st_size} for rel,path in sorted(files())]
    manifest={'version':VERSION,'created_utc':datetime.now(timezone.utc).isoformat(),
       'archive_paths_relative':True,'file_count_excluding_manifest':len(entries),
       'author_review_status':'PENDING','submission_ready':False,
       'files':entries}
    manifest_path=ROOT/'baseline_manifest.json'
    manifest_path.write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    archive=RELEASE/(VERSION+'.zip')
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=3,allowZip64=True) as z:
        for e in entries:z.write(ROOT/e['relative_path'],e['relative_path'])
        z.write(manifest_path,'baseline_manifest.json')
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        assert set(z.namelist())=={e['relative_path'] for e in entries}|{'baseline_manifest.json'}
        assert all(not n.startswith('/') and '..' not in Path(n).parts for n in z.namelist())
        with tempfile.TemporaryDirectory(prefix='b1_v1_1_replay_',dir=RELEASE) as tmp:
            dest=Path(tmp).resolve()
            assert dest.is_relative_to(RELEASE.resolve())
            z.extractall(dest)
            for e in entries:
                if sha(dest/e['relative_path'])!=e['sha256']:raise AssertionError(e['relative_path'])
            logs=[run(dest,['05_code/build_evidence.py']),
                  run(dest,['05_code/qa_baseline.py','--input-only']),
                  run(dest,['05_code/release_replay.py'])]
            if any(x['exit_code'] for x in logs):raise RuntimeError(json.dumps(logs,ensure_ascii=False))
    report={'version':VERSION,'status':'PORTABLE_REPLAY_PASS','archive_relative_path':archive.relative_to(ROOT).as_posix(),
       'archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,
       'payload_files':len(entries),'replay':logs,
       'full_calibration_recomputed_in_replay':False,
       'representative_history_and_all_seven_scenarios_recomputed':True}
    (RELEASE/'portable_replay_log.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in report.items() if k!='replay'},ensure_ascii=False))

if __name__=='__main__':main()
