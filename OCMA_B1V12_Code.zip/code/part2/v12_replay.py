"""Portable fixed-vector replay; no optimizer or candidate generation."""
from __future__ import annotations
import json,sys
from pathlib import Path
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'05_code/engine'),str(ROOT/'05_code')]
import sd_model as model
from numeric_analysis import load_settings
from v12_evaluation import one as history_one
from v12_scenarios import vector_job
from v12_attribution import one as attribution_one

def compare(constructed,packaged,keys,fields,tolerance):
    a=constructed.set_index(keys).sort_index();b=packaged.set_index(keys).sort_index()
    if not a.index.equals(b.index):raise AssertionError(f'Replay keys differ: {keys}')
    error=float(np.max(np.abs(a[fields].to_numpy(float)-b[fields].to_numpy(float))))
    if error>tolerance:raise AssertionError(f'Replay differs: {error} > {tolerance}')
    return error

def main():
    frame=pd.read_csv(ROOT/'03_indicators/model_input_B1.csv').sort_values('year').reset_index(drop=True)
    status=json.loads((ROOT/'06_runs/formal_main/calibration/formal_calibration_status.json').read_text(encoding='utf-8'))
    structure=status['structure'];names=model.parameter_names(structure)
    ensemble=pd.read_csv(ROOT/'06_runs/formal_main/calibration/accepted_parameter_ensemble.csv')
    r=ensemble.iloc[0];pid=str(r.parameter_set_id);params={n:float(r[n]) for n in names}
    history,_=history_one((pid,params,structure,frame))
    history_package=pd.read_csv(ROOT/'06_runs/formal_main/evaluation/historical_ensemble_trajectories.csv')
    history_package=history_package[history_package.parameter_set_id.eq(pid)]
    fields=['G1','G2','G3','SP','SC','NS','OS','BS','TF','SM','PR','PRS','IM','ES','SR']
    e_history=compare(history,history_package,['parameter_set_id','year'],fields,5e-6)
    climate=pd.read_csv(ROOT/'06_runs/formal_main/scenarios/common_climate_draw_001.csv')
    settings=load_settings()
    _,scenario=vector_job((pid,params,structure,frame,settings,climate))
    scenario_package=pd.read_csv(ROOT/'06_runs/formal_main/scenarios/scenario_trajectories_long.csv')
    scenario_package=scenario_package[scenario_package.parameter_set_id.eq(pid)]
    e_scenario=compare(scenario,scenario_package,['parameter_set_id','scenario','year'],fields,5e-6)
    _,coalition=attribution_one((pid,params,structure,frame,climate,settings))
    coalition_package=pd.read_csv(ROOT/'06_runs/formal_main/attribution/coalition_outputs_and_inputs.csv')
    coalition_package=coalition_package[coalition_package.parameter_set_id.eq(pid)]
    e_coalition=compare(coalition,coalition_package,
        ['parameter_set_id','contrast','coalition_mask'],['min_ES_2026_2030','ES_2030','SR_2030'],5e-6)
    report={'replay_pass':True,'parameter_set_id':pid,'history_max_abs_error':e_history,
        'seven_scenarios_max_abs_error':e_scenario,'grouped_coalitions_max_abs_error':e_coalition,
        'full_calibration_recomputed':False,'all_parameter_sets_replayed':False,
        'scope':'one fixed accepted vector, all historical years, seven future scenarios, 16+8 coalitions'}
    print(json.dumps(report,ensure_ascii=False),flush=True)

if __name__=='__main__':main()
