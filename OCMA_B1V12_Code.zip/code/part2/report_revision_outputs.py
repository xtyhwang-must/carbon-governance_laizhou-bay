"""Shared equation registry required by formal numerical table reproduction. R1 exporters are archived."""
from pathlib import Path
import ast,hashlib,re
import pandas as pd
R=Path(__file__).resolve().parents[1]
STRUCT='M3_AC_SM_TF_INTERCEPTS'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def build_complete_equation_registry():
    source=R/'05_code/engine/sd_model.py';tree=ast.parse(source.read_text('utf8'));rows=[]
    selected={'rhs':{'pre','feedback_shift','g_targets','dg','operations_potential','dim','ecological_risk','risk','memory_tau','dpr','dprs','social_feedback_memory','sp_signal','sp_target','dsp','sc_signal','sc_target','dsc','ns_signal','ns_target','dns','os_signal','os_target','dos','bs_signal','bs_target','dbs','tf_signal','sm_signal','tf_target','sm_target','tf_rate','sm_rate','dtf','dsm','conversion_action','conversion_rate','conversion_tf_units','conversion_sm_units','derivative'},
      '_implementation_potentials':{'gate','sc_factor','capacity_factor','operations','capacity'},'_actions':{'implementation_ops','implementation_capacity','synergy','synergy_multiplier','a1','a2','a3'}}
    def walk(nodes,fn,condition='ALWAYS'):
        for node in nodes:
            if isinstance(node,ast.If):
                cond=ast.unparse(node.test);walk(node.body,fn,condition+' AND '+cond);walk(node.orelse,fn,condition+' AND NOT('+cond+')')
            elif isinstance(node,(ast.Assign,ast.AugAssign)):
                target=ast.unparse(node.targets[0] if isinstance(node,ast.Assign) else node.target)
                hits=set(re.findall(r'[A-Za-z_]\w*',target))&selected[fn]
                if hits:
                    formula=ast.unparse(node.value) if isinstance(node,ast.Assign) else target+(' - ' if isinstance(node.op,ast.Sub) else ' + ')+ast.unparse(node.value)
                    rows.append(dict(variable=target,formula=formula,condition=condition,code='engine/sd_model.py::'+fn,line=node.lineno,structure=STRUCT,
                      stage='FINAL_BOUNDARY_DERIVATIVE' if target=='derivative' else 'POST_CONVERSION_UPDATE' if isinstance(node,ast.AugAssign) else 'TARGET_OR_PROCESS',source_sha256=sha(source)))
    for fn in tree.body:
        if isinstance(fn,ast.FunctionDef) and fn.name in selected:walk(fn.body,fn.name)
    for label,formula,fn in [
      ('REFERENCE_2011','parameter-specific _baseline_context(initial_state(year=2011), historical_forcing.at(2011), parameters, default_mode); fixed for future comparisons','make_training_reference_context'),
      ('INITIAL_STATE','exactly one explicit year row, all 13 state columns finite; 2011 history or 2023 RESET; CONTINUATION is original-vector free run','initial_state'),
      ('TF_SM_AREA_RATIO','TF normalized transfer multiplied by frozen TF_scale/SM_scale = habitat_scale_ratio; area units, not carbon conservation','rhs'),
      ('FINAL_dTF','asymmetric_tf_rate*(tf_target-tf) - conversion_tf_units, then raw-state invariant-domain guard','rhs'),
      ('FINAL_dSM','asymmetric_sm_rate*(sm_target-sm) + conversion_sm_units, then raw-state invariant-domain guard','rhs')]:
        node=next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name==fn)
        rows.append(dict(variable=label,formula=formula,condition='ACTUAL_MODE_AND_STRUCTURE',code='engine/sd_model.py::'+fn,line=node.lineno,structure=STRUCT,stage='EXPLICIT_DEFINITION',source_sha256=sha(source)))
    return pd.DataFrame(rows)
