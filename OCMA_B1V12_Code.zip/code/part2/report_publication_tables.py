"""R3 presentation helpers for the existing report entry. Frozen numeric inputs only."""
from pathlib import Path
import json,shutil,sys,os,subprocess,hashlib,time,zipfile,ast
import pandas as pd
import numpy as np
import report_r2 as c
O=c.OUT;R=c.ROOT;OLD=R/'07_publication/R2_FIGURE_CLEANUP_20261029'
BUNDLE=Path.home()/'.cache/codex-runtimes/codex-primary-runtime/dependencies'
TABLES=[];EVIDENCE=[]
def read(p):return pd.read_csv(p)
def old(name):return read(OLD/'tables'/name)
def part(name):return read(c.PART1/name)
def check_inputs():
    records=json.loads((O/'R3_START_SNAPSHOT.json').read_text('utf8'))
    changed=[r['path'] for r in records if not Path(r['path']).exists() or c.sha(Path(r['path']))!=r['sha256']]
    if changed:raise ValueError('Protected frozen files changed: '+str(changed[:5]))
    return len(records)
def fmt(x,d=3):
    return '—' if pd.isna(x) else f'{float(x):.{d}f}'.replace('-','−')
def interval(m,lo,hi,d=3,k=1):return f'{fmt(m*k,d)} [{fmt(lo*k,d)}, {fmt(hi*k,d)}]'
def add(id,title,cols,rows,note,sources,widths=None,part_title=None):
    item=dict(id=id,title=title,columns=cols,rows=rows,note=note,sources=sources,widths=widths,part_title=part_title)
    TABLES.append(item);suffix='_'+part_title.split('.')[0] if part_title else ''
    c.csvout(pd.DataFrame(rows,columns=cols),O/'display_tables'/f'{id}{suffix}.csv');return item
def prepare():
    check_inputs()
    for folder in ['source_data','plot_data','diagnostic_evidence','SM_local_results','frozen_part1']:
        shutil.copytree(OLD/folder,O/folder,dirs_exist_ok=True)
    shutil.copy2(OLD/'SOURCE_INPUTS.csv',O/'SOURCE_INPUTS.csv')
    for name in ['FIGURE_TABLE_DATA_MAP.csv','PRE_CLEANUP_SNAPSHOT.json']:
        shutil.copy2(OLD/name,O/name)
    for d in ['figures','display_tables','data','qa_previews','logs']:(O/d).mkdir(exist_ok=True)
    # Full canonical sources are retained in four thematic directories, never filtered for sign.
    roots=[('Data_S1',c.PART1),('Data_S2',R/'06_runs/ses'),('Data_S3',R/'06_runs/formal_main/evaluation'),('Data_S3',R/'06_runs/formal_main/calibration'),('Data_S4',R/'06_runs/formal_main/scenarios'),('Data_S4',R/'06_runs/formal_main/attribution'),('Data_S4',R/'06_runs/formal_main/robustness'),('Data_S4',R/'06_runs/formal_main/additional_sensitivity'),('Data_S4',R/'06_runs/formal_main/mechanisms'),('Data_S4',R/'06_runs/formal_main/SM_local_20261029'),('Data_S3',R/'04_model'),('Data_S3',R/'00_contract')]
    for group,root in roots:
        for p in root.rglob('*'):
            if p.is_file() and p.suffix.lower() in ['.csv','.json','.yaml','.yml'] and 'historical_archive' not in p.parts and 'code' not in p.parts and 'cache' not in str(p.relative_to(root)).lower():
                dst=O/'data'/group/root.name/p.relative_to(root);dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dst)
    for p in (OLD/'tables').glob('*.csv'):
        g='Data_S2' if p.stem in ['Table1_source','Table3_source','Table4_source','TableS1_source','TableS3_source'] else 'Data_S4' if p.stem in ['Scenarios_source','Paired_scenarios_source','TableS5_source','TableS6_source','TableS16_source','TableS17_source'] else 'Data_S3'
        dst=O/'data'/g/'archived_summary_csv'/p.name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dst)
    for p in (OLD/'diagnostic_evidence').glob('*.csv'):
        dst=O/'data/Data_S4/diagnostic_evidence'/p.name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dst)
    # Actual membership, independent stock identities and annual arrays are distinct checks.
    a=c.data('admission');dates=c.data('policy_dates');a=a.merge(dates[['policy_id','independent_stock_policy']],on='policy_id',validate='one_to_one');members=[]
    for scope,q in [('ALL_ELIGIBLE',a),('A_GRADE',a[a.text_evidence_grade.eq('A')]),('LOCAL',a[a['层级'].str.contains('市|区|县')])]:
        for row in q.itertuples():members.append(dict(scope=scope,policy_id=row.policy_id,independent_stock_policy=row.independent_stock_policy,text_grade=row.text_evidence_grade))
    m=pd.DataFrame(members);c.csvout(m,O/'data/Data_S2/policy_scope_members.csv')
    counts=m.groupby('scope').agg(texts=('policy_id','nunique'),stocks=('independent_stock_policy','sum'));assert counts.loc['A_GRADE','texts']==50 and counts.loc['ALL_ELIGIBLE','texts']==68
    from scipy.stats import rankdata
    series=c.data('g2_series');rows=[]
    for scope in counts.index:
        x=series[series.policy_scope.eq(scope)&series.coastal_band_km.eq(10)].sort_values('year');y=series[series.policy_scope.eq(scope)&series.coastal_band_km.eq(20)].sort_values('year')
        for var in ['G2','H','TF','SM','ES']:
            rows.append(dict(comparison='10_vs_20km',scope=scope,variable=var,values_equal=np.array_equal(x[var],y[var]),ranks_equal=np.array_equal(rankdata(x[var]),rankdata(y[var])),max_absolute_difference=max(abs(x[var].to_numpy()-y[var].to_numpy()))))
    x=series[series.policy_scope.eq('ALL_ELIGIBLE')&series.coastal_band_km.eq(10)].sort_values('year');y=series[series.policy_scope.eq('A_GRADE')&series.coastal_band_km.eq(10)].sort_values('year')
    rows.append(dict(comparison='All_vs_GradeA',scope='G2',variable='G2',values_equal=np.array_equal(x.G2,y.G2),ranks_equal=np.array_equal(rankdata(x.G2),rankdata(y.G2)),max_absolute_difference=max(abs(x.G2.to_numpy()-y.G2.to_numpy()))))
    c.csvout(pd.DataFrame(rows),O/'G2_H_MEMBERSHIP_ARRAY_RANK_CHECK.csv');c.csvout(counts.reset_index(),O/'POLICY_SCOPE_COUNTS.csv')
    # Inspect unrounded frozen arrays, not redo a stock build or annual governance input.
    for scope in counts.index:
        q=c.data('g2_statistics');q=q[q.policy_scope.eq(scope)]
        assert set(q.policy_texts)=={counts.loc[scope,'texts']} and set(q.independent_stock_sources)=={counts.loc[scope,'stocks']}
    print('R3 prepared; actual scope counts',counts.to_dict('index'),flush=True)
def build_views():
    TABLES.clear()
    x=c.data('part1_table2');rows=[]
    for stage,q in x.groupby('stage',sort=False):
        q=q.set_index('label');rows.append([stage.replace('-','–'),int(q.policies_included_in_HT_estimation.iloc[0])]+[interval(q.loc[g,'HT_policy_equal_share'],q.loc[g,'policy_bootstrap_p025'],q.loc[g,'policy_bootstrap_p975'],1,100) for g in ['G1','G2','G3']])
    add('Table2','Governance-function composition across policy stages',['Policy stage','Policies included, n','G1 share, %','G2 share, %','G3 share, %'],rows,'G1, source-pressure control; G2, habitat protection and restoration; G3, monitoring and coordination. Shares are estimated within policies, then averaged with equal policy weights. Brackets show the 2.5–97.5 percentiles of 2,000 within-stage policy resamples: composition sensitivity, not total coding-error or frame-omission uncertainty. Figure 4b uses separate audit-design Taylor intervals. Rounding need not sum to 100%.',['CURRENT_TABLE2.csv'],[.18,.14,.226,.227,.227])
    q=old('Table3_source.csv').set_index('state');names={'G':'Governance supply (G)','SR':'Social resilience proxy (SR)','ES':'Ecological support (ES)'}
    add('Table3','Long-term changes in governance supply, social resilience and ecological support',['SES state','2011','2023','Net change','Theil–Sen slope, year⁻¹ [LOYO range]'],[[names[g],fmt(q.loc[g,'initial']),fmt(q.loc[g,'terminal'])+('†' if g=='ES' else ''),fmt(q.loc[g,'net_change']),interval(q.loc[g,'Theil_Sen'],q.loc[g,'loo_min'],q.loc[g,'loo_max'])] for g in names],'Constructed historical indicators, 2011–2023 (n = 13), not SD fitted values. Net change = 2023 − 2011. LOYO is the leave-one-year-out sensitivity range, not a confidence interval. †The 2023 ES endpoint includes bridge-estimated habitat.',['Table3_source.csv'],[.27,.11,.11,.13,.38])
    q=c.data('g2_statistics');q=q[q.relationship.eq('G2-H')]
    add('Table4','Sensitivity of the contemporaneous G2–H association to habitat support width and policy scope',['Habitat support width','All eligible policies','Grade A policies','Local policies'],[[str(b)+' km'+(' reference' if b==10 else '')]+[fmt(q[(q.coastal_band_km==b)&(q.policy_scope==s)].rho.iloc[0]) for s in ['ALL_ELIGIBLE','A_GRADE','LOCAL']] for b in [5,10,20]],'Spearman ρ, 2011–2022 (n = 12), using the common fixed 10-km reference scale. All, Grade A and local scopes contain 68/50/33 texts and 67/49/32 independent stock sources, respectively. Grade A follows the recorded text-evidence grade; local means municipal or county-level applicability. Equal coefficients do not imply identical members or arrays. LOYO ranges appear in Table S5.',['G2_H_and_related_scope_statistics.csv'],[.28,.24,.24,.24])
    # S1 is a readable view of the complete canonical dictionary. Alias is one row.
    roles={'G1':'Source-pressure control supply','G2':'Habitat protection and restoration supply','G3':'Monitoring and coordination supply','SP':'Social pressure','SC':'Adaptive capacity (SC = AC)','SR':'Social resilience proxy','NS':'Nutrient stress','OS':'Oxygen stress','BS':'Bloom stress','TF':'Tidal-flat habitat','SM':'Salt-marsh habitat','WQ':'Water-quality support','H':'Habitat support','ES':'Ecological support','PPT':'Precipitation forcing','RUNOFF':'Modelled runoff forcing','SST':'Sea-surface temperature forcing','PR':'Combined risk memory','PRS':'Social risk memory','PRE':'Ecological risk memory','IM':'Implementation memory','fiscal':'Fiscal capacity component','education':'Education capacity component','ETA_POTENTIAL':'Text-derived implementation proxy','SYNERGY_LEVER':'Conditional institutional-relation proxy'}
    transforms={'G1':'HT-weighted active stock S₁/(S₁ + 6.608)','G2':'HT-weighted active stock S₂/(S₂ + 6.605)','G3':'HT-weighted active stock S₃/(S₃ + 7.936)','SP':'Equal population, real industry and agriculture; grain/meat equal within agriculture','SC':'Mean of fixed-scale fiscal and education ratios; AC is an alias','SR':'√[(1 − SP) SC]','NS':'Fixed-reference marine nutrient indicator; original mixed support','OS':'Fixed-reference marine oxygen indicator; original mixed support','BS':'Fixed-reference bloom indicator; original mixed support','TF':'Area → fixed 2011–2020 scale; 2023 bridge estimate','SM':'Area → fixed 2011–2020 scale; 2023 bridge estimate','PPT':'TerraClimate annual forcing; frozen spatial support','RUNOFF':'TerraClimate modelled runoff, not measured discharge','SST':'Source workbook; seasonal aggregation not independently revalidated','WQ':'[(1 − NS)(1 − OS)(1 − BS)]^(1/3)','H':'√(TF SM)','ES':'√(WQ H)','PR':'(PRS + 2 PRE)/3 at initialization; dynamic risk memory','PRS':'Exponentially weighted SP at initialization; dynamic memory','PRE':'Derived from PR and PRS; ecological risk memory','IM':'Initialized from implementation potential; first-order adjustment','fiscal':'Aggregate revenue/expenditure; author-confirmed scope','education':'Aggregate teachers per 1,000 pupils','ETA_POTENTIAL':'Frozen text-signal mapping; proxy, not measured execution','SYNERGY_LEVER':'Frozen relation proxy; not a validated observed network'}
    rows=[]
    for r in old('TableS1_source.csv').itertuples():
        if r.variable=='AC':continue
        v=r.variable;support='Nine counties → bay; 2011–2023' if v in ['SP','SC','SR','fiscal','education'] else 'Admitted policies, 2000–2023; bay-year interface' if v in ['G1','G2','G3','ETA_POTENTIAL','SYNERGY_LEVER'] else '10-km coastal band; 2011–2023' if v in ['TF','SM','PPT','RUNOFF'] else 'Bay / mixed support; 2011–2023'
        unit='Area km² → 0–1' if v in ['TF','SM'] else 'mm year⁻¹ → 0–1' if v in ['PPT','RUNOFF'] else '°C → 0–1' if v=='SST' else 'Revenue/expenditure ratio' if v=='fiscal' else 'Teachers/1,000 pupils' if v=='education' else 'Constructed 0–1 scale'
        rows.append([{'SC':'SC (= AC)','ETA_POTENTIAL':'η','SYNERGY_LEVER':'Synergy'}.get(v,v),roles[v],unit,support,transforms[v]])
    add('TableS1','Variables, sources and transformations',['Variable','Definition / role','Unit or model scale','Spatial and temporal support','Transformation / source'],rows,'Reference scaling is fixed at 2011–2020 and is not refitted to scenario values. Normalized low values do not mean near-zero physical capacity or area. Raw marine metadata and SST temporal aggregation retain their source limitations. Full source identifiers, units, transformation rows and hashes are in Data S1/S2; equations and fixed constants appear in Supplementary Methods.',['TableS1_source.csv'],[.11,.20,.16,.23,.30])
    e=part('ACTUAL_AUDIT_ERROR_METRICS.csv');e=e[(e.dimension=='ALL')&(e.scope=='ALL')].set_index('label');ag=part('INDEPENDENT_CODING_AGREEMENT.csv').set_index('label');rows=[]
    for g in ['eligibility','G1','G2','G3']:
        z=e.loc[g];tp,fp,fn=z.HT_TP,z.HT_FP,z.HT_FN;rows.append([g.title() if g=='eligibility' else g,fmt(tp/(tp+fp)),fmt(tp/(tp+fn)),fmt(2*tp/(2*tp+fp+fn)),int(ag.loc[g,'paired_actual_n']),fmt(ag.loc[g,'raw_agreement']),fmt(ag.loc[g,'cohen_kappa'])])
    add('TableS2','Policy-coding reliability and uncertainty in G estimates',['Field','Weighted precision','Weighted recall','Weighted F1','Paired n','Agreement','Kappa'],rows,'Precision, recall and F1 use design-weighted confusion totals in the 528-unit audit domain; agreement and Cohen’s kappa use only fields independently judged by both coders in the nested 106-unit scope (actual paired n shown). These are different estimands. Existing directed cases are not pooled into probability metrics. G3 omissions and G2 false positives remain visible.',['ACTUAL_AUDIT_ERROR_METRICS.csv','INDEPENDENT_CODING_AGREEMENT.csv'],[.15,.145,.145,.13,.1,.16,.17], 'A. Coding audit and independent agreement')
    z=part('G_STAGE_HT_ESTIMATES.csv');loo=part('HT_leave_one_policy_out.csv');rows=[]
    for r in z.itertuples():
        v=loo[(loo.stage==r.stage)&(loo.label==r.label)].delta;rows.append([r.stage.replace('-','–'),r.label,fmt(r.standard_error*100,2),f'[{fmt(v.min()*100,2)}, {fmt(v.max()*100,2)}]'])
    add('TableS2','Policy-coding reliability and uncertainty in G estimates',['Stage','Function','Design SE, percentage points','Leave-one-policy change range, percentage points'],rows,'HT fixed-extracted-frame estimates were selected after DIFF produced negative component totals for 24 policies. Taylor design SE excludes coder disagreement and frame omissions; zero empirical SE is not zero risk. Policy Bootstrap ranges remain in Table 2. Full Taylor intervals, HT/DIFF, policy estimates, stage contrasts and coder sensitivity are retained in Data S1.',['G_STAGE_HT_ESTIMATES.csv','HT_leave_one_policy_out.csv'],[.22,.15,.28,.35],'B. Stage estimation uncertainty')
    b=json.loads(c.source('best').read_text('utf8'))['parameters'];z=old('TableS4_source.csv');rows=[]
    for r in z.itertuples():rows.append([r.parameter.replace('alpha_','α ').replace('r_','r ').replace('k_','k ').replace('_',' '),f'[{fmt(r.lower)}, {fmt(r.upper)}]',fmt(b[r.parameter]),interval(r.P50,r.P5,r.P95),fmt(100*r.near_1pct_boundary_fraction,1)])
    add('TableS3','Model parameters and retained-set support',['Parameter','Numerical bounds','Best fit','Retained median [P5, P95]','Near-boundary fraction, %'],rows,'All 12 estimated parameters are shown. Near-boundary means within the existing 1% of numerical range at either bound. Rates are year⁻¹; response coefficients and logit intercepts are dimensionless. The 600 retained-vector quantiles are finite-set support, not posterior or confidence intervals. r water, k bloom and α SM concentrate near upper bounds. Fixed constants and unchanged optimization/screening rules are in Supplementary Methods; full candidate and five-seed results are in Data S3.',['TableS4_source.csv','best_parameter_set.json'],[.23,.17,.13,.30,.17])
    perf=old('Retrospective_source.csv');perf=perf[perf['2023_estimate_treatment'].eq('weighted')].set_index('state');base=old('TableS15_source.csv');cov=old('Parameter_coverage_source.csv');cov=cov[cov.treatment.eq('unweighted')].set_index('state');rows=[]
    for g in ['SP','SC','NS','OS','BS','TF','SM']:
        q=perf.loc[g];bb=base[base.state.eq(g)].set_index('benchmark');rows.append([g if g!='SC' else 'SC / AC',fmt(q.RMSE),fmt(bb.loc['persistence','baseline_RMSE']),fmt(bb.loc['training_endpoint_drift','baseline_RMSE']),fmt(q.NRMSE),fmt(q.bias),f'{int(cov.loc[g,"covered_years"])}/{int(cov.loc[g,"n_years"])}'])
    add('TableS4','Retrospective performance and simple benchmarks',['State','Model RMSE','Persistence RMSE','Endpoint-drift RMSE','Model NRMSE','Bias','Covered years'],rows,'2021–2023 was previously viewed: this is a conditional retrospective evaluation. Model metrics are medians of per-vector errors, not errors of the median trajectory. Designated 2023 estimated-habitat items receive weight 0.35 in model and benchmark RMSE; NRMSE uses the fixed 2011–2020 P95−P5 range. Coverage is the unweighted count of years within the pure parameter P5–P95 envelope. The 600 vectors are not independent observations. Six states fail to outperform both simple baselines. All treatments and derived-state results remain in Data S3. Residual records are descriptive; no validated probability interval is claimed.',['Retrospective_source.csv','TableS15_source.csv','Parameter_coverage_source.csv'],[.10,.15,.15,.19,.15,.12,.14])
    ass=c.data('associations');rows=[]
    for mode in ['level','annual_change']:
        for scope in ['FULL_2011_2023','EXCLUDE_ESTIMATED_2023']:
            for u,v in [('G','SR'),('G','ES'),('SR','ES')]:
                q=ass[(ass.scope==scope)&(ass['mode']==mode)&(ass.state_a==u)&(ass.state_b==v)].iloc[0]
                rows.append(['Levels' if mode=='level' else 'Annual changes', 'Full' if scope.startswith('FULL') else 'Exclude 2023',u+'–'+v,int(q.n),fmt(q.rho),f'[{fmt(q.loo_min)}, {fmt(q.loo_max)}]'])
    add('TableS5','Historical associations and measurement sensitivity',['Series','Period','Pair','n','ρ','LOYO range'],rows,'Full levels span 2011–2023 (13 years); changes span the 12 adjacent transitions. Excluding 2023 removes the last year or transition. LOYO denotes the corresponding leave-one-year/transition range, not a confidence interval. Associations are descriptive and do not identify policy effects.',['associations_and_sensitivities.csv'],[.20,.20,.13,.08,.13,.26],'A. Main SES associations')
    rows=[]
    for r in c.data('g2_statistics').query("relationship == 'G2-H'").itertuples():rows.append(['G2–H',f'{r.coastal_band_km} km; '+{'ALL_ELIGIBLE':'all','A_GRADE':'Grade A','LOCAL':'local'}[r.policy_scope],int(r.n),fmt(r.rho),f'[{fmt(r.LOYO_min)}, {fmt(r.LOYO_max)}]'])
    for scope,name in [('HABITAT_2023_LOWER','2023 habitat low'),('HABITAT_2023_UPPER','2023 habitat high'),('A_GRADE','Grade A'),('LOCAL','Local')]:
        q=ass[(ass.scope==scope)&(ass['mode']=='level')&(ass.state_a=='G')&(ass.state_b=='ES')].iloc[0];rows.append(['G–ES',name,int(q.n),fmt(q.rho),f'[{fmt(q.loo_min)}, {fmt(q.loo_max)}]'])
    add('TableS5','Historical associations and measurement sensitivity',['Pair','Setting','n','ρ','LOYO range'],rows,'G2–H uses 2011–2022 and the common 10-km measurement reference. G–ES endpoint alternatives use the 2023 bridge sensitivity, not new observations. Full component associations, descriptive p values, exact member IDs and support arrays remain in Data S2. All and Grade A differ in membership even when Spearman ranks agree.',['G2_H_and_related_scope_statistics.csv','associations_and_sensitivities.csv'],[.13,.34,.08,.15,.30],'B. Spatial and endpoint sensitivity')
    z=old('Scenarios_source.csv');rows=[[r.scenario,fmt(r.min_ES_median),fmt(r.ES_2030_median),fmt(r.median_D_SR_2030,5), 'Pass' if r.main_screen_pass else 'Fail'] for r in z.itertuples()]
    add('TableS6','Scenario outcomes and key sensitivity results',['Scenario','Minimum ES, 2026–2030','ES in 2030','Paired ΔSR in 2030 versus S0','Social screen'],rows,'All scenarios use the main 600 retained vectors, 2023 RESET and matched forcing. State entries are parameter medians; ΔSR is the median of per-vector paired differences. The social screen is median ΔSR ≥ −0.0005. S5 fails. A trajectory minimum is calculated before pairing and ensemble summarization. Lever definitions and τ appear in Supplementary Methods.',['Scenarios_source.csv'],[.12,.25,.19,.28,.16],'A. Main scenarios')
    init=c.data('initialization_pairs');gate=c.data('gate_summary');rows=[]
    for ini in ['RESET','CONTINUATION']:
        vals=[]
        for metric in ['min_ES_2026_2030','SR_2030']:
            q=init[(init.contrast=='S4-S6')&(init.metric==metric)][ini];vals.append(interval(q.median(),q.quantile(.05),q.quantile(.95),3,1000))
        rows.append([ini.title(),'0.30',100]+vals)
    for ini in ['RESET','CONTINUATION']:
        for mid in sorted(gate.midpoint.unique()):
            vals=[]
            for metric in ['min_ES_2026_2030','SR_2030']:
                q=gate[(gate.contrast=='S4-S6')&(gate.metric==metric)&(gate.initialization==ini)&(gate.midpoint==mid)].iloc[0];vals.append(interval(q['median'],q.P5,q.P95,3,1000))
            rows.append([ini.title(),fmt(mid,2),12]+vals)
    add('TableS6','Scenario outcomes and key sensitivity results',['Initialization','Gate midpoint','Parameter n','S4−S6 minimum ES, ×10⁻³ [P5, P95]','S4−S6 terminal SR, ×10⁻³ [P5, P95]'],rows,'The 100-vector initialization comparison and separate 12-vector gate experiment are distinct matched subsets. Continuation and high-gate adverse results are retained. Intervals describe finite parameter sets. Prior SM local forward sensitivity changed α SM by −0.1 for 12 vectors and fixed starts: the maximum difference-of-contrasts was 3.793×10⁻⁶, with no tolerance-category changes. This local result does not establish global identifiability. Full 54-row sensitivity and all specifications remain in Data S4.',['INITIALIZATION_EFFECT_BY_PARAMETER.csv','AC_GATE_PAIRED_SUMMARY.csv','SM_LOCAL_FORWARD_SUMMARY.csv'],[.20,.12,.12,.28,.28],'B. Initialization and capacity-gate sensitivity')
    sh=old('TableS6_source.csv');pairs=c.data('paired');rows=[]
    glabel={'policy_G1_G2_G3':'G1/G2/G3 supply','response_eta_tau':'η/τ response','feedback':'Feedback','synergy':'Synergy proxy','G3':'G3 supply','tau':'τ response'}
    for contrast in ['S4-S0','S4-S6']:
        for group in (['policy_G1_G2_G3','response_eta_tau','feedback','synergy'] if contrast=='S4-S0' else ['G3','tau','feedback']):
            vals=[]
            for metric in ['min_ES_2026_2030','ES_2030','SR_2030']:
                q=sh[(sh.contrast==contrast)&(sh.metric==metric)&(sh['group']==group)].iloc[0];vals.append(interval(q['median'],q.P5,q.P95,3,1000))
            rows.append([contrast.replace('-','−'),glabel[group]]+vals)
        q=pairs[pairs.contrast==contrast];rows.append([contrast.replace('-','−'),'True paired total']+[interval(q[f].median(),q[f].quantile(.05),q[f].quantile(.95),3,1000) for f in ['D_min_ES_2026_2030','D_ES_2030','D_SR_2030']])
    add('TableS7','Matched grouped Shapley decompositions',['Contrast','Factor group','Minimum ES, ×10⁻³','2030 ES, ×10⁻³','2030 SR, ×10⁻³'],rows,'Entries are median [P5, P95] for all 600 matched vectors. S4−S0 uses four groups and S4−S6 uses three actual differing factors. Totals are read from per-vector paired results, not sums of component medians. Negative feedback remains. This is matched attribution within the SD model, not ML-SHAP or an independently identified causal policy effect. Full coalition endpoints and per-vector closure residuals are in Data S4.',['TableS6_source.csv','four_primary_paired_differences.csv'],[.13,.21,.22,.22,.22])
    c.js(TABLES,O/'TABLE_SPEC.json');c.js(TABLES,O/'tables_payload_R3.json')
    print('Built3 main tables and7 themed supplements; split parts',len(TABLES),flush=True)
def tables():
    build_views()
    sig=hashlib.sha256(''.join(c.sha(p) for p in [O/'tables_payload_R3.json',O/'TABLE_STYLE_SOURCE_AUDIT.json',O/'SOURCE_INPUTS.csv',c.CODE/'report_documents.py',c.CODE/'report_workbook.mjs',c.CODE/'report_publication_tables.py']).encode()).hexdigest()
    cache=O/'TABLE_REPORT_CACHE.json'
    if cache.exists():
        z=json.loads(cache.read_text('utf8'))
        if z['signature']==sig and all((O/k).is_file() and c.sha(O/k)==v for k,v in z['outputs'].items()):
            print('Valid R3 display-table cache; all artifacts checked',flush=True);return
    env=dict(os.environ,PYTHONIOENCODING='utf-8',B1_REPORT_DIR=str(O))
    exits=[]
    for cmd in [[str(BUNDLE/'python/python.exe'),str(c.CODE/'report_documents.py')],[str(BUNDLE/'node/bin/node.exe'),str(c.CODE/'report_workbook.mjs'),str(O)]]:
        p=subprocess.run(cmd,capture_output=True,text=True,encoding='utf8',env=env);(O/'logs'/('author_'+Path(cmd[1]).stem+'.log')).write_text(p.stdout+p.stderr,'utf8')
        exits.append(dict(command=cmd,exit_code=p.returncode))
        if p.returncode and (Path(cmd[1]).suffix!='.mjs' or 'New workbook exported 10 sheets' not in p.stdout):raise RuntimeError('Authoring failed '+str(cmd)+p.stderr[-1500:])
    # Native artifact worker can report exit1 after a completed export. Never infer success from its text alone.
    workbook_readback();c.js(dict(processes=exits,export_verified_independently=True,native_exit_note='Actual worker status retained; nonzero accepted only after complete cell readback and ZIP verification'),O/'AUTHORING_PROCESS_QA.json')
    p=subprocess.run(['powershell','-NoProfile','-ExecutionPolicy','Bypass','-File',str(c.CODE/'report_render_word.ps1'),'-ReportDir',str(O)],capture_output=True,env=env)
    (O/'logs/DOCX_RENDER_LOG.txt').write_bytes(p.stdout+p.stderr)
    if p.returncode:raise RuntimeError('Native Word render failed')
    names=['Publication_Tables.xlsx','WORKBOOK_EXPECTED_CELLS.json','WORKBOOK_QA.json','DOCX_RENDER_QA.json']+[n+ext for n in ['Main_Result_Tables_2_4','Supplementary_Tables_S1_S7','Supplementary_Methods_equations'] for ext in ['.docx','.pdf']]
    c.js(dict(signature=sig,outputs={n:c.sha(O/n) for n in names}),cache)
def workbook_readback():
    from openpyxl import load_workbook
    p=O/'Publication_Tables.xlsx'
    with zipfile.ZipFile(p) as z:assert z.testzip() is None
    exp=json.loads((O/'WORKBOOK_EXPECTED_CELLS.json').read_text('utf8'));wb=load_workbook(p,data_only=True,read_only=True);bad=[];n=0
    for sh in exp:
        rows=list(wb[sh['sheet']].iter_rows(values_only=True))
        for e in sh['entries']:
            got=rows[e['row']-1][e['col']-1];want=e['value'];n+=1
            if got!=want:bad.append([sh['sheet'],e,got])
    assert len(wb.sheetnames)==10 and not bad,str(bad[:3]);wb.close()
    c.js(dict(current_payload_cell_count=n,mismatches=bad,sheets=10,all_current_sheet_names=[s['sheet'] for s in exp],xlsx_sha256=c.sha(p),method='Independent saved XLSX ZIP and openpyxl read-only cell comparison; no old workbook reuse'),O/'WORKBOOK_QA.json')
def run(stage):
    funcs={'audit':check_inputs,'prepare':prepare,'figures':lambda:__import__('report_r2_figures').render(),'tables':tables,'verify':verify,'package':release}
    for name in ['audit','prepare','figures','tables','verify','package'] if stage=='all' else [stage]:
        start=time.time();print('R3',name,flush=True);funcs[name]();(O/'logs').mkdir(exist_ok=True)
        if name!='package':
            with (O/'logs/execution.jsonl').open('a',encoding='utf8') as f:f.write(json.dumps(dict(stage=name,elapsed_seconds=time.time()-start,success=True))+'\n')
def verify():
    from report_r3_checks import verify
    verify()
def release():
    from report_r3_checks import release
    release()

