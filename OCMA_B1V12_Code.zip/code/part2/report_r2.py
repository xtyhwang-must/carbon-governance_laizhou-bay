"""Read-only report chain. Never import the numerical model or start an ODE."""
from pathlib import Path
import argparse,ast,csv,hashlib,json,os,platform,re,shutil,subprocess,sys,time,zipfile
import numpy as np
import pandas as pd

CODE=Path(__file__).resolve().parent
ROOT=CODE.parent
OUT=Path(os.environ.get('B1_REPORT_DIR',str(ROOT/'07_publication/R3_FIGURE_TABLE_POLISH_20261029')))
R1=ROOT/'07_publication/R1_20261029'
RUN='B1V12_PART2_HT_20261028'
PART1=ROOT.parents[1]/'outputs/B1_V1.2_PART1_CURRENT_REPORT'
DIAG=ROOT.parents[1]/'outputs/B1_V1.2_SC_INIT_GATE_LOGIT_DIAGNOSTIC_20261029'
MAP=CODE/'report_result_map.json'
STYLE=CODE/'report_style.json'
CALLS=[]

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def js(x,p):
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(x,ensure_ascii=False,indent=2,default=lambda z:float(z) if isinstance(z,np.floating) else int(z) if isinstance(z,np.integer) else bool(z) if isinstance(z,np.bool_) else str(z)),encoding='utf8')
def csvout(x,p):
    p.parent.mkdir(parents=True,exist_ok=True);x.to_csv(p,index=False,encoding='utf-8-sig',float_format='%.17g');return x
def table(p):return pd.read_csv(p)
def source(key):
    entry=json.loads(MAP.read_text('utf8'))['sources'][key]
    packed=OUT/'source_data'/entry['scope']/entry['path']
    if packed.is_file():return packed
    base={'p2':ROOT,'part1':PART1,'diagnostic':DIAG}[entry['scope']]
    return base/entry['path']
def data(key):return table(source(key))
def protected():
    snap=json.loads((OUT/'PRE_CLEANUP_SNAPSHOT.json').read_text('utf8'))
    for x in snap['protected']:
        if sha(x['path'])!=x['sha256']:raise RuntimeError('Frozen numerical/result content changed: '+x['path'])
    return snap
def guard(frame,event,arg):
    if event!='call':return
    if frame.f_code.co_name not in {'simulate','rhs','integrate','simulate_fast','solve_ivp','odeint','minimize','least_squares','differential_evolution','quad','main','evaluate'}:return
    p=Path(frame.f_code.co_filename)
    if p.name in ['sd_model.py','fast_kernel.py','numeric_calibration.py','v12_formal_calibration.py','v12_modeling.py','v12_scenarios.py','v12_attribution.py','v12_mechanisms.py','v12_response_surface.py']:
        raise RuntimeError('Report chain attempted numerical execution: '+str(p)+':'+frame.f_code.co_name)
    if 'scipy' in str(p) and ('optimize' in p.parts or 'integrate' in p.parts) and frame.f_code.co_name in ['minimize','least_squares','differential_evolution','solve_ivp','odeint','quad']:
        raise RuntimeError('Optimizer/integrator is prohibited during reporting')

def prepare():
    protected();config=json.loads(MAP.read_text('utf8'));records=[]
    for key,e in config['sources'].items():
        base={'p2':ROOT,'part1':PART1,'diagnostic':DIAG}[e['scope']];p=base/e['path']
        if not p.is_file():raise FileNotFoundError(key+': '+str(p))
        dest=OUT/'source_data'/e['scope']/e['path'];dest.parent.mkdir(parents=True,exist_ok=True)
        if not dest.exists() or sha(dest)!=sha(p):shutil.copy2(p,dest)
        records.append(dict(key=key,path=dest.relative_to(OUT).as_posix(),original_path=str(p),sha256=sha(p),identity=e['identity']))
    csvout(pd.DataFrame(records),OUT/'SOURCE_INPUTS.csv')
    for folder in ['tables','diagnostic_evidence','SM_local_results']:
        if (R1/folder).exists():shutil.copytree(R1/folder,OUT/folder,dirs_exist_ok=True)
    # These reporting tables were already reconciled in R1. No numerical recomputation.
    for name in ['CURRENT_SUPPLEMENT_INDEX.csv','REPORTING_LINEAGE_CORRECTIONS.csv','DIAGNOSTIC_INTEGRATION_MAP.csv','executed_model_specification.json','REVIEWER_CHANGE_EVIDENCE.csv']:
        if (R1/name).exists():shutil.copy2(R1/name,OUT/name)
    idx=table(OUT/'CURRENT_SUPPLEMENT_INDEX.csv');idx['source_scope_root']=idx['source_scope_root'].str.replace(str(R1),str(OUT),regex=False)
    idx['source_csv']=idx['source_csv'].str.replace('source_data/','source_data/p2/',regex=False)
    # Exact frozen Part1 sources are copied, not recomputed or restyled.
    for i,row in idx.iterrows():
        if str(row.source_scope_root)==str(PART1):
            dest=OUT/'frozen_part1'/row.source_csv;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(PART1/row.source_csv,dest)
            idx.loc[i,'source_scope_root']=str(OUT);idx.loc[i,'source_csv']='frozen_part1/'+row.source_csv
    csvout(idx,OUT/'CURRENT_SUPPLEMENT_INDEX.csv')
    # Verify actual arrays, ranks and membership separately; equal rho alone is insufficient.
    from scipy.stats import rankdata
    reg=data('policy_shares').merge(data('admission')[['policy_id','text_evidence_grade']],on='policy_id',validate='one_to_one')
    allids=set(reg.policy_id);aid=set(reg.loc[reg.text_evidence_grade.eq('A'),'policy_id'])
    series=data('g2_series');rows=[]
    for scope in ['ALL_ELIGIBLE','A_GRADE','LOCAL']:
        a=series[series.policy_scope.eq(scope)&series.coastal_band_km.eq(10)].sort_values('year')
        b=series[series.policy_scope.eq(scope)&series.coastal_band_km.eq(20)].sort_values('year')
        for var in ['G2','H','TF','SM','ES']:
            x=a[var].to_numpy();y=b[var].to_numpy()
            rows.append(dict(check='10km_vs_20km',scope=scope,variable=var,n=len(x),array_equal=np.array_equal(x,y),max_abs_difference=float(np.max(abs(x-y))),ranks_equal=np.array_equal(rankdata(x),rankdata(y)),interpretation='RANK_AND_VALUE_SEPARATELY_CHECKED'))
    rows.append(dict(check='A_grade_vs_all_members',scope='POLICY',variable='policy_id',n=len(allids),array_equal=allids==aid,max_abs_difference=len(allids^aid),ranks_equal=None,interpretation='ACTUAL_MEMBER_SET_COMPARISON;EQUAL_RHO_NOT_EQUAL_MEMBERS'))
    csvout(pd.DataFrame(rows),OUT/'G2_H_MEMBERSHIP_ARRAY_RANK_CHECK.csv')
    write_docs();print('Prepared frozen figure/table sources; no numerical calculation',flush=True)

def cleanup_log():
    snap=json.loads((OUT/'PRE_CLEANUP_SNAPSHOT.json').read_text('utf8'));inventory=table(OUT/'DEPENDENCY_INVENTORY.csv').set_index('path')
    applied={r['path']:r for r in json.loads((OUT/'CLEANUP_APPLIED.json').read_text('utf8'))};rows=[]
    for rec in snap['files']:
        rel=rec['path'];p=ROOT/rel;after=sha(p) if p.is_file() else '';op=applied.get(rel,{})
        changed=rec['sha256']!=after
        classification=inventory.loc[rel,'classification'] if rel in inventory.index else 'ARCHIVE_REQUIRED'
        if rel in inventory.index and inventory.loc[rel,'reference_count']==0 and classification=='NUMERIC_REPRODUCTION_REQUIRED':classification='UNRESOLVED_DEPENDENCY'
        if op:classification='DEAD_OR_DUPLICATE' if op['action']!='RETAIN_REGISTRY_ONLY' else 'REPORT_ACTIVE'
        reason=op.get('symbol','Retained for formal numerical reproduction, supported tests, source contracts or audit evidence' if classification!='UNRESOLVED_DEPENDENCY' else 'No direct caller found; standalone CLI/historical use not excluded. Retained rather than inferred dead from report non-use.')
        if rel.endswith('report_revision_20261029.py'):reason='Single report entry replaced by read-only R2 chain; R1 integrators remain archived, not exposed by report all'
        if rel=='BASELINE_README.md':reason='Correct current M3/run/report metadata; inherited M0 statement archived'
        refs=inventory.loc[rel,'references'] if rel in inventory.index else ''
        rows.append(dict(path=rel,symbol_or_lines=str(op.get('removed_ranges','entire file' if changed else 'retained')),classification=classification,dependency_evidence=str(refs),action=op.get('action','UPDATE' if changed else 'RETAIN'),archive_or_commit_reference=rec['archive'],before_sha256=rec['sha256'],after_sha256=after,reason=reason,tests_executed='syntax; help; dependency existence; read-only report run; protected hashes' if changed else 'static dependency inventory'))
    known={r['path'] for r in snap['files']}
    for p in CODE.glob('report_*'):
        rel=p.relative_to(ROOT).as_posix()
        if p.is_file() and rel not in known:rows.append(dict(path=rel,symbol_or_lines='new report-only module/config',classification='REPORT_ACTIVE',dependency_evidence='single report entry; result map/style',action='ADD',archive_or_commit_reference='new in this reporting revision',before_sha256='',after_sha256=sha(p),reason='Pure frozen-result preparation, display or export; numerical modules not imported',tests_executed='syntax; CLI; real report run; numerical-call guard'))
    csvout(pd.DataFrame(rows),OUT/'CODE_CLEANUP_LOG.csv')

def tables():
    # Reuse exact, verified R1 workbook. No authoring or native teardown is repeated.
    xlsx=next(R1.glob('*结果表.xlsx'));dest=OUT/'B1_V1.2_PART2_R2_results.xlsx';shutil.copy2(xlsx,dest)
    from openpyxl import load_workbook
    payload=json.loads((R1/'tables_payload.json').read_text('utf8'));book=load_workbook(dest,read_only=True,data_only=True)
    count=0;bad=[]
    for item in payload:
        if item['name'] not in book.sheetnames:raise ValueError('Missing workbook sheet '+item['name'])
        sh=book[item['name']]
        # Verified original artifact builder places column headers at row1.
        gotrows=sh.iter_rows(min_row=1,max_row=len(item['rows']),max_col=len(item['rows'][0]),values_only=True)
        for i,(row,gotrow) in enumerate(zip(item['rows'],gotrows),1):
            for j,(want,got) in enumerate(zip(row,gotrow),1):
                count+=1
                if isinstance(want,(int,float)) and not isinstance(want,bool):ok=isinstance(got,(int,float)) and abs(got-want)<=1e-12*max(1,abs(want))
                else:ok=(got==want) or (want is None and got is None)
                if not ok:bad.append((item['name'],i,j,str(want),str(got)))
    book.close()
    if bad:raise ValueError('Workbook readback mismatch '+str(bad[:3]))
    js(dict(sheets=len(payload),actual_cells_checked=count,mismatches=len(bad),operation='BYTE_IDENTICAL_R1_WORKBOOK_REUSE_WITH_FULL_READBACK',sha256=sha(dest),source_sha256=sha(xlsx),authoring_process_started=False,prior_native_exit_record_retained='R1/WORKBOOK_QA.json'),OUT/'WORKBOOK_QA.json')
    print('Reused stable workbook, readback',len(payload),'sheets',count,'cells',flush=True)

def write_docs():
    (OUT/'ACTIVE_PIPELINE_MAP.md').write_text('''# Current execution map

The default report command is `05_code/report_revision_20261029.py --stage all`.
It reads frozen CSVs, draws figures, reuses verified tables/workbook, checks and packages.
It does not import numerical model modules, optimize, integrate, rebuild annual inputs or calculate coalitions.

`05_code/run_v12.py` is retained for formal numerical reproduction. Its `rebuild-inputs`,
`compare`, `calibrate`, `evaluate`, `scenarios`, `robustness`, `attribution`, `mechanisms`,
`surface` and `replay` commands remain available; none is executed during R2.
M0/M1/M2 implementations remain necessary for recorded structure comparisons.

`numeric_analysis.py` provides forcing/summary helpers used by numerical stages.
`build_policy_interface.py::load_legacy_kernels` still loads historical kernels from
`00_handoff/historical_code_reference`; those local dependencies are retained rather than cosmetically renamed.
`report_revision_outputs.py` now only owns the shared equation registry required by `part2_tables.register`.
Its superseded R1 drawing/export functions, the R1-only PDF script and workbook builder are removed from active code.
R1 code is preserved both in its original release snapshot and in `archive_before_cleanup`.

Original numerical code: `07_publication/R1_20261029/archive_pre_revision`.
Original numerical manifest: `07_publication/PART2_MANIFEST.json` (unchanged).
Current report code was not used to calibrate the original 600 vectors.
''',encoding='utf8')
    (OUT/'FIGURE_LAYOUT_SPEC.md').write_text('''# Figure contract and layout

Backend: existing Python Matplotlib, editable SVG/PDF and 450 dpi PNG. White background,
178 mm page width; 8–9 pt axes, 9–10 pt titles, 11–12 pt panel letters.
All statistical units, adverse results and finite-ensemble interval identities are retained.

3: schematic-led composite, triangular governance/social/ecological layout; model-defined signs.
4: frozen Part1 ternary policy composition + Taylor design approximation (reused unchanged).
5: constructed annual levels + common-scale signed annual-change strip, not SD fitted histories.
6: six raw point clouds: levels and first differences; no fit or threshold search.
7: 3x3 G2–H bubble matrix + precise G–ES result table; LOYO is not a confidence interval.
8: directed three-node ablation chord + annual heatmap + joint nonadditivity cards + actual 13x13 surface.
9: seven unsmoothed median trajectories with direct endpoint labels; all ranges in S7.
10: parameter-paired rainclouds and grouped Shapley swarms; true metric coordinates never jitter.
11: complete specification matrix + matched100 initialization scatter + distinct12 gate matrix.

Figure4, Table2, S1, S7–S14 frozen source statistics remain untouched.
The main Figure10 metric is minimum ES for both Shapley contrasts; ES2030/SR remain in TableS6/CSV.
''',encoding='utf8')
    (OUT/'RUN_AND_ARTIFACT_LINEAGE.md').write_text(f'''# R2 report-only revision

Numerical run: `{RUN}`; M3_AC_SM_TF_INTERCEPTS, 12 parameters, retained600.
Current result identity: R2_FIGURE_CLEANUP_20261029 over original formal results and completed R1 diagnostics.
No optimization, ODE, threshold search, new climate draw or new ablation/coalition is performed.
R1 SM72 trajectories, gate216 cells and initialization100 are reused.

Existing-workspace command (independent of cwd):
`& "{ROOT.parent/'.venv/Scripts/python.exe'}" "{CODE/'report_revision_20261029.py'}" --stage all`
Light check: same command with `--stage verify`.
Cleanup commands: `code_cleanup_20261029.py --mode plan` / `--mode apply`;
apply only consumes its fixed, hash-bound allowlist and never recursively deletes a directory.

Figure source inputs are copied under source_data with source hashes in SOURCE_INPUTS.csv.
Original calibration modules are available at R1/archive_pre_revision, and historical pure-function
dependencies remain in the working project. These are verified for existence, not rerun in R2.
Portable plotting uses the same report module and the included result map/style.
The package includes CSVs needed to draw the figures and current report modules; it is not
a full new-machine calibration package containing all 68 policy texts/county source carriers.
Python dependencies: numpy, pandas, scipy, matplotlib, PyYAML, openpyxl (read only).
Neutral PDF merge/inspection uses bundled pypdf; no figure redraw or page scaling occurs there.
The workbook is an exact copy of verified R1 authoring output; all data cells are rechecked,
with no new authoring worker started. Original R1 native exit and controlled shutdown remain in historical QA.

Word full-text edits remain deferred. Reporting completion does not strengthen model validation.
Six of seven state median retrospective RMSEs fail at least one simple baseline.
RESET2023 scenario advantage is conditional; continuation/gate sensitivity and negative contributions remain visible.
''',encoding='utf8')

def figures():
    dependencies=[CODE/'report_r2_figures.py',STYLE,MAP]
    dependencies += [OUT/r.path for r in table(OUT/'SOURCE_INPUTS.csv').itertuples()]
    signature=hashlib.sha256(json.dumps([(str(p.relative_to(OUT)) if p.is_relative_to(OUT) else p.name,sha(p)) for p in dependencies],sort_keys=True).encode()).hexdigest()
    cache=OUT/'REPORT_FIGURE_CACHE.json'
    if cache.is_file():
        old=json.loads(cache.read_text('utf8'))
        if old['signature']==signature and all((OUT/r['path']).is_file() and sha(OUT/r['path'])==r['sha256'] for r in old['outputs']):
            print('Reused valid figure-only cache; numerical caches never touched',flush=True);return
    from report_r2_figures import render
    render()
    outputs=[p for d in ['figures','plot_data'] for p in (OUT/d).glob('*') if p.is_file()]
    outputs += [OUT/n for n in ['FIGURE_NUMERIC_QA.json','FIGURE_TEXT_BOUNDS.json','FIGURE_CAPTIONS.md']]
    js(dict(signature=signature,identity='REPORT_ONLY_SOURCE_STYLE_CODE_CACHE;NOT_NUMERICAL_CACHE',outputs=[dict(path=p.relative_to(OUT).as_posix(),sha256=sha(p)) for p in outputs]),cache)

def verify():
    protected();checks=[]
    def ck(name,ok,detail):
        checks.append(dict(check=name,passed=bool(ok),detail=str(detail)))
        if not ok:raise AssertionError(name+': '+str(detail))
    for p in CODE.rglob('*.py'):
        if '__pycache__' in p.parts:continue
        ast.parse(p.read_text('utf-8-sig'))
    ck('Active Python syntax',True,'AST parse; no import-time input build')
    for path in ['run_v12.py','numeric_analysis.py','numeric_calibration.py','v12_replay.py','compare_structures.py','build_policy_interface.py']:
        ck('Numerical reproduction dependency retained '+path,(CODE/path).is_file(),'existence only; no ODE/recalibration')
    for name in ['report_revision_pdf.py','report_revision_workbook.mjs']:
        ck('Superseded active exporter actually removed '+name,not(CODE/name).exists(),'archived code remains accessible')
    # Independent paired-minimum verification from existing annual curves, no simulator.
    tr=data('scenario_trajectories');metrics=data('scenario_metrics')
    calc=tr[tr.year.between(2026,2030)].groupby(['parameter_set_id','scenario']).ES.min()
    stored=metrics.set_index(['parameter_set_id','scenario']).min_ES_2026_2030
    ck('Minimum ES before pairing',np.max(abs(calc-stored))<1e-12,float(np.max(abs(calc-stored))))
    pairs=data('paired')
    errs=[]
    for r in pairs.itertuples():
        a,b=r.contrast.split('-');errs.append(abs(calc.loc[(r.parameter_set_id,a)]-calc.loc[(r.parameter_set_id,b)]-r.D_min_ES_2026_2030))
    ck('Stored parameter paired minima',max(errs)<1e-12,max(errs))
    sh=data('shapley');closures=sh.groupby(['parameter_set_id','contrast','metric']).agg(sum_component=('contribution','sum'),total=('total_paired_delta','first'))
    ck('Two grouped Shapley sums match true per-vector totals',np.max(abs(closures.sum_component-closures.total))<1e-10,np.max(abs(closures.sum_component-closures.total)))
    ep=data('shapley_endpoints');ck('Coalition endpoint matches',ep['pass'].all(),len(ep))
    effects=data('ablations');e=effects[effects.metric=='ES_2030'].pivot(index='parameter_set_id',columns='disabled_link_spec',values='contribution_full_minus_ablated')
    joint=data('nonadditivity');joint=joint[(joint.metric=='ES')&(joint.year==2030)].set_index(['parameter_set_id','pair']).nonadditivity
    joint_errors=[]
    for pair,aa,bb in [('G_S_reciprocal','G_to_S','S_to_G'),('G_E_reciprocal','G_to_E','E_to_G'),('S_E_reciprocal','S_to_E','E_to_S')]:
        expected=e[pair]-e[aa]-e[bb]
        joint_errors.extend(abs(expected-joint.xs(pair,level='pair')))
    ck('Joint J independently recomputed within each vector',max(joint_errors)<1e-12,max(joint_errors))
    annual=data('ablation_annual');annual=annual[(annual.metric=='ES')&(annual.year==2030)]
    ae=annual.pivot(index='parameter_set_id',columns='link',values='effect')
    ck('Annual2030 effects match terminal ES effects',np.max(abs((ae-e).to_numpy()))<1e-12,np.max(abs((ae-e).to_numpy())))
    archived=OUT/'archive_before_cleanup/05_code'
    def functions(p):return {n.name:n for n in ast.parse(p.read_text('utf-8-sig')).body if isinstance(n,ast.FunctionDef)}
    old=functions(archived/'build_evidence.py');new=functions(CODE/'build_evidence.py')
    for name,fn in old.items():
        for i,node in enumerate(fn.body):
            if isinstance(node,(ast.Raise,ast.Return)):fn.body=fn.body[:i+1];break
        ck('Reachable input-build AST unchanged '+name,ast.dump(fn,include_attributes=False)==ast.dump(new[name],include_attributes=False),'unreachable tail only removed')
    ck('Shared equation-registry implementation unchanged',ast.dump(functions(archived/'report_revision_outputs.py')['build_complete_equation_registry'],include_attributes=False)==ast.dump(functions(CODE/'report_revision_outputs.py')['build_complete_equation_registry'],include_attributes=False),'report registry still available to formal tables')
    snap=json.loads((OUT/'PRE_CLEANUP_SNAPSHOT.json').read_text('utf8'));before={r['path']:r['sha256'] for r in snap['files']}
    numerical_paths=['05_code/engine/sd_model.py','05_code/engine/fast_kernel.py','05_code/numeric_analysis.py','05_code/v12_scenarios.py','05_code/v12_modeling.py','05_code/cache_safety.py','00_contract/baseline_contract.yaml','00_contract/structure_selection_protocol.yaml']
    ck('Numeric cache dependencies unchanged by report cleanup',all(sha(ROOT/p)==before[p] for p in numerical_paths),'Report layout/config/code is outside the declared numerical signature dependencies; old signatures not rewritten')
    # Matrix identity is sample-specific, not main600 in disguise.
    init=data('initialization_pairs');q=init[(init.contrast=='S4-S6')&(init.metric=='min_ES_2026_2030')]
    ck('Initialization scatter exact matched100',len(q)==100 and q.parameter_set_id.is_unique,len(q))
    gate=data('gate_summary');ck('Gate matrix distinct12 identity',set(gate.n)=={12},gate.n.unique())
    ck('Formal vectors remain600',data('accepted').parameter_set_id.nunique()==600,data('accepted').parameter_set_id.nunique())
    src=table(OUT/'SOURCE_INPUTS.csv')
    ck('Copied input hashes match frozen source',all(sha(OUT/r.path)==r.sha256 for r in src.itertuples()),len(src))
    idx=table(OUT/'CURRENT_SUPPLEMENT_INDEX.csv');missing=[]
    for row in idx.itertuples():
        for p in row.source_csv.split(' | '):
            if not (Path(row.source_scope_root)/p).is_file():missing.append((row.table,p))
    ck('All frozen and current supplement source paths resolve',not missing,missing)
    ck('Frozen Table2 remains exact Bootstrap source',sha(source('part1_table2'))==sha(PART1/'CURRENT_TABLE2.csv'),'No Table2 recomputation or Taylor substitution')
    w=json.loads((OUT/'WORKBOOK_QA.json').read_text('utf8'))
    ck('Workbook full readback',w['mismatches']==0,w)
    c=json.loads((OUT/'FIGURE_NUMERIC_QA.json').read_text('utf8'))
    ck('Figure source calculations',all(r['passed'] for r in c),len(c))
    for n in range(3,12):
        for ext in ['svg','pdf','png']:ck(f'Figure{n} {ext} exists',(OUT/'figures'/f'Figure{n}.{ext}').is_file(),'generated or exact Part1 reuse')
    ck('No numerical modules imported during report',not any(n in sys.modules for n in ['sd_model','fast_kernel','numeric_calibration','v12_formal_calibration']),[n for n in sys.modules if n in ['sd_model','fast_kernel','numeric_calibration','v12_formal_calibration']])
    cleanup_log();csvout(pd.DataFrame(checks),OUT/'REPORT_QA.csv')
    print('Report checks passed:',len(checks),flush=True)

def package():
    from report_r2_release import release
    release()

def main():
    ap=argparse.ArgumentParser(description='Read frozen numerical results; report-only stages never simulate or optimize.')
    ap.add_argument('--stage',choices=['audit','prepare','figures','tables','verify','package','all'],default='all');a=ap.parse_args()
    OUT.mkdir(parents=True,exist_ok=True);sys.setprofile(guard)
    if 'R3_' in OUT.name:
        import report_publication_tables as pub
        pub.run(a.stage)
        sys.setprofile(None)
        return
    start=time.time()
    for stage in ['audit','prepare','figures','tables','verify','package'] if a.stage=='all' else [a.stage]:
        t=time.time();print('REPORT_STAGE',stage,flush=True)
        if stage=='audit':protected();cleanup_log()
        else:globals()[stage]()
        CALLS.append(dict(stage=stage,elapsed_seconds=time.time()-t))
    sys.setprofile(None)
    print('Report-only completed',a.stage,'seconds',round(time.time()-start,2),flush=True)

if __name__=='__main__':main()
