"""Matched B1 v1.2 S0--S6 trajectories using the selected structural model."""
from __future__ import annotations
import hashlib,json,sys
from itertools import combinations
from concurrent.futures import ProcessPoolExecutor,as_completed
from pathlib import Path
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'05_code/engine'),str(ROOT/'05_code')]
import engine_config as cfg
import sd_model as model
from cache_safety import ChunkCache,signature,atomic_json
from v12_modeling import reference_for,sha
from v12_scenario_summary import metrics_from_trajectories,summarize,MATCH
from numeric_analysis import load_settings,climate_path,scenario_forcing

CAL=ROOT/'06_runs/formal_main/calibration'
OUT=ROOT/'06_runs/formal_main/scenarios'

def vector_job(args):
    pid,params,structure,frame,settings,climate=args
    initial=model.initial_state(frame,year=2023)
    ih=hashlib.sha256(np.asarray(initial,float).tobytes()).hexdigest()
    historical=model.historical_forcing(frame)
    ref=reference_for(frame,historical,model.initial_state(frame,year=2011),params,structure)
    rh=hashlib.sha256(json.dumps(ref,sort_keys=True).encode()).hexdigest() if ref is not None else 'RUN_SPECIFIC'
    cells=[]
    for sid in sorted(settings):
        forcing,future,forcing_frame=scenario_forcing(frame,settings[sid],climate)
        fh=hashlib.sha256(forcing_frame.to_csv(index=False).encode()).hexdigest()
        result=model.simulate(params,forcing,np.arange(2023,2031,dtype=float),initial,
            structure=structure,reference_context=ref)
        if not np.allclose(result.iloc[0][cfg.STATE_NAMES].to_numpy(float),initial,atol=1e-12):
            raise AssertionError('Scenario first state differs from registered 2023 initial')
        result=result[result.year.ge(2024)].copy()
        result.insert(0,'forcing_sha256',fh)
        result.insert(0,'reference_context_sha256',rh)
        result.insert(0,'initial_state_hash',ih)
        result.insert(0,'forcing_draw_id','CLIM_20260725_001')
        result.insert(0,'parameter_set_id',pid)
        result.insert(0,'scenario',sid)
        result.insert(0,'cache_row_id',[f'{pid}:{sid}:{int(y)}' for y in result.year])
        cells.append(result)
    return pid,pd.concat(cells,ignore_index=True)

def main():
    OUT.mkdir(parents=True,exist_ok=True)
    frame=pd.read_csv(ROOT/'03_indicators/model_input_B1.csv').sort_values('year').reset_index(drop=True)
    if frame.year.tolist()!=list(range(2011,2024)):raise ValueError('Incomplete or duplicate year grid')
    status=json.loads((CAL/'formal_calibration_status.json').read_text(encoding='utf-8'))
    structure=status['structure'];names=model.parameter_names(structure)
    ensemble=pd.read_csv(CAL/'accepted_parameter_ensemble.csv')
    if ensemble.empty:raise RuntimeError('No accepted ensemble; cannot claim ensemble scenario results')
    if ensemble.parameter_set_id.duplicated().any():raise ValueError('Duplicate parameter_set_id')
    settings=load_settings();climate=climate_path(frame,shock=True)
    climate.to_csv(OUT/'common_climate_draw_001.csv',index=False)
    initial=model.initial_state(frame,year=2023)
    atomic_json(OUT/'initial_state_2023.json',dict(zip(cfg.STATE_NAMES,map(float,initial))))
    dependencies=[ROOT/p for p in ['03_indicators/model_input_B1.csv',
        '04_model/scenario_registry.csv','04_model/scenario_lever_audit.csv',
        '04_model/equation_registry.csv','04_model/parameter_registry.csv',
        '02_policy/reconstructed/policy_stock_by_year_B1.csv',
        '02_policy/reconstructed/interface_quantiles_B1.csv',
        '00_contract/baseline_contract.yaml','00_contract/structure_selection_protocol.yaml',
        '05_code/engine/sd_model.py','05_code/engine/engine_config.py',
        '05_code/engine/engine_common.py','05_code/numeric_analysis.py',
        '05_code/v12_modeling.py','05_code/v12_scenarios.py',
        '05_code/v12_scenario_summary.py','05_code/cache_safety.py',
        '06_runs/formal_main/calibration/accepted_parameter_ensemble.csv']]
    dependencies.append(OUT/'common_climate_draw_001.csv')
    vectors=ensemble[names].to_numpy(float)
    initial2011=model.initial_state(frame,year=2011)
    refs=[reference_for(frame,model.historical_forcing(frame),initial2011,
        dict(zip(names,map(float,v))),structure) for v in vectors]
    ref_hashes=[hashlib.sha256(json.dumps(r,sort_keys=True).encode()).hexdigest()
        if r is not None else 'RUN_SPECIFIC' for r in refs]
    key,material=signature(dependencies,{'structure':structure,'parameters':vectors.tolist(),
        'initial_year':2023,'initial_vector':initial.tolist(),'reference_year':2011,
        'reference_hashes':ref_hashes,'climate_draw_id':'CLIM_20260725_001',
        'solver_step':.05,'protocol':'TERMINAL_SR_THEN_MIN_ES_2026_2030'},
        code_version=cfg.CONTRACT['version'],root=ROOT)
    cache=ChunkCache(OUT/'cache',key,material)
    tasks=[];specs=[];required=['cache_row_id','scenario','year','ES','SR','parameter_set_id']
    for row in ensemble.itertuples(index=False):
        pid=row.parameter_set_id;params={n:float(getattr(row,n)) for n in names}
        ids=[f'{pid}:S{s}:{y}' for s in range(7) for y in range(2024,2031)]
        specs.append((pid,ids,required))
        if cache.load(pid,ids,required) is None:tasks.append((pid,params,structure,frame,settings,climate))
    with ProcessPoolExecutor(max_workers=8) as pool:
        futures=[pool.submit(vector_job,t) for t in tasks]
        for i,f in enumerate(as_completed(futures),1):
            pid,cells=f.result();ids=next(x[1] for x in specs if x[0]==pid)
            cache.commit(pid,cells,ids,required)
            if i%50==0 or i==len(futures):print(f'main scenario vectors={i}/{len(futures)}',flush=True)
    cache.finalize(specs)
    trajectories=pd.concat([cache.load(*spec) for spec in specs],ignore_index=True)
    if not np.isfinite(trajectories[cfg.STATE_NAMES].to_numpy(float)).all():raise AssertionError('Nonfinite state')
    if trajectories[cfg.STATE_NAMES].to_numpy(float).min()<-1e-9 or trajectories[cfg.STATE_NAMES].to_numpy(float).max()>1+1e-9:
        raise AssertionError('State outside [0,1]')
    trajectories.to_csv(OUT/'scenario_trajectories_long.csv',index=False,encoding='utf-8-sig')
    metrics=metrics_from_trajectories(trajectories)
    metrics.to_csv(OUT/'scenario_metrics_by_parameter.csv',index=False,encoding='utf-8-sig')
    social,screen,summary,pair_summary=summarize(metrics)
    social.to_csv(OUT/'social_screen_by_parameter.csv',index=False,encoding='utf-8-sig')
    screen.to_csv(OUT/'social_screen_summary.csv',index=False,encoding='utf-8-sig')
    summary.to_csv(OUT/'scenario_summary.csv',index=False,encoding='utf-8-sig')
    pair_summary.to_csv(OUT/'all_pair_tolerance_summary.csv',index=False,encoding='utf-8-sig')
    # Registered ecological distinguishability is 0.0005; endpoints 0 and
    # 0.001 are reported as sensitivity, never used to select the main rank.
    tolerance_rows=[]
    for metric_name in ['min_ES_2026_2030','ES_2030']:
        pivot=metrics.pivot(index=MATCH,columns='scenario',values=metric_name)
        for a,b in combinations(sorted(pivot.columns),2):
            delta=pivot[a]-pivot[b]
            for epsilon in [0.,.0005,.001]:
                tolerance_rows.append({'scenario_a':a,'scenario_b':b,'metric':metric_name,
                    'epsilon_ES':epsilon,'n_matched':len(delta),
                    'median_a_minus_b':float(delta.median()),
                    'median_distinguishable':bool(abs(delta.median())>epsilon),
                    'fraction_a_above_tolerance':float((delta>epsilon).mean()),
                    'fraction_b_above_tolerance':float((delta<-epsilon).mean()),
                    'fraction_within_tolerance':float((delta.abs()<=epsilon).mean())})
    pd.DataFrame(tolerance_rows).to_csv(OUT/'ecological_tolerance_sensitivity.csv',
        index=False,encoding='utf-8-sig')
    pair_rows=[]
    for a,b in [('S4','S0'),('S6','S0'),('S4','S6'),('S5','S0')]:
        aa=metrics[metrics.scenario.eq(a)].drop(columns='scenario')
        bb=metrics[metrics.scenario.eq(b)].drop(columns='scenario')
        merged=aa.merge(bb,on=MATCH,validate='one_to_one',suffixes=('_a','_b'))
        for r in merged.itertuples(index=False):
            d={k:getattr(r,k) for k in MATCH};d['contrast']=f'{a}-{b}'
            for col in ['min_ES_2026_2030','ES_2030','SR_2030','min_SR_2024_2030']:
                d['D_'+col]=getattr(r,col+'_a')-getattr(r,col+'_b')
            pair_rows.append(d)
    pd.DataFrame(pair_rows).to_csv(OUT/'four_primary_paired_differences.csv',index=False,encoding='utf-8-sig')
    atomic_json(OUT/'scenario_status.json',{'complete':True,'structure':structure,
        'parameter_sets':len(ensemble),'scenario_count':7,'trajectory_rows':len(trajectories),
        'paired_count':len(pair_rows),'cache_signature':key,'author_confirmation':'CONFIRMED_BY_AUTHOR',
        'input_sha256':sha(ROOT/'03_indicators/model_input_B1.csv'),
        'ensemble_sha256':sha(CAL/'accepted_parameter_ensemble.csv'),
        'model_code_sha256':sha(ROOT/'05_code/engine/sd_model.py'),
        'common_climate_sha256':sha(OUT/'common_climate_draw_001.csv'),
        'initial_year':2023,'initial_vector':initial.tolist(),'reference_year':2011,
        'ranking_definition':'terminal_median_SR_screen_then_min_ES_2026_2030_then_ES_2030',
        'result_selection_used_submitted_ranking':False})
    print(summary[['scenario','main_screen_pass','min_ES_median','ES_2030_median','main_rank']].to_string(index=False),flush=True)

if __name__=='__main__':main()
