from part2_ses import main
if __name__=="__main__":main()
