"""R3 cross-reference, export, protected-source checks and atomic report release."""
from pathlib import Path
import json,os,hashlib,shutil,zipfile,re,sys,ast,difflib
import pandas as pd
import numpy as np
import report_r2 as c
import report_publication_tables as pub
O=c.OUT;R=c.ROOT;OLD=pub.OLD
def captions():
    text='''# Current figure captions

Figure 3. Model-defined governance, social and ecological pathways. Circles are 13 integrated states; rounded boxes are derived quantities. Signs describe equations, not empirical effect sizes. The full M3 equations and final TF/SM area conversion appear in Supplementary Methods. This schematic does not validate an institutional network.

Figure 4. Governance-function composition in the fixed extracted-unit policy frame. (a) Exact HT policy shares in ternary coordinates, with boundary points retained without jitter or inward adjustment. (b) Four policy-equal stage means and 95% Taylor audit-design approximations. These exclude coder disagreement and frame omissions. Table 2 instead reports the frozen 2,000-replicate policy Bootstrap composition range. The 68 policy texts are distinct from 67 independent stock sources.

Figure 5. Constructed SES history. (a) Governance supply G, social resilience proxy SR and ecological support ES, 2011–2023 (13 annual values), using uniform continuous lines and markers. These are constructed historical indicators, not SD fitted trajectories. The 2023 ES value includes bridge-estimated habitat, although it is not specially marked in the panel. (b) Twelve adjacent-year changes on a shared signed color scale. Table 3 reports exact endpoints and trends.

Figure 6. Descriptive contemporaneous SES correspondence. Top: G–SR, G–ES and SR–ES levels; bottom: adjacent-year changes. All-year and exclusion-of-2023 Spearman coefficients and actual n appear above each panel. Prespecified year labels retain their observed coordinates. Hollow points identify the 2023 estimated ES involvement. No regression, smoothing or threshold search was added. Exact rho and leave-one-year/transition ranges are in Table S5 and Data S2; they do not identify causal policy effects.

Figure 7. Sensitivity of the G2–H association to spatial support and policy scope, 2011–2022 (n = 12). Bubble area is proportional to |rho| and the signed color scale is fixed at −1 to 1. All eligible, Grade A and local scopes comprise 68/50/33 policy texts and 67/49/32 independent stock sources. All and Grade A differ in membership and annual G2 values, despite equal ranks and coefficients in these settings. The 10/20-km H and ES values also differ despite equal ranks. Table 4 gives the nine coefficients; Table S5 gives LOYO ranges. Broader G–ES checks are retained in Table S5 and Data S2, not duplicated as another figure panel.

Figure 8. Model-internal pathway sensitivities under matched conditions. (a) Six directed ES2030 ablation effects; equal subsystem arcs and one common effect-width scale. Positive effects are red and negative effects blue. (b) Effects calculated within each of 100 matched parameter vectors before annual medians. (c) Reciprocal nonadditivity J = E_joint − E_a − E_b calculated within vectors, then summarized. (d) Frozen 24-vector, 13×13 response surface: each trajectory minimum over 2026–2030 precedes parameter aggregation. These are conditional model sensitivities, not observed causal network effects. Full values and intervals are in Data S4.

Figure 9. Seven scenario median ES paths, common forcing and 2023 RESET. All S0–S6 curves, including low S5 outcomes, use the frozen main 600 parameter vectors; no curve smoothing or endpoint movement is applied. Leader lines place labels outside the axes according to font height. The shaded period is the common 2026–2028 disturbance. Full finite-parameter P5–P95 ranges appear in Figure S7; they are not validated probabilistic forecasts.

Figure 10. Matched scenario contrasts and grouped Shapley attribution. (a) Per-trajectory minimum ES differences for four contrasts. (b) Terminal SR differences, with the −0.0005 screen shown as −0.5 on the ×10⁻³ axis. (c) S4−S0 four-group and (d) S4−S6 three-factor Shapley contributions to minimum ES. Horizontal coordinates are unchanged; category-axis offsets avoid overplotting. Each panel uses all 600 vectors. Negative feedback is retained. Redundant total rows are omitted from c/d; exact true paired totals, other metrics and per-vector closure remain in Table S7/Data S4. Component medians need not sum to the median total.

Figure 11. Conditional robustness and initialization sensitivity. (a) All existing ES-affecting specifications grouped as A reporting only, B fixed-parameter input/dynamics, C prior limited refit, with separate vector and climate-path counts. Four SR-only reporting settings are omitted from this ES matrix but their true SR/screen results remain in Data S4. Values use the original median of draw-specific paired medians. (b) Same 100 vectors under RESET and historical CONTINUATION for S4−S6 minimum ES. (c) Separate 12-vector gate experiment with RESET/CONTINUATION facets, showing median and P5–P95 at 0.20/0.30/0.40. The two y scales are explicit. Grey tolerance bands are ±0.5×10⁻³. Adverse continuation and 0.40-gate results are retained; different parameter subsets are not pooled.

Figure S1. Frozen within-stage paired G-function contrasts with audit-design approximations; unchanged Part 1 source and statistical identity.

Figure S2. Frozen complementary association results; unchanged R1 export. Full numeric records and applicable periods are indexed in Data S2. No new significance selection is performed.

Figure S3. Constructed governance (G1/G2/G3) and ecological (WQ/H) components. The duplicate total ES line has been removed because it is already in Figure 5. Component values and 2023 habitat-estimate status are unchanged.

Figure S4. Seven-state historical and retrospective model envelopes and simple benchmarks. All weak fits and estimated 2023 habitat observations remain. Table S4 provides per-vector error medians and actual coverage counts; 2021–2023 was previously viewed.

Figure S5. Finite retained-parameter support, fixed-other-parameter loss scans, target diagnostics and prior SM local sensitivity. Scans are not profile likelihood; ranges are not posterior intervals. The prior 72 additional SM forward cells are reused, not rerun. Exact parameters and errors appear in Table S3/Data S3/S4.

Figure S6. SC raw ratio inputs, change accounting and input-only aggregation sensitivity. This is not a new model refit. SC is the AC alias; a low standardized value does not imply negligible physical capacity.

Figure S7. All seven scenario P5–P95 parameter envelopes on common scales, with the same 600 vectors and forcing as Figure 9. These finite-set envelopes exclude unmodelled structural and observational uncertainties.
'''
    (O/'FIGURE_CAPTIONS.md').write_text(text,'utf8')
def documentation():
    captions()
    # Resolve and index every retained CSV, with exact rows/columns and source identities.
    for name,folder in [('Data_S1',R/'02_policy/reconstructed'),('Data_S2',R/'03_indicators'),('Data_S3',R/'06_runs/structure_compare')]:
        for p in folder.glob('*'):
            if p.is_file() and p.suffix in ['.csv','.json','.yaml']:
                dest=O/'data'/name/folder.name/p.name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
    for p in (R/'07_publication/figures').glob('*source_data.csv'):
        dest=O/'data/Data_S3/diagnostic_sources'/p.name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
    descriptions={'Data_S1':'Policy evidence, 528 audit and106 nested independent coding, fixed-frame HT/DIFF estimates, policy Bootstrap, source coverage and governance interface provenance. T2 remains unknown. Historical network counts are not a verified current network.', 'Data_S2':'Constructed annual SES inputs, fixed scales, endpoints/trends, full associations, spatial support and exact scope members. These are descriptive historical measurements, not model predictions.', 'Data_S3':'Structure comparisons,12parameter calibration, all candidate outcomes, weak fits, simple benchmarks, pure-parameter coverage, equations and protocols. Previously viewed retrospective years are not new blind validation.', 'Data_S4':'Seven scenarios, all paired contrasts, coalitions and per-vector attribution, directional/joint mechanisms, every robustness specification, initialization100, gate12 and prior SM72. Parameter and climate-path counts are distinct.'}
    definitions={'policy_id':'Stable policy-text identifier; not independent stock-source count','parameter_set_id':'Retained parameter-vector identity; not independent observed replicate','scenario':'Registered S0–S6 intervention setting','rho':'Spearman rank association; descriptive','median':'Median under the source-specific matched ensemble/aggregation','P5':'5th percentile of the source-specific finite set, not automatically a probability bound','P95':'95th percentile of the source-specific finite set, not automatically a probability bound','n':'Actual source-specific sample count; consult row identity','year':'Calendar year','standard_error':'Design-based approximation under the registered audit estimator','TP':'Unweighted true-positive count in the stated audit domain','HT_TP':'Inclusion-weighted true-positive total in that domain','FP':'Unweighted false-positive count','FN':'Unweighted false-negative count','HT_FP':'Design-weighted false-positive total','HT_FN':'Design-weighted false-negative total','treatment':'Registered2023estimate-weight/exclusion treatment','policy_scope':'All eligible /Grade A/local member set','source_sha256':'SHA256 of the source content','G1_share':'Policy share of all G assignments attributed to source-pressure control','G2_share':'Policy share attributed to habitat protection/restoration','G3_share':'Policy share attributed to monitoring/coordination'}
    allidx=[]
    for group,desc in descriptions.items():
        root=O/'data'/group;idx=[];fields=[]
        for p in sorted(root.rglob('*')):
            if not p.is_file() or p.name in ['README.md','FILE_INDEX.csv','FIELD_DICTIONARY.csv']:continue
            n=None;cols=[]
            if p.suffix=='.csv':
                q=pd.read_csv(p);n=len(q);cols=list(q)
                fields.extend(dict(file=p.relative_to(root).as_posix(),field=f,dtype=str(q[f].dtype),definition=definitions.get(f,'Source-specific field; retain original meaning from protocol, equation registry or accompanying identity column; no new definition imposed.')) for f in cols)
            row=dict(file=p.relative_to(root).as_posix(),rows=n,columns=' | '.join(cols),bytes=p.stat().st_size,sha256=c.sha(p));idx.append(row);allidx.append(dict(data_directory=group,**row))
        c.csvout(pd.DataFrame(idx),root/'FILE_INDEX.csv');c.csvout(pd.DataFrame(fields),root/'FIELD_DICTIONARY.csv')
        (root/'README.md').write_text('# '+group.replace('_',' ')+'\n\n'+desc+'\n\nFILE_INDEX.csv lists every retained file, row count, columns and hash. FIELD_DICTIONARY.csv distinguishes documented common fields from source-specific fields. Canonical CSVs preserve full precision, missing values, adverse outcomes and historical identities. They are not additional printed supplementary tables. Frozen sources are not overwritten. Protocols/equations accompany the data; this package supports result and report inspection, not an unqualified new-machine full raw-source calibration claim.\n','utf8')
    c.csvout(pd.DataFrame(allidx),O/'DATA_FILE_INDEX.csv')
    idx=c.table(OLD/'CURRENT_SUPPLEMENT_INDEX.csv');maps=[]
    dest={1:('Table S1','Data S2'),2:('Supplementary Methods equations','Data S3'),3:('Table S5','Data S2'),4:('Table S3','Data S3'),5:('Table S6 and Figure11','Data S4'),6:('Table S7','Data S4'),7:('Table S2','Data S1'),8:('Table S2','Data S1'),9:('Table S2','Data S1'),10:('Table S2','Data S1'),11:('Table S2','Data S1'),12:('Table S2','Data S1'),13:('Table S2','Data S1'),14:('Table S1','Data S1'),15:('Table S4','Data S3'),16:('Table S6 and Figure11','Data S4'),17:('Table S6 note and Supplementary Methods','Data S4')}
    for n,(new,dat) in dest.items():
        q=idx[idx.table.eq('Table S'+str(n))];src=' | '.join(q.source_csv.astype(str))
        if not src:src='tables/TableS'+str(n)+'_source.csv'
        maps.append(dict(old_artifact_id='Table S'+str(n),stable_content_id='R2_SUPPLEMENT_CONTENT_'+str(n),new_destination=new+'; '+dat,new_table_or_method_section=new,source_file=src,information_retained=True,cross_reference_action='Replace by content at the named paragraph/caption; do not replace Figure S identifiers'))
    c.csvout(pd.DataFrame(maps),O/'SUPPLEMENT_RENUMBERING_MAP.csv')
    tableidx=[];fmap=c.table(O/'FIGURE_TABLE_DATA_MAP.csv');fmap=fmap[~fmap.artifact_id.str.startswith('Table')]
    for id,parts in pd.DataFrame(json.loads((O/'TABLE_SPEC.json').read_text('utf8'))).groupby('id',sort=False):
        name=id.replace('TableS','Table S').replace('Table2','Table 2').replace('Table3','Table 3').replace('Table4','Table 4')
        tableidx.append(dict(artifact_id=name,title=parts.title.iloc[0],display_files=' | '.join(p.relative_to(O).as_posix() for p in (O/'display_tables').glob(id+'*.csv')),destination='Supplementary_Tables_S1_S7.docx' if 'TableS' in id else 'Main_Result_Tables_2_4.docx'))
        for item in parts.to_dict('records'):
            for name in item['sources']:
                matches=list((O/'data').rglob(name))+list((O/'source_data').rglob(name))
                if not matches:raise FileNotFoundError('Table source not packaged: '+name)
                p=matches[0];fmap=pd.concat([fmap,pd.DataFrame([dict(artifact_id=id,panel_id=item['part_title'] or 'table',source_file=p.relative_to(O).as_posix(),source_hash=c.sha(p),run_id=c.RUN,filter_rule='Frozen source → TABLE_SPEC display; all prespecified rows retained',metric_definition=item['title'],aggregation_order='No model recalculation; original aggregation before rounding',parameter_population='See table note',year_range='See table note',display_unit='See columns',interval_identity='See table note',output_file=tableidx[-1]['destination'])])],ignore_index=True)
    c.csvout(fmap,O/'FIGURE_TABLE_DATA_MAP.csv');c.csvout(pd.DataFrame(tableidx),O/'CURRENT_TABLE_INDEX.csv')
    c.csvout(pd.DataFrame(tableidx)[pd.DataFrame(tableidx).artifact_id.str.startswith('Table S')],O/'CURRENT_SUPPLEMENT_INDEX.csv')
    c.csvout(pd.DataFrame([
        dict(content='Table1 vs variable dictionary',decision='No additional Table1 result sheet; original Table1 remains method overview',retained='Full variable dictionary in Table S1/Data S2'),
        dict(content='Figure7b G–ES cards',decision='Removed from main figure; no replacement figure',retained='Table S5/Data S2'),
        dict(content='Figure10c/d true total row',decision='Removed duplicate display',retained='Table S7/Data S4 exact per-vector totals and closure'),
        dict(content='FigureS3 total ES',decision='Removed duplicate line; components retained',retained='Figure5/Data S2'),
        dict(content='Four reporting-SR ES rows',decision='Removed repeated unchanged ES from Figure11',retained='Data S4 true SR and social-screen records'),
        dict(content='Old17supplement tables',decision='Seven themed tables plus readable methods',retained='All canonical CSVs and adverse results indexed in Data S1–S4')]),O/'DISPLAY_REDUNDANCY_AUDIT.csv')
    (O/'CONTENT_REVISION_HANDOFF.md').write_text('''# R3内容修改交接

## 当前可用材料
正文结果表保持Table 2—4：阶段HT组成/政策Bootstrap；构造历史三状态端点与趋势；九个G2–H设置的3×3矩阵。Table1保留为原方法数据概览，不复制26行变量字典。原稿及整稿Word未修改。

正式附表仅S1—S7：变量；政策编码及G估计；12参数；七状态回顾与简单基准；历史关联；情景和初始化/门控；匹配分组Shapley。旧S8—S17及全部其他明细有逐项去向，不再打印为额外附表。图号与表号分别处理。

## 按原稿位置修改
1. Methods 3.2.1、Results 4.1及Table2附近：使用68篇固定框HT、11/13/16/28分期；不能再写67篇可编码或旧阶段百分比。Table2为政策重抽样范围，Figure4b为审核设计Taylor近似，不能互换。可报告点组成改变，不能以点排序断言显著差异。
2. Table3及Figure5附近：历史构造状态，不是拟合值。2023ES桥接估计身份写图注/Methods，图内已不额外标记。
3. Table4、Figure7及空间敏感性段落：All/GradeA/Local是68/50/33文本、67/49/32独立库存。All/GradeA成员和G2值不同、秩相同；相同ρ不是同一集合。当前5km相关强于10/20km，不能沿用旧“5km较弱”。完整LOYO和G–ES对照转新S5。
4. 模型Methods原TableS2引用：改指Supplementary Methods编号公式；最终dTF/dSM同时包括目标松弛与尺度转换。模型参数引用新S3，评价新S4，情景新S6，归因新S7。其余逐项编号映射见SUPPLEMENT_RENUMBERING_MAP.csv，禁止全局替换S7。
5. Figure9—11结果：主600RESET排序属于模型条件。初始化100与门控12分开；延续条件下S4−S6可反向，0.40门控负向结果保留。图11四个SR-only规格的真实SR结果在DataS4。
6. Discussion/limitations和回复：六状态不能同时优于两简单基准；低纯参数覆盖、边界浓集、αSM饱和及有限局部敏感性仍在。未验证原始制度网络；来源覆盖、SST聚合、估计生境和固定框误差边界仍需说明。T2及完整六类配置不因G输出获得验证。

## 表图和证据身份
原始数值run、M3、12参数、最佳点与600集合未变。本轮没有新ODE、筛选、Shapley或人工判断。HT、DIFF负估计和三池失败不改写。报告完成不意味着预测验证、审稿意见全部解决或submission_ready。
当前交付是可编辑表格、方法公式片段与图注；Word全文仍暂缓。建议采用状态READY_FOR_TEXT_REVISION_WITH_LIMITATIONS，仅在实际页面/数据QA完成后设置。

## 复算
沿用05_code/report_revision_20261029.py --stage all；仅报告层读取、展示、导出、核验、打包。--stage verify为轻核验。报告缓存绑定真实源数据、表格payload、样式、代码及编号映射；不碰数值缓存。环境及命令详见RUN_REPORT.ps1。
''','utf8')
    (O/'RUN_REPORT.ps1').write_text("param([ValidateSet('all','prepare','figures','tables','verify','package')][string]$Stage='verify')\n$env:B1_REPORT_DIR=$PSScriptRoot\n$python=if($env:B1_PYTHON){$env:B1_PYTHON}else{'"+str(R.parent/'.venv/Scripts/python.exe').replace('\\','/')+"'}\n& $python (Join-Path $PSScriptRoot '05_code/report_revision_20261029.py') --stage $Stage\nexit $LASTEXITCODE\n",'utf8')
def verify():
    checks=[]
    def ck(n,ok,detail):
        checks.append(dict(check=n,passed=bool(ok),detail=str(detail)))
        if not ok:c.csvout(pd.DataFrame(checks),O/'REPORT_QA.csv');raise AssertionError(n+': '+str(detail))
    ck('Frozen numeric files, R2 snapshot and original results unchanged',pub.check_inputs()>0,'SHA256 content comparison, no original hash rewriting')
    spec=json.loads((O/'TABLE_SPEC.json').read_text('utf8'));ids=set(i['id'] for i in spec)
    ck('Exactly3 main result tables',ids & {'Table1','Table2','Table3','Table4','Table5'}=={'Table2','Table3','Table4'},ids)
    ck('Exactly7 formal supplementary table IDs',{s for s in ids if s.startswith('TableS')}=={'TableS'+str(i) for i in range(1,8)},ids)
    get=lambda id:[i for i in spec if i['id']==id]
    t=get('Table2')[0];ck('Table2 four stages counts and5columns',[r[1] for r in t['rows']]==[11,13,16,28] and len(t['columns'])==5,t['rows'])
    x=c.data('part1_table2');ck('Table2 full-precision shares sum1',np.allclose(x.groupby('stage').HT_policy_equal_share.sum(),1,atol=1e-12),'No rounding adjustment')
    for r in x.itertuples():
        row=next(a for a in t['rows'] if a[0]==r.stage.replace('-','–'));ck('Bootstrap display '+r.stage+r.label,row[2+['G1','G2','G3'].index(r.label)]==pub.interval(r.HT_policy_equal_share,r.policy_bootstrap_p025,r.policy_bootstrap_p975,1,100),'Exact frozen percent formatting')
    tr=pub.old('Table3_source.csv');ses=c.data('ses').set_index('year')
    ck('Table3 endpoints and net changes',all(abs(r.initial-ses.loc[2011,r.state])<1e-12 and abs(r.terminal-ses.loc[2023,r.state])<1e-12 and abs(r.net_change-(r.terminal-r.initial))<1e-12 for r in tr.itertuples()),'Slopes/LOYO copied from frozen verified table, not re-estimated')
    q=c.data('g2_statistics').query("relationship=='G2-H'");ck('All9 G2-H combinations',len(q)==9 and q.groupby('policy_scope').size().eq(3).all(),'n12, no G-ES substitution')
    counts=pub.read(O/'POLICY_SCOPE_COUNTS.csv').set_index('scope');ck('Actual scope counts and inventories',counts.loc[['ALL_ELIGIBLE','A_GRADE','LOCAL'],'texts'].tolist()==[68,50,33] and counts.loc[['ALL_ELIGIBLE','A_GRADE','LOCAL'],'stocks'].tolist()==[67,49,32],counts.to_dict())
    ck('Seven base states retained',len(get('TableS4')[0]['rows'])==7,[r[0] for r in get('TableS4')[0]['rows']])
    ck('All7scenarios with adverse S5',len(get('TableS6')[0]['rows'])==7 and next(r for r in get('TableS6')[0]['rows'] if r[0]=='S5')[-1]=='Fail','No favorable selection')
    rows=get('TableS6')[1]['rows'];ck('Matched100 anddistinct12gate support',len(rows)==8 and [r[2] for r in rows]==[100,100]+[12]*6,'RESET/CONT12×3 retained')
    ck('Negative continuation high gate retained',any(r[0]=='Continuation' and r[1]=='0.40' and r[3].startswith('−') for r in rows),'Actual interval not direction relabel')
    ck('Shapley negatives and true totals',sum(r[1]=='True paired total' for r in get('TableS7')[0]['rows'])==2 and any(r[1]=='Feedback' and r[2].startswith('−') for r in get('TableS7')[0]['rows']),'All metrics scaled1000 after source aggregation')
    pub.workbook_readback();ck('New workbook all cells match payload',not json.loads((O/'WORKBOOK_QA.json').read_text('utf8'))['mismatches'],'Current payload, not R1 reuse')
    from zipfile import ZipFile
    from lxml import etree
    ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main','m':'http://schemas.openxmlformats.org/officeDocument/2006/math'}
    for name,n in [('Main_Result_Tables_2_4',3),('Supplementary_Tables_S1_S7',10)]:
        with ZipFile(O/(name+'.docx')) as z:xml=etree.fromstring(z.read('word/document.xml'))
        ts=xml.findall('.//w:tbl',ns);ck(name+' editable table objects',len(ts)==n,len(ts))
        ck(name+' repeating headers and no row split',all(t.find('./w:tr/w:trPr/w:tblHeader',ns) is not None for t in ts) and all(tr.find('./w:trPr/w:cantSplit',ns) is not None for t in ts for tr in t.findall('./w:tr',ns)),'OOXML repeat/cantSplit')
    with ZipFile(O/'Supplementary_Methods_equations.docx') as z:xml=etree.fromstring(z.read('word/document.xml'))
    ck('Editable numbered equations',len(xml.findall('.//m:oMath',ns))==51,'OMML, not formula screenshots')
    mt=(O/'Supplementary_Methods_equations.md').read_text('utf8');ck('Final TF/SM transfer retained','dTF/dt = r_TF' in mt and 'dSM/dt = r_SM' in mt and '1.5687953135133381' in mt,'Full relaxation and area conversion')
    bounds=json.loads((O/'FIGURE_TEXT_BOUNDS.json').read_text('utf8'));ck('Figure text within page',not any(r['text_outside_page'] for r in bounds),len(bounds))
    a=pub.read(O/'plot_data/Figure4a_coordinates.csv');b=c.data('part1_ternary');ck('Figure4 no moved boundary points',np.allclose(a[['x','y']].to_numpy(),b[['x','y']].to_numpy(),rtol=0,atol=2e-16),'CSV float roundtrip max error 1.11e-16; no geometric adjustment')
    ck('Figure5 observations unchanged',np.allclose(pub.read(O/'plot_data/Figure5_levels.csv')[['G','SR','ES']],c.data('ses')[['G','SR','ES']]),'Only display marker identity changed')
    f=pub.read(O/'plot_data/Figure11_main_ES_specifications.csv');full=pub.read(O/'plot_data/Figure11_all_specifications.csv');ck('Figure11 exactly four SR-only rows removed',len(full)-len(f)==4 and not f.specification.str.startswith('REPORTING_SR_').any(),'All other ES specifications retained')
    ck('Figure10 duplicate totals removed onlyfromdisplay',not pub.read(O/'plot_data/Figure10_shapley_display_values.csv')['group'].eq('TRUE_TOTAL').any(),'True totals preserved in TableS7 and canonical source')
    ck('FigureS3 components only',set(pub.read(O/'plot_data/Figure_S3_components.csv').columns)=={'year','G1','G2','G3','WQ','H'},'ES retained Figure5')
    documentation();mapping=pub.read(O/'SUPPLEMENT_RENUMBERING_MAP.csv');ck('All oldS1–S17 destinations',set(mapping.old_artifact_id)=={'Table S'+str(i) for i in range(1,18)},'IncludesS8–S17; figure IDs unchanged')
    for p in c.CODE.glob('report*.py'):ast.parse(p.read_text('utf8'))
    ck('No numerical module imported by current report',not any(k in sys.modules for k in ['sd_model','fast_kernel','v12_formal_calibration','v12_scenarios','v12_attribution']),list(k for k in sys.modules if k.startswith('report_')))
    ck('Original figure/table numerical results preserved',pub.check_inputs()>0,'Post-export protected SHA check')
    c.csvout(pd.DataFrame(checks),O/'REPORT_QA.csv');print('R3 checks',len(checks),'passed',flush=True)
def release():
    from pypdf import PdfReader,PdfWriter
    verify()
    visual=json.loads((O/'VISUAL_REVIEW.json').read_text('utf8'))
    if not visual['all_final_pages_reviewed'] or not all(c.sha(O/r['path'])==r['sha256'] for r in visual['artifacts']):raise ValueError('Final visual review missing or stale')
    files=[O/'figures'/f'Figure{i}.pdf' for i in range(3,12)]+[O/'figures'/f'Figure_S{i}.pdf' for i in range(1,8)]
    w=PdfWriter();geo=[]
    for p in files:
        rd=PdfReader(p);assert len(rd.pages)==1;w.add_page(rd.pages[0]);w.add_outline_item(p.stem,len(w.pages)-1);geo.append(dict(name=p.stem,width=float(rd.pages[0].mediabox.width),height=float(rd.pages[0].mediabox.height)))
    with (O/'Figures_3_11_and_S1_S7.pdf').open('wb') as f:w.write(f)
    rr=PdfReader(O/'Figures_3_11_and_S1_S7.pdf');assert all(abs(float(p.mediabox.width)-g['width'])<1e-6 and abs(float(p.mediabox.height)-g['height'])<1e-6 for p,g in zip(rr.pages,geo));c.js(dict(direct_merge_no_scaling=True,pages=geo),O/'PDF_GEOMETRY_QA.json')
    packed=O/'05_code';packed.mkdir(exist_ok=True)
    names=['report_revision_20261029.py','report_r2.py','report_r2_figures.py','report_r2_release.py','report_publication_tables.py','report_r3_checks.py','report_documents.py','report_render_word.ps1','report_workbook.mjs','report_result_map.json','report_style.json']
    changes=[]
    for name in names:
        p=c.CODE/name;shutil.copy2(p,packed/name);old=O/'archive_before_R3'/name
        changes.append(dict(file=name,classification='REPORT_ONLY',before_sha256=c.sha(old) if old.exists() else None,after_sha256=c.sha(p)))
    c.csvout(pd.DataFrame(changes),O/'REPORT_CODE_CHANGES.csv')
    diff=[]
    for row in changes:
        name=row['file'];old=O/'archive_before_R3'/name;p=c.CODE/name
        diff.extend(difflib.unified_diff(old.read_text('utf8').splitlines(True) if old.exists() else [],p.read_text('utf8').splitlines(True),fromfile='R2/'+name,tofile='R3/'+name))
    (O/'REPORT_PATCH.diff').write_text(''.join(diff),'utf8')
    deps=[p for p in packed.iterdir() if p.is_file()]+[O/'TABLE_SPEC.json',O/'TABLE_STYLE_SPEC.json',O/'SUPPLEMENT_RENUMBERING_MAP.csv',O/'FIGURE_TABLE_DATA_MAP.csv',O/'SOURCE_INPUTS.csv']
    c.js(dict(signature=hashlib.sha256(''.join(c.sha(p) for p in deps).encode()).hexdigest(),dependencies=[dict(path=p.relative_to(O).as_posix(),sha256=c.sha(p)) for p in deps],source_inputs='SOURCE_INPUTS.csv',only_report_cache=True),O/'REPORT_CACHE_SIGNATURE.json')
    c.js(dict(status='READY_FOR_TEXT_REVISION_WITH_LIMITATIONS',report_revision=O.name,numerical_run=c.RUN,main_result_tables=3,formal_supplement_tables=7,new_calibrations=0,new_ODE_calls=0,new_scenario_propagations=0,new_shapley_calls=0,Word_full_text_updated=False,model_predictive_validation=False,all_reviewer_issues_resolved=False,submission_ready=False,remaining_limits='See CONTENT_REVISION_HANDOFF.md and all adverse data'),O/'REPORT_STATUS.json')
    with (O/'logs/execution.jsonl').open('a',encoding='utf8') as f:f.write(json.dumps(dict(stage='package_precommit',QA_passed=True,release_completion_evidence='External archive QA and atomic CURRENT pointer'))+'\n')
    records=[]
    for p in O.rglob('*'):
        if not p.is_file() or any(x in p.parts for x in ['archive_before_R3','qa_previews','__pycache__','node_modules']) or p.name=='REPORT_MANIFEST.json' or p.suffix=='.zip':continue
        records.append(dict(path=p.relative_to(O).as_posix(),bytes=p.stat().st_size,sha256=c.sha(p)))
    c.js(dict(report_revision=O.name,numerical_run=c.RUN,original_R2_manifest_sha256=c.sha(OLD/'REPORT_MANIFEST.json'),files=records,full_calibration_not_rerun=True),O/'REPORT_MANIFEST.json')
    dest=R.parents[1]/'outputs/B1_V1.2_R3_正文三表_附录七表_图形与方法交接_20261029.zip';tmp=dest.with_suffix('.tmp')
    with zipfile.ZipFile(tmp,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for r in records:z.write(O/r['path'],r['path'])
        z.write(O/'REPORT_MANIFEST.json','REPORT_MANIFEST.json')
    with zipfile.ZipFile(tmp) as z:
        assert z.testzip() is None
        assert all(hashlib.sha256(z.read(r['path'])).hexdigest()==r['sha256'] for r in records)
    os.replace(tmp,dest)
    pointer=R.parent/'PART2_CURRENT.json';old=json.loads(pointer.read_text('utf8'));old.update(report_revision=O.name,current_report_directory=str(O),report_manifest=str(O/'REPORT_MANIFEST.json'),report_manifest_sha256=c.sha(O/'REPORT_MANIFEST.json'),report_code_used_in_original_calibration=False)
    temp=pointer.with_suffix('.tmp');c.js(old,temp);os.replace(temp,pointer)
    c.js(dict(zip=str(dest),sha256=c.sha(dest),CRC_and_member_hashes_pass=True,report_manifest_sha256=c.sha(O/'REPORT_MANIFEST.json')),dest.with_name(dest.stem+'_QA.json'))
    print('R3 released; CURRENT atomically updated',dest,flush=True)
