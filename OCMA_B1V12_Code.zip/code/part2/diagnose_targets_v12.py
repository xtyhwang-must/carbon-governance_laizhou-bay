"""Observation-reset target decomposition, checked against actual RHS for seven states."""
from __future__ import annotations
import argparse,json,sys
from pathlib import Path
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'05_code/engine'),str(ROOT/'05_code')]
import engine_config as cfg
import sd_model as m
from v12_modeling import reference_for

STATES=['SP','SC','NS','OS','BS','TF','SM']
IDX=[3,4,5,6,7,8,9]


def terms(state,exo,baseline,p,structure,mode=None):
    from mode_aware_diagnostics import terms as current_terms
    return current_terms(state,exo,baseline,p,structure,mode=mode)

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--structure',default=None)
    parser.add_argument('--parameter-json',default='06_runs/formal_main/calibration/best_parameter_set.json')
    parser.add_argument('--output',default='06_runs/formal_main/report_revision_20261029/target_regression')
    parser.add_argument('--gate-midpoint',type=float,default=.30)
    parser.add_argument('--disable-conversion',action='store_true')
    args=parser.parse_args()
    frame=pd.read_csv(ROOT/'03_indicators/model_input_B1.csv').sort_values('year')
    payload=json.loads((ROOT/args.parameter_json).read_text(encoding='utf-8'))
    if args.structure is None:
        args.structure=json.loads((ROOT/'06_runs/structure_compare/model_selection.json').read_text('utf8'))['selected_structure']
    if 'structure' in payload and payload['structure']!=args.structure:
        raise ValueError('Parameter structure differs from explicit/current diagnostic structure')
    parameters=payload['parameters'] if 'parameters' in payload else payload
    p=m.parameter_dict(parameters,structure=args.structure)
    forcing=m.historical_forcing(frame);initial=m.initial_state(frame,year=2011)
    baseline=reference_for(frame,forcing,initial,parameters,args.structure)
    if baseline is None:baseline=m._baseline_context(initial,forcing.at(2011.),p,m.ModelMode())
    mode=m.ModelMode(sc_gate_midpoint=args.gate_midpoint,tf_sm_conversion=not args.disable_conversion)
    if (ROOT/args.parameter_json).resolve()==(ROOT/'06_runs/formal_main/calibration/best_parameter_set.json').resolve() and args.structure=='M3_AC_SM_TF_INTERCEPTS' and mode==m.ModelMode():
        prediction=pd.read_csv(ROOT/'06_runs/formal_main/calibration/best_prediction_2011_2023.csv')
        prediction_origin='REUSED_FROZEN_BEST_HISTORY'
    else:
        prediction=m.simulate(parameters,forcing,frame.year.to_numpy(float),initial,mode=mode,
            structure=args.structure,reference_context=baseline if args.structure!='M0_RUN_SPECIFIC' else None)
        prediction_origin='EXPLICIT_DIAGNOSTIC_REPLAY'
    lineage=pd.read_csv(ROOT/'03_indicators/indicator_lineage.csv').set_index(['year','state_id'])
    records=[]
    for r in frame.itertuples(index=False):
        year=int(r.year);state=np.array([float(getattr(r,name)) for name in cfg.STATE_NAMES]);exo=forcing.at(float(year))
        expected=m.rhs(float(year),state,p,forcing,baseline,mode,args.structure)
        for row in terms(state,exo,baseline,p,args.structure,mode=mode):
            name=row['state'];index=row.pop('state_index')
            assert abs(row['reconstructed_derivative']-expected[index])<1e-10,(year,name)
            source_name='AC' if name=='SC' else name
            source=lineage.loc[(year,source_name)]
            row.update({'year':year,'structure':args.structure,
                'observed_raw_value':source.raw_value,'observed_raw_unit':source.raw_unit,
                'transformation':source.transformation,'source_row_locator':source.source_row_locator,
                'simulated_free_run':float(prediction.loc[prediction.year.eq(year),name].iloc[0]),
                'free_run_error':float(prediction.loc[prediction.year.eq(year),name].iloc[0]-row['observed']),
                'RHS_derivative':float(expected[index]),'RHS_reconstruction_error':row['reconstructed_derivative']-expected[index],
                'diagnostic_role':'OBSERVATION_RESET_DIAGNOSTIC_NOT_FREE_RUN_VALIDATION'})
            records.append(row)
    out=ROOT/args.output;out.mkdir(parents=True,exist_ok=True)
    pd.DataFrame(records).to_csv(out/f'{args.structure}_seven_state_targets.csv',index=False,encoding='utf-8-sig')
    (out/f'{args.structure}_reference_context.json').write_text(json.dumps(baseline,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'structure':args.structure,'rows':len(records),'prediction_origin':prediction_origin,
      'maximum_RHS_reconstruction_error':float(max(abs(x['RHS_reconstruction_error']) for x in records))},ensure_ascii=False))

if __name__=='__main__':main()
