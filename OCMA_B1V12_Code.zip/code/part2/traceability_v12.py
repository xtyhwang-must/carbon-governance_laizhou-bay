"""Append machine-checkable same-version result links to the source-row chain."""
from __future__ import annotations
import json,sys
from pathlib import Path
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]
FILE=ROOT/'00_contract/analysis_traceability.csv'
BASE=['year','source_id','source_row_locator','policy_id','clause_id','state_id',
    'transformation','equation_id','parameter_id','scenario_id','metric_protocol_id',
    'run_function','result_file','trace_status','version','change_type']

def main():
    old=pd.read_csv(FILE)
    old=old[old.get('version',pd.Series(index=old.index,dtype=str)).ne('B1_v1.2.0_definition_consistent')]
    for col in BASE:
        if col not in old:old[col]='B1_v1.1_SOURCE_CHAIN' if col=='version' else ''
    status=json.loads((ROOT/'06_runs/formal_main/calibration/formal_calibration_status.json').read_text(encoding='utf-8'))
    structure=status['structure'];records=[]
    def add(year,state,source,source_row,trans,eq,parameter,scenario,protocol,function,result,change):
        records.append({'year':year,'source_id':source,'source_row_locator':source_row,
            'policy_id':'','clause_id':'','state_id':state,'transformation':trans,
            'equation_id':eq,'parameter_id':parameter,'scenario_id':scenario,
            'metric_protocol_id':protocol,'run_function':function,'result_file':result,
            'trace_status':'SAME_VERSION_COMPUTED_RESULT','version':'B1_v1.2.0_definition_consistent',
            'change_type':change})
    for year in range(2011,2024):
        for state in ['SP','SC','NS','OS','BS','TF','SM']:
            add(year,state,'B1_CONFIRMED_MODEL_INPUT',f'model_input_B1.csv:year={year}',
                'source state or forcing -> explicit 2011 initial -> selected RHS -> annual RK4 trajectory',
                '04_model/equation_registry.csv',structure,'HISTORICAL',
                '2011_2020_fit_2021_2023_development_evaluation',
                'v12_evaluation.one|sd_model.simulate',
                '06_runs/formal_main/evaluation/historical_ensemble_trajectories.csv','METHOD_REVISION')
    for sid in [f'S{i}' for i in range(7)]:
        for state in ['SP','SC','NS','OS','BS','TF','SM','ES','SR']:
            add(2023,state,'B1_CONFIRMED_INPUT_AND_SCENARIO_REGISTRY',
                f'model_input_B1.csv:year=2023; scenario_registry.csv:{sid}',
                '2023 initial + matched parameter/reference/climate + registered lever forcing',
                '04_model/equation_registry.csv',structure,sid,
                'terminal_SR_then_annual_minES_2026_2030_then_ES2030',
                'v12_scenarios.vector_job|v12_scenario_summary.summarize',
                '06_runs/formal_main/scenarios/scenario_trajectories_long.csv','IMPLEMENTATION_FIX_AND_METHOD_REVISION')
    for contrast in ['S4-S0','S6-S0','S4-S6','S5-S0']:
        for metric in ['min_ES_2026_2030','ES_2030','SR_2030']:
            add(2030,metric,'MATCHED_B1_SCENARIO_TRAJECTORIES',contrast,
                'within-vector scenario extrema then paired subtraction',
                'B1V12_INITIAL_YEAR',structure,contrast,'paired_same_initial_reference_forcing',
                'v12_scenarios.main','06_runs/formal_main/scenarios/four_primary_paired_differences.csv',
                'DEFINITION_CORRECTION')
    for contrast in ['S4-S0','S4-S6']:
        for metric in ['min_ES_2026_2030','ES_2030','SR_2030']:
            add(2030,metric,'MATCHED_B1_COALITION_FORCING',contrast,
                'four-group 16-coalition or three-group 8-coalition Shapley',
                'B1V12_FIXED_REFERENCE',structure,contrast,'matched_grouped_factorial',
                'v12_attribution.one|v12_attribution.shapley',
                '06_runs/formal_main/attribution/shapley_by_parameter.csv','METHOD_REVISION')
    result=pd.concat([old[BASE],pd.DataFrame(records,columns=BASE)],ignore_index=True)
    new=result[result.version.eq('B1_v1.2.0_definition_consistent')]
    missing=sorted({x for x in new.result_file if not (ROOT/x).is_file()})
    if missing:raise FileNotFoundError('Trace result files absent: '+str(missing))
    if new.empty:raise AssertionError('Missing actual trace rows')
    result.to_csv(FILE,index=False,encoding='utf-8-sig')
    print({'total_trace_rows':len(result),'v12_same_version_result_links':len(new)},flush=True)

if __name__=='__main__':main()
