"""Finite prespecified coder/input and single-factor stress contrasts; no model search."""
from pathlib import Path
import sys,json,hashlib
import numpy as np,pandas as pd
from scipy.optimize import differential_evolution,minimize
ROOT=Path(__file__).resolve().parents[1];sys.path[:0]=[str(ROOT/'05_code/engine'),str(ROOT/'05_code')]
import sd_model as m,engine_config as cfg
from v12_modeling import TrainingContext,reference_for
from numeric_analysis import scenario_forcing,load_settings,climate_path
from v12_robustness import habitat_initial
from v12_scenario_summary import summarize
OUT=ROOT/'06_runs/formal_main/additional_sensitivity';OUT.mkdir(exist_ok=True)
def metrics(z,pid,sid,spec):
 sh=z[z.year.between(2026,2030)];end=z[z.year.eq(2030)].iloc[0]
 return dict(parameter_set_id=pid,scenario=sid,specification_id=spec,forcing_draw_id='COMMON_WITHIN_SPEC',initial_state_hash=hashlib.sha256(z.iloc[0][cfg.STATE_NAMES].to_numpy(float).tobytes()).hexdigest(),min_ES_2026_2030=float(sh.ES.min()),ES_2030=float(end.ES),SR_2030=float(end.SR),min_SR_2024_2030=float(z[z.year.ge(2024)].SR.min()))
def main():
 # Protocol fixed in code before running these unviewed comparisons.
 protocol={'subset_rule':'12 equally spaced indices from main retained set','fixed_parameter_specs':['CODER_SWAP','LINEAR_WATER','SYMMETRIC_HABITAT','RISK_TAU_X0.5','RISK_TAU_X2','COMPOUND_X0.8','COMPOUND_X1.2','SYNERGY_X0.8','SYNERGY_X1.2','CLIMATE_BLOCK1','CLIMATE_BLOCK5'], 'coder_refit':{'structure':'locked main','seed':20261024,'DE_maxiter':14,'population_per_dimension':6,'Powell_maxiter':260},'not_main_ranking':True}
 (OUT/'protocol_before_results.json').write_text(json.dumps(protocol,indent=2),'utf8')
 frame=pd.read_csv(ROOT/'03_indicators/model_input_B1.csv');status=json.loads((ROOT/'06_runs/formal_main/calibration/formal_calibration_status.json').read_text('utf8'));s=status['structure'];names=m.parameter_names(s);ens=pd.read_csv(ROOT/'06_runs/formal_main/calibration/accepted_parameter_ensemble.csv');sample=ens.iloc[np.unique(np.linspace(0,len(ens)-1,min(12,len(ens)),dtype=int))]
 swap=frame.copy();tab=pd.read_csv(ROOT/'06_runs/ses/second_coder_whole_policy_input_sensitivity.csv')
 for g in ['G1','G2','G3']:swap[g]=swap.year.map(tab[tab.channel.eq(g)].set_index('year').G)
 gate=swap.SC**2/(.3**2+swap.SC**2);gh=swap.G3**2.2/(.45**2.2+swap.G3**2.2);swap.IM=np.clip(swap.ETA_POTENTIAL*gh*(.12+.88*gate)/(1+.75*swap.SP),.001,.999);swap.to_csv(OUT/'coder_swap_model_input.csv',index=False)
 ht=pd.read_csv(ROOT/'01_sources/part1_current/G_POLICY_DESCRIPTIVE_68.csv');dates=pd.read_csv(ROOT/'02_policy/reconstructed/policy_validity_decisions.csv');h=ht.merge(dates,on='policy_id');projection={};settings=load_settings();altsettings={k:dict(v) for k,v in settings.items()}
 for g in ['G1','G2','G3']:
  stocks=[];entries=[]
  for y in range(2000,2031):
   a=h[h.independent_stock_policy&h.stock_start_year.le(y)&h.future_exposure_end_year.ge(y)];e=h[h.independent_stock_policy&h.stock_start_year.eq(y)];stocks.append(a[g+'_second_coder_swap_share'].sum());entries.append(e[g+'_second_coder_swap_share'].sum())
  vals=swap[g];q50,q75=vals.quantile([.5,.75]);projection[g]=(stocks[23],float(np.median(entries[21:24])),float(q50),float(q75),np.asarray(stocks[24:31]))
  # Preserve each scenario's quantile role, do not reuse old numeric controls after alternate input.
  base_low=settings['S0'][g];high=settings['S4'][g]
  for sid in settings:altsettings[sid][g]=float(q75 if np.isclose(settings[sid][g],high) and not np.isclose(high,base_low) else q50)
 climate=climate_path(frame);rows=[]
 for rr in sample.itertuples():
  params={n:float(getattr(rr,n)) for n in names}
  for spec in protocol['fixed_parameter_specs']:
   f=swap if spec=='CODER_SWAP' else frame;par=dict(params);mode=m.ModelMode();cl=climate.copy();projection_used=projection if spec=='CODER_SWAP' else None;sett=altsettings if spec=='CODER_SWAP' else settings
   if spec=='LINEAR_WATER':mode=m.ModelMode(nonlinear_water=False)
   if spec=='SYMMETRIC_HABITAT':mode=m.ModelMode(asymmetric_habitat=False)
   for pref,key in [('RISK_TAU_X','tau_risk'),('COMPOUND_X','k_compound'),('SYNERGY_X','k_synergy')]:
    if spec.startswith(pref):par[key]=cfg.FIXED_PARAMETERS[key]*float(spec[len(pref):])
   if spec.startswith('CLIMATE_BLOCK'):
    length=int(spec.removeprefix('CLIMATE_BLOCK'));rng=np.random.default_rng(20260725);ix=[]
    while len(ix)<7:
     start=int(rng.integers(0,len(frame)-length+1));ix.extend(range(start,start+length))
    cl=frame.iloc[ix[:7]][['PPT','RUNOFF','SST']].reset_index(drop=True);cl.insert(0,'year',range(2024,2031));cl.loc[cl.year.between(2026,2028),['PPT','RUNOFF','SST']]=climate.loc[climate.year.between(2026,2028),['PPT','RUNOFF','SST']].to_numpy()
   forcinghist=m.historical_forcing(f);initial=m.initial_state(f,year=2023);ref=reference_for(f,forcinghist,m.initial_state(f,year=2011),par,s)
   for sid in settings:
    force,_,_=scenario_forcing(f,sett[sid],cl,projection=projection_used);z=m.simulate(par,force,np.arange(2023,2031,dtype=float),initial,mode=mode,structure=s,reference_context=ref);rows.append(metrics(z,rr.parameter_set_id,sid,spec))
 print('Fixed parameter additional sensitivities complete',len(rows),flush=True)
 pd.DataFrame(rows).to_csv(OUT/'fixed_parameter_metrics.csv',index=False,encoding='utf-8-sig')
 # One finite refit on the locked structure, explicitly distinct from main five-seed ensemble.
 ctx=TrainingContext(swap,s,2020);de=differential_evolution(ctx.evaluate,ctx.bounds,seed=20261024,maxiter=14,popsize=6,tol=1e-6,polish=False);po=minimize(ctx.evaluate,de.x,method='Powell',bounds=ctx.bounds,options={'maxiter':260,'xtol':1e-6,'ftol':1e-8});v=po.x if ctx.evaluate(po.x)<ctx.evaluate(de.x) else de.x;par=ctx.vector_dict(v)
 (OUT/'coder_swap_limited_refit.json').write_text(json.dumps({'structure':s,'budget':protocol['coder_refit'],'parameters':par,'diagnostics':ctx.evaluate(v,True),'DE_success':bool(de.success),'Powell_success':bool(po.success),'identity':'ONE_REFITTED_POINT_DIAGNOSTIC_NOT_ACCEPTED_ENSEMBLE'},indent=2),'utf8')
 ref=reference_for(swap,ctx.forcing,ctx.initial,par,s);init=m.initial_state(swap,year=2023)
 for sid in settings:
  force,_,_=scenario_forcing(swap,altsettings[sid],climate,projection=projection);z=m.simulate(par,force,np.arange(2023,2031,dtype=float),init,structure=s,reference_context=ref);rows.append(metrics(z,'CODER_REFIT_POINT',sid,'CODER_SWAP_LIMITED_REFIT_POINT'))
 allrows=pd.DataFrame(rows);allrows.to_csv(OUT/'all_additional_metrics.csv',index=False,encoding='utf-8-sig');pairrows=[]
 for spec,z in allrows.groupby('specification_id'):
  _,_,rank,pair=summarize(z);pair.insert(0,'specification_id',spec);pairrows.append(pair)
 pd.concat(pairrows).to_csv(OUT/'paired_sensitivity_summary.csv',index=False,encoding='utf-8-sig')
 print('Coder fixed-input and finite refit sensitivity complete',flush=True)
if __name__=='__main__':main()
