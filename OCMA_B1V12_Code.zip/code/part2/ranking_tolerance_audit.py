"""Audit every matched scenario pair under a predeclared numerical tolerance."""
from __future__ import annotations
from itertools import combinations
from pathlib import Path
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parents[1]
FOLDER=ROOT/'06_runs/B1_v1_1/scenarios'
TOL=5e-4

def main():
    frame=pd.read_csv(FOLDER/'scenario_metrics_by_parameter.csv')
    key=['parameter_set_id','forcing_draw_id','initial_state_hash']
    if frame.duplicated(key+['scenario']).any():raise AssertionError('Duplicate scenario match keys')
    pivot=frame.pivot(index=key,columns='scenario',values='ES_2030')
    if pivot.isna().any().any():raise AssertionError('Incomplete matched scenario set')
    rows=[]
    for a,b in combinations(sorted(pivot.columns),2):
        d=pivot[a]-pivot[b]
        rows.append({'scenario_a':a,'scenario_b':b,'matched_parameter_sets':len(d),
            'median_a_minus_b':float(d.median()),'P5_a_minus_b':float(d.quantile(.05)),
            'P95_a_minus_b':float(d.quantile(.95)),
            'fraction_a_gt_b_plus_tolerance':float((d>TOL).mean()),
            'fraction_b_gt_a_plus_tolerance':float((d<-TOL).mean()),
            'fraction_within_tolerance':float((d.abs()<=TOL).mean()),
            'tolerance_ES_units':TOL,'forcing_spec':'primary_compound_single_common_draw',
            'interpretation':'numerical_distinguishability_only_not_forecast_reliability'})
    out=pd.DataFrame(rows)
    out.to_csv(FOLDER/'all_pair_tolerance_audit.csv',index=False,encoding='utf-8-sig')
    if len(out)!=21 or not np.allclose(out[[c for c in out if c.startswith('fraction_')]].sum(axis=1),1):
        raise AssertionError('Tolerance partition or pair count')
    print({'scenario_pairs':len(out),'matched_parameter_sets':len(pivot),'tolerance':TOL})

if __name__=='__main__':main()
