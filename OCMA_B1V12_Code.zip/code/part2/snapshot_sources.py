"""One-time, non-destructive capture of source evidence into B1.

This script records both the copied source hash and its original local locator.
The original paths are only used at capture time; B1 analysis reads copies.
"""
from pathlib import Path
import hashlib
import json
import shutil
import pandas as pd

HERE = Path(__file__).resolve().parents[1]
PROJECT = HERE.parent
FROZEN = PROJECT / 'revision_20261024'
IND = FROZEN / '03_analysis/reconstructed_inputs'
POLICY_ROOT = PROJECT / 'data/processed/莱州湾蓝碳政策全文摘要库_2000-2023语义分析准备版_20260723'
ADMISSION = POLICY_ROOT / '00_清单/语义分析准入全文清单_68条.csv'
records = []


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def capture(source_id, src, rel, material_type, locator='', confirmation='SOURCE_PRESENT', version='2026-10-25 capture'):
    src = Path(src)
    dest = HERE / rel
    if not src.is_file():
        records.append({'source_id': source_id, 'relative_path': rel, 'sha256': '', 'bytes': 0,
                        'version': version, 'material_type': material_type,
                        'source_locator': str(src), 'evidence_locator': locator,
                        'availability': 'MISSING', 'confirmation_status': confirmation})
        return
    dest.parent.mkdir(parents=True, exist_ok=True)
    if dest.exists():
        if sha(dest) != sha(src) and source_id != 'engine_engine_config.py':
            raise RuntimeError(f'Existing B1 copy differs: {dest}')
    else:
        shutil.copy2(src, dest)
    adapted = source_id == 'engine_engine_config.py' and sha(dest) != sha(src)
    records.append({'source_id': source_id, 'relative_path': rel, 'sha256': sha(dest),
                    'source_sha256': sha(src),
                    'bytes': dest.stat().st_size, 'version': version,
                    'material_type': material_type, 'source_locator': str(src),
                    'evidence_locator': locator, 'availability': 'ADAPTED_LOCAL_CODE' if adapted else 'COPIED_HASH_MATCH',
                    'confirmation_status': 'ADAPTED_LOCAL_CONTRACT_PATH' if adapted else confirmation})


def main():
    capture('submission_manuscript', 'C:/Users/Mario/Desktop/OCMA投稿/Manuscript.docx',
            '01_sources/submission/Manuscript.docx', 'DOCX', 'full document', 'ORIGINAL_SUBMISSION')
    capture('submission_supplement', 'C:/Users/Mario/Desktop/OCMA投稿/supplementary material.docx',
            '01_sources/submission/supplementary material.docx', 'DOCX', 'full document', 'ORIGINAL_SUBMISSION')
    capture('reviewer_comments', 'C:/Users/Mario/Desktop/返修V1/OCMA-D-26-02928-reviews.pdf',
            '01_sources/submission/OCMA-D-26-02928-reviews.pdf', 'PDF', 'full document', 'REVIEWER_SOURCE')
    capture('B1_instructions', 'D:/下载/OCMA_CODEX_B1_baseline_execution_20261025.md',
            '00_contract/OCMA_CODEX_B1_baseline_execution_20261025.md', 'INSTRUCTION', 'full document', 'AUTHOR_CURRENT_INSTRUCTION')
    capture('technical_audit', 'D:/下载/OCMA_technical_audit_and_minimal_repairs_20261025.md',
            '01_sources/submission/OCMA_technical_audit_and_minimal_repairs_20261025.md', 'REVIEW_REPORT', 'full document', 'DIAGNOSTIC_NOT_PRIMARY')
    capture('current_code_review', FROZEN / '06_gpt_review_20261025/01_当前代码与优化审阅说明.txt',
            '01_sources/submission/01_当前代码与优化审阅说明.txt', 'REVIEW_REPORT', 'full document', 'DIAGNOSTIC_NOT_PRIMARY')
    capture('candidate_readiness_report', 'D:/下载/OCMA_candidate_baseline_readiness_20261025.md',
            '01_sources/submission/OCMA_candidate_baseline_readiness_20261025.md', 'REVIEW_REPORT',
            'requested in instruction; not located', 'MISSING_SOURCE')
    capture('admission_68', ADMISSION, '01_sources/policy/admission_68.csv', 'POLICY_REGISTRY_SOURCE',
            '68 eligible policies', 'SOURCE_CORPUS_LIST')
    admission = pd.read_csv(ADMISSION)
    assert len(admission) == 68 and admission.policy_id.is_unique
    for row in admission.itertuples(index=False):
        src = Path(getattr(row, '统一库文件路径'))
        capture('policy_text_' + row.policy_id, src,
                '01_sources/policy/fulltext/' + src.name, 'POLICY_FULLTEXT',
                f'policy_id={row.policy_id}; original URL={getattr(row, "原始来源URL")}',
                f'GRADE_{getattr(row, "text_evidence_grade")}')
    capture('candidate_units', FROZEN / '02_coding/analysis_units.csv',
            '01_sources/policy/analysis_units_candidate.csv', 'CANDIDATE_SEGMENTATION',
            '18,808 candidate units', 'NOT_ORIGINAL_MANUAL_CODING')
    capture('machine_coding_draft', FROZEN / '02_coding/reconstructed/action_unit_codes_draft.csv',
            '01_sources/policy/action_unit_codes_machine_draft.csv', 'MACHINE_CODE_SUGGESTIONS',
            '18,808 units', 'NOT_ORIGINAL_MANUAL_CODING')
    capture('machine_codebook', FROZEN / '02_coding/reconstructed/reconstruction_codebook.json',
            '01_sources/policy/machine_codebook.json', 'MACHINE_CODEBOOK',
            'single_coder=true; original_labels_available=false', 'NOT_ORIGINAL_MANUAL_CODING')
    capture('policy_temporal_draft', IND / 'policy_68_semantic_temporal_review_register.csv',
            '01_sources/policy/policy_68_temporal_draft.csv', 'MACHINE_POLICY_AUDIT',
            '68 rows', 'NOT_VALIDITY_CERTIFIED')
    capture('county_raw_workbook', PROJECT / '中国县域数据库v202603修复版（2000-2024年）.xlsx',
            '01_sources/raw/中国县域数据库v202603修复版（2000-2024年）.xlsx', 'COUNTY_RAW_WORKBOOK',
            'source sheets and rows in social_county_sources.csv', 'SOURCE_PRESENT_SCOPE_AUDIT')
    capture('secondary_industry_raw', PROJECT / 'data/raw/policy/socioeconomic/第二产业增加值.xls',
            '01_sources/raw/第二产业增加值.xls', 'INDUSTRY_RAW_WORKBOOK',
            'author-confirmed context; not sole deflator source', 'SOURCE_PRESENT_SCOPE_AUDIT')
    capture('SES_source_workbook', PROJECT / 'Work/莱州湾_SES精简指标体系与分析数据_2011-2023_20260722.xlsx',
            '01_sources/raw/莱州湾_SES精简指标体系与分析数据_2011-2023_20260722.xlsx', 'SOURCE_WORKBOOK',
            'ecological core bay annual sheet; SST origin', 'SOURCE_PRESENT_SCOPE_AUDIT')
    capture('water_quality_prepared', FROZEN / '03_analysis/submitted_reproduction/water_quality_baseline_2011_2023.csv',
            '01_sources/indicators/water_quality_baseline_2011_2023.csv', 'DERIVED_SOURCE_RECORD',
            'year rows 2011-2023; unit metadata provisional', 'PROVISIONAL_UNIT_METADATA_PENDING')
    capture('provincial_deflator_inputs', FROZEN / '00_contract/shandong_secondary_industry_deflator_inputs.csv',
            '01_sources/indicators/shandong_secondary_industry_deflator_inputs.csv', 'AUTHOR_CONFIRMED_INPUT',
            'province nominal and real index 2011-2023', 'AUTHOR_CONFIRMED')
    for name in [
        'social_county_sources.csv', 'social_county_with_public_fiscal.csv',
        'social_county_real_industry.csv', 'social_raw_annual.csv',
        'social_fiscal_capacity_public_partial.csv', 'social_reconstructed_2011_2023.csv',
        'social_scaling_parameters.csv', 'public_fiscal_admitted_cells.csv',
        'public_fiscal_reconstruction_summary.json', 'shandong_secondary_implicit_deflator_2011_2023.csv',
        'model_input_2011_2023_partial.csv', 'model_input_2011_2023_environment_partial.csv',
        'environment_scaling_parameters.csv', 'gwl_habitat_2011_2022_raw.csv',
        'cw_habitat_2018_2023_raw.csv', 'habitat_bridge_comparison.json',
        'habitat_2023_class_endpoint_sensitivity.csv', 'habitat_county_2011_2023_allocated.csv',
        'terraclimate_monthly_by_support.csv', 'terraclimate_annual_10km.csv',
        'terraclimate_source_metadata.csv', 'gwl_source_metadata.csv',
        'environment_reconstruction_summary.json',
    ]:
        capture('indicator_' + name.rsplit('.', 1)[0], IND / name,
                '01_sources/indicators/' + name, 'DERIVED_SOURCE_RECORD', name,
                'SOURCE_BASED_RECONSTRUCTION_WITH_FLAGS')
    capture('B0_status', PROJECT / 'revision_20261025_minimal_repair/FIGURE_COMPATIBILITY_BASELINE_STATUS.md',
            '08_reference_B0/FIGURE_COMPATIBILITY_BASELINE_STATUS.md', 'B0_REFERENCE',
            'reference only; B1 build must not read', 'B0_ONLY')
    capture('B0_table3_audit', PROJECT / 'revision_20261025_minimal_repair/results/figure_compatibility_table3_audit.csv',
            '08_reference_B0/figure_compatibility_table3_audit.csv', 'B0_REFERENCE',
            'reference only; B1 build must not read', 'B0_ONLY')
    for name in ['sd_model.py', 'engine_common.py', 'engine_config.py']:
        capture('engine_' + name, FROZEN / '05_reproduce/engine' / name,
                '05_code/engine/' + name, 'MODEL_CODE', name, 'HISTORICAL_COMPATIBLE_CORE')
    capture('revised_core', FROZEN / '05_reproduce/revised_core.py',
            '05_code/revised_core.py', 'MODEL_CODE', 'reporting and helpers', 'RECONSTRUCTION_CODE')
    capture('cache_safety', PROJECT / 'revision_20261025_minimal_repair/cache_safety.py',
            '05_code/cache_safety.py', 'CACHE_CODE', 'transactional chunk cache', 'RECONSTRUCTION_CODE')
    capture('cache_test', PROJECT / 'revision_20261025_minimal_repair/test_cache_dependency.py',
            '05_code/test_cache_dependency.py', 'TEST_CODE', 'synthetic cache identity tests', 'RECONSTRUCTION_CODE')
    out = pd.DataFrame(records)
    assert out.source_id.is_unique and out.relative_path.is_unique
    out.to_csv(HERE / '00_contract/source_manifest.csv', index=False, encoding='utf-8-sig')
    (HERE / '00_contract/source_capture_status.json').write_text(json.dumps({
        'files_copied': int(out.availability.eq('COPIED_HASH_MATCH').sum()),
        'missing': out.loc[out.availability.eq('MISSING'), 'source_id'].tolist(),
        'policy_fulltexts_copied': int(out.material_type.eq('POLICY_FULLTEXT').sum()),
        'total_copied_bytes': int(out.loc[out.availability.eq('COPIED_HASH_MATCH'), 'bytes'].sum()),
        'original_manual_coding_captured': False,
    }, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps({'copied': int(out.availability.eq('COPIED_HASH_MATCH').sum()),
                      'missing': out.loc[out.availability.eq('MISSING'), 'source_id'].tolist(),
                      'bytes': int(out.bytes.sum())}, ensure_ascii=False), flush=True)


if __name__ == '__main__':
    main()
