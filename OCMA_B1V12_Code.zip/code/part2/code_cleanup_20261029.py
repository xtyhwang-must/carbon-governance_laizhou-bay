"""Finite, hash-bound cleanup plan. Never traverse junctions or delete a directory."""
from pathlib import Path
import argparse,ast,csv,hashlib,json,shutil,subprocess,sys

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'07_publication/R2_FIGURE_CLEANUP_20261029'
R1=ROOT/'07_publication/R1_20261029'

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(x,p):p.write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf8')

def plan():
    OUT.mkdir(parents=True,exist_ok=True)
    target=OUT/'PRE_CLEANUP_SNAPSHOT.json'
    if target.exists():
        print('Existing immutable pre-cleanup snapshot retained');return
    r1=json.loads((R1/'REPORT_REVISION_MANIFEST.json').read_text('utf8'))
    for row in r1['files']:
        if sha(R1/row['path'])!=row['sha256']:raise ValueError('R1 manifest mismatch '+row['path'])
    archive=OUT/'archive_before_cleanup';files=[]
    paths=[p for p in (ROOT/'05_code').rglob('*') if p.is_file() and p.suffix in ('.py','.ps1','.mjs') and '__pycache__' not in p.parts]
    paths += [ROOT/'BASELINE_README.md',ROOT/'PROGRESS.md',ROOT/'requirements_B1.txt']
    paths += [p for d in ['00_contract','04_model'] for p in (ROOT/d).glob('*') if p.is_file() and p.suffix in ('.yaml','.json')]
    for p in paths:
        if not p.exists():continue
        dest=archive/p.relative_to(ROOT);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
        files.append(dict(path=p.relative_to(ROOT).as_posix(),sha256=sha(p),archive=dest.relative_to(OUT).as_posix()))
    frozen=json.loads((R1/'PRE_REVISION_SNAPSHOT.json').read_text('utf8'))['protected']
    # All completed SM results are read-only; no new integration during R2.
    frozen += [dict(path=str(p),sha256=sha(p)) for p in (ROOT/'06_runs/formal_main/SM_local_20261029').glob('*.csv')]
    dump(dict(files=files,protected=frozen,R1_manifest_sha256=sha(R1/'REPORT_REVISION_MANIFEST.json'),
              original_current=json.loads((ROOT.parent/'PART2_CURRENT.json').read_text('utf8'))),target)
    # File graph covers imports, dynamic path strings, stage maps and wrappers.
    textfiles=[]
    for d in ['05_code','00_contract','04_model','00_handoff']:
        textfiles += [p for p in (ROOT/d).rglob('*') if p.is_file() and p.suffix in ('.py','.ps1','.mjs','.yaml','.json','.md','.txt') and '__pycache__' not in p.parts]
    texts={str(p.relative_to(ROOT)):p.read_text('utf-8-sig',errors='replace') for p in textfiles}
    rows=[]
    for p in (ROOT/'05_code').rglob('*.py'):
        if '__pycache__' in p.parts:continue
        own=p.relative_to(ROOT).as_posix();refs=[]
        for name,text in texts.items():
            if name.replace('\\','/')!=own and (p.name in text or p.stem in text):refs.append(name)
        tree=ast.parse(p.read_text('utf-8-sig'))
        dynamic=[ast.unparse(n)[:220] for n in ast.walk(tree) if isinstance(n,ast.Call) and any(s in ast.unparse(n.func) for s in ['import_module','spec_from_file_location','subprocess','load_legacy'])]
        kind='TEST_OR_DIAGNOSTIC_REQUIRED' if p.name.startswith(('test_','qa_','diagnose','state_target','mode_aware')) else 'NUMERIC_REPRODUCTION_REQUIRED'
        if p.stem.startswith(('report_','code_cleanup')):kind='REPORT_ACTIVE'
        rows.append(dict(path=own,classification=kind,references=' | '.join(refs),dynamic_calls=' | '.join(dynamic),reference_count=len(refs)))
    with (OUT/'DEPENDENCY_INVENTORY.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    dump(dict(approved_root=str(ROOT),operations=[
        dict(path='05_code/build_evidence.py',symbol='unreachable statements after terminal raise in policy_chain',action='REMOVE_UNREACHABLE'),
        dict(path='05_code/state_target_diagnostics.py',symbol='legacy_main',action='REMOVE_SUPERSEDED_FUNCTION'),
        dict(path='05_code/diagnose_targets_v12.py',symbol='legacy_terms',action='REMOVE_SUPERSEDED_FUNCTION'),
        dict(path='05_code/report_revision_outputs.py',symbol='R1 report-only functions; retain equation registry used by formal tables',action='RETAIN_REGISTRY_ONLY'),
        dict(path='05_code/report_revision_pdf.py',symbol='R1-only top-level exporter',action='DELETE_FILE'),
        dict(path='05_code/report_revision_workbook.mjs',symbol='R1-only builder',action='DELETE_FILE')]),OUT/'CLEANUP_PLAN.json')
    print('Snapshot and finite plan prepared:',len(files),'code/config/docs; protected',len(frozen))

def apply():
    snap=json.loads((OUT/'PRE_CLEANUP_SNAPSHOT.json').read_text('utf8'));lookup={r['path']:r for r in snap['files']}
    plan=json.loads((OUT/'CLEANUP_PLAN.json').read_text('utf8'))
    receipt=OUT/'CLEANUP_APPLIED.json'
    if receipt.exists():print('ALREADY_APPLIED; explicit plan is idempotent');return
    changes=[]
    for op in plan['operations']:
        path=(ROOT/op['path']).resolve()
        if not path.is_relative_to(ROOT.resolve()) or path.is_symlink() or not path.is_file():raise ValueError('Not an allowed ordinary file')
        archived=OUT/lookup[op['path']]['archive']
        if sha(path)!=sha(archived):raise ValueError('Plan input changed: '+op['path'])
        src=path.read_text('utf-8-sig');lines=src.splitlines(keepends=True);action=op['action'];ranges=[]
        if action=='DELETE_FILE':path.unlink()
        else:
            tree=ast.parse(src)
            if action=='REMOVE_UNREACHABLE':
                for fn in tree.body:
                    if not isinstance(fn,ast.FunctionDef):continue
                    for i,node in enumerate(fn.body[:-1]):
                        if isinstance(node,(ast.Raise,ast.Return)):ranges.append((fn.body[i+1].lineno,fn.body[-1].end_lineno))
            elif action=='REMOVE_SUPERSEDED_FUNCTION':
                fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name==op['symbol']);ranges=[(fn.lineno,fn.end_lineno)]
            else:
                ranges=[(n.lineno,n.end_lineno) for n in tree.body if isinstance(n,ast.FunctionDef) and n.name not in ['sha','rd','write','jout','build_complete_equation_registry']]
            for lo,hi in sorted(ranges,reverse=True):del lines[lo-1:hi]
            cleaned=''.join(lines)
            if action=='RETAIN_REGISTRY_ONLY':cleaned=cleaned.replace('Tables, figures and release snapshot for the reporting-only M3 revision.','Shared equation registry required by formal numerical table reproduction. R1 exporters are archived.')
            ast.parse(cleaned);path.write_text(cleaned,encoding='utf8')
        changes.append(op|dict(before_sha256=sha(archived),after_sha256=sha(path) if path.exists() else '',removed_ranges=ranges,archive=lookup[op['path']]['archive']))
    dump(changes,receipt);print('Applied finite cleanup:',len(changes),'operations')

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--mode',choices=['plan','apply'],required=True);a=ap.parse_args()
    (plan if a.mode=='plan' else apply)()
