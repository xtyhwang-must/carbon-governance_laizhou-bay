"""Hash and ZIP the complete B1 v1.2 workspace, then extract and replay."""
from __future__ import annotations
import hashlib,json,subprocess,sys,tempfile,zipfile
from datetime import datetime,timezone
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
RELEASE=ROOT/'08_release'
VERSION='B1_v1.2.0_definition_consistent'
FAILED_MECHANISM_CACHE='run_d1e3ef4779496b2a024e63c47a67fdd3d82e1394f006c6c993b0e7cd0dc28589'
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def active_cache_generations():
    registered=[
        ('calibration/candidate_cache','calibration/formal_calibration_status.json','candidate_cache_signature'),
        ('scenarios/cache','scenarios/scenario_status.json','cache_signature'),
        ('robustness/cache','robustness/robustness_status.json','cache_signature'),
        ('attribution/cache','attribution/attribution_status.json','cache_signature'),
        ('mechanisms/cache','mechanisms/mechanism_status.json','cache_signature'),
        ('mechanisms/response_surface/cache','mechanisms/response_surface/response_surface_status.json','cache_signature')]
    base=ROOT/'06_runs/formal_main'
    return {(base/cache_dir/('run_'+json.loads((base/status).read_text(encoding='utf-8'))[key])).resolve()
        for cache_dir,status,key in registered}

def files():
    active=active_cache_generations()
    for path in ROOT.rglob('*'):
        if not path.is_file():continue
        rel=path.relative_to(ROOT)
        if rel.parts[0]=='08_release' or rel.name=='baseline_manifest.json':continue
        if rel.parts[:5]==('06_runs','formal_main','mechanisms','cache',FAILED_MECHANISM_CACHE):continue
        obsolete=False
        for i,part in enumerate(rel.parts):
            if (i>0 and part.startswith('run_') and rel.parts[i-1] in {'cache','candidate_cache'}
                    and rel.parts[:2]==('06_runs','formal_main')):
                obsolete=(ROOT/Path(*rel.parts[:i+1])).resolve() not in active
                break
        if obsolete:continue
        if '__pycache__' in rel.parts or path.suffix in ['.pyc','.tmp'] or '.tmp.' in rel.name:continue
        if not path.resolve().is_relative_to(ROOT.resolve()):raise ValueError('External file path')
        yield rel.as_posix(),path

def run(dest,script,timeout=900):
    completed=subprocess.run([sys.executable,'05_code/'+script],cwd=dest,
        text=True,capture_output=True,timeout=timeout)
    return {'script':script,'returncode':completed.returncode,
        'stdout_tail':completed.stdout[-4000:],'stderr_tail':completed.stderr[-4000:]}

def main():
    qa=json.loads((ROOT/'06_runs/formal_main/qa/qa_report.json').read_text(encoding='utf-8'))
    if not qa['all_checks_pass']:raise RuntimeError('B1 v1.2 QA has failures')
    RELEASE.mkdir(parents=True,exist_ok=True)
    entries=[{'relative_path':rel,'sha256':sha(path),'bytes':path.stat().st_size}
        for rel,path in sorted(files())]
    manifest={'version':VERSION,'created_utc':datetime.now(timezone.utc).isoformat(),
        'file_count_excluding_manifest':len(entries),'paths_relative':True,
        'author_confirmation':'CONFIRMED_BY_AUTHOR','source_code_origin':'CODEX_SOURCE_RECONSTRUCTION',
        'full_calibration_executed_in_original_workspace':True,
        'full_calibration_recomputed_in_portable_replay':False,
        'excluded_failed_cache_generation':FAILED_MECHANISM_CACHE,
        'only_current_complete_cache_generations_included':True,
        'files':entries}
    manifest_path=ROOT/'baseline_manifest.json'
    manifest_path.write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    archive=RELEASE/(VERSION+'.zip')
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=3,allowZip64=True) as z:
        for e in entries:z.write(ROOT/e['relative_path'],e['relative_path'])
        z.write(manifest_path,'baseline_manifest.json')
    with zipfile.ZipFile(archive) as z:
        if z.testzip() is not None:raise RuntimeError('ZIP CRC failure')
        names=set(z.namelist())
        if names!={e['relative_path'] for e in entries}|{'baseline_manifest.json'}:
            raise RuntimeError('ZIP path manifest mismatch')
        if any(n.startswith('/') or '..' in Path(n).parts for n in names):raise RuntimeError('Unsafe ZIP path')
        with tempfile.TemporaryDirectory(prefix='B1v12_replay_',dir=RELEASE) as scratch:
            dest=Path(scratch).resolve()
            if not dest.is_relative_to(RELEASE.resolve()):raise RuntimeError('Replay outside release')
            z.extractall(dest)
            for e in entries:
                if sha(dest/e['relative_path'])!=e['sha256']:
                    raise RuntimeError('Extracted source mismatch '+e['relative_path'])
            input_before=sha(dest/'03_indicators/model_input_B1.csv')
            rebuild=run(dest,'build_evidence.py')
            if rebuild['returncode']!=0:raise RuntimeError(json.dumps(rebuild,ensure_ascii=False))
            input_after=sha(dest/'03_indicators/model_input_B1.csv')
            if input_after!=input_before:raise RuntimeError('Input rebuild changed frozen B1 numeric input file')
            replay=run(dest,'v12_replay.py')
            if replay['returncode']!=0:raise RuntimeError(json.dumps(replay,ensure_ascii=False))
    result={'version':VERSION,'portable_replay_pass':True,
        'archive_relative_path':archive.relative_to(ROOT).as_posix(),
        'archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,
        'payload_files':len(entries),'full_calibration_recomputed_in_replay':False,
        'input_rebuilt_from_packaged_sources_identical':True,
        'representative_history_seven_scenarios_and_24_coalitions_replayed':True,
        'rebuild_log':rebuild,'replay_log':replay}
    result['prepublication_replay_archive_sha256']=result['archive_sha256']
    log_path=RELEASE/'portable_replay_log.json'
    log_path.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    # The final decision may now truthfully record the completed portable replay.
    finalize=run(ROOT,'v12_publication.py')
    if finalize['returncode']!=0:raise RuntimeError(json.dumps(finalize,ensure_ascii=False))
    entries=[{'relative_path':rel,'sha256':sha(path),'bytes':path.stat().st_size}
        for rel,path in sorted(files())]
    manifest['created_utc']=datetime.now(timezone.utc).isoformat()
    manifest['file_count_excluding_manifest']=len(entries)
    manifest['portable_replay_completed_before_final_archive']=True
    manifest['files']=entries
    manifest_path.write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=3,allowZip64=True) as z:
        for e in entries:z.write(ROOT/e['relative_path'],e['relative_path'])
        z.write(manifest_path,'baseline_manifest.json')
    with zipfile.ZipFile(archive) as z:
        if z.testzip() is not None:raise RuntimeError('Final ZIP CRC failure')
        if set(z.namelist())!={e['relative_path'] for e in entries}|{'baseline_manifest.json'}:
            raise RuntimeError('Final ZIP paths differ')
        for e in entries:
            if hashlib.sha256(z.read(e['relative_path'])).hexdigest()!=e['sha256']:
                raise RuntimeError('Final ZIP hash differs '+e['relative_path'])
    result.update({'archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,
        'payload_files':len(entries),'final_decision_inside_archive':True,
        'final_archive_hashes_checked':True})
    log_path.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if not k.endswith('_log')},ensure_ascii=False),flush=True)

if __name__=='__main__':main()
