"""One finite mean-vs-median policy-admission-flow pressure test; fixed parameters."""
from pathlib import Path
import json,sys
import pandas as pd,numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path[:0]=[str(ROOT/'05_code/engine'),str(ROOT/'05_code')]
import sd_model as m
from numeric_analysis import projection_constants,scenario_forcing,load_settings,climate_path
from v12_modeling import reference_for
from part2_additional_sensitivity import metrics
from v12_scenario_summary import summarize

def main():
 out=ROOT/'06_runs/formal_main/additional_sensitivity';(out/'policy_flow_protocol.json').write_text(json.dumps({'specification':'POLICY_FLOW_RECENT_MEAN','only_change':'recent2021-2023mean weighted admissions replaces median','parameters':'12 existing equally spaced retained indices','no_refit':True,'does_not_change_main_ranking':True},indent=2),'utf8')
 f=pd.read_csv(ROOT/'03_indicators/model_input_B1.csv');cal=json.loads((ROOT/'06_runs/formal_main/calibration/formal_calibration_status.json').read_text('utf8'));s=cal['structure'];names=m.parameter_names(s);ens=pd.read_csv(ROOT/'06_runs/formal_main/calibration/accepted_parameter_ensemble.csv');sample=ens.iloc[np.unique(np.linspace(0,len(ens)-1,min(12,len(ens)),dtype=int))];stock=pd.read_csv(ROOT/'02_policy/reconstructed/policy_stock_by_year_B1.csv');projection=projection_constants()
 for g in projection:
  x=list(projection[g]);x[1]=float(stock[stock.channel.eq(g)&stock.year.between(2021,2023)].new_effective_admissions.mean());projection[g]=tuple(x)
 settings=load_settings();climate=climate_path(f);rows=[]
 for r in sample.itertuples():
  p={n:float(getattr(r,n)) for n in names};ref=reference_for(f,m.historical_forcing(f),m.initial_state(f,year=2011),p,s)
  for sid in settings:
   force,_,_=scenario_forcing(f,settings[sid],climate,projection=projection);z=m.simulate(p,force,np.arange(2023,2031,dtype=float),m.initial_state(f,year=2023),structure=s,reference_context=ref);rows.append(metrics(z,r.parameter_set_id,sid,'POLICY_FLOW_RECENT_MEAN'))
 path=out/'all_additional_metrics.csv';old=pd.read_csv(path);pd.concat([old[old.specification_id.ne('POLICY_FLOW_RECENT_MEAN')],pd.DataFrame(rows)],ignore_index=True).to_csv(path,index=False,encoding='utf-8-sig')
 _,_,_,q=summarize(pd.DataFrame(rows));q.insert(0,'specification_id','POLICY_FLOW_RECENT_MEAN');path=out/'paired_sensitivity_summary.csv';old=pd.read_csv(path);pd.concat([old[old.specification_id.ne('POLICY_FLOW_RECENT_MEAN')],q],ignore_index=True).to_csv(path,index=False,encoding='utf-8-sig');print('Policy-flow pressure test completed84 cells')
if __name__=='__main__':main()
