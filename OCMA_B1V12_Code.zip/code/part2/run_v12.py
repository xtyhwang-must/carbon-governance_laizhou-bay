"""Executable B1 v1.2 stage runner. Each command performs the named calculation."""
from __future__ import annotations
import argparse,hashlib,json,os,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
PY=sys.executable
SCRIPTS={
    'preflight':'part2_preflight.py',
    'ses':'part2_ses.py',
    'sensitivity':'part2_additional_sensitivity.py',
    'documents':'part2_documents.py',
    'report-qa':'part2_report_qa.py',
    'compare':'compare_structures.py',
    'calibrate':'v12_formal_calibration.py',
    'evaluate':'v12_evaluation.py',
    'scenarios':'v12_scenarios.py',
    'robustness':'v12_robustness.py',
    'attribution':'v12_attribution.py',
    'mechanisms':'v12_mechanisms.py',
    'surface':'v12_response_surface.py',
    'figures':'part2_figures.py',
    'tables':'part2_tables.py',
    'workbook':'part2_workbook.py',
    'trace':'traceability_v12.py',
    'publish':'part2_release.py',
    'numerical':'v12_numerical_qa.py',
    'release':'part2_release.py',
    'replay':'v12_replay.py'}

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest().upper()
def execute(script):
    print(f'RUN {script}',flush=True)
    if script=='part2_figures.py':execute('v12_figures.py')
    if script=='v12_formal_calibration.py':
        from part2_tables import register
        register()
    interpreter=os.environ.get('B1_DOCUMENT_PYTHON',PY) if script=='v12_tables.py' else PY
    subprocess.run([interpreter,str(ROOT/'05_code'/script)],cwd=ROOT,check=True)
    if script=='part2_additional_sensitivity.py':execute('part2_policy_flow_test.py')

def rebuild_inputs():
    if (ROOT/'00_contract/part2_run.json').exists():
        execute('part2_ht_bridge.py');execute('build_evidence.py');return
    raise RuntimeError('Use frozen b1 for historical rebuild; Part2 requires its current HT contract')

def verify():
    execute('part2_report_qa.py')

def main():
    choices=['rebuild-inputs',*SCRIPTS,'verify','all']
    p=argparse.ArgumentParser();p.add_argument('--stage',choices=choices,required=True)
    args=p.parse_args()
    if args.stage=='rebuild-inputs':rebuild_inputs()
    elif args.stage=='verify':verify()
    elif args.stage=='all':
        rebuild_inputs()
        execute('part2_ses.py')
        for stage in ['compare','calibrate','evaluate','scenarios','robustness','attribution',
            'mechanisms','surface','numerical','sensitivity','tables','figures','workbook','trace']:execute(SCRIPTS[stage])
        verify();execute(SCRIPTS['publish']);execute(SCRIPTS['release'])
    else:execute(SCRIPTS[args.stage])

if __name__=='__main__':main()
