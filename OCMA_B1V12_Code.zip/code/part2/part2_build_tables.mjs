import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import {createHash} from 'node:crypto';
import { createRequire } from 'node:module';
const req=createRequire('C:/Users/Mario/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/package.json');
const {Workbook,SpreadsheetFile}=await import(pathToFileURL(req.resolve('@oai/artifact-tool')).href);
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../07_publication');
const data=JSON.parse(await fs.readFile(path.join(root,'tables_payload.json'),'utf8'));
const book=Workbook.create();
const previews=path.join(root,'table_previews'); await fs.mkdir(previews,{recursive:true});
for(const entry of data){
 const sheet=book.worksheets.add(entry.name);sheet.showGridLines=false;
 const rows=entry.rows.map(row=>row.map(v=>typeof v==='string'&&v.startsWith('=')?"'"+v:v));
 const range=sheet.getRangeByIndexes(0,0,rows.length,rows[0].length);range.values=rows;
 range.format.font={name:'Arial',size:10};range.format.rowHeight=20;range.format.columnWidth=18;
 const header=sheet.getRangeByIndexes(0,0,1,rows[0].length);
 header.format={fill:'#244A73',font:{name:'Arial',size:10,bold:true,color:'#FFFFFF'},wrapText:true,rowHeight:42};
 sheet.freezePanes.freezeRows(1);
 const widths=[];
 for(let j=0;j<rows[0].length;j++){
  const vals=rows.slice(1).map(r=>r[j]);const num=vals.some(v=>typeof v==='number');
  const r=sheet.getRangeByIndexes(1,j,Math.max(1,rows.length-1),1);
  widths[j]=num?18:Math.min(58,Math.max(18,...vals.filter(v=>typeof v==='string').map(v=>Math.min(58,v.length*.85))));
  if(num)r.setNumberFormat(/count|sets|paths|cells|^n$|^n_|year|seed|candidate|accepted|fail|nfev|^line$|^direction_(numerator|denominator)$|^TP$|^FP$|^FN$|^TN$/.test(String(rows[0][j]))?'0':'0.0000');
  else {r.format.columnWidth=widths[j];r.format.wrapText=true;}
 }
 for(let i=1;i<rows.length;i++){
  const lines=Math.max(1,...rows[i].map((v,j)=>typeof v==='string'?Math.ceil(v.length/Math.max(10,widths[j]*.78)):1));
  sheet.getRangeByIndexes(i,0,1,rows[0].length).format.rowHeight=Math.max(20,lines*14+6);
 }
 const source=sheet.getRangeByIndexes(rows.length+2,0,1,1);source.values=[['Source: '+entry.source]];
 source.format.font={name:'Arial',size:9,color:'#666666'};
}
book.recalculate();
const errors=await book.inspect({kind:'match',searchTerm:'#REF!|#DIV/0!|#VALUE!|#NAME\\?|#NUM!|#SPILL!',options:{useRegex:true,maxResults:100},maxChars:1500});
await fs.writeFile(path.join(root,'workbook_inspection.json'),errors.ndjson);
for(const entry of data){
 const preview=await book.render({sheetName:entry.name,range:`A1:${String.fromCharCode(65+Math.min(7,entry.rows[0].length-1))}${Math.min(10,entry.rows.length)}`,scale:1.4,format:'png'});
 await fs.writeFile(path.join(previews,entry.name+'.png'),new Uint8Array(await preview.arrayBuffer()));
}
await (await SpreadsheetFile.exportXlsx(book)).save(path.join(root,'B1_V1.2_PART2_更新结果表.xlsx'));
await fs.writeFile(path.join(root,'workbook_generation.json'),JSON.stringify({payload_sha256:createHash('sha256').update(await fs.readFile(path.join(root,'tables_payload.json'))).digest('hex'),completed:true}));
console.log(JSON.stringify({sheets:data.length,output:path.join(root,'B1_V1.2_PART2_更新结果表.xlsx')}));
