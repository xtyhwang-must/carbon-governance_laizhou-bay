"""B1 v1.2 endpoint social screen and minimum-ES-first matched summaries."""
from __future__ import annotations
from itertools import combinations
import numpy as np
import pandas as pd

MATCH=['parameter_set_id','forcing_draw_id','initial_state_hash']
EPS_SR=5e-4
EPS_ES=5e-4

def metrics_from_trajectories(trajectories:pd.DataFrame)->pd.DataFrame:
    rows=[]
    for keys,g in trajectories.groupby(MATCH+['scenario'],sort=False):
        g=g.sort_values('year');shock=g[g.year.between(2026,2030)]
        terminal=g[g.year.eq(2030)]
        if len(shock)!=5 or len(terminal)!=1:raise ValueError('Annual 2026–2030/2030 cells incomplete')
        rows.append(dict(zip(MATCH+['scenario'],keys))|{
            'min_ES_2026_2030':float(shock.ES.min()),
            'ES_2030':float(terminal.ES.iloc[0]),'SR_2030':float(terminal.SR.iloc[0]),
            'min_SR_2024_2030':float(g[g.year.between(2024,2030)].SR.min())})
    return pd.DataFrame(rows)

def summarize(metrics:pd.DataFrame,eps_sr=EPS_SR,eps_es=EPS_ES):
    if metrics.duplicated(MATCH+['scenario']).any():raise ValueError('Duplicate matched scenario key')
    scenarios=sorted(metrics.scenario.unique())
    if scenarios!=[f'S{i}' for i in range(7)]:raise ValueError('S0–S6 required')
    counts=metrics.groupby(MATCH).scenario.nunique()
    if not counts.eq(7).all():raise ValueError('Unmatched seven-scenario cells')
    base=metrics[metrics.scenario.eq('S0')][MATCH+['SR_2030','min_SR_2024_2030']].rename(columns={
        'SR_2030':'S0_SR_2030','min_SR_2024_2030':'S0_min_SR_2024_2030'})
    social=metrics.merge(base,on=MATCH,validate='many_to_one')
    social['D_SR_2030']=social.SR_2030-social.S0_SR_2030
    social['D_min_SR_2024_2030']=social.min_SR_2024_2030-social.S0_min_SR_2024_2030
    social['individual_terminal_pass']=social.D_SR_2030.ge(-eps_sr)
    screening=social.groupby('scenario').agg(
        n=('D_SR_2030','size'),median_D_SR_2030=('D_SR_2030','median'),
        individual_terminal_pass_count=('individual_terminal_pass','sum'),
        individual_terminal_pass_fraction=('individual_terminal_pass','mean'),
        median_D_min_SR=('D_min_SR_2024_2030','median')).reset_index()
    screening['main_screen_pass']=screening.median_D_SR_2030.ge(-eps_sr)
    screening['epsilon_SR']=eps_sr
    summary=metrics.groupby('scenario').agg(min_ES_median=('min_ES_2026_2030','median'),
        ES_2030_median=('ES_2030','median'),SR_2030_median=('SR_2030','median')).reset_index()
    summary=summary.merge(screening[['scenario','main_screen_pass','median_D_SR_2030']],on='scenario')
    summary['main_rank']=pd.NA
    passed=summary[summary.main_screen_pass].sort_values(['min_ES_median','ES_2030_median'],ascending=False)
    for rank,idx in enumerate(passed.index,1):summary.loc[idx,'main_rank']=rank
    summary['ranking_definition']='screen_terminal_median_then_min_ES_2026_2030_then_ES_2030'
    pivots={metric:metrics.pivot(index=MATCH,columns='scenario',values=metric)
        for metric in ['min_ES_2026_2030','ES_2030','SR_2030','min_SR_2024_2030']}
    pair_rows=[]
    for a,b in combinations(scenarios,2):
        deltas={k:pivots[k][a]-pivots[k][b] for k in pivots}
        for metric,d in deltas.items():
            pair_rows.append({'scenario_a':a,'scenario_b':b,'metric':metric,
                'n_matched':len(d),'median_a_minus_b':float(d.median()),
                'P5_a_minus_b':float(d.quantile(.05)),'P95_a_minus_b':float(d.quantile(.95)),
                'fraction_a_above_tolerance':float((d>eps_es).mean()),
                'fraction_b_above_tolerance':float((d<-eps_es).mean()),
                'fraction_within_tolerance':float((d.abs()<=eps_es).mean()),
                'tolerance_ES':eps_es})
    pairs=pd.DataFrame(pair_rows)
    return social,screening,summary,pairs

def test_definitions():
    # The extrema occur in different years. The two possible formulas differ.
    x=pd.DataFrame({'year':[2026,2027,2028,2029,2030]*2,
      'scenario':['S4']*5+['S0']*5,
      'ES':[.3,.1,.3,.3,.3,.2,.4,.4,.4,.4],
      'SR':[.2]*10,'parameter_set_id':['TEST']*10,
      'forcing_draw_id':['TEST']*10,'initial_state_hash':['TEST']*10})
    m=metrics_from_trajectories(x).set_index('scenario')
    correct=m.loc['S4','min_ES_2026_2030']-m.loc['S0','min_ES_2026_2030']
    naive=np.min(x[x.scenario.eq('S4')].ES.to_numpy()-x[x.scenario.eq('S0')].ES.to_numpy())
    assert np.isclose(correct,-.1) and np.isclose(naive,-.3) and not np.isclose(correct,naive)
    # Terminal screening and process-minimum screening deliberately disagree.
    assert np.median([-.0003,-.0004])>=-EPS_SR
    assert np.median([-.0007,-.0008])<-EPS_SR
    return {'different_minima_formula':True,'terminal_vs_process_screen_distinct':True}

if __name__=='__main__':print(test_definitions())
