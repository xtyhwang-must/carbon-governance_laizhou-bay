"""Exercise candidate cache recovery without touching empirical candidate blocks."""
from pathlib import Path
import json
import tempfile
import numpy as np
import pandas as pd
import numeric_calibration as n

def main():
    original=n.OUT
    try:
        with tempfile.TemporaryDirectory(prefix='b1_candidate_cache_') as folder:
            n.OUT=Path(folder)
            n.context();v=(n.BOUNDS[:,0]+n.BOUNDS[:,1])/2
            dependency=n.deps()
            path=Path(n.candidate_block(('test',0,v.reshape(1,-1),dependency)))
            baseline=pd.read_csv(path)
            assert len(baseline)==1
            meta=json.loads(path.with_suffix('.meta.json').read_text(encoding='utf-8'))
            assert meta['file_sha256']==n.sha(path)
            changed=baseline.copy();changed.loc[0,'loss']=999.
            changed.to_csv(path,index=False)
            n.candidate_block(('test',0,v.reshape(1,-1),dependency))
            assert abs(pd.read_csv(path).loss.iloc[0]-baseline.loss.iloc[0])<1e-12
            altered=v.copy();altered[0]+=0.01
            n.candidate_block(('test',0,altered.reshape(1,-1),dependency))
            assert np.isclose(pd.read_csv(path)[n.NAMES[0]].iloc[0],altered[0])
            path.with_suffix('.meta.json').unlink()
            n.candidate_block(('test',0,altered.reshape(1,-1),dependency))
            assert path.with_suffix('.meta.json').exists()
        print('candidate cache: tamper, same ID changed vector, missing metadata recovery PASS')
    finally:n.OUT=original

if __name__=='__main__':main()
