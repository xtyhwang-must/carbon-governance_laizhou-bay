"""Independent negative tests for atomic chunk cache and full dependency identity."""
from __future__ import annotations
import json,sys,tempfile
from pathlib import Path
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'05_code'))
from cache_safety import ChunkCache,signature,sha256

def test():
    with tempfile.TemporaryDirectory(prefix='b12_cache_',dir=ROOT/'06_runs') as d:
        root=Path(d);data=root/'input.csv';code=root/'code.py';config=root/'config.json'
        data.write_text('year,value\n2023,0.1\n',encoding='utf-8')
        code.write_text('result=1\n',encoding='utf-8')
        config.write_text('{"step":0.05}',encoding='utf-8')
        deps=[data,code,config]
        params={'id':'P1','actual_vector':[.1,.2],'initial_year':2023,
            'initial_vector':[.3,.4],'reference_hash':'A','forcing_hash':'B'}
        key,material=signature(deps,params,root=root)
        cache=ChunkCache(root/'cache',key,material)
        expected=['P1:S0:2030'];required=['cache_row_id','value']
        frame=pd.DataFrame({'cache_row_id':expected,'value':[.1]})
        assert cache.load('P1',expected,required) is None
        assert not cache.complete.exists(), 'Interrupted run must not be COMPLETE'
        cache.commit('P1',frame,expected,required)
        assert cache.load('P1',expected,required) is not None
        assert not cache.complete.exists(), 'COMPLETE must be last'
        cache.finalize([('P1',expected,required)])
        assert json.loads(cache.complete.read_text())['status']=='COMPLETE'
        data_path,_=cache.chunk_paths('P1');data_path.write_text('cache_row_id,value\nP1:S0:2030,0.9\n')
        assert cache.load('P1',expected,required) is None,'Tampered block reused'
        cache.commit('P1',frame,expected,required)
        assert cache.load('P1',['P1:S1:2030'],required) is None,'Same row count but wrong IDs reused'
        changed=dict(params);changed['actual_vector']=[.1,.3]
        key_changed,mat_changed=signature(deps,changed,root=root)
        assert key_changed!=key
        assert ChunkCache(root/'cache',key_changed,mat_changed).load('P1',expected,required) is None
        for file,new_text in [(config,'{"step":0.02}'),(code,'result=2\n'),(data,'year,value\n2023,0.2\n')]:
            original=file.read_text(encoding='utf-8');file.write_text(new_text,encoding='utf-8')
            newer,_=signature(deps,params,root=root)
            assert newer!=key,f'Change to {file.name} failed to invalidate cache'
            file.write_text(original,encoding='utf-8')
    return {'pass':True,'interrupt_before_complete':True,'tamper_rejected':True,
        'same_id_different_content_rejected':True,'data_code_config_change_invalidates':True}

if __name__=='__main__':
    x=test();dest=ROOT/'06_runs/P0_legacy_structure_correct_initial/cache_negative_tests.json'
    dest.parent.mkdir(parents=True,exist_ok=True)
    dest.write_text(json.dumps(x,indent=2),encoding='utf-8')
    print(x)
