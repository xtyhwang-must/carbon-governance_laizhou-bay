"""Independent-value and negative tests for the P0 year-specific initial state."""
from __future__ import annotations
import importlib.util,json,sys
from pathlib import Path
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'05_code/engine'),str(ROOT/'05_code')]
import engine_config as cfg
import sd_model as model
from numeric_analysis import scenario_forcing,load_settings,climate_path

def independent_row(frame,year):
    chosen=frame.loc[frame.year.eq(year)]
    assert len(chosen)==1
    return chosen.iloc[0][cfg.STATE_NAMES].to_numpy(float)

def main():
    frame=pd.read_csv(ROOT/'03_indicators/model_input_B1.csv')
    old_path=ROOT/'00_reference_v1_1/legacy_engine/sd_model.py'
    spec=importlib.util.spec_from_file_location('frozen_v11_sd_model_for_negative_test',old_path)
    old=importlib.util.module_from_spec(spec);sys.modules[spec.name]=old;spec.loader.exec_module(old)
    observed_2011=independent_row(frame,2011);observed_2023=independent_row(frame,2023)
    old_future=old.initial_state(frame)
    assert np.allclose(old_future,observed_2011) and not np.allclose(old_future,observed_2023)
    outcome={'frozen_v11_wrong_future_year_detected':True,'negative_cases':{},'tests':{}}
    for year,expected in [(2011,observed_2011),(2023,observed_2023)]:
        actual=model.initial_state(frame,year=year)
        assert np.allclose(actual,expected,rtol=0,atol=1e-12)
        outcome['tests'][f'explicit_{year}']=True
    for label,bad in [('missing_2023',frame[frame.year.ne(2023)]),
                      ('duplicate_2023',pd.concat([frame,frame[frame.year.eq(2023)]],ignore_index=True)),
                      ('nonfinite_2023',frame.assign(SC=lambda x:x.SC.mask(x.year.eq(2023),np.nan)))]:
        try:model.initial_state(bad,year=2023)
        except ValueError:outcome['negative_cases'][label]='REJECTED'
        else:raise AssertionError(f'{label} was accepted')
    try:model.initial_state(frame)
    except TypeError:outcome['negative_cases']['omitted_year']='REJECTED'
    else:raise AssertionError('Omitted year accepted')
    shuffled=frame.sample(frac=1,random_state=20261025).reset_index(drop=True)
    assert np.allclose(model.initial_state(shuffled,year=2023),observed_2023,atol=1e-12)
    outcome['tests']['shuffled_input_same_2023']=True
    settings=load_settings();forcing,_,annual=scenario_forcing(frame,settings['S0'],climate_path(frame))
    first=annual.loc[annual.year.eq(2023)]
    assert len(first)==1
    first=first.iloc[0]
    row=frame.loc[frame.year.eq(2023)].iloc[0]
    for a,b in [('G1_TARGET','G1'),('G2_TARGET','G2'),('G3_TARGET','G3'),('PPT','PPT'),('RUNOFF','RUNOFF'),('SST','SST'),('ETA_POTENTIAL','ETA_POTENTIAL'),('SYNERGY_LEVER','SYNERGY_LEVER')]:
        assert abs(float(first[a])-float(row[b]))<1e-12
    assert first.POLICY_TAU==.5 and first.FEEDBACK_STRENGTH==0
    assert np.allclose(np.array(list(forcing.at(2023).values()),float),
                       np.array([first[k] for k in forcing.required_columns if k!='year'],float))
    best=json.loads((ROOT/'00_reference_v1_1/calibration/best_parameter_set.json').read_text(encoding='utf-8'))['parameters']
    result=model.simulate(best,forcing,np.array([2023.,2024.]),model.initial_state(frame,year=2023))
    assert result.year.iloc[0]==2023 and np.allclose(result.iloc[0][cfg.STATE_NAMES].to_numpy(float),observed_2023,atol=1e-12)
    # Derive ES and SR from the main-table states without calling reporting_states.
    wq=((1-row.NS)*(1-row.OS)*(1-row.BS))**(1/3)
    habitat=np.sqrt(row.TF*row.SM)
    expected_es=np.sqrt(wq*habitat);expected_sr=np.sqrt((1-row.SP)*row.SC)
    assert abs(result.ES.iloc[0]-expected_es)<1e-12 and abs(result.SR.iloc[0]-expected_sr)<1e-12
    outcome['tests']['solver_first_state_forcing_ES_SR']=True
    wrong=model.initial_state(frame,year=2011)
    assert not np.allclose(wrong,observed_2023)
    outcome['negative_cases']['2011_injected_as_future']='REJECTED_BY_INDEPENDENT_EXPECTED_2023'
    out=ROOT/'06_runs/P0_legacy_structure_correct_initial';out.mkdir(parents=True,exist_ok=True)
    for year in [2011,2023]:
        x=independent_row(frame,year)
        record={'year':year,'state_order':cfg.STATE_NAMES,'state_vector':x.tolist(),
            'observation_row_year':year,'initial_value_role':'observed_or_registered_derived_state',
            'IM_PR_PRS_measured':False}
        if year==2023:
            record.update({'ES':float(expected_es),'SR':float(expected_sr),'initial_forcing':first.to_dict()})
        (out/f'initial_state_{year}.json').write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
    (out/'initialization_tests.json').write_text(json.dumps(outcome,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(outcome,ensure_ascii=False))

if __name__=='__main__':main()
