"""Targeted, source-aware QA for the incomplete B1 evidence chain."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import sys

import numpy as np
import pandas as pd
import yaml

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(Path(__file__).resolve().parent))
from test_cache_dependency import main as test_cache


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def check(name, condition, detail, records):
    passed = bool(condition)
    records.append({'check': name, 'pass': passed, 'detail': str(detail)})
    if not passed:
        raise AssertionError(f'{name}: {detail}')


def main():
    records = []
    c = yaml.safe_load((ROOT / '00_contract/baseline_contract.yaml').read_text(encoding='utf-8'))
    manifest = pd.read_csv(ROOT / '00_contract/source_manifest.csv').fillna('')
    available = manifest[manifest.availability.isin(['COPIED_HASH_MATCH', 'ADAPTED_LOCAL_CODE'])]
    for row in available.itertuples():
        path = (ROOT / row.relative_path).resolve()
        check('manifest_' + row.source_id, path.is_relative_to(ROOT.resolve()) and path.is_file() and sha(path) == row.sha256,
              row.relative_path, records)
    check('68_policy_texts', (manifest.source_id.str.startswith('policy_text_')).sum() == 68,
          'exactly 68 fulltext source records', records)

    registry = pd.read_csv(ROOT / '02_policy/policy_registry.csv')
    clauses = pd.read_csv(ROOT / '02_policy/coded_clauses.csv')
    stock = pd.read_csv(ROOT / '02_policy/policy_stock_by_year.csv')
    check('policy_count', len(registry) == 68 and registry.policy_id.is_unique, len(registry), records)
    check('clause_anchors', len(clauses) == 18808 and not clauses.duplicated(['policy_id', 'unit_id']).any() and
          (clauses.end_char > clauses.start_char).all(), len(clauses), records)
    original = ['original_qualification', 'original_G1', 'original_G2', 'original_G3'] + [f'original_T{i}' for i in range(1,7)]
    check('no_false_manual_codes', clauses[original].isna().all().all() and
          clauses.coding_status.eq('ORIGINAL_SINGLE_CODER_LABEL_NOT_RECOVERED').all(),
          'all source single-coder labels absent; machine suggestions separate', records)
    check('no_false_policy_stock', len(stock) == 72 and stock.active_valid_policy_stock.isna().all(),
          '2000-2023 x 3 channels remain unknown', records)

    mi = pd.read_csv(ROOT / '03_indicators/model_input_B1.csv')
    lin = pd.read_csv(ROOT / '03_indicators/indicator_lineage.csv')
    social = pd.read_csv(ROOT / '03_indicators/social_states_B1.csv')
    env = pd.read_csv(ROOT / '03_indicators/environment_states_B1.csv')
    check('year_grid', mi.year.tolist() == list(range(2011, 2024)) and len(lin) == 351,
          '13 annual states, 351 lineage rows', records)
    check('no_B0_main_ancestor', not lin.source_id.astype(str).str.contains('B0|digitiz|target_guided', case=False, regex=True).any(),
          'lineage excludes B0 digitized and target-guided series', records)
    blocked = ['G1', 'G2', 'G3', 'ETA_POTENTIAL', 'SYNERGY_LEVER', 'IM']
    check('calibration_guard', mi[blocked].isna().all().all() and not mi.input_complete.any(),
          'required policy and implementation inputs missing', records)
    check('social_formula', np.allclose(mi.SR, np.sqrt((1-mi.SP)*mi.AC), atol=1e-10) and
          np.allclose(mi.AC, mi.SC, atol=1e-12), 'SR and AC/SC mapping', records)
    check('ecology_formula', np.allclose(mi.WQ, ((1-mi.NS)*(1-mi.OS)*(1-mi.BS))**(1/3), atol=1e-10) and
          np.allclose(mi.H, np.sqrt(mi.TF*mi.SM), atol=1e-10) and
          np.allclose(mi.ES, np.sqrt(mi.WQ*mi.H), atol=1e-10), 'WQ, H, ES equations', records)
    check('bounded_observed_states', mi[['SP','AC','NS','OS','BS','TF','SM','PPT','RUNOFF','SST']].ge(0).all().all() and
          mi[['SP','AC','NS','OS','BS','TF','SM','PPT','RUNOFF','SST']].le(1).all().all(),
          'state values in [0,1]', records)
    check('habitat_estimate_flag', bool(mi.loc[mi.year.eq(2023),'habitat_2023_estimated'].iloc[0]) and
          not mi.loc[mi.year.lt(2023),'habitat_2023_estimated'].any(), '2023 only', records)
    check('evaluation_weight_isolated', c['ecology']['2023_evaluation_weight'] == .35 and
          c['ecology']['2023_initial_state_blend'] is False and
          np.allclose(mi.H, env.H) and np.allclose(mi.SR, social.SR), '0.35 not used in state construction', records)

    pars = pd.read_csv(ROOT / '04_model/parameter_registry.csv')
    sc = pd.read_csv(ROOT / '04_model/scenario_registry.csv')
    eq = pd.read_csv(ROOT / '04_model/equation_registry.csv')
    check('nine_original_bounds', pars.identity.eq('CALIBRATED').sum() == 9 and
          set(pars.loc[pars.identity.eq('CALIBRATED'),'parameter']) == set(c['parameter_bounds']),
          'nine calibrated parameter names', records)
    for row in pars.loc[pars.identity.eq('CALIBRATED')].itertuples():
        check('bounds_'+row.parameter, np.allclose([row.lower,row.upper],c['parameter_bounds'][row.parameter]),
              [row.lower,row.upper], records)
    tau = dict(zip(sc.scenario_id, sc.tau_years))
    check('scenario_tau', tau == c['scenario_tau_years'] and not sc.model_executable.any(), tau, records)
    check('equation_source_objects', len(eq) >= 60 and eq.full_expression_OMML_XML.notna().all(),
          f'{len(eq)} OMML source objects', records)
    check('run_identity', (ROOT / '06_runs/B1_preflight/run_identity.json').exists(), 'input/code/config hashes captured', records)

    # A synthetic solver check guards code wiring only; it is not an empirical
    # parameter estimate, historical trajectory, or scenario comparison.
    sys.path.insert(0, str(CODE_ENGINE := ROOT / '05_code/engine'))
    import sd_model
    import engine_config
    forcing_rows = []
    for year in [2011, 2012, 2013]:
        forcing_rows.append({'year': year, 'G1_TARGET': .5, 'G2_TARGET': .5,
                             'G3_TARGET': .5, 'PPT': .5, 'RUNOFF': .5, 'SST': .5,
                             'ETA_POTENTIAL': .5, 'POLICY_TAU': .5,
                             'FEEDBACK_STRENGTH': .5, 'SYNERGY_LEVER': .5})
    forcing = sd_model.AnnualForcing(pd.DataFrame(forcing_rows))
    pars_mid = np.array([(a+b)/2 for a,b in c['parameter_bounds'].values()])
    times = np.array([2011., 2012., 2013.])
    init = np.full(len(engine_config.STATE_NAMES), .5)
    t05 = sd_model.simulate(pars_mid, forcing, times, init, max_step=.05)
    t02 = sd_model.simulate(pars_mid, forcing, times, init, max_step=.02)
    state_cols = engine_config.STATE_NAMES
    delta = float(np.max(np.abs(t05[state_cols].to_numpy() - t02[state_cols].to_numpy())))
    check('synthetic_solver_wiring', np.isfinite(t05[state_cols]).all().all() and
          t05[state_cols].ge(0).all().all() and t05[state_cols].le(1).all().all() and delta < 1e-4,
          f'2-year midpoint-parameter synthetic replay; max .05/.02 step delta={delta:.6g}', records)

    # Tests the cache implementation with synthetic data only. It is not a B1 model run.
    test_cache(ROOT / '06_runs/B1_preflight/cache_dependency_test.csv')
    check('cache_dependency_suite', True, 'ten synthetic failure modes passed', records)
    report = {'version': c['version'], 'status': 'PASS_FOR_EVIDENCE_PREFLIGHT_ONLY',
              'full_B1_model_executed': False, 'checks': len(records), 'records': records}
    out = ROOT / '06_runs/B1_preflight'
    (out / 'baseline_qa_report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    pd.DataFrame(records).to_csv(out / 'test_log.csv', index=False, encoding='utf-8-sig')
    print(f'{len(records)} B1 evidence preflight checks passed; numerical B1 remains blocked')


if __name__ == '__main__':
    main()
