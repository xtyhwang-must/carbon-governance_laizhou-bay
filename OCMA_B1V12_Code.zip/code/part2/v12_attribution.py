"""Matched grouped Shapley for S4-S0 and audited-difference S4-S6."""
from __future__ import annotations
import hashlib,itertools,json,math,sys
from concurrent.futures import ProcessPoolExecutor,as_completed
from pathlib import Path
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'05_code/engine'),str(ROOT/'05_code')]
import engine_config as cfg
import sd_model as model
from cache_safety import ChunkCache,signature,atomic_json
from v12_modeling import reference_for
from numeric_analysis import load_settings,climate_path,scenario_forcing

CAL=ROOT/'06_runs/formal_main/calibration'
SCEN=ROOT/'06_runs/formal_main/scenarios'
OUT=ROOT/'06_runs/formal_main/attribution'
GROUPS_40={'policy_G1_G2_G3':['G1','G2','G3'],'response_eta_tau':['eta','tau'],
    'feedback':['feedback'],'synergy':['synergy']}
GROUPS_46={'G3':['G3'],'tau':['tau'],'feedback':['feedback']}
REPORT=['min_ES_2026_2030','ES_2030','SR_2030']

def group_spec(base,high):
    settings=load_settings()
    differing={k for k in settings[base] if not np.isclose(settings[base][k],settings[high][k],atol=1e-12)}
    if (base,high)==('S0','S4'):
        groups=GROUPS_40
    elif (base,high)==('S6','S4'):
        if not differing.issubset({'G3','tau','feedback'}):
            raise ValueError(f'S4-S6 actual differences changed: {differing}')
        groups=GROUPS_46
    else:raise ValueError((base,high))
    grouped={lever for names in groups.values() for lever in names}
    if not differing.issubset(grouped):raise ValueError(f'Grouped={grouped}, actual={differing}')
    return groups

def one(args):
    pid,params,structure,frame,climate,settings=args
    initial=model.initial_state(frame,year=2023)
    ih=hashlib.sha256(initial.tobytes()).hexdigest()
    hist=model.historical_forcing(frame)
    ref=reference_for(frame,hist,model.initial_state(frame,year=2011),params,structure)
    rh=hashlib.sha256(json.dumps(ref,sort_keys=True).encode()).hexdigest() if ref is not None else 'RUN_SPECIFIC'
    ph=hashlib.sha256(json.dumps(params,sort_keys=True).encode()).hexdigest()
    rows=[]
    for base,high in [('S0','S4'),('S6','S4')]:
        groups=group_spec(base,high);names=list(groups)
        for count in range(len(names)+1):
            for coalition in itertools.combinations(names,count):
                active=set(coalition);setting=dict(settings[base])
                for group in active:
                    for lever in groups[group]:setting[lever]=settings[high][lever]
                forcing,_,f_frame=scenario_forcing(frame,setting,climate)
                trajectory=model.simulate(params,forcing,np.arange(2023,2031,dtype=float),initial,
                    structure=structure,reference_context=ref)
                if not np.allclose(trajectory.iloc[0][cfg.STATE_NAMES].to_numpy(float),initial,atol=1e-12):
                    raise AssertionError('Coalition initial mismatch')
                shock=trajectory[trajectory.year.between(2026,2030)]
                endpoint=trajectory[trajectory.year.eq(2030)].iloc[0]
                mask=sum(1<<names.index(x) for x in active)
                rows.append({'cache_row_id':f'{pid}:{high}-{base}:{mask:02d}',
                    'parameter_set_id':pid,'contrast':f'{high}-{base}','coalition_mask':mask,
                    'coalition_groups':'+'.join(sorted(active)) if active else 'EMPTY',
                    'n_groups':len(names),'forcing_draw_id':'CLIM_20260725_001',
                    'parameter_sha256':ph,'initial_state_hash':ih,'reference_context_sha256':rh,
                    'forcing_sha256':hashlib.sha256(f_frame.to_csv(index=False).encode()).hexdigest(),
                    'setting_json':json.dumps(setting,sort_keys=True),
                    'min_ES_2026_2030':float(shock.ES.min()),
                    'ES_2030':float(endpoint.ES),'SR_2030':float(endpoint.SR)})
    # Cache identity order is numeric coalition-mask order within each
    # contrast, independent of combination-cardinality enumeration.
    return pid,pd.DataFrame(rows).sort_values(
        ['contrast','coalition_mask']).reset_index(drop=True)

def shapley(values,groups,metric):
    n=len(groups);lookup=values.set_index('coalition_mask')[metric]
    if set(lookup.index)!=set(range(1<<n)):raise ValueError('Missing coalition mask')
    rows=[]
    delta=float(lookup[2**n-1]-lookup[0])
    for j,group in enumerate(groups):
        phi=0.
        for mask in range(1<<n):
            if mask&(1<<j):continue
            k=int(mask.bit_count());weight=math.factorial(k)*math.factorial(n-k-1)/math.factorial(n)
            phi+=weight*(float(lookup[mask|(1<<j)])-float(lookup[mask]))
        rows.append((group,phi))
    if abs(sum(x[1] for x in rows)-delta)>1e-10:
        raise AssertionError('Per-parameter Shapley closure failed')
    return delta,rows

def main():
    OUT.mkdir(parents=True,exist_ok=True)
    frame=pd.read_csv(ROOT/'03_indicators/model_input_B1.csv').sort_values('year').reset_index(drop=True)
    status=json.loads((CAL/'formal_calibration_status.json').read_text(encoding='utf-8'))
    structure=status['structure'];names=model.parameter_names(structure)
    ensemble=pd.read_csv(CAL/'accepted_parameter_ensemble.csv')
    if ensemble.empty:raise RuntimeError('No accepted parameters')
    settings=load_settings();group_spec('S0','S4');group_spec('S6','S4')
    climate=pd.read_csv(SCEN/'common_climate_draw_001.csv')
    primary=pd.read_csv(SCEN/'scenario_metrics_by_parameter.csv')
    required=['cache_row_id','parameter_set_id','contrast','coalition_mask','ES_2030','SR_2030']
    files=[ROOT/p for p in ['03_indicators/model_input_B1.csv','04_model/scenario_registry.csv',
        '04_model/scenario_lever_audit.csv','04_model/equation_registry.csv',
        '04_model/parameter_registry.csv','02_policy/reconstructed/policy_stock_by_year_B1.csv',
        '02_policy/reconstructed/interface_quantiles_B1.csv','00_contract/baseline_contract.yaml',
        '05_code/engine/sd_model.py','05_code/engine/engine_config.py',
        '05_code/engine/engine_common.py','05_code/numeric_analysis.py','05_code/v12_modeling.py',
        '05_code/v12_attribution.py','05_code/cache_safety.py',
        '06_runs/formal_main/calibration/accepted_parameter_ensemble.csv',
        '06_runs/formal_main/scenarios/common_climate_draw_001.csv',
        '06_runs/formal_main/scenarios/scenario_metrics_by_parameter.csv']]
    key,material=signature(files,{'structure':structure,'vectors':ensemble[names].to_numpy(float).tolist(),
        'initial_year':2023,'initial_vector':model.initial_state(frame,year=2023).tolist(),
        'reference_year':2011,'groups_40':GROUPS_40,'groups_46':GROUPS_46,'solver_step':.05},
        code_version=cfg.CONTRACT['version'],root=ROOT)
    cache=ChunkCache(OUT/'cache',key,material)
    specs=[];jobs=[]
    for r in ensemble.itertuples(index=False):
        pid=r.parameter_set_id;ids=[f'{pid}:S4-S0:{j:02d}' for j in range(16)]+[f'{pid}:S4-S6:{j:02d}' for j in range(8)]
        specs.append((pid,ids,required))
        if cache.load(pid,ids,required) is None:
            jobs.append((pid,{n:float(getattr(r,n)) for n in names},structure,frame,climate,settings))
    completed=0
    with ProcessPoolExecutor(max_workers=8) as pool:
        # Bounded submission avoids queuing the entire 600-vector payload and
        # keeps every completed coalition block committed promptly.
        for start in range(0,len(jobs),16):
            futures=[pool.submit(one,j) for j in jobs[start:start+16]]
            for f in as_completed(futures):
                pid,rows=f.result();ids=next(s[1] for s in specs if s[0]==pid)
                cache.commit(pid,rows,ids,required)
                completed+=1
                if completed%50==0 or completed==len(jobs):
                    print(f'Shapley vectors={completed}/{len(jobs)}',flush=True)
    cache.finalize(specs)
    coalitions=pd.concat([cache.load(*s) for s in specs],ignore_index=True)
    # Empty and full coalitions must equal the same-vector main scenario outputs.
    checks=[];contributions=[]
    main=primary.set_index(['parameter_set_id','scenario'])
    for (pid,contrast),g in coalitions.groupby(['parameter_set_id','contrast']):
        high,base=contrast.split('-');groups=list(group_spec(base,high));n=len(groups)
        low=g[g.coalition_mask.eq(0)].iloc[0];highrow=g[g.coalition_mask.eq(2**n-1)].iloc[0]
        for metric in REPORT:
            expected_low=float(main.loc[(pid,base),metric]);expected_high=float(main.loc[(pid,high),metric])
            error=max(abs(float(low[metric])-expected_low),abs(float(highrow[metric])-expected_high))
            checks.append({'parameter_set_id':pid,'contrast':contrast,'metric':metric,
                'max_endpoint_abs_error':error,'pass':error<=1e-10})
            if error>1e-10:raise AssertionError(f'Factorial endpoint differs from main: {pid} {contrast} {metric} {error}')
            delta,phis=shapley(g,groups,metric)
            for group,value in phis:
                contributions.append({'parameter_set_id':pid,'contrast':contrast,'metric':metric,
                    'group':group,'contribution':value,'total_paired_delta':delta,
                    'closure_error':sum(v for _,v in phis)-delta})
    coalitions.to_csv(OUT/'coalition_outputs_and_inputs.csv',index=False,encoding='utf-8-sig')
    pd.DataFrame(checks).to_csv(OUT/'endpoint_matches.csv',index=False,encoding='utf-8-sig')
    phi=pd.DataFrame(contributions)
    phi.to_csv(OUT/'shapley_by_parameter.csv',index=False,encoding='utf-8-sig')
    phi.groupby(['contrast','metric','group']).contribution.agg(['median',lambda s:s.quantile(.05),
        lambda s:s.quantile(.95)]).reset_index().to_csv(OUT/'shapley_summary.csv',index=False,encoding='utf-8-sig')
    atomic_json(OUT/'attribution_status.json',{'complete':True,'parameter_sets':len(ensemble),
        'coalition_rows':len(coalitions),'all_endpoints_match':True,
        'max_closure_error':float(phi.closure_error.abs().max()),
        'group_count_S4_S0':4,'group_count_S4_S6':3,'cache_signature':key,
        'full_main_parameter_population':True})

if __name__=='__main__':main()
