"""Shared, fixed-loss model context for finite B1 v1.2 structure comparisons."""
from __future__ import annotations
import hashlib,json,sys
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.optimize import differential_evolution,minimize
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'05_code/engine'),str(ROOT/'05_code')]
import engine_config as cfg
import sd_model as model
from revised_core import simple_baselines

STATES=['SP','SC','NS','OS','BS','TF','SM']
CORE_BOUNDS=np.array([cfg.PARAMETER_BOUNDS[n] for n in cfg.PARAMETER_NAMES],float)
VALID_STRUCTURES=tuple(model.STRUCTURE_EXTRA_PARAMETERS)

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def bounds(structure):
    names=model.parameter_names(structure)
    return names,np.array([cfg.PARAMETER_BOUNDS[n] if n in cfg.PARAMETER_BOUNDS
        else cfg.STRUCTURAL_PARAMETER_BOUNDS[n] for n in names],float)
def reference_for(frame,forcing,initial,params,structure,mode=None):
    if structure=='M0_RUN_SPECIFIC':return None
    mode=mode or model.ModelMode()
    ref=model._baseline_context(initial,forcing.at(2011.),
        model.parameter_dict(params,structure=structure),mode)
    ref['REFERENCE_YEAR']=2011.
    return ref

class TrainingContext:
    def __init__(self,frame,structure,train_end):
        if structure not in VALID_STRUCTURES:raise ValueError(structure)
        self.frame=frame.sort_values('year').reset_index(drop=True)
        self.structure=structure;self.train_end=train_end
        self.train=self.frame[self.frame.year.between(2011,train_end)]
        if self.train.year.tolist()!=list(range(2011,train_end+1)):raise ValueError('Incomplete training years')
        self.forcing=model.historical_forcing(self.frame)
        self.initial=model.initial_state(self.frame,year=2011)
        self.names,self.bounds=bounds(structure)
        self.observed=self.train[STATES].to_numpy(float)
        self.denom=np.array([np.quantile(self.train[s],.95)-np.quantile(self.train[s],.05) for s in STATES])
        if not (self.denom>0).all():raise ValueError('Nonpositive fold NRMSE denominator')
        self.failure_count=0

    def vector_dict(self,vector):return dict(zip(self.names,map(float,vector)))
    def predict(self,vector,end_year=None):
        params=self.vector_dict(vector)
        ref=reference_for(self.frame,self.forcing,self.initial,params,self.structure)
        years=np.arange(2011,(self.train_end if end_year is None else end_year)+1,dtype=float)
        return model.simulate(params,self.forcing,years,self.initial,
            structure=self.structure,reference_context=ref)

    def evaluate(self,vector,details=False):
        try:
            prediction=self.predict(vector)
            pred=prediction[STATES].to_numpy(float)
            if not np.isfinite(pred).all():raise FloatingPointError('Nonfinite trajectory')
            obs=self.observed
            mse=float(np.mean((obs-pred)**2))
            hit=np.mean(np.sign(np.diff(obs,axis=0))==np.sign(np.diff(pred,axis=0)),axis=0)
            endpoint=(pred[-1]-pred[0]-obs[-1]+obs[0])**2
            behavior=.5*np.mean(endpoint+.04*(1-hit))
            # Exactly the nine legacy parameters enter the weak regularization.
            core=np.asarray(vector[:9],float)
            scaled=(core-CORE_BOUNDS.mean(axis=1))/(CORE_BOUNDS[:,1]-CORE_BOUNDS[:,0])
            regularization=.006*np.mean(scaled**2)
            loss=float(mse+.18*behavior+regularization)
            if not details:return loss
            nrmse=np.sqrt(np.mean((obs-pred)**2,axis=0))/self.denom
            return {'loss':loss,'mse':mse,'behavior':float(behavior),'regularization':float(regularization),
              'mean_nrmse':float(nrmse.mean()),'trend_hit':float(hit.mean()),
              'state_nrmse':dict(zip(STATES,map(float,nrmse))),
              'state_bias':dict(zip(STATES,map(float,np.mean(pred-obs,axis=0)))),
              'state_direction':dict(zip(STATES,map(float,hit)))}
        except (ValueError,FloatingPointError,OverflowError,KeyError) as e:
            self.failure_count+=1
            if details:return {'loss':1e6,'error':repr(e),'mean_nrmse':1e6,'trend_hit':0.}
            return 1e6

def fit_one(args):
    structure,train_end,seed,budget,folder=args
    frame=pd.read_csv(ROOT/'03_indicators/model_input_B1.csv')
    context=TrainingContext(frame,structure,train_end)
    path=Path(folder)/structure/f'train_through_{train_end}'/f'fit_seed_{seed}.json'
    path.parent.mkdir(parents=True,exist_ok=True)
    dependencies={rel:sha(ROOT/rel) for rel in ['03_indicators/model_input_B1.csv',
      '00_contract/baseline_contract.yaml','00_contract/structure_selection_protocol.yaml',
      '05_code/engine/sd_model.py','05_code/engine/engine_config.py',
      '05_code/engine/engine_common.py','05_code/engine/fast_kernel.py','05_code/revised_core.py','05_code/v12_modeling.py']}
    if path.exists():
        old=json.loads(path.read_text(encoding='utf-8'))
        if old.get('dependencies')==dependencies and old.get('complete') and old.get('budget')==budget:return old
    import time
    started=time.time()
    de=differential_evolution(context.evaluate,bounds=context.bounds.tolist(),seed=seed,
      maxiter=budget['maxiter'],popsize=budget['popsize_per_dimension'],tol=budget['tol'],
      polish=False,workers=1,updating='immediate')
    powell=minimize(context.evaluate,de.x,method='Powell',bounds=context.bounds.tolist(),
      options={'maxiter':budget['Powell_maxiter'],'xtol':budget['xtol'],'ftol':budget['ftol']})
    best=np.asarray(powell.x if context.evaluate(powell.x)<context.evaluate(de.x) else de.x,float)
    result={'complete':True,'structure':structure,'train_end':train_end,'seed':seed,
      'parameter_count':len(context.names),'parameters':context.vector_dict(best),
      'diagnostics':context.evaluate(best,True),'DE_nfev':int(de.nfev),'DE_success':bool(de.success),
      'DE_message':str(de.message),'Powell_nfev':int(powell.nfev),'Powell_success':bool(powell.success),
      'Powell_message':str(powell.message),'objective_failures':context.failure_count,
      'elapsed_seconds':time.time()-started,'dependencies':dependencies,'budget':budget}
    temp=path.with_suffix('.json.tmp');temp.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    temp.replace(path)
    return result

def diagnostic_rows(frame,fit,diagnose_end):
    train_end=fit['train_end'];ctx=TrainingContext(frame,fit['structure'],train_end)
    vector=np.array([fit['parameters'][n] for n in ctx.names],float)
    simulated=ctx.predict(vector,diagnose_end)
    test=frame[frame.year.between(train_end+1,diagnose_end)].sort_values('year')
    pred=simulated[simulated.year.between(train_end+1,diagnose_end)].sort_values('year')
    first=frame.loc[frame.year.eq(train_end),STATES].iloc[0].to_numpy(float)
    last=frame.loc[frame.year.eq(2011),STATES].iloc[0].to_numpy(float)
    slope=(first-last)/(train_end-2011)
    rows=[]
    for j,state in enumerate(STATES):
        for i,(obs,p) in enumerate(zip(test[state].to_numpy(float),pred[state].to_numpy(float))):
            year=int(test.year.iloc[i]);delta=year-train_end
            rows.append({'structure':fit['structure'],'fold_train_end':train_end,'seed':fit['seed'],
              'diagnose_year':year,'state':state,'observed':obs,'predicted':p,
              'error':p-obs,'squared_error':(p-obs)**2,'abs_error':abs(p-obs),
              'NRMSE_squared_error':((p-obs)/ctx.denom[j])**2,
              'persistence':first[j],'training_linear_trend':float(simple_baselines(ctx.train.year,ctx.train[state],test.year)['training_endpoint_drift'][i]),
              'denominator_fold_P95_minus_P5':ctx.denom[j],
              'conditional_exogenous_forcing_known':True,'observation_reset':False})
    return rows
