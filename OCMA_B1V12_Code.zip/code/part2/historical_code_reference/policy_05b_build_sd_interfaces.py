"""Build model-agnostic governance inputs for later dynamic and SD analysis.

This module does not specify, calibrate, or simulate a system-dynamics model.
It converts the frozen policy coding and actor relations into:

* a 2000-2023 governance history used for stock initialization;
* a 2011-2023 Laizhou Bay-year modelling interface;
* a 2011-2023 county-year exposure extension;
* a separately isolated 2024 boundary-response record; and
* provenance, dictionary, merge-QA, and evidence-trace artifacts.
"""

from __future__ import annotations

import json
import math
import re
from importlib import import_module
from pathlib import Path
from typing import Any, Iterable

import numpy as np
import pandas as pd

# Compatibility with older NetworkX releases under NumPy 2.x.
if not hasattr(np, "float_"):
    np.float_ = np.float64
if not hasattr(np, "complex_"):
    np.complex_ = np.complex128
if "int" not in np.__dict__:
    np.int = int
if "float" not in np.__dict__:
    np.float = float
if "bool" not in np.__dict__:
    np.bool = bool
if "complex" not in np.__dict__:
    np.complex = complex

import networkx as nx


CFG = import_module("00_config")

G_CODES = ["G1", "G2", "G3"]
T_CODES = ["T1", "T2", "T3", "T4", "T5", "T6"]
LEVELS = ["National", "Shandong", "Municipal", "County"]
HISTORY_YEARS = list(range(CFG.HISTORICAL_START, CFG.HISTORICAL_END + 1))
MODEL_YEARS = list(range(2011, CFG.HISTORICAL_END + 1))
COUNTY_IDS = {
    "东营区": "DY_DONGYING",
    "垦利区": "DY_KENLI",
    "广饶县": "DY_GUANGRAO",
    "寒亭区": "WF_HANTING",
    "寿光市": "WF_SHOUGUANG",
    "昌邑市": "WF_CHANGYI",
    "莱州市": "YT_LAIZHOU",
    "招远市": "YT_ZHAOYUAN",
    "龙口市": "YT_LONGKOU",
}

G_NAMES = {
    "G1": "pressure-reduction governance",
    "G2": "habitat-protection and restoration governance",
    "G3": "monitoring, coordination and learning governance",
}
T_NAMES = {
    "T1": "regulatory instruments",
    "T2": "fiscal or economic instruments",
    "T3": "engineering interventions",
    "T4": "information instruments",
    "T5": "organizational coordination",
    "T6": "participation or capacity building",
}

# The lexicon is intentionally transparent and conservative. It is derived
# from the pre-specified pressure, ecological-risk, and feedback-signal search
# groups in the research framework. A match is policy-side language evidence,
# not proof that an external event occurred or caused the policy.
RISK_SIGNAL_TERMS = {
    "pressure_signal": [
        "工业废水",
        "城镇污水",
        "农业面源",
        "农村生活污水",
        "化肥减量",
        "畜禽养殖",
        "养殖尾水",
        "港口船舶",
        "围填海",
        "岸线开发",
        "入海排污口",
        "排污口",
        "陆源污染",
        "海洋污染",
        "水污染",
        "污染物排放",
        "污染源",
        "超标排放",
    ],
    "ecological_state_signal": [
        "总氮",
        "总磷",
        "营养盐",
        "富营养化",
        "溶解氧",
        "缺氧",
        "赤潮",
        "湿地退化",
        "生境退化",
        "生态退化",
        "生态破坏",
        "生态损害",
        "岸线侵蚀",
        "湿地丧失",
        "水质恶化",
        "环境质量下降",
        "海洋灾害",
    ],
    "explicit_feedback_signal": [
        "生态损害",
        "渔业损失",
        "养殖损失",
        "海洋灾害",
        "赤潮损失",
        "投诉",
        "督察整改",
        "应急处置",
        "应急响应",
        "问题清单",
        "风险预警",
        "突发环境事件",
        "超标",
    ],
}
RESPONSE_ACTION_TERMS = [
    "加强",
    "完善",
    "建立",
    "开展",
    "实施",
    "推进",
    "整改",
    "防治",
    "控制",
    "修复",
    "保护",
    "监测",
    "预警",
    "应急",
    "处置",
    "治理",
    "减少",
    "削减",
    "禁止",
    "限制",
    "监管",
    "督察",
    "考核",
    "问责",
]
RISK_RULE_VERSION = "policy_side_risk_response_v1"

RELATION_TYPES = {
    "observed_joint_issuance",
    "vertical_administrative_linkage",
}


def clean_text(value: Any) -> str:
    if value is None or (isinstance(value, float) and pd.isna(value)):
        return ""
    return re.sub(r"\s+", " ", str(value)).strip()


def safe_ratio(numerator: float, denominator: float) -> float:
    return float(numerator / denominator) if denominator > 0 else math.nan


def active_bounds(row: pd.Series) -> tuple[int, int, int | None]:
    """Return inclusive active start/end years and first inactive transition."""

    effective = pd.to_datetime(row.get("effective_date"), errors="coerce")
    publication = pd.to_datetime(row.get("publication_date"), errors="coerce")
    publication_year = int(row["publication_year"])
    start_year = (
        int(effective.year)
        if not pd.isna(effective)
        else int(publication.year)
        if not pd.isna(publication)
        else publication_year
    )
    recorded_end = pd.to_datetime(
        row.get("end_or_replacement_date"),
        errors="coerce",
    )
    raw_end_year = (
        int(recorded_end.year)
        if not pd.isna(recorded_end)
        else CFG.HISTORICAL_END
    )
    start_year = max(start_year, CFG.HISTORICAL_START)
    end_year = min(raw_end_year, CFG.HISTORICAL_END)
    exit_year = (
        raw_end_year + 1
        if not pd.isna(recorded_end)
        and raw_end_year < CFG.HISTORICAL_END
        else None
    )
    return start_year, end_year, exit_year


def build_policy_stock_ledger(
    master: pd.DataFrame,
    summary: pd.DataFrame,
    exposure: pd.DataFrame,
    issuer_edges: pd.DataFrame,
) -> pd.DataFrame:
    historical = master.loc[
        master["temporal_role"].eq("historical_core")
    ].copy()
    summary_columns = [
        "policy_id",
        "action_unit_count_all",
        "semantic_codable",
        "metadata_joint_issuance",
        *[f"{code}_share" for code in G_CODES + T_CODES],
    ]
    ledger = historical.merge(
        summary[summary_columns],
        on="policy_id",
        how="left",
        validate="one_to_one",
    )
    county_groups = (
        exposure.groupby("policy_id")
        .agg(
            applicable_counties=(
                "county",
                lambda values: ";".join(sorted(set(values.astype(str)))),
            ),
            applicable_counties_n=("county", "nunique"),
            exposure_basis=(
                "applicability_basis",
                lambda values: " | ".join(
                    sorted(set(values.dropna().astype(str)))
                ),
            ),
        )
        .reset_index()
    )
    issuer_groups = (
        issuer_edges.loc[
            issuer_edges["temporal_role"].eq("historical_core")
        ]
        .groupby("policy_id")
        .agg(
            issuer_ids=(
                "issuer_id",
                lambda values: ";".join(sorted(set(values.astype(str)))),
            ),
            issuer_names=(
                "issuer_name",
                lambda values: ";".join(sorted(set(values.astype(str)))),
            ),
            issuers_n=("issuer_id", "nunique"),
            joint_issuance=("joint_issuance", "max"),
            issuer_list_complete=("issuer_list_complete", "min"),
        )
        .reset_index()
    )
    ledger = ledger.merge(
        county_groups,
        on="policy_id",
        how="left",
        validate="one_to_one",
    ).merge(
        issuer_groups,
        on="policy_id",
        how="left",
        validate="one_to_one",
    )
    bounds = ledger.apply(active_bounds, axis=1, result_type="expand")
    bounds.columns = [
        "stock_start_year",
        "stock_end_year",
        "stock_exit_transition_year",
    ]
    ledger = pd.concat([ledger, bounds], axis=1)
    ledger["stock_exit_transition_year"] = ledger[
        "stock_exit_transition_year"
    ].astype("Int64")
    ledger["open_ended_through_2023"] = (
        pd.to_datetime(
            ledger["end_or_replacement_date"],
            errors="coerce",
        ).isna()
        | ledger["stock_end_year"].ge(CFG.HISTORICAL_END)
    ).astype(int)
    ledger["publication_to_stock_entry_lag_years"] = (
        ledger["stock_start_year"] - ledger["publication_year"].astype(int)
    )
    ledger["tool_codable"] = ledger[
        [f"{code}_share" for code in T_CODES]
    ].notna().any(axis=1).astype(int)
    keep = [
        "policy_id",
        "publication_year",
        "publication_date",
        "effective_date",
        "end_or_replacement_date",
        "stock_start_year",
        "stock_end_year",
        "stock_exit_transition_year",
        "open_ended_through_2023",
        "publication_to_stock_entry_lag_years",
        "phase",
        "admin_level",
        "title",
        "semantic_codable",
        "tool_codable",
        "action_unit_count_all",
        "metadata_joint_issuance",
        *[f"{code}_share" for code in G_CODES + T_CODES],
        "issuers_n",
        "issuer_ids",
        "issuer_names",
        "joint_issuance",
        "issuer_list_complete",
        "applicable_counties_n",
        "applicable_counties",
        "exposure_basis",
    ]
    return ledger[keep].sort_values(
        ["stock_start_year", "publication_year", "policy_id"]
    ).reset_index(drop=True)


def build_risk_signal_trace(
    action_units: pd.DataFrame,
    master: pd.DataFrame,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    policy_meta = master.set_index("policy_id")[
        ["publication_year", "phase", "temporal_role", "title"]
    ]
    evidence_rows: list[dict[str, Any]] = []
    for row in action_units.itertuples(index=False):
        evidence_text = clean_text(row.evidence_text)
        if not evidence_text:
            continue
        matched_response_terms = [
            term for term in RESPONSE_ACTION_TERMS if term in evidence_text
        ]
        g_codes = clean_text(row.G_codes)
        explicit_response = int(
            bool(g_codes) and bool(matched_response_terms)
        )
        for category, terms in RISK_SIGNAL_TERMS.items():
            matched = [term for term in terms if term in evidence_text]
            if not matched:
                continue
            evidence_rows.append(
                {
                    "action_unit_id": row.action_unit_id,
                    "policy_id": row.policy_id,
                    "publication_year": int(row.publication_year),
                    "phase": row.phase,
                    "temporal_role": policy_meta.loc[
                        row.policy_id,
                        "temporal_role",
                    ],
                    "signal_category": category,
                    "matched_terms": ";".join(matched),
                    "matched_response_terms": ";".join(
                        matched_response_terms
                    ),
                    "explicit_governance_response_proxy": explicit_response,
                    "source_location": row.source_location,
                    "evidence_text": evidence_text,
                    "G_codes": g_codes,
                    "T_codes": clean_text(row.T_codes),
                    "document_unit_weight": float(row.document_unit_weight),
                    "coding_scope": row.coding_scope,
                    "rule_version": RISK_RULE_VERSION,
                }
            )
    evidence = pd.DataFrame(evidence_rows)
    if evidence.empty:
        raise ValueError("Risk-signal lexicon matched no evidence units.")
    action_policy_ids = set(action_units["policy_id"].astype(str))
    summary_rows: list[dict[str, Any]] = []
    for policy_id, meta in policy_meta.iterrows():
        selected = evidence.loc[evidence["policy_id"].eq(policy_id)]
        row: dict[str, Any] = {
            "policy_id": policy_id,
            "publication_year": int(meta["publication_year"]),
            "phase": meta["phase"],
            "temporal_role": meta["temporal_role"],
            "title": meta["title"],
            "risk_evidence_observable": int(policy_id in action_policy_ids),
        }
        category_terms: set[str] = set()
        for category in RISK_SIGNAL_TERMS:
            category_rows = selected.loc[
                selected["signal_category"].eq(category)
            ]
            row[f"{category}_action_units_n"] = int(
                category_rows["action_unit_id"].nunique()
            )
            row[f"{category}_present"] = int(not category_rows.empty)
            for value in category_rows["matched_terms"]:
                category_terms.update(str(value).split(";"))
        row["any_risk_signal_action_units_n"] = int(
            selected["action_unit_id"].nunique()
        )
        row["any_risk_signal_present"] = int(not selected.empty)
        explicit_rows = selected.loc[
            selected["explicit_governance_response_proxy"].eq(1)
        ]
        row["explicit_governance_response_proxy_action_units_n"] = int(
            explicit_rows["action_unit_id"].nunique()
        )
        row["explicit_governance_response_proxy_present"] = int(
            not explicit_rows.empty
        )
        response_terms: set[str] = set()
        for value in explicit_rows["matched_response_terms"]:
            response_terms.update(
                term for term in str(value).split(";") if term
            )
        row["matched_response_terms"] = ";".join(sorted(response_terms))
        row["matched_risk_terms"] = ";".join(sorted(category_terms))
        summary_rows.append(row)
    policy_summary = pd.DataFrame(summary_rows)
    return (
        evidence.sort_values(
            ["publication_year", "policy_id", "action_unit_id", "signal_category"]
        ).reset_index(drop=True),
        policy_summary.sort_values(["publication_year", "policy_id"]).reset_index(
            drop=True
        ),
    )


def policy_sets_by_year(
    ledger: pd.DataFrame,
) -> tuple[dict[int, set[str]], dict[int, set[str]]]:
    flow: dict[int, set[str]] = {}
    stock: dict[int, set[str]] = {}
    for year in HISTORY_YEARS:
        flow[year] = set(
            ledger.loc[ledger["publication_year"].eq(year), "policy_id"].astype(str)
        )
        stock[year] = set(
            ledger.loc[
                ledger["stock_start_year"].le(year)
                & ledger["stock_end_year"].ge(year),
                "policy_id",
            ].astype(str)
        )
    return flow, stock


def unordered_pairs(frame: pd.DataFrame) -> pd.Series:
    return frame.apply(
        lambda row: "||".join(
            sorted(
                [
                    str(row["source_actor_id"]),
                    str(row["target_actor_id"]),
                ]
            )
        ),
        axis=1,
    )


def one_network_snapshot(
    year: int,
    network_scope: str,
    policy_ids: set[str],
    issuer_edges: pd.DataFrame,
    actor_events: pd.DataFrame,
) -> dict[str, Any]:
    selected_issuers = issuer_edges.loc[
        issuer_edges["policy_id"].astype(str).isin(policy_ids)
    ].copy()
    selected_events = actor_events.loc[
        actor_events["policy_id"].astype(str).isin(policy_ids)
    ].copy()
    joint = selected_events.loc[
        selected_events["relation_type"].eq("observed_joint_issuance")
    ].copy()
    vertical = selected_events.loc[
        selected_events["relation_type"].eq(
            "vertical_administrative_linkage"
        )
    ].copy()
    if not joint.empty:
        joint["pair"] = unordered_pairs(joint)
    if not vertical.empty:
        vertical["pair"] = unordered_pairs(vertical)

    graph = nx.Graph()
    for event in selected_events.itertuples(index=False):
        source = str(event.source_actor_id)
        target = str(event.target_actor_id)
        weight = float(event.document_balanced_event_weight)
        if graph.has_edge(source, target):
            graph[source][target]["weight"] += weight
        else:
            graph.add_edge(source, target, weight=weight)

    linked_nodes = set(graph.nodes)
    linked_issuers = {
        node
        for node in linked_nodes
        if not node.startswith("RCV")
    }
    recipient_nodes = {
        node
        for node in linked_nodes
        if node.startswith("RCV")
    }
    formal_issuers = set(selected_issuers["issuer_id"].astype(str))
    n = graph.number_of_nodes()
    m = graph.number_of_edges()
    components = list(nx.connected_components(graph)) if n else []
    degrees = dict(graph.degree())
    strengths = dict(graph.degree(weight="weight"))
    if n >= 3:
        denominator = (n - 1) * (n - 2)
        degree_centralization = (
            sum(max(degrees.values()) - value for value in degrees.values())
            / denominator
        )
        distance_graph = graph.copy()
        for source, target, data in distance_graph.edges(data=True):
            data["distance"] = 1.0 / max(float(data["weight"]), 1e-12)
        betweenness = nx.betweenness_centrality(
            distance_graph,
            normalized=True,
            weight="distance",
        )
        max_betweenness = max(betweenness.values(), default=math.nan)
    else:
        degree_centralization = math.nan
        max_betweenness = math.nan

    issuer_policy_ties = len(selected_issuers)
    issuer_nodes_n = len(formal_issuers)
    policies_n = len(policy_ids)
    bipartite_density = safe_ratio(
        issuer_policy_ties,
        issuer_nodes_n * policies_n,
    )
    joint_policy_ids = set(joint["policy_id"].astype(str))
    vertical_policy_ids = set(vertical["policy_id"].astype(str))
    joint_weight = float(joint["document_balanced_event_weight"].sum())
    vertical_weight = float(vertical["document_balanced_event_weight"].sum())
    total_relation_weight = joint_weight + vertical_weight
    return {
        "year": year,
        "network_scope": network_scope,
        "policies_n": policies_n,
        "formal_issuer_nodes_n": issuer_nodes_n,
        "issuer_policy_ties_n": issuer_policy_ties,
        "issuer_policy_bipartite_density": bipartite_density,
        "joint_issue_policies_n": len(joint_policy_ids),
        "joint_issue_policy_share": safe_ratio(
            len(joint_policy_ids),
            policies_n,
        ),
        "issuer_lists_incomplete_policy_n": int(
            selected_issuers.loc[
                selected_issuers["issuer_list_complete"].eq(0),
                "policy_id",
            ].nunique()
        ),
        "issuing_admin_levels_n": int(
            selected_issuers["issuer_admin_level"].nunique()
        ),
        "joint_event_rows_n": len(joint),
        "joint_unique_dyads_n": int(joint["pair"].nunique()) if len(joint) else 0,
        "joint_document_balanced_weight": joint_weight,
        "vertical_linkage_policies_n": len(vertical_policy_ids),
        "vertical_event_rows_n": len(vertical),
        "vertical_unique_dyads_n": (
            int(vertical["pair"].nunique()) if len(vertical) else 0
        ),
        "vertical_document_balanced_weight": vertical_weight,
        "relation_linked_actor_nodes_n": n,
        "linked_issuer_nodes_n": len(linked_issuers),
        "recipient_county_nodes_n": len(recipient_nodes),
        "omitted_standalone_issuer_nodes_n": len(formal_issuers - linked_issuers),
        "combined_unique_edges_n": m,
        "combined_density": nx.density(graph) if n >= 2 else math.nan,
        "components_n": len(components),
        "largest_component_actor_n": (
            max((len(component) for component in components), default=0)
        ),
        "largest_component_share": (
            safe_ratio(
                max((len(component) for component in components), default=0),
                n,
            )
            if n
            else math.nan
        ),
        "mean_degree": (
            float(np.mean(list(degrees.values()))) if degrees else math.nan
        ),
        "mean_document_balanced_strength": (
            float(np.mean(list(strengths.values()))) if strengths else math.nan
        ),
        "degree_centralization": degree_centralization,
        "max_weighted_betweenness": max_betweenness,
        "joint_relation_weight_share": safe_ratio(
            joint_weight,
            total_relation_weight,
        ),
        "vertical_relation_weight_share": safe_ratio(
            vertical_weight,
            total_relation_weight,
        ),
        "network_defined": int(n >= 2),
        "policy_ids": ";".join(sorted(policy_ids)),
    }


def build_network_year(
    ledger: pd.DataFrame,
    issuer_edges: pd.DataFrame,
    actor_events: pd.DataFrame,
) -> pd.DataFrame:
    historical_ids = set(ledger["policy_id"].astype(str))
    issuer_historical = issuer_edges.loc[
        issuer_edges["policy_id"].astype(str).isin(historical_ids)
    ].copy()
    actor_historical = actor_events.loc[
        actor_events["policy_id"].astype(str).isin(historical_ids)
    ].copy()
    if set(actor_historical["relation_type"]) != RELATION_TYPES:
        raise ValueError("Unexpected relation type in annual actor interface.")
    flow_sets, stock_sets = policy_sets_by_year(ledger)
    rows = []
    for year in HISTORY_YEARS:
        rows.append(
            one_network_snapshot(
                year,
                "flow",
                flow_sets[year],
                issuer_historical,
                actor_historical,
            )
        )
        rows.append(
            one_network_snapshot(
                year,
                "stock",
                stock_sets[year],
                issuer_historical,
                actor_historical,
            )
        )
    return pd.DataFrame(rows).sort_values(
        ["year", "network_scope"]
    ).reset_index(drop=True)


def network_wide(network_year: pd.DataFrame) -> pd.DataFrame:
    numeric_columns = [
        column
        for column in network_year.columns
        if column not in {"year", "network_scope", "policy_ids"}
    ]
    rows = []
    for year, group in network_year.groupby("year", sort=True):
        row: dict[str, Any] = {"year": int(year)}
        for scope in ["flow", "stock"]:
            selected = group.loc[group["network_scope"].eq(scope)]
            if len(selected) != 1:
                raise ValueError(f"Missing {scope} network row for {year}")
            values = selected.iloc[0]
            for column in numeric_columns:
                row[f"{scope}_network_{column}"] = values[column]
        rows.append(row)
    return pd.DataFrame(rows)


def aggregate_signal_counts(
    selected: pd.DataFrame,
    prefix: str,
) -> dict[str, Any]:
    observable = int(selected["risk_evidence_observable"].sum())
    result: dict[str, Any] = {
        f"{prefix}_risk_evidence_observable_policy_count": observable,
        f"{prefix}_any_risk_signal_policy_count": int(
            selected["any_risk_signal_present"].sum()
        ),
        f"{prefix}_explicit_governance_response_proxy_policy_count": int(
            selected["explicit_governance_response_proxy_present"].sum()
        ),
    }
    for category in RISK_SIGNAL_TERMS:
        result[f"{prefix}_{category}_policy_count"] = int(
            selected[f"{category}_present"].sum()
        )
    result[f"{prefix}_any_risk_signal_policy_share"] = safe_ratio(
        result[f"{prefix}_any_risk_signal_policy_count"],
        observable,
    )
    result[f"{prefix}_explicit_feedback_signal_policy_share"] = safe_ratio(
        result[f"{prefix}_explicit_feedback_signal_policy_count"],
        observable,
    )
    result[
        f"{prefix}_explicit_governance_response_proxy_policy_share"
    ] = safe_ratio(
        result[
            f"{prefix}_explicit_governance_response_proxy_policy_count"
        ],
        observable,
    )
    return result


def add_composition_shares(frame: pd.DataFrame) -> pd.DataFrame:
    frame = frame.copy()
    for code in G_CODES:
        frame[f"{code}_new_flow_share"] = frame.apply(
            lambda row: safe_ratio(
                row[f"{code}_new_flow"],
                row["new_semantic_codable_count"],
            ),
            axis=1,
        )
        frame[f"{code}_active_stock_share"] = frame.apply(
            lambda row: safe_ratio(
                row[f"{code}_active_stock"],
                row["active_semantic_codable_count"],
            ),
            axis=1,
        )
    for code in T_CODES:
        frame[f"{code}_new_flow_share"] = frame.apply(
            lambda row: safe_ratio(
                row[f"{code}_new_flow"],
                row["new_tool_codable_count"],
            ),
            axis=1,
        )
        frame[f"{code}_active_stock_share"] = frame.apply(
            lambda row: safe_ratio(
                row[f"{code}_active_stock"],
                row["active_tool_codable_count"],
            ),
            axis=1,
        )
    return frame


def build_system_history(
    system_year: pd.DataFrame,
    ledger: pd.DataFrame,
    risk_summary: pd.DataFrame,
    network_year: pd.DataFrame,
) -> pd.DataFrame:
    history = system_year.copy().sort_values("year").reset_index(drop=True)
    history.insert(
        1,
        "analysis_role",
        np.where(history["year"].lt(2011), "warm_up", "model_ready_window"),
    )
    risk_lookup = risk_summary.set_index("policy_id")
    ledger_lookup = ledger.set_index("policy_id")
    flow_sets, stock_sets = policy_sets_by_year(ledger)

    derived_rows: list[dict[str, Any]] = []
    for year in HISTORY_YEARS:
        entries = ledger.loc[ledger["stock_start_year"].eq(year)]
        exits = ledger.loc[
            ledger["stock_exit_transition_year"].astype("Int64").eq(year)
        ]
        new_ids = flow_sets[year]
        active_ids = stock_sets[year]
        new_risk = risk_lookup.loc[
            sorted(new_ids)
        ] if new_ids else risk_lookup.iloc[0:0]
        active_risk = risk_lookup.loc[
            sorted(active_ids)
        ] if active_ids else risk_lookup.iloc[0:0]
        row: dict[str, Any] = {
            "year": year,
            "stock_entry_policy_count": int(len(entries)),
            "stock_exit_policy_count": int(len(exits)),
            "stock_entry_semantic_codable_count": int(
                entries["semantic_codable"].sum()
            ),
            "stock_exit_semantic_codable_count": int(
                exits["semantic_codable"].sum()
            ),
            "stock_entry_tool_codable_count": int(entries["tool_codable"].sum()),
            "stock_exit_tool_codable_count": int(exits["tool_codable"].sum()),
        }
        for code in G_CODES + T_CODES:
            row[f"{code}_stock_entry"] = float(
                entries[f"{code}_share"].sum(skipna=True)
            )
            row[f"{code}_stock_exit"] = float(
                exits[f"{code}_share"].sum(skipna=True)
            )
        for level in LEVELS:
            level_key = level.lower()
            row[f"new_policy_{level_key}_count"] = int(
                ledger.loc[
                    ledger["policy_id"].isin(new_ids)
                    & ledger["admin_level"].eq(level),
                    "policy_id",
                ].nunique()
            )
            row[f"active_policy_{level_key}_count"] = int(
                ledger.loc[
                    ledger["policy_id"].isin(active_ids)
                    & ledger["admin_level"].eq(level),
                    "policy_id",
                ].nunique()
            )
        row.update(aggregate_signal_counts(new_risk, "new"))
        row.update(aggregate_signal_counts(active_risk, "active"))
        derived_rows.append(row)
    derived = pd.DataFrame(derived_rows)
    history = history.merge(
        derived,
        on="year",
        how="left",
        validate="one_to_one",
    ).merge(
        network_wide(network_year),
        on="year",
        how="left",
        validate="one_to_one",
    )
    history = add_composition_shares(history)

    history["active_policy_stock_net_change"] = history[
        "active_policy_count"
    ].diff()
    for code in G_CODES + T_CODES:
        history[f"{code}_active_stock_net_change"] = history[
            f"{code}_active_stock"
        ].diff()
        history[f"{code}_new_flow_change"] = history[f"{code}_new_flow"].diff()
        history[f"{code}_new_flow_share_change"] = history[
            f"{code}_new_flow_share"
        ].diff()
    history["new_policy_count_change"] = history["new_policy_count"].diff()

    new_share_columns = [f"{code}_new_flow_share" for code in G_CODES]
    active_share_columns = [f"{code}_active_stock_share" for code in G_CODES]
    history["new_G_composition_shift_tv"] = (
        history[new_share_columns].diff().abs().sum(axis=1, min_count=len(G_CODES))
        * 0.5
    )
    history["active_G_composition_shift_tv"] = (
        history[active_share_columns]
        .diff()
        .abs()
        .sum(axis=1, min_count=len(G_CODES))
        * 0.5
    )
    for scope in ["flow", "stock"]:
        for metric in [
            "joint_issue_policies_n",
            "vertical_linkage_policies_n",
            "joint_document_balanced_weight",
            "vertical_document_balanced_weight",
        ]:
            source = f"{scope}_network_{metric}"
            history[f"{source}_change"] = history[source].diff()
    return history


def rename_county_base_columns(frame: pd.DataFrame) -> pd.DataFrame:
    mapping = {
        "new_policy_count": "new_exposed_policy_count",
        "active_policy_count": "active_exposed_policy_count",
        "new_semantic_codable_count": "new_exposed_semantic_codable_count",
        "active_semantic_codable_count": "active_exposed_semantic_codable_count",
        "new_tool_codable_count": "new_exposed_tool_codable_count",
        "active_tool_codable_count": "active_exposed_tool_codable_count",
        "new_semantic_coding_coverage": "new_exposed_semantic_coding_coverage",
        "active_semantic_coding_coverage": "active_exposed_semantic_coding_coverage",
    }
    for code in G_CODES + T_CODES:
        mapping[f"{code}_new_flow"] = f"{code}_exposed_new_flow"
        mapping[f"{code}_active_stock"] = f"{code}_exposed_active_stock"
    return frame.rename(columns=mapping)


def build_county_extension(
    county_year: pd.DataFrame,
    ledger: pd.DataFrame,
    exposure: pd.DataFrame,
    risk_summary: pd.DataFrame,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    full = rename_county_base_columns(county_year.copy())
    risk_lookup = risk_summary.set_index("policy_id")
    county_policy_ids = (
        exposure.groupby("county")["policy_id"]
        .agg(lambda values: set(values.astype(str)))
        .to_dict()
    )
    ledger_lookup = ledger.set_index("policy_id")
    rows: list[dict[str, Any]] = []
    for county in CFG.COUNTIES:
        ids = county_policy_ids[county]
        county_ledger = ledger_lookup.loc[sorted(ids)].reset_index()
        for year in HISTORY_YEARS:
            new = county_ledger.loc[county_ledger["publication_year"].eq(year)]
            active = county_ledger.loc[
                county_ledger["stock_start_year"].le(year)
                & county_ledger["stock_end_year"].ge(year)
            ]
            entries = county_ledger.loc[
                county_ledger["stock_start_year"].eq(year)
            ]
            exits = county_ledger.loc[
                county_ledger["stock_exit_transition_year"].astype("Int64").eq(
                    year
                )
            ]
            local_new = new.loc[new["admin_level"].eq("County")]
            local_active = active.loc[active["admin_level"].eq("County")]
            new_risk = risk_lookup.loc[
                sorted(set(new["policy_id"]))
            ] if len(new) else risk_lookup.iloc[0:0]
            active_risk = risk_lookup.loc[
                sorted(set(active["policy_id"]))
            ] if len(active) else risk_lookup.iloc[0:0]
            row: dict[str, Any] = {
                "county": county,
                "county_id": COUNTY_IDS[county],
                "year": year,
                "analysis_role": (
                    "warm_up" if year < 2011 else "model_ready_window"
                ),
                "exposed_stock_entry_policy_count": int(len(entries)),
                "exposed_stock_exit_policy_count": int(len(exits)),
                "local_issued_new_policy_count": int(len(local_new)),
                "local_issued_active_policy_count": int(len(local_active)),
                "new_inherited_policy_exposure_count": int(
                    len(new) - len(local_new)
                ),
                "active_inherited_policy_exposure_count": int(
                    len(active) - len(local_active)
                ),
                "exposure_is_not_issuance": 1,
            }
            for code in G_CODES + T_CODES:
                row[f"{code}_exposed_stock_entry"] = float(
                    entries[f"{code}_share"].sum(skipna=True)
                )
                row[f"{code}_exposed_stock_exit"] = float(
                    exits[f"{code}_share"].sum(skipna=True)
                )
            new_signal = aggregate_signal_counts(new_risk, "new_exposed")
            active_signal = aggregate_signal_counts(
                active_risk,
                "active_exposed",
            )
            row.update(new_signal)
            row.update(active_signal)
            rows.append(row)
    additions = pd.DataFrame(rows)
    full = full.merge(
        additions,
        on=["county", "year"],
        how="left",
        validate="one_to_one",
    )
    for code in G_CODES:
        full[f"{code}_exposed_new_flow_share"] = full.apply(
            lambda row: safe_ratio(
                row[f"{code}_exposed_new_flow"],
                row["new_exposed_semantic_codable_count"],
            ),
            axis=1,
        )
        full[f"{code}_exposed_active_stock_share"] = full.apply(
            lambda row: safe_ratio(
                row[f"{code}_exposed_active_stock"],
                row["active_exposed_semantic_codable_count"],
            ),
            axis=1,
        )
    for code in T_CODES:
        full[f"{code}_exposed_new_flow_share"] = full.apply(
            lambda row: safe_ratio(
                row[f"{code}_exposed_new_flow"],
                row["new_exposed_tool_codable_count"],
            ),
            axis=1,
        )
        full[f"{code}_exposed_active_stock_share"] = full.apply(
            lambda row: safe_ratio(
                row[f"{code}_exposed_active_stock"],
                row["active_exposed_tool_codable_count"],
            ),
            axis=1,
        )
    full = full.sort_values(["county", "year"]).reset_index(drop=True)
    full["active_exposed_policy_stock_net_change"] = full.groupby("county")[
        "active_exposed_policy_count"
    ].diff()
    for code in G_CODES + T_CODES:
        full[f"{code}_exposed_active_stock_net_change"] = full.groupby(
            "county"
        )[f"{code}_exposed_active_stock"].diff()
    model = full.loc[full["year"].isin(MODEL_YEARS)].copy()
    return full, model


def build_boundary_record(
    master: pd.DataFrame,
    summary: pd.DataFrame,
    issuer_edges: pd.DataFrame,
    risk_summary: pd.DataFrame,
) -> pd.DataFrame:
    boundary = master.loc[master["temporal_role"].eq("boundary_only")].copy()
    ids = set(boundary["policy_id"].astype(str))
    semantic_lookup = summary.set_index("policy_id")
    risk_lookup = risk_summary.set_index("policy_id")
    family_history = master.loc[
        master["policy_family_id"].isin(boundary["policy_family_id"])
        & master["temporal_role"].eq("historical_core")
    ]
    predecessor_lookup = (
        family_history.sort_values("publication_year")
        .groupby("policy_family_id")["policy_id"]
        .last()
        .to_dict()
    )
    rows: list[dict[str, Any]] = []
    for policy in boundary.sort_values("policy_id").itertuples(index=False):
        semantic = semantic_lookup.loc[policy.policy_id]
        risk = risk_lookup.loc[policy.policy_id]
        policy_issuers = issuer_edges.loc[
            issuer_edges["policy_id"].eq(policy.policy_id)
        ]
        applicable_counties = [
            county
            for county in CFG.COUNTIES
            if county in clean_text(policy.applicable_counties_raw)
        ]
        predecessor_id = predecessor_lookup.get(policy.policy_family_id, "")
        row: dict[str, Any] = {
            "policy_id": policy.policy_id,
            "policy_family_id": policy.policy_family_id,
            "version": policy.version,
            "title": policy.title,
            "admin_level": policy.admin_level,
            "publication_year": int(policy.publication_year),
            "effective_date": policy.effective_date,
            "reference_signal_year": 2023,
            "boundary_response_year": 2024,
            "included_in_main_interface": 0,
            "included_in_history": 0,
            "causal_response_confirmed": 0,
            "predecessor_policy_id": predecessor_id,
            "boundary_change_type": (
                "substantive_revision"
                if predecessor_id
                else "new_boundary_policy"
            ),
            "semantic_codable": int(semantic["semantic_codable"]),
            "risk_evidence_observable": int(
                risk["risk_evidence_observable"]
            ),
            "any_risk_signal_present": int(
                risk["any_risk_signal_present"]
            ),
            "explicit_feedback_signal_present": int(
                risk["explicit_feedback_signal_present"]
            ),
            "explicit_governance_response_proxy_present": int(
                risk["explicit_governance_response_proxy_present"]
            ),
            "issuers_n": int(policy_issuers["issuer_id"].nunique()),
            "joint_issuance": int(
                policy_issuers["joint_issuance"].max()
            ),
            "issuer_list_complete": int(
                policy_issuers["issuer_list_complete"].min()
            ),
            "applicable_counties_n": len(applicable_counties),
            "applicable_counties": ";".join(applicable_counties),
            "interpretation_scope": (
                "Boundary sensitivity only; no post-2023 social or ecological "
                "outcome is attributed to this policy."
            ),
        }
        for code in G_CODES + T_CODES:
            row[f"{code}_share"] = semantic[f"{code}_share"]
        rows.append(row)
    result = pd.DataFrame(rows)
    if set(result["policy_id"]) != ids:
        raise ValueError("Boundary policy trace does not match reconciled IDs.")
    return result


NETWORK_DEFINITIONS = {
    "policies_n": "Policies included in the network snapshot.",
    "formal_issuer_nodes_n": "Distinct formal issuing institutions.",
    "issuer_policy_ties_n": "Observed issuer-policy incidence ties.",
    "issuer_policy_bipartite_density": (
        "Issuer-policy ties divided by issuer nodes times policy nodes."
    ),
    "joint_issue_policies_n": "Policies with observed joint issuance.",
    "joint_issue_policy_share": "Joint-issuance policies divided by policies.",
    "issuer_lists_incomplete_policy_n": (
        "Policies whose available issuer list is explicitly incomplete."
    ),
    "issuing_admin_levels_n": "Administrative levels represented by issuers.",
    "joint_event_rows_n": (
        "Policy-specific projected issuer-pair events from observed joint issuance."
    ),
    "joint_unique_dyads_n": "Distinct observed joint-issuance issuer dyads.",
    "joint_document_balanced_weight": (
        "Sum of document-balanced observed joint-issuance event weights."
    ),
    "vertical_linkage_policies_n": (
        "Policies creating at least one applicability-based vertical linkage."
    ),
    "vertical_event_rows_n": (
        "Policy-specific issuer-recipient applicability linkage events."
    ),
    "vertical_unique_dyads_n": (
        "Distinct issuer-recipient county administrative dyads."
    ),
    "vertical_document_balanced_weight": (
        "Sum of document-balanced vertical-linkage event weights."
    ),
    "relation_linked_actor_nodes_n": (
        "Issuer and recipient nodes with at least one actor relation."
    ),
    "linked_issuer_nodes_n": "Issuer nodes with at least one actor relation.",
    "recipient_county_nodes_n": (
        "Distinct recipient county-government nodes in vertical relations."
    ),
    "omitted_standalone_issuer_nodes_n": (
        "Formal issuers without a joint or vertical actor relation."
    ),
    "combined_unique_edges_n": (
        "Distinct undirected edges in the combined actor-relation graph."
    ),
    "combined_density": "Density of the combined undirected actor-relation graph.",
    "components_n": "Connected components in the combined actor-relation graph.",
    "largest_component_actor_n": "Actors in the largest connected component.",
    "largest_component_share": (
        "Largest-component actors divided by relation-linked actors."
    ),
    "mean_degree": "Mean unweighted degree in the combined actor graph.",
    "mean_document_balanced_strength": (
        "Mean weighted actor strength using document-balanced event weights."
    ),
    "degree_centralization": (
        "Freeman degree centralization of the combined undirected actor graph."
    ),
    "max_weighted_betweenness": (
        "Maximum normalized betweenness using inverse document-balanced weight "
        "as distance."
    ),
    "joint_relation_weight_share": (
        "Joint-issuance share of total document-balanced relation weight."
    ),
    "vertical_relation_weight_share": (
        "Vertical-linkage share of total document-balanced relation weight."
    ),
    "network_defined": "One when at least two relation-linked actors are present.",
    "policy_ids": "Semicolon-delimited policy IDs in the snapshot.",
}


def code_variable_metadata(
    code: str,
    suffix: str,
) -> tuple[str, str, str]:
    name = G_NAMES.get(code, T_NAMES.get(code, code))
    suffixes = {
        "share": (
            f"Policy-level document-balanced share assigned to {name}.",
            "proportion",
            "trace",
        ),
        "new_flow": (
            f"Publication-year document-balanced {name} flow.",
            "policy-equivalents",
            "flow",
        ),
        "active_stock": (
            f"Effective-policy document-balanced {name} stock.",
            "policy-equivalents",
            "stock",
        ),
        "stock_entry": (
            f"{name} weight entering the effective stock in the year.",
            "policy-equivalents",
            "flow",
        ),
        "stock_exit": (
            f"{name} weight leaving the effective stock at the year transition.",
            "policy-equivalents",
            "flow",
        ),
        "active_stock_net_change": (
            f"Annual change in effective {name} stock.",
            "policy-equivalents",
            "response_proxy",
        ),
        "new_flow_share": (
            f"{name} share of codable publication-year flow.",
            "proportion",
            "auxiliary",
        ),
        "active_stock_share": (
            f"{name} share of codable effective-policy stock.",
            "proportion",
            "auxiliary",
        ),
        "new_flow_change": (
            f"Year-on-year change in publication-year {name} flow.",
            "policy-equivalents",
            "response_proxy",
        ),
        "new_flow_share_change": (
            f"Year-on-year change in publication-year {name} share.",
            "proportion-point change",
            "response_proxy",
        ),
        "exposed_new_flow": (
            f"County-exposed publication-year {name} flow.",
            "policy-equivalents",
            "flow",
        ),
        "exposed_active_stock": (
            f"County-exposed effective {name} stock.",
            "policy-equivalents",
            "stock",
        ),
        "exposed_stock_entry": (
            f"County-exposed {name} weight entering effective stock.",
            "policy-equivalents",
            "flow",
        ),
        "exposed_stock_exit": (
            f"County-exposed {name} weight leaving effective stock.",
            "policy-equivalents",
            "flow",
        ),
        "exposed_active_stock_net_change": (
            f"Annual change in county-exposed effective {name} stock.",
            "policy-equivalents",
            "response_proxy",
        ),
        "exposed_new_flow_share": (
            f"{name} share of codable county-exposed publication flow.",
            "proportion",
            "auxiliary",
        ),
        "exposed_active_stock_share": (
            f"{name} share of codable county-exposed effective stock.",
            "proportion",
            "auxiliary",
        ),
        "boundary_new_flow": (
            f"Boundary-year document-balanced {name} flow.",
            "policy-equivalents",
            "boundary",
        ),
        "boundary_new_flow_share": (
            f"{name} share of codable boundary-year flow.",
            "proportion",
            "boundary",
        ),
    }
    if suffix not in suffixes:
        raise KeyError(f"Undefined coded-variable suffix: {code}_{suffix}")
    return suffixes[suffix]


def variable_metadata(
    column: str,
) -> tuple[str, str, str, str]:
    """Return definition, unit, potential role, and missingness rule."""

    exact: dict[str, tuple[str, str, str, str]] = {
        "year": ("Calendar year.", "year", "time", "Never missing."),
        "analysis_role": (
            "Warm-up period or 2011-2023 model-ready window.",
            "category",
            "metadata",
            "Never missing.",
        ),
        "county": (
            "Stable nine-county study unit.",
            "identifier",
            "space",
            "Never missing.",
        ),
        "county_id": (
            "Stable ASCII identifier for the county.",
            "identifier",
            "space",
            "Never missing.",
        ),
        "municipality": (
            "Municipal grouping of the county.",
            "category",
            "space",
            "Never missing.",
        ),
        "new_policy_count": (
            "Policies published in the year.",
            "policies",
            "flow",
            "Structural zero when no policy was published.",
        ),
        "active_policy_count": (
            "Policies effective in the year under the inclusive end-year rule.",
            "policies",
            "stock",
            "Structural zero only when no policy is active.",
        ),
        "new_semantic_codable_count": (
            "Publication-year policies with observable G1-G3 actions.",
            "policies",
            "denominator",
            "Zero is observed; not imputed.",
        ),
        "active_semantic_codable_count": (
            "Effective policies with observable G1-G3 actions.",
            "policies",
            "denominator",
            "Zero is observed; not imputed.",
        ),
        "new_tool_codable_count": (
            "Publication-year policies with tool composition.",
            "policies",
            "denominator",
            "Zero is observed; not imputed.",
        ),
        "active_tool_codable_count": (
            "Effective policies with tool composition.",
            "policies",
            "denominator",
            "Zero is observed; not imputed.",
        ),
        "new_semantic_coding_coverage": (
            "New semantic-codable policies divided by new policies.",
            "proportion",
            "diagnostic",
            "NA when no policy was published.",
        ),
        "active_semantic_coding_coverage": (
            "Active semantic-codable policies divided by active policies.",
            "proportion",
            "diagnostic",
            "NA when no policy is active.",
        ),
        "stock_entry_policy_count": (
            "Policies entering effective stock in the year.",
            "policies",
            "flow",
            "Structural zero is valid.",
        ),
        "stock_exit_policy_count": (
            "Policies becoming inactive at the start of the year transition.",
            "policies",
            "flow",
            "Structural zero is valid.",
        ),
        "stock_entry_semantic_codable_count": (
            "Semantic-codable policies entering effective stock.",
            "policies",
            "flow",
            "Structural zero is valid.",
        ),
        "stock_exit_semantic_codable_count": (
            "Semantic-codable policies leaving effective stock.",
            "policies",
            "flow",
            "Structural zero is valid.",
        ),
        "stock_entry_tool_codable_count": (
            "Tool-codable policies entering effective stock.",
            "policies",
            "flow",
            "Structural zero is valid.",
        ),
        "stock_exit_tool_codable_count": (
            "Tool-codable policies leaving effective stock.",
            "policies",
            "flow",
            "Structural zero is valid.",
        ),
        "active_policy_stock_net_change": (
            "Year-on-year change in effective policy count.",
            "policies",
            "response_proxy",
            "NA only in the first history year.",
        ),
        "new_policy_count_change": (
            "Year-on-year change in published policy count.",
            "policies",
            "response_proxy",
            "NA only in the first history year.",
        ),
        "new_G_composition_shift_tv": (
            "Total-variation distance from the previous year's G-flow composition.",
            "proportion",
            "response_proxy",
            "NA when either year has no codable publication flow.",
        ),
        "active_G_composition_shift_tv": (
            "Total-variation distance from the previous effective-stock G composition.",
            "proportion",
            "response_proxy",
            "NA only when either stock composition is undefined.",
        ),
        "new_exposed_policy_count": (
            "Policies published in the year and applicable to the county.",
            "policy exposures",
            "flow",
            "Structural zero is valid.",
        ),
        "active_exposed_policy_count": (
            "Effective policies applicable to the county.",
            "policy exposures",
            "stock",
            "Structural zero is valid.",
        ),
        "active_exposed_policy_stock_net_change": (
            "Year-on-year change in effective county policy exposure.",
            "policy exposures",
            "response_proxy",
            "NA only in the first history year per county.",
        ),
        "exposed_stock_entry_policy_count": (
            "County-applicable policies entering effective stock.",
            "policy exposures",
            "flow",
            "Structural zero is valid.",
        ),
        "exposed_stock_exit_policy_count": (
            "County-applicable policies leaving effective stock.",
            "policy exposures",
            "flow",
            "Structural zero is valid.",
        ),
        "local_issued_new_policy_count": (
            "New county-level policies formally issued for this county.",
            "policies",
            "flow",
            "Structural zero is valid.",
        ),
        "local_issued_active_policy_count": (
            "Effective county-level policies formally issued for this county.",
            "policies",
            "stock",
            "Structural zero is valid.",
        ),
        "new_inherited_policy_exposure_count": (
            "New applicable policies not issued at county level.",
            "policy exposures",
            "flow",
            "Structural zero is valid.",
        ),
        "active_inherited_policy_exposure_count": (
            "Effective applicable policies not issued at county level.",
            "policy exposures",
            "stock",
            "Structural zero is valid.",
        ),
        "exposure_is_not_issuance": (
            "Guard flag: inherited exposure is not a county issuance.",
            "binary",
            "diagnostic",
            "Always one.",
        ),
        "reference_signal_year": (
            "Last historical year that can precede the boundary response.",
            "year",
            "boundary",
            "Never missing.",
        ),
        "boundary_response_year": (
            "Boundary-only policy year.",
            "year",
            "boundary",
            "Never missing.",
        ),
        "included_in_main_interface": (
            "Flag for inclusion in the 2011-2023 main interface.",
            "binary",
            "boundary",
            "Always zero in the boundary file.",
        ),
        "interpretation_scope": (
            "Non-causal use restriction for the boundary record.",
            "text",
            "boundary",
            "Never missing.",
        ),
    }
    if column in exact:
        return exact[column]

    code_match = re.fullmatch(r"(G[123]|T[1-6])_(.+)", column)
    if code_match:
        definition, unit, role = code_variable_metadata(
            code_match.group(1),
            code_match.group(2),
        )
        missing = (
            "NA when the relevant codable denominator is zero."
            if "share" in column
            else "Zero is valid; NA only for a first-year change."
            if column.endswith("_change")
            else "Zero is valid; non-codable policy values never enter the sum."
        )
        return definition, unit, role, missing

    network_match = re.fullmatch(r"(flow|stock)_network_(.+)", column)
    if network_match:
        scope, metric = network_match.groups()
        if metric.endswith("_change"):
            base = metric[: -len("_change")]
            definition = (
                f"Year-on-year change in the {scope}-network metric: "
                f"{NETWORK_DEFINITIONS[base]}"
            )
            return (
                definition,
                "metric change",
                "response_proxy",
                "NA only in the first history year.",
            )
        if metric not in NETWORK_DEFINITIONS:
            raise KeyError(f"Undefined network metric: {column}")
        missing = (
            "NA when the graph denominator or centrality is undefined."
            if metric
            in {
                "issuer_policy_bipartite_density",
                "combined_density",
                "largest_component_share",
                "mean_degree",
                "mean_document_balanced_strength",
                "degree_centralization",
                "max_weighted_betweenness",
                "joint_relation_weight_share",
                "vertical_relation_weight_share",
            }
            else "Structural zero is valid."
        )
        return (
            f"{scope.capitalize()} network: {NETWORK_DEFINITIONS[metric]}",
            "network metric",
            "stock" if scope == "stock" else "flow",
            missing,
        )

    if column in NETWORK_DEFINITIONS:
        return (
            NETWORK_DEFINITIONS[column],
            "network metric",
            "diagnostic",
            "NA when undefined; event and node counts use structural zero.",
        )
    if column == "network_scope":
        return (
            "Publication flow or effective-policy stock membership.",
            "category",
            "metadata",
            "Never missing.",
        )

    if re.fullmatch(
        r"(new|active)_policy_(national|shandong|municipal|county)_count",
        column,
    ):
        return (
            "Policies by publication/active status and issuing administrative level.",
            "policies",
            "auxiliary",
            "Structural zero is valid.",
        )
    if "risk_evidence_observable_policy_count" in column:
        return (
            "Policies with at least one extracted action unit available for risk-language screening.",
            "policies",
            "denominator",
            "Zero is observed; metadata-only policies remain outside the denominator.",
        )
    if re.search(
        r"(pressure_signal|ecological_state_signal|"
        r"explicit_feedback_signal|any_risk_signal|"
        r"explicit_governance_response_proxy)_policy_count$",
        column,
    ):
        return (
            "Policies whose action-unit evidence contains the named pre-specified signal language.",
            "policies",
            "response_proxy",
            "Structural zero is valid; this is not an event or causal-response measure.",
        )
    if re.search(
        r"(any_risk_signal|explicit_feedback_signal|"
        r"explicit_governance_response_proxy)_policy_share$",
        column,
    ):
        return (
            "Signal-language policies divided by policies with observable action-unit evidence.",
            "proportion",
            "response_proxy",
            "NA when the evidence-observable denominator is zero.",
        )
    if column.startswith("new_exposed_") or column.startswith("active_exposed_"):
        if column.endswith("_coding_coverage"):
            return (
                "Semantic coding coverage among county-exposed policies.",
                "proportion",
                "diagnostic",
                "NA when the exposed policy denominator is zero.",
            )
        if column.endswith("_codable_count"):
            return (
                "County-exposed policies with the named codable information.",
                "policy exposures",
                "denominator",
                "Structural zero is valid.",
            )

    trace_exact = {
        "policy_id": "Stable deduplicated policy identifier.",
        "policy_family_id": "Stable policy-family identifier.",
        "version": "Recorded policy version.",
        "action_unit_id": "Stable coded action-unit identifier.",
        "publication_year": "Policy publication year.",
        "publication_date": "Policy publication date.",
        "effective_date": "Recorded policy effective date.",
        "end_or_replacement_date": "Recorded expiry or replacement date.",
        "stock_start_year": "First effective-stock year.",
        "stock_end_year": "Last effective-stock year within 2000-2023.",
        "stock_exit_transition_year": "First inactive year after recorded end.",
        "open_ended_through_2023": (
            "One when no earlier end is recorded within the observation window."
        ),
        "publication_to_stock_entry_lag_years": (
            "Stock-entry year minus publication year."
        ),
        "phase": "Pre-specified policy-flow stage.",
        "temporal_role": "Historical-core or boundary-only role.",
        "admin_level": "Issuing administrative level.",
        "title": "Policy title.",
        "semantic_codable": "Observable G1-G3 action indicator.",
        "tool_codable": "Observable policy-tool composition indicator.",
        "action_unit_count_all": "Extracted action-unit count.",
        "metadata_joint_issuance": "Metadata-derived coordination-tool indicator.",
        "issuers_n": "Distinct formal issuers for the policy.",
        "issuer_ids": "Semicolon-delimited issuer IDs.",
        "issuer_names": "Semicolon-delimited issuer names.",
        "joint_issuance": "Observed joint-issuance indicator.",
        "issuer_list_complete": "Issuer-list completeness indicator.",
        "applicable_counties_n": "Study counties to which the policy applies.",
        "applicable_counties": "Semicolon-delimited applicable study counties.",
        "exposure_basis": "Recorded rule supporting county applicability.",
        "risk_evidence_observable": "Action-unit evidence availability indicator.",
        "signal_category": "Pre-specified risk-language category.",
        "matched_terms": "Matched dictionary terms.",
        "matched_response_terms": "Matched governance-response action terms.",
        "explicit_governance_response_proxy": (
            "Action-unit indicator requiring risk language, response language, "
            "and a non-empty final G code."
        ),
        "explicit_governance_response_proxy_action_units_n": (
            "Distinct policy action units meeting the explicit response-proxy rule."
        ),
        "explicit_governance_response_proxy_present": (
            "Policy-level explicit governance-response proxy indicator."
        ),
        "source_location": "Traceable location in the normalized policy source.",
        "evidence_text": "Verbatim coded evidence unit.",
        "G_codes": "Final G labels assigned to the evidence unit.",
        "T_codes": "Final tool labels assigned to the evidence unit.",
        "coding_scope": "Full-text or partial-text coding scope.",
        "document_unit_weight": "Equal-policy action-unit weight.",
        "rule_version": "Versioned risk-response screening rule.",
        "matched_risk_terms": "Distinct matched terms within the policy.",
        "any_risk_signal_action_units_n": (
            "Distinct action units with any risk-language match."
        ),
        "any_risk_signal_present": "Policy-level any-risk-language indicator.",
        "included_in_history": (
            "Flag for inclusion in the 2000-2023 historical interface."
        ),
        "causal_response_confirmed": (
            "Always zero; policy-side text does not confirm a causal response."
        ),
        "predecessor_policy_id": (
            "Historical predecessor in the same policy family, when present."
        ),
        "boundary_change_type": (
            "New boundary policy or substantive revision classification."
        ),
    }
    if column in trace_exact:
        return (
            trace_exact[column],
            "metadata or count",
            "trace",
            "Blank only when the source field was not recorded.",
        )
    if re.fullmatch(
        r"(pressure_signal|ecological_state_signal|"
        r"explicit_feedback_signal)_(action_units_n|present)",
        column,
    ):
        return (
            "Policy-level count or presence indicator for the named signal category.",
            "count or binary",
            "response_proxy",
            "Structural zero is valid.",
        )
    raise KeyError(f"No data-dictionary definition for column: {column}")


def build_data_dictionary(
    frames: dict[str, pd.DataFrame],
) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for filename, frame in frames.items():
        for column in frame.columns:
            definition, unit, role, missing_rule = variable_metadata(column)
            rows.append(
                {
                    "file": filename,
                    "variable": column,
                    "definition": definition,
                    "unit": unit,
                    "potential_SD_role": role,
                    "source_variables_or_formula": (
                        "Derived from the frozen policy ledger, semantic shares, "
                        "effective dates, issuer relations, county applicability, "
                        "or action-unit evidence; see interface manifest."
                    ),
                    "missing_value_rule": missing_rule,
                    "model_status": (
                        "Input candidate only; no SD equation or parameter is "
                        "specified in this bundle."
                    ),
                }
            )
    dictionary = pd.DataFrame(rows)
    if dictionary.duplicated(["file", "variable"]).any():
        raise ValueError("Duplicate data-dictionary entries.")
    return dictionary


def dictionary_markdown(dictionary: pd.DataFrame) -> str:
    lines = [
        "# Governance interface data dictionary",
        "",
        "These fields are model-agnostic candidates for later lagged dynamic, "
        "system-dynamics, and scenario work. They are not calibrated parameters, "
        "behavioural equations, implementation measures, or causal effects.",
        "",
    ]
    for filename, group in dictionary.groupby("file", sort=False):
        lines.extend(
            [
                f"## `{filename}`",
                "",
                "| Variable | Definition | Unit | Potential role | Missing-value rule |",
                "|---|---|---|---|---|",
            ]
        )
        for row in group.itertuples(index=False):
            values = [
                str(row.variable),
                str(row.definition),
                str(row.unit),
                str(row.potential_SD_role),
                str(row.missing_value_rule),
            ]
            values = [value.replace("|", r"\|") for value in values]
            lines.append("| " + " | ".join(values) + " |")
        lines.append("")
    return "\n".join(lines).rstrip() + "\n"


def source_registry() -> pd.DataFrame:
    update_date = "2026-07-24"
    rows = [
        {
            "source": "policy_master_83.csv",
            "domain": "governance",
            "spatial_unit": "policy and applicability area",
            "time_unit": "publication/effective/end date",
            "key_variables": "policy_id, dates, level, temporal_role, applicability",
            "transformation": "Historical/boundary separation and active-year expansion",
            "last_update": update_date,
            "license_or_access": "Internal derived research corpus",
        },
        {
            "source": "policy_G_tool_summary.csv",
            "domain": "governance semantics",
            "spatial_unit": "policy",
            "time_unit": "publication year",
            "key_variables": "semantic_codable, G1-G3 shares, T1-T6 shares",
            "transformation": "Equal-policy flow and effective-stock aggregation",
            "last_update": update_date,
            "license_or_access": "Internal derived coding output",
        },
        {
            "source": "issuer_policy_edges.csv",
            "domain": "formal governance network",
            "spatial_unit": "issuer-policy tie",
            "time_unit": "publication year",
            "key_variables": "issuer_id, policy_id, joint_issuance, completeness",
            "transformation": "Annual publication-flow and active-stock membership",
            "last_update": update_date,
            "license_or_access": "Internal derived metadata",
        },
        {
            "source": "multilevel_actor_events.csv",
            "domain": "multilevel governance relations",
            "spatial_unit": "policy-specific actor dyad",
            "time_unit": "publication/effective year",
            "key_variables": "relation_type, actors, document-balanced weight",
            "transformation": "Separate flow and stock graph snapshots",
            "last_update": update_date,
            "license_or_access": "Internal derived actor-relation output",
        },
        {
            "source": "policy_county_exposure.csv",
            "domain": "governance exposure",
            "spatial_unit": "policy-county relation",
            "time_unit": "publication/effective year",
            "key_variables": "policy_id, county, applicability_basis",
            "transformation": "County exposure; never recoded as county issuance",
            "last_update": update_date,
            "license_or_access": "Internal derived applicability mapping",
        },
        {
            "source": "action_unit_codes.csv",
            "domain": "policy-side signal language",
            "spatial_unit": "coded action unit",
            "time_unit": "publication year",
            "key_variables": "evidence_text, location, G/T labels",
            "transformation": "Transparent pre-specified keyword screening",
            "last_update": update_date,
            "license_or_access": "Internal derived coding output",
        },
    ]
    return pd.DataFrame(rows)


def merge_qa(
    master: pd.DataFrame,
    summary: pd.DataFrame,
    ledger: pd.DataFrame,
    issuer_edges: pd.DataFrame,
    exposure: pd.DataFrame,
    action_units: pd.DataFrame,
    actor_events: pd.DataFrame,
) -> pd.DataFrame:
    historical_ids = set(
        master.loc[
            master["temporal_role"].eq("historical_core"),
            "policy_id",
        ].astype(str)
    )
    steps = [
        {
            "step": "master_to_semantics",
            "left_table": "policy_master_83.csv",
            "right_table": "policy_G_tool_summary.csv",
            "join_key": "policy_id",
            "left_units_n": len(master),
            "matched_units_n": len(
                set(master["policy_id"].astype(str))
                & set(summary["policy_id"].astype(str))
            ),
            "dropped_units_n": 0,
            "notes": "One-to-one; NA semantics retained for non-codable policies.",
        },
        {
            "step": "historical_to_issuer_edges",
            "left_table": "historical policy ledger",
            "right_table": "issuer_policy_edges.csv",
            "join_key": "policy_id",
            "left_units_n": len(historical_ids),
            "matched_units_n": len(
                historical_ids & set(issuer_edges["policy_id"].astype(str))
            ),
            "dropped_units_n": 0,
            "notes": "Every historical policy retains at least one formal issuer.",
        },
        {
            "step": "historical_to_county_exposure",
            "left_table": "historical policy ledger",
            "right_table": "policy_county_exposure.csv",
            "join_key": "policy_id",
            "left_units_n": len(historical_ids),
            "matched_units_n": len(
                historical_ids & set(exposure["policy_id"].astype(str))
            ),
            "dropped_units_n": 0,
            "notes": "Exposure is applicability, not county issuance.",
        },
        {
            "step": "policy_to_action_evidence",
            "left_table": "policy_master_83.csv",
            "right_table": "action_unit_codes.csv",
            "join_key": "policy_id",
            "left_units_n": len(master),
            "matched_units_n": int(action_units["policy_id"].nunique()),
            "dropped_units_n": int(
                len(master) - action_units["policy_id"].nunique()
            ),
            "notes": (
                "Three metadata-only policies lack action units and remain "
                "outside risk-language denominators."
            ),
        },
        {
            "step": "historical_to_actor_events",
            "left_table": "historical policy ledger",
            "right_table": "multilevel_actor_events.csv",
            "join_key": "policy_id",
            "left_units_n": len(historical_ids),
            "matched_units_n": int(actor_events["policy_id"].nunique()),
            "dropped_units_n": int(
                len(historical_ids) - actor_events["policy_id"].nunique()
            ),
            "notes": (
                "Unmatched policies are standalone county/single-issuer cases "
                "without a joint or vertical actor relation; they remain in "
                "formal issuer-policy counts."
            ),
        },
    ]
    frame = pd.DataFrame(steps)
    frame["match_rate"] = (
        frame["matched_units_n"] / frame["left_units_n"]
    )
    return frame


def model_input_manifest() -> pd.DataFrame:
    return pd.DataFrame(
        [
            {
                "variable_family": "Policy publication flow",
                "field_pattern": "new_*",
                "potential_role": "governance input flow or response proxy",
                "recommended_scope": "2011-2023 Bay-year main interface",
                "deferred_decisions": "Scaling, functional form, and lag choice",
            },
            {
                "variable_family": "Effective policy stock",
                "field_pattern": "*_active_stock; active_policy_count",
                "potential_role": "governance stock or initial condition",
                "recommended_scope": "2000-2023 history, initialized at 2011",
                "deferred_decisions": "SD state definition and depreciation form",
            },
            {
                "variable_family": "Stock entry and exit",
                "field_pattern": "stock_entry_*; stock_exit_*",
                "potential_role": "stock-flow accounting inputs",
                "recommended_scope": "2000-2023 history",
                "deferred_decisions": "Continuous-time conversion if required",
            },
            {
                "variable_family": "Network coordination",
                "field_pattern": "flow_network_*; stock_network_*",
                "potential_role": "annual coordination flow/stock auxiliary",
                "recommended_scope": "Bay-year only",
                "deferred_decisions": "Indicator selection and normalization",
            },
            {
                "variable_family": "Policy-side response language",
                "field_pattern": "*risk_signal*; *feedback_signal*",
                "potential_role": "observable response-language proxy",
                "recommended_scope": "Bay-year, with evidence trace",
                "deferred_decisions": (
                    "Event validation and linkage to future S/E observations"
                ),
            },
            {
                "variable_family": "County policy exposure",
                "field_pattern": "*exposed*; *inherited*; local_issued_*",
                "potential_role": "spatial extension or robustness",
                "recommended_scope": "nine counties, 2011-2023",
                "deferred_decisions": "Spatial weighting and panel specification",
            },
        ]
    )


def numeric_variable_qa(
    frames: dict[str, pd.DataFrame],
) -> pd.DataFrame:
    rows = []
    for filename, frame in frames.items():
        for column in frame.select_dtypes(include=[np.number]).columns:
            values = pd.to_numeric(frame[column], errors="coerce")
            rows.append(
                {
                    "file": filename,
                    "variable": column,
                    "rows_n": len(frame),
                    "missing_n": int(values.isna().sum()),
                    "missing_rate": float(values.isna().mean()),
                    "minimum": (
                        float(values.min()) if values.notna().any() else math.nan
                    ),
                    "maximum": (
                        float(values.max()) if values.notna().any() else math.nan
                    ),
                    "outlier_action": (
                        "None; the short annual series is retained without "
                        "winsorization or model-specific scaling."
                    ),
                }
            )
    return pd.DataFrame(rows)


def stock_identity_errors(
    history: pd.DataFrame,
) -> dict[str, float]:
    check = history.loc[history["year"].gt(CFG.HISTORICAL_START)].copy()
    previous_policy = history["active_policy_count"].shift(1)
    policy_expected = (
        previous_policy
        + history["stock_entry_policy_count"]
        - history["stock_exit_policy_count"]
    )
    errors = {
        "policy_stock_identity_max_abs_error": float(
            np.nanmax(
                np.abs(history["active_policy_count"] - policy_expected)
            )
        ),
        "G_stock_identity_max_abs_error": 0.0,
        "T_stock_identity_max_abs_error": 0.0,
    }
    for code in G_CODES + T_CODES:
        expected = (
            history[f"{code}_active_stock"].shift(1)
            + history[f"{code}_stock_entry"]
            - history[f"{code}_stock_exit"]
        )
        error = float(
            np.nanmax(
                np.abs(history[f"{code}_active_stock"] - expected)
            )
        )
        key = (
            "G_stock_identity_max_abs_error"
            if code in G_CODES
            else "T_stock_identity_max_abs_error"
        )
        errors[key] = max(errors[key], error)
    return errors


def write_manifest(
    history: pd.DataFrame,
    main: pd.DataFrame,
    county: pd.DataFrame,
    boundary: pd.DataFrame,
    audit: dict[str, Any],
) -> None:
    lines = [
        "# Governance interface for later dynamic and system-dynamics work",
        "",
        "## Scope",
        "",
        "This bundle supplies a governance-side annual data layer only. It does "
        "not specify system-dynamics equations, calibrate parameters, run "
        "scenarios, or estimate ecological or social responses.",
        "",
        "## Time and spatial frames",
        "",
        f"- Historical initialization: {history['year'].min()}-"
        f"{history['year'].max()} ({len(history)} Bay-year rows).",
        f"- Main model-ready window: {main['year'].min()}-"
        f"{main['year'].max()} ({len(main)} Bay-year rows).",
        f"- County extension: {county['county'].nunique()} counties x "
        f"{county['year'].nunique()} years = {len(county)} rows.",
        "- Boundary sensitivity: the three reconciled 2024 policies are isolated "
        "from every historical and main interface.",
        "",
        "The 2000-2010 history is a warm-up for the observed corpus, allowing "
        "policies still effective in 2011 to enter the 2011 initial stock. It "
        "does not claim that every pre-2000 institution or policy was observed.",
        "",
        "## Construction rules",
        "",
        "- Publication year defines new-policy flow.",
        "- Effective date defines stock entry; publication date/year is the "
        "fallback when an effective date is absent.",
        "- Recorded end or replacement year is inclusive; exit is recorded at "
        "the next annual transition. Policies without an end remain active "
        "through 2023.",
        "- G1-G3 and T1-T6 sums are equal-policy equivalents. Policies without "
        "observable semantic evidence remain in policy/network counts but not "
        "semantic denominators.",
        "- Flow networks use policies published in year t; stock networks use "
        "policies effective in year t.",
        "- Solid joint-issuance relations and applicability-based vertical "
        "administrative linkages remain separate. County exposure never creates "
        "a county issuance.",
        "- Risk and feedback fields are transparent policy-language proxies. "
        "They are not verified external events, response lags, or causal effects.",
        "",
        "## Files",
        "",
        "| File | Purpose |",
        "|---|---|",
        "| `governance_sd_history_2000_2023.csv` | Full governance history and warm-up |",
        "| `governance_sd_interface_2011_2023.csv` | Bay-year main interface |",
        "| `governance_county_year_extension_2011_2023.csv` | County exposure extension |",
        "| `governance_response_boundary_2024.csv` | Isolated boundary sensitivity |",
        "| `governance_network_year_2000_2023.csv` | Long flow/stock network snapshots |",
        "| `governance_policy_stock_events_2000_2023.csv` | Policy stock-event ledger |",
        "| `policy_risk_signal_summary.csv` | Policy-level signal-language flags |",
        "| `policy_risk_signal_evidence.csv` | Evidence-level signal trace |",
        "| `governance_sd_data_dictionary.csv/.md` | Machine/human-readable definitions |",
        "| `governance_sd_source_registry.csv` | Input provenance |",
        "| `governance_sd_merge_qa.csv` | Join coverage and nonmatches |",
        "| `governance_sd_variable_qa.csv` | Missingness and observed ranges |",
        "| `governance_sd_model_input_manifest.csv` | Potential roles; modelling deferred |",
        "",
        "## Reproduction",
        "",
        "```powershell",
        "conda run -n gba-research python "
        ".\\analysis\\05b_build_sd_interfaces.py",
        "```",
        "",
        "## Validation",
        "",
        f"- Policy stock identity maximum error: "
        f"{audit['policy_stock_identity_max_abs_error']:.3g}.",
        f"- G-stock identity maximum error: "
        f"{audit['G_stock_identity_max_abs_error']:.3g}.",
        f"- T-stock identity maximum error: "
        f"{audit['T_stock_identity_max_abs_error']:.3g}.",
        f"- Data-dictionary coverage: "
        f"{audit['dictionary_columns_defined']}/"
        f"{audit['dictionary_columns_required']}.",
    ]
    (CFG.OUTPUT_ROOT / "governance_sd_interface_manifest.md").write_text(
        "\n".join(lines).rstrip() + "\n",
        encoding="utf-8",
    )


def main() -> None:
    CFG.ensure_dirs()
    master = pd.read_csv(CFG.OUTPUT_ROOT / "policy_master_83.csv")
    summary = pd.read_csv(CFG.OUTPUT_ROOT / "policy_G_tool_summary.csv")
    action_units = pd.read_csv(CFG.OUTPUT_ROOT / "action_unit_codes.csv")
    issuer_edges = pd.read_csv(CFG.OUTPUT_ROOT / "issuer_policy_edges.csv")
    actor_events = pd.read_csv(CFG.OUTPUT_ROOT / "multilevel_actor_events.csv")
    system_year = pd.read_csv(CFG.OUTPUT_ROOT / "governance_system_year.csv")
    county_year = pd.read_csv(CFG.OUTPUT_ROOT / "governance_county_year.csv")
    exposure = pd.read_csv(CFG.OUTPUT_ROOT / "policy_county_exposure.csv")

    ledger = build_policy_stock_ledger(
        master,
        summary,
        exposure,
        issuer_edges,
    )
    risk_evidence, risk_summary = build_risk_signal_trace(
        action_units,
        master,
    )
    network_year = build_network_year(
        ledger,
        issuer_edges,
        actor_events,
    )
    history = build_system_history(
        system_year,
        ledger,
        risk_summary,
        network_year,
    )
    main_interface = history.loc[history["year"].isin(MODEL_YEARS)].copy()
    county_history, county_extension = build_county_extension(
        county_year,
        ledger,
        exposure,
        risk_summary,
    )
    boundary = build_boundary_record(
        master,
        summary,
        issuer_edges,
        risk_summary,
    )

    core_frames = {
        "governance_sd_history_2000_2023.csv": history,
        "governance_sd_interface_2011_2023.csv": main_interface,
        "governance_county_year_extension_2011_2023.csv": county_extension,
        "governance_response_boundary_2024.csv": boundary,
        "governance_network_year_2000_2023.csv": network_year,
        "governance_policy_stock_events_2000_2023.csv": ledger,
        "policy_risk_signal_summary.csv": risk_summary,
        "policy_risk_signal_evidence.csv": risk_evidence,
    }
    dictionary = build_data_dictionary(core_frames)
    registry = source_registry()
    joins = merge_qa(
        master,
        summary,
        ledger,
        issuer_edges,
        exposure,
        action_units,
        actor_events,
    )
    input_manifest = model_input_manifest()
    variable_qa = numeric_variable_qa(core_frames)

    identities = stock_identity_errors(history)
    g_flow_error = float(
        np.max(
            np.abs(
                history[[f"{code}_new_flow" for code in G_CODES]].sum(axis=1)
                - history["new_semantic_codable_count"]
            )
        )
    )
    g_stock_error = float(
        np.max(
            np.abs(
                history[[f"{code}_active_stock" for code in G_CODES]].sum(
                    axis=1
                )
                - history["active_semantic_codable_count"]
            )
        )
    )
    t_flow_error = float(
        np.max(
            np.abs(
                history[[f"{code}_new_flow" for code in T_CODES]].sum(axis=1)
                - history["new_tool_codable_count"]
            )
        )
    )
    t_stock_error = float(
        np.max(
            np.abs(
                history[[f"{code}_active_stock" for code in T_CODES]].sum(
                    axis=1
                )
                - history["active_tool_codable_count"]
            )
        )
    )
    boundary_ids = set(
        master.loc[
            master["temporal_role"].eq("boundary_only"),
            "policy_id",
        ].astype(str)
    )
    history_network_ids: set[str] = set()
    for value in network_year["policy_ids"]:
        history_network_ids.update(
            item for item in clean_text(value).split(";") if item
        )
    expected_dictionary_rows = sum(
        len(frame.columns) for frame in core_frames.values()
    )
    main_subset_ok = main_interface.reset_index(drop=True).equals(
        history.loc[history["year"].isin(MODEL_YEARS)].reset_index(drop=True)
    )
    active_2011_ids = set(
        ledger.loc[
            ledger["stock_start_year"].le(2011)
            & ledger["stock_end_year"].ge(2011),
            "policy_id",
        ].astype(str)
    )
    carried_into_2011_ids = set(
        ledger.loc[
            ledger["policy_id"].isin(active_2011_ids)
            & ledger["publication_year"].lt(2011),
            "policy_id",
        ].astype(str)
    )
    delayed_stock_entry_policies_n = int(
        (
            ledger["stock_start_year"]
            > ledger["publication_year"].astype(int)
        ).sum()
    )
    county_issue_guard_ok = bool(
        (
            county_history["local_issued_new_policy_count"]
            <= county_history["new_exposed_policy_count"]
        ).all()
        and (
            county_history["local_issued_active_policy_count"]
            <= county_history["active_exposed_policy_count"]
        ).all()
        and county_history["exposure_is_not_issuance"].eq(1).all()
    )
    audit: dict[str, Any] = {
        "history_rows": len(history),
        "history_year_min": int(history["year"].min()),
        "history_year_max": int(history["year"].max()),
        "main_rows": len(main_interface),
        "main_year_min": int(main_interface["year"].min()),
        "main_year_max": int(main_interface["year"].max()),
        "main_is_exact_history_subset": main_subset_ok,
        "county_extension_rows": len(county_extension),
        "county_extension_counties": int(county_extension["county"].nunique()),
        "county_extension_years": int(county_extension["year"].nunique()),
        "network_year_rows": len(network_year),
        "network_scopes": sorted(network_year["network_scope"].unique()),
        "risk_evidence_rows": len(risk_evidence),
        "risk_signal_policies": int(
            risk_summary["any_risk_signal_present"].sum()
        ),
        "explicit_feedback_signal_policies": int(
            risk_summary["explicit_feedback_signal_present"].sum()
        ),
        "explicit_governance_response_proxy_policies": int(
            risk_summary[
                "explicit_governance_response_proxy_present"
            ].sum()
        ),
        "risk_rule_version": RISK_RULE_VERSION,
        "risk_evidence_blank_text_rows": int(
            risk_evidence["evidence_text"].map(clean_text).eq("").sum()
        ),
        "boundary_policy_ids": sorted(boundary_ids),
        "boundary_policy_count": len(boundary_ids),
        "boundary_output_rows": len(boundary),
        "boundary_output_policy_ids": sorted(
            boundary["policy_id"].astype(str)
        ),
        "boundary_ids_in_history_network": sorted(
            boundary_ids & history_network_ids
        ),
        "boundary_included_in_main": int(
            boundary["included_in_main_interface"].sum()
        ),
        "county_exposure_issuance_guard": county_issue_guard_ok,
        "dictionary_columns_required": expected_dictionary_rows,
        "dictionary_columns_defined": len(dictionary),
        "dictionary_duplicate_rows": int(
            dictionary.duplicated(["file", "variable"]).sum()
        ),
        "G_flow_denominator_max_abs_error": g_flow_error,
        "G_stock_denominator_max_abs_error": g_stock_error,
        "T_flow_denominator_max_abs_error": t_flow_error,
        "T_stock_denominator_max_abs_error": t_stock_error,
        "delayed_stock_entry_policies_n": delayed_stock_entry_policies_n,
        "active_policies_2011": len(active_2011_ids),
        "pre_2011_policies_carried_into_2011": len(
            carried_into_2011_ids
        ),
        "transition_2010_to_2011_net_change": float(
            history.loc[
                history["year"].eq(2011),
                "active_policy_stock_net_change",
            ].iloc[0]
        ),
        **identities,
    }
    failures = {
        "history_dimensions": not (
            len(history) == 24
            and history["year"].tolist() == HISTORY_YEARS
        ),
        "main_dimensions": not (
            len(main_interface) == 13
            and main_interface["year"].tolist() == MODEL_YEARS
        ),
        "main_subset": not main_subset_ok,
        "county_dimensions": not (
            len(county_extension) == 117
            and county_extension["county"].nunique() == 9
            and county_extension["year"].nunique() == 13
            and not county_extension.duplicated(["county", "year"]).any()
        ),
        "network_dimensions": not (
            len(network_year) == 48
            and set(network_year["network_scope"]) == {"flow", "stock"}
        ),
        "stock_identities": max(identities.values()) > 1e-9,
        "semantic_denominators": max(
            g_flow_error,
            g_stock_error,
            t_flow_error,
            t_stock_error,
        )
        > 1e-9,
        "warm_up_initialization": not (
            delayed_stock_entry_policies_n == 8
            and len(active_2011_ids) == 12
            and len(carried_into_2011_ids) == 10
            and math.isclose(
                audit["transition_2010_to_2011_net_change"],
                1.0,
                abs_tol=1e-9,
            )
        ),
        "county_issue_guard": not county_issue_guard_ok,
        "boundary_isolation": not (
            len(boundary_ids) == 3
            and len(boundary) == 3
            and set(boundary["policy_id"].astype(str)) == boundary_ids
            and not (boundary_ids & history_network_ids)
            and int(boundary["included_in_main_interface"].sum()) == 0
            and int(boundary["included_in_history"].sum()) == 0
            and int(boundary["causal_response_confirmed"].sum()) == 0
        ),
        "risk_trace": not (
            audit["risk_evidence_blank_text_rows"] == 0
            and risk_evidence["rule_version"].eq(RISK_RULE_VERSION).all()
            and (
                risk_evidence.loc[
                    risk_evidence[
                        "explicit_governance_response_proxy"
                    ].eq(1),
                    "G_codes",
                ]
                .map(clean_text)
                .ne("")
                .all()
            )
        ),
        "dictionary_coverage": not (
            len(dictionary) == expected_dictionary_rows
            and audit["dictionary_duplicate_rows"] == 0
        ),
    }
    audit["failed_invariants"] = [
        name for name, failed in failures.items() if failed
    ]
    audit["status"] = "PASS" if not audit["failed_invariants"] else "FAIL"
    if audit["failed_invariants"]:
        raise ValueError(
            "Governance SD-interface invariant failed: "
            + json.dumps(audit, ensure_ascii=False, indent=2)
        )

    for filename, frame in core_frames.items():
        CFG.write_csv(frame, CFG.OUTPUT_ROOT / filename)
    CFG.write_csv(
        dictionary,
        CFG.OUTPUT_ROOT / "governance_sd_data_dictionary.csv",
    )
    (CFG.OUTPUT_ROOT / "governance_sd_data_dictionary.md").write_text(
        dictionary_markdown(dictionary),
        encoding="utf-8",
    )
    CFG.write_csv(
        registry,
        CFG.OUTPUT_ROOT / "governance_sd_source_registry.csv",
    )
    CFG.write_csv(
        joins,
        CFG.OUTPUT_ROOT / "governance_sd_merge_qa.csv",
    )
    CFG.write_csv(
        variable_qa,
        CFG.OUTPUT_ROOT / "governance_sd_variable_qa.csv",
    )
    CFG.write_csv(
        input_manifest,
        CFG.OUTPUT_ROOT / "governance_sd_model_input_manifest.csv",
    )
    CFG.write_json(
        audit,
        CFG.QA_DIR / "governance_sd_interface_audit.json",
    )
    write_manifest(
        history,
        main_interface,
        county_extension,
        boundary,
        audit,
    )
    print(json.dumps(audit, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
