"""Produce strict semantic results, figures, tables, and provenance outputs."""

from __future__ import annotations

import json
import math
from importlib import import_module
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
import numpy as np
import pandas as pd


CFG = import_module("00_config")
plt.rcParams["font.family"] = "Arial"
plt.rcParams["svg.fonttype"] = "none"
plt.rcParams["pdf.fonttype"] = 42


def parse_codes(value: object, allowed: set[str]) -> list[str]:
    if value is None or (isinstance(value, float) and pd.isna(value)):
        return []
    return [item for item in str(value).split(";") if item in allowed]


def bootstrap_mean_ci(
    values: np.ndarray, rng: np.random.Generator
) -> tuple[np.ndarray, np.ndarray]:
    if len(values) == 0:
        return np.repeat(np.nan, 3), np.repeat(np.nan, 3)
    draws = values[
        rng.integers(0, len(values), size=(2000, len(values)))
    ].mean(axis=1)
    return np.quantile(draws, 0.025, axis=0), np.quantile(draws, 0.975, axis=0)


def make_composition(
    master: pd.DataFrame,
    *,
    subset_name: str,
    subset: pd.DataFrame,
    rng: np.random.Generator,
) -> pd.DataFrame:
    rows: list[dict[str, object]] = []
    for phase, start, end in CFG.PERIODS:
        phase_all = master.loc[master["phase"].eq(phase)].copy()
        phase_subset = subset.loc[subset["phase"].eq(phase)].copy()
        coded = phase_subset.loc[phase_subset["semantic_codable"].eq(1)].copy()
        values = coded[[f"{g}_share" for g in CFG.G_CODES]].to_numpy(dtype=float)
        low, high = bootstrap_mean_ci(values, rng)
        row: dict[str, object] = {
            "subset": subset_name,
            "phase": phase,
            "year_start": start,
            "year_end": end,
            "eligible_policies_n": int(len(phase_all)),
            "subset_policies_n": int(len(phase_subset)),
            "codable_policies_n": int(len(coded)),
            "uncodable_policies_n": int(len(phase_subset) - len(coded)),
            "A_grade_policies_n": int(
                phase_subset["text_evidence_grade"].eq("A").sum()
            ),
            "B_grade_policies_n": int(
                phase_subset["text_evidence_grade"].eq("B").sum()
            ),
            "complete_body_policies_n": int(
                phase_subset["text_complete"].eq("complete").sum()
            ),
        }
        for idx, g in enumerate(CFG.G_CODES):
            row[f"{g}_share"] = (
                float(np.nanmean(values[:, idx])) if len(values) else math.nan
            )
            row[f"{g}_ci_low"] = float(low[idx])
            row[f"{g}_ci_high"] = float(high[idx])
        rows.append(row)
    return pd.DataFrame(rows)


def strict_g_tool_matrix(
    action_units: pd.DataFrame, strict_ids: set[str]
) -> pd.DataFrame:
    relevant = action_units.loc[
        action_units["policy_id"].isin(strict_ids)
        & action_units["G0_context"].eq(0)
    ].copy()
    records: list[dict[str, object]] = []
    for _, row in relevant.iterrows():
        gs = parse_codes(row["G_codes"], set(CFG.G_CODES))
        ts = parse_codes(row["T_codes"], set(CFG.T_CODES))
        if not gs or not ts:
            continue
        unit_weight = float(row["document_unit_weight"])
        allocation = unit_weight / (len(gs) * len(ts))
        for g in gs:
            for t in ts:
                records.append(
                    {
                        "G_code": g,
                        "T_code": t,
                        "joint_weight": allocation,
                        "policy_id": row["policy_id"],
                        "action_unit_id": row["action_unit_id"],
                    }
                )
    observed = pd.DataFrame(records)
    grid = pd.MultiIndex.from_product(
        [CFG.G_CODES, CFG.T_CODES], names=["G_code", "T_code"]
    ).to_frame(index=False)
    if observed.empty:
        grid["joint_weight"] = 0.0
        grid["supporting_policies_n"] = 0
        grid["supporting_action_units_n"] = 0
    else:
        aggregate = (
            observed.groupby(["G_code", "T_code"], as_index=False)
            .agg(
                joint_weight=("joint_weight", "sum"),
                supporting_policies_n=("policy_id", "nunique"),
                supporting_action_units_n=("action_unit_id", "nunique"),
            )
        )
        grid = grid.merge(aggregate, on=["G_code", "T_code"], how="left")
        grid[
            [
                "joint_weight",
                "supporting_policies_n",
                "supporting_action_units_n",
            ]
        ] = grid[
            [
                "joint_weight",
                "supporting_policies_n",
                "supporting_action_units_n",
            ]
        ].fillna(0)
    grid["row_total_weight"] = grid.groupby("G_code")["joint_weight"].transform(
        "sum"
    )
    grid["row_share"] = np.where(
        grid["row_total_weight"] > 0,
        grid["joint_weight"] / grid["row_total_weight"],
        np.nan,
    )
    grid["interpretation"] = (
        "Within-G share of action-unit G-by-tool co-coding; descriptive design "
        "matching, not a causal effect."
    )
    return grid


def stage_network_structure() -> pd.DataFrame:
    baseline_network = pd.read_csv(CFG.BASELINE_ROOT / "network_metrics_by_period.csv")
    multi = pd.read_csv(CFG.BASELINE_ROOT / "multilevel_network_metrics_by_period.csv")
    phase_numbers = multi["phase"].astype(str).str.extract(
        r"(?P<year_start>\d{4}).*?(?P<year_end>\d{4})"
    )
    multi = pd.concat([multi, phase_numbers.astype(int)], axis=1)
    rows: list[dict[str, object]] = []
    for phase, start, end in CFG.PERIODS:
        structural = baseline_network.loc[
            baseline_network["year_start"].eq(start)
            & baseline_network["year_end"].eq(end)
        ]
        vertical = multi.loc[
            multi["year_start"].eq(start) & multi["year_end"].eq(end)
        ]
        if len(structural) != 1 or len(vertical) != 1:
            raise RuntimeError(f"Missing architecture inputs for {phase}")
        s = structural.iloc[0]
        v = vertical.iloc[0]
        rows.append(
            {
                "phase": phase,
                "year_start": start,
                "year_end": end,
                "policy_documents_n": int(s["policies_n"]),
                "issuing_organisations_n": int(s["issuers_n"]),
                "issuer_policy_ties_n": int(s["issuer_policy_ties_n"]),
                "observed_joint_issue_policies_n": int(v["joint_issue_policies_n"]),
                "observed_joint_issuance_events_n": int(
                    v["joint_issuance_events_n"]
                ),
                "vertical_applicability_policies_n": int(
                    v["vertical_linkage_policies_n"]
                ),
                "vertical_administrative_events_n": int(
                    v["vertical_administrative_events_n"]
                ),
                "joint_issue_policy_share": float(
                    v["joint_issue_policies_n"] / s["policies_n"]
                ),
                "vertical_applicability_policy_share": float(
                    v["vertical_linkage_policies_n"] / s["policies_n"]
                ),
                "largest_component_issuer_coverage": float(
                    s["largest_component_coverage"]
                ),
                "network_definition": (
                    "Policy-flow architecture: observed issuer-policy structure; "
                    "co-issuance and vertical applicability reported separately."
                ),
            }
        )
    return pd.DataFrame(rows)


def build_reconciliation(
    master: pd.DataFrame,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    legacy = pd.read_csv(CFG.BASELINE_ROOT / "policy_G_tool_summary.csv")
    legacy = legacy.loc[
        legacy["publication_year"].between(
            CFG.HISTORICAL_START, CFG.HISTORICAL_END
        )
    ].copy()
    frozen_ids = set(legacy.loc[legacy["semantic_codable"].eq(1), "policy_id"])
    strict_ids = set(master["policy_id"])
    lookup = pd.concat(
        [
            master[["policy_id", "publication_year", "title"]].copy(),
            legacy[["policy_id", "publication_year", "title"]].copy(),
        ],
        ignore_index=True,
    ).drop_duplicates("policy_id")
    rows: list[dict[str, object]] = []
    for policy_id in sorted(strict_ids.union(frozen_ids)):
        is_strict = policy_id in strict_ids
        is_frozen = policy_id in frozen_ids
        if is_strict and is_frozen:
            membership = "both"
        elif is_strict:
            membership = "strict_68_only"
        else:
            membership = "legacy_frozen_proxy_only"
        details = lookup.loc[lookup["policy_id"].eq(policy_id)].iloc[0]
        rows.append(
            {
                "policy_id": policy_id,
                "publication_year": int(details["publication_year"]),
                "title": details["title"],
                "strict_formal_semantic_manifest_68": int(is_strict),
                "legacy_codable_proxy_for_frozen_SD": int(is_frozen),
                "membership": membership,
                "interpretation": (
                    "Do not silently substitute the strict 68-text semantic result "
                    "for the frozen SD governance interface."
                ),
            }
        )
    differences = pd.DataFrame(rows)
    frozen_interface = CFG.BASELINE_ROOT / "governance_sd_interface_2011_2023.csv"
    frozen_state = CFG.SD_ROOT / "data" / "model_input_2011_2023.csv"
    source_rows = pd.DataFrame(
        [
            {
                "artifact": "policy_flow_architecture_historical_80",
                "path": str(CFG.BASELINE_ROOT / "network_metrics_by_period.csv"),
                "sha256": CFG.sha256_bytes(
                    CFG.BASELINE_ROOT / "network_metrics_by_period.csv"
                ),
                "role": "read_only structural governance layer",
                "policy_universe": 80,
            },
            {
                "artifact": "formal_semantic_manifest",
                "path": str(CFG.OUTPUT_ROOT / "semantic_manifest_68.csv"),
                "sha256": CFG.sha256_bytes(
                    CFG.OUTPUT_ROOT / "semantic_manifest_68.csv"
                ),
                "role": "V2 primary semantic layer",
                "policy_universe": 68,
            },
            {
                "artifact": "frozen_governance_SD_interface",
                "path": str(frozen_interface),
                "sha256": CFG.sha256_bytes(frozen_interface),
                "role": "immutable SD governance input reference",
                "policy_universe": int(len(frozen_ids)),
            },
            {
                "artifact": "frozen_SD_state_layer",
                "path": str(frozen_state),
                "sha256": CFG.sha256_bytes(frozen_state),
                "role": "immutable state interface used by the V2 trend module",
                "policy_universe": math.nan,
            },
        ]
    )
    return differences, source_rows


def save_figure(fig: plt.Figure, base: Path) -> None:
    base.parent.mkdir(parents=True, exist_ok=True)
    for suffix, dpi in [("png", 320), ("tiff", 600)]:
        fig.savefig(base.with_suffix(f".{suffix}"), dpi=dpi, facecolor="white")
    fig.savefig(base.with_suffix(".pdf"), facecolor="white")
    fig.savefig(base.with_suffix(".svg"), facecolor="white")


def make_figure_1(composition: pd.DataFrame, structure: pd.DataFrame) -> None:
    primary = composition.loc[composition["subset"].eq("primary_68")].copy()
    fig = plt.figure(figsize=(15.0, 5.7))
    grid = fig.add_gridspec(1, 3, width_ratios=[1.0, 1.10, 1.15])
    fig.subplots_adjust(left=0.055, right=0.985, bottom=0.145, top=0.89, wspace=0.54)

    ax = fig.add_subplot(grid[0, 0])
    x = np.arange(len(structure))
    bars = ax.bar(
        x,
        structure["policy_documents_n"],
        color="#8EAFC1",
        width=0.62,
        label="policy documents",
    )
    ax.set_ylabel("Policy documents (n)", color="#274C65")
    ax.set_xticks(x, structure["phase"], rotation=32, ha="right")
    ax.set_title(
        "a  Institutional supply architecture (80 policy flows)",
        loc="left",
        fontweight="bold",
    )
    for bar, value in zip(bars, structure["policy_documents_n"]):
        ax.text(
            bar.get_x() + bar.get_width() / 2,
            value + 0.35,
            str(value),
            ha="center",
            va="bottom",
            fontsize=8,
        )
    twin = ax.twinx()
    twin.plot(
        x,
        structure["joint_issue_policy_share"] * 100,
        "o-",
        color="#C9755E",
        lw=1.8,
        ms=5,
        label="observed co-issuance",
    )
    twin.plot(
        x,
        structure["vertical_applicability_policy_share"] * 100,
        "^-",
        color="#5E6C76",
        lw=1.4,
        ms=5,
        label="vertical applicability",
    )
    twin.set_ylabel("Share of policies (%)", color="#4B555C")
    twin.set_ylim(0, 110)
    handles, labels = ax.get_legend_handles_labels()
    h2, l2 = twin.get_legend_handles_labels()
    ax.legend(
        handles + h2,
        labels + l2,
        fontsize=7,
        frameon=False,
        loc="upper left",
    )

    ax = fig.add_subplot(grid[0, 1])
    for g in CFG.G_CODES:
        y = primary[f"{g}_share"].to_numpy() * 100
        lo = primary[f"{g}_ci_low"].to_numpy() * 100
        hi = primary[f"{g}_ci_high"].to_numpy() * 100
        ax.errorbar(
            x,
            y,
            yerr=np.vstack([y - lo, hi - y]),
            marker="o",
            lw=1.8,
            capsize=2.5,
            color=CFG.G_COLORS[g],
            label=g,
        )
    ax.set_ylim(0, 80)
    ax.set_ylabel("Equal-policy composition (%)")
    ax.set_xticks(x, primary["phase"], rotation=32, ha="right")
    ax.set_title(
        "b  Formal semantic action composition (fixed 68 texts)",
        loc="left",
        fontweight="bold",
    )
    for idx, row in primary.reset_index(drop=True).iterrows():
        ax.text(
            idx,
            77.0,
            f"n={int(row['codable_policies_n'])}/{int(row['eligible_policies_n'])}",
            ha="center",
            va="top",
            fontsize=7.2,
            color="#4B555C",
        )
    ax.legend(
        title="Governance action",
        fontsize=7.5,
        title_fontsize=7.5,
        frameon=False,
        loc="lower right",
    )

    ax = fig.add_subplot(grid[0, 2])
    ax.set_axis_off()
    ax.set_title(
        "c  Evidence hand-off and claim boundary",
        loc="left",
        fontweight="bold",
    )
    boxes = [
        (
            0.07,
            0.70,
            0.86,
            0.17,
            "80 historical policy flows\nInstitutional supply and administrative reach",
        ),
        (
            0.07,
            0.42,
            0.86,
            0.17,
            "68 fixed formal-text universe\nGovernance-action and tool composition",
        ),
        (
            0.07,
            0.14,
            0.86,
            0.17,
            "Frozen SD-compatible state layer\nHistorical G-S-E trajectories\nand descriptive co-movement",
        ),
    ]
    for xx, yy, ww, hh, label in boxes:
        patch = FancyBboxPatch(
            (xx, yy),
            ww,
            hh,
            boxstyle="round,pad=0.02,rounding_size=0.02",
            linewidth=0.9,
            edgecolor="#355B74",
            facecolor="#F4F7F8",
            transform=ax.transAxes,
        )
        ax.add_patch(patch)
        ax.text(
            xx + ww / 2,
            yy + hh / 2,
            label,
            ha="center",
            va="center",
            fontsize=8.2,
        )
    ax.annotate(
        "",
        xy=(0.50, 0.59),
        xytext=(0.50, 0.70),
        xycoords=ax.transAxes,
        arrowprops={"arrowstyle": "->", "color": "#5E6C76", "lw": 1.0},
    )
    ax.annotate(
        "",
        xy=(0.50, 0.31),
        xytext=(0.50, 0.42),
        xycoords=ax.transAxes,
        arrowprops={"arrowstyle": "->", "color": "#5E6C76", "lw": 1.0},
    )
    ax.text(
        0.08,
        0.01,
        "The arrow denotes analytical sequencing, not causal identification. "
        "SD feedback and nonlinearity remain model-based counterfactual mechanisms.",
        transform=ax.transAxes,
        fontsize=7.0,
        color="#4B555C",
        wrap=True,
    )
    save_figure(fig, CFG.FIGURE_DIR / "Figure_1_governance_evidence_layers")
    plt.close(fig)


def make_figure_s1(matrix: pd.DataFrame) -> None:
    pivot = matrix.pivot(
        index="G_code", columns="T_code", values="row_share"
    ).reindex(index=CFG.G_CODES, columns=CFG.T_CODES)
    supports = matrix.pivot(
        index="G_code", columns="T_code", values="supporting_policies_n"
    ).reindex(index=CFG.G_CODES, columns=CFG.T_CODES)
    fig, ax = plt.subplots(figsize=(190 / 25.4, 80 / 25.4))
    fig.subplots_adjust(left=0.10, right=0.91, bottom=0.18, top=0.94)
    max_value = max(20, float(np.nanmax(pivot.to_numpy() * 100)))
    im = ax.imshow(pivot.to_numpy() * 100, cmap="Blues", vmin=0, vmax=max_value)
    ax.set_xticks(range(len(CFG.T_CODES)), CFG.T_CODES)
    ax.set_yticks(range(len(CFG.G_CODES)), CFG.G_CODES)
    ax.set_xlabel("Policy tool")
    ax.set_ylabel("Governance action")
    for i, g in enumerate(CFG.G_CODES):
        for j, t in enumerate(CFG.T_CODES):
            share = pivot.loc[g, t] * 100
            support = int(supports.loc[g, t])
            color = "white" if share > 12 else "#1F2D36"
            ax.text(
                j,
                i,
                f"{share:.1f}%\n(n={support})",
                ha="center",
                va="center",
                fontsize=8,
                color=color,
            )
    cb = fig.colorbar(im, ax=ax, shrink=0.85)
    cb.set_label("Within-action co-coding share (%)")
    save_figure(
        fig,
        CFG.FIGURE_DIR / "supplementary" / "Figure_S1_G_tool_design_matching",
    )
    plt.close(fig)


def write_text_outputs(composition: pd.DataFrame) -> None:
    primary = composition.loc[composition["subset"].eq("primary_68")]
    first = primary.iloc[0]
    last = primary.iloc[-1]
    text = f"""# 政策语义网络演化模块：V2 方法与结果表述

## 研究边界与估计对象

治理制度层分为两个不可混同的证据宇宙。第一，2000—2023 年的 80 条政策流量用于描述正式发文、发文机关、联合发文与行政适用/传导架构。第二，固定的 68 条正式全文（A 级 50 条、B 级 18 条）用于政策语义、治理行动（G1—G3）与工具组合分析。2024 年边界文本以及非准入的部分材料均不进入语义编码、统计、图表或表格。

语义组成以可观察到 G1—G3 行动的政策为分析单元，每条政策等权；没有可观察行动的正式全文保留在样本覆盖率分母中，不以零值替代。阶段不确定性采用政策重抽样的 95% 区间，仅表达样本组成对文献抽样的敏感性，不表示总体推断或因果效应。

## 主要发现（谨慎表述）

在 2000—2010 阶段，语义可编码政策为 {int(first['codable_policies_n'])}/{int(first['eligible_policies_n'])}；在 2021—2023 阶段为 {int(last['codable_policies_n'])}/{int(last['eligible_policies_n'])}。图 1b 展示 G1、G2 与 G3 在正式全文中的阶段性等权组成，而不是政策数量或实施强度的变化。图 S1 进一步描述行动—工具的共编码匹配；它不识别政策工具的实施效果。

制度架构图将观测到的联合发文与行政适用/传导分开报告，避免将两类关系混合成“桥接机构”或协同治理的中心性结论。图 1c 中的箭头只表示论文的分析顺序：治理供给与语义意图提出状态关联的研究问题，后续由独立的 SD 模型在既定结构下讨论非线性机制与情景反事实。

## 与冻结 SD 工件的衔接

冻结 SD 的治理接口保持只读。本 V2 的 68 条正式全文并不替代该接口；两者的重叠和差集均在 semantic_sd_sample_reconciliation.csv 中显式记录。因而，语义结果可用于界定治理供给、行动设计和机制候选，但不能回填为 SD 反馈、阈值或情景效果的历史验证。
"""
    (CFG.TEXT_DIR / "methods_results_semantic_v2_chinese.md").write_text(
        text, encoding="utf-8"
    )
    captions = """# Figure captions and quantitative-panel QA

## Figure 1. Governance evidence layers

**Conclusion:** Governance supply expanded across the 80-policy structural layer,
whereas the fixed 68-text semantic layer describes composition and evidence
coverage rather than implementation or causal effects.

- Panel a: source data are Figure_1a_architecture.csv. Bars are policy-document
  counts. Lines are separate shares of observed joint issuance and vertical
  applicability; these edge types are not pooled.
- Panel b: source data are Figure_1b_G_composition.csv. n is the number of
  codable texts over the fixed formal-text denominator in each stage. Points are
  equal-policy mean G shares; whiskers are 2,000 policy-resampling 95% intervals.
  No hypothesis test, p value, or multiple-testing correction is claimed.
- Panel c: a provenance schematic. Arrows state analysis order only, not a causal
  pathway.

## Figure S1. G-by-tool action design matching

Source data are Figure_S1_G_tool_matrix.csv. Cell values are within-action
co-coding shares among action units with an explicit tool code; n is the number
of supporting policies. This is descriptive policy-design matching, not an
estimate of implementation, effectiveness, or causal mechanisms.
"""
    (CFG.TEXT_DIR / "figure_captions_and_QA.md").write_text(
        captions, encoding="utf-8"
    )
    readme = """# Policy semantic network evolution V2

This versioned package preserves the 20260724 output as a read-only baseline.

Run:

    conda run -n gba-research python analysis/run_all.py

Primary semantic universe: the immutable 68-document formal-text manifest for
2000-2023. The 80-policy historical flow architecture is retained only as a
separate structural governance layer. The frozen SD input is read only and is
reconciled explicitly rather than overwritten.
"""
    (CFG.OUTPUT_ROOT / "README_reproduce.md").write_text(readme, encoding="utf-8")


def main() -> None:
    CFG.ensure_dirs()
    rng = np.random.default_rng(CFG.RANDOM_SEED)
    master = pd.read_csv(CFG.INTERMEDIATE_DIR / "policy_master_current.csv")
    summary = pd.read_csv(CFG.OUTPUT_ROOT / "policy_G_tool_summary.csv")
    action_units = pd.read_csv(CFG.OUTPUT_ROOT / "action_unit_codes.csv")
    if len(master) != 68 or not master["semantic_eligible_legacy"].eq(1).all():
        raise RuntimeError("Strict semantic master was not preserved through extraction")
    if set(summary["policy_id"]) != set(master["policy_id"]):
        raise RuntimeError(
            "Policy summary does not exactly match the strict semantic universe"
        )

    merged = master.merge(
        summary[
            [
                "policy_id",
                "semantic_codable",
                "G1_share",
                "G2_share",
                "G3_share",
                "g_action_unit_count",
            ]
        ],
        on="policy_id",
        how="left",
        validate="one_to_one",
    )
    merged["semantic_codable"] = merged["semantic_codable"].fillna(0).astype(int)
    primary = make_composition(
        master, subset_name="primary_68", subset=merged, rng=rng
    )
    a_only = make_composition(
        master,
        subset_name="A_grade_only",
        subset=merged.loc[merged["text_evidence_grade"].eq("A")],
        rng=rng,
    )
    complete = make_composition(
        master,
        subset_name="complete_body_only",
        subset=merged.loc[merged["text_complete"].eq("complete")],
        rng=rng,
    )
    composition = pd.concat([primary, a_only, complete], ignore_index=True)
    matrix = strict_g_tool_matrix(action_units, set(master["policy_id"]))
    reconciliation, source_registry = build_reconciliation(master)

    quality = merged[
        [
            "policy_id",
            "publication_year",
            "phase",
            "title",
            "text_evidence_grade",
            "全文状态",
            "text_source",
            "text_complete",
            "coding_scope",
            "semantic_codable",
            "g_action_unit_count",
            "canonical_source_file",
            "canonical_source_role",
        ]
    ].copy()
    quality["sample_role"] = "fixed_68_formal_semantic_universe"
    quality["no_observable_action_rule"] = (
        "Retained in coverage denominator; not imputed as a zero G-share."
    )
    quality["attachment_routing_note"] = np.where(
        quality["policy_id"].isin({"YT_2020_AQ_PLAN_01", "WF_2022_AQ_PLAN_01"}),
        "approved attachment selected as canonical semantic body",
        "",
    )

    table = primary[
        [
            "phase",
            "eligible_policies_n",
            "codable_policies_n",
            "A_grade_policies_n",
            "B_grade_policies_n",
            "complete_body_policies_n",
            "G1_share",
            "G1_ci_low",
            "G1_ci_high",
            "G2_share",
            "G2_ci_low",
            "G2_ci_high",
            "G3_share",
            "G3_ci_low",
            "G3_ci_high",
        ]
    ].copy()
    table = table.rename(
        columns={
            "phase": "Policy stage",
            "eligible_policies_n": "Fixed formal texts (n)",
            "codable_policies_n": "Codable texts (n)",
            "A_grade_policies_n": "A-grade texts (n)",
            "B_grade_policies_n": "B-grade texts (n)",
            "complete_body_policies_n": "Complete body texts (n)",
            "G1_share": "G1 equal-policy share",
            "G1_ci_low": "G1 95% low",
            "G1_ci_high": "G1 95% high",
            "G2_share": "G2 equal-policy share",
            "G2_ci_low": "G2 95% low",
            "G2_ci_high": "G2 95% high",
            "G3_share": "G3 equal-policy share",
            "G3_ci_low": "G3 95% low",
            "G3_ci_high": "G3 95% high",
        }
    )

    CFG.write_csv(
        composition, CFG.OUTPUT_ROOT / "strict_G_composition_by_phase.csv"
    )
    CFG.write_csv(
        composition.loc[composition["subset"].ne("primary_68")],
        CFG.OUTPUT_ROOT / "semantic_sensitivity_by_phase.csv",
    )
    CFG.write_csv(matrix, CFG.OUTPUT_ROOT / "G_tool_matrix_strict.csv")
    CFG.write_csv(
        quality, CFG.OUTPUT_ROOT / "semantic_eligibility_and_coding_audit.csv"
    )
    CFG.write_csv(
        reconciliation, CFG.OUTPUT_ROOT / "semantic_sd_sample_reconciliation.csv"
    )
    CFG.write_csv(source_registry, CFG.OUTPUT_ROOT / "source_registry.csv")
    CFG.write_csv(table, CFG.TABLE_DIR / "Table_1_governance_evidence_layers.csv")

    handoff = pd.DataFrame(
        [
            {
                "sequence": 1,
                "layer": "68 fixed formal-text universe",
                "use": "institutional collaboration, governance action and policy-tool composition",
                "claim_boundary": "descriptive policy-supply evidence only",
            },
            {
                "sequence": 2,
                "layer": "V4 strict-68 policy-stock interface",
                "use": "G1-G3 and G_supply descriptive trend layer",
                "claim_boundary": "future SD input; not current SD calibration or scenario validation",
            },
            {
                "sequence": 3,
                "layer": "frozen SD baseline",
                "use": "historical state trajectories and descriptive co-movement",
                "claim_boundary": "read-only ecological/social source; governance synchronization pending",
            },
        ]
    )
    CFG.write_csv(handoff, CFG.FIGURE_SOURCE_DIR / "V4_module_handoff.csv")
    CFG.write_csv(
        matrix, CFG.FIGURE_SOURCE_DIR / "Figure_S1_G_tool_matrix.csv"
    )

    spec = {
        "version": "20260728_v4_strict68_ocm",
        "primary_semantic_estimand": (
            "Equal-policy composition of observable G1-G3 action coding within "
            "the immutable 68 formal-text sample."
        ),
        "structural_governance_layer": (
            "Strict 68 formal full-text policies; 80-flow materials are retained "
            "only as a read-only baseline audit."
        ),
        "excluded_from_primary_semantic_analysis": [
            "2024 boundary policies",
            "noneligible partial-content records",
            "combined co-issuance plus vertical-linkage centrality",
        ],
        "inference_boundary": (
            "Descriptive composition and bootstrap sample sensitivity; no causal "
            "effect, implementation, feedback, or threshold claim."
        ),
        "frozen_SD_rule": (
            "The legacy SD governance interface is read only and is not overwritten "
            "by the strict 68-document semantic result."
        ),
    }
    CFG.write_json(spec, CFG.OUTPUT_ROOT / "analysis_specification.json")
    make_figure_s1(matrix)
    write_text_outputs(composition)

    audit = {
        "strict_policy_universe": int(len(master)),
        "codable_policy_count": int(merged["semantic_codable"].sum()),
        "uncodable_policy_count": int((merged["semantic_codable"] == 0).sum()),
        "action_units": int(len(action_units)),
        "G_tool_matrix_cells": int(len(matrix)),
        "primary_figure": "figures/Figure_1_governance_evidence_layers",
        "status": "PASS",
    }
    CFG.write_json(audit, CFG.QA_DIR / "strict_semantic_build_audit.json")
    print(json.dumps(audit, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
