"""重建正式湾级SD输入，修正治理版本与水质重复计权。"""

from __future__ import annotations

from importlib import import_module

import numpy as np
import pandas as pd

cfg = import_module("00_config")
from common import (
    calibration_scaler,
    geometric_mean_columns,
    hill,
    sha256_file,
    write_json,
)


def _apply_scaler(series: pd.Series, spec: dict[str, float]) -> pd.Series:
    denominator = spec["upper"] - spec["lower"]
    if abs(denominator) < 1e-12:
        return pd.Series(0.5, index=series.index)
    mapped = 0.02 + 0.96 * (series - spec["lower"]) / denominator
    return mapped.clip(0.02, 0.98)


def _build_scenario_bounds(panel: pd.DataFrame) -> pd.DataFrame:
    """由正式83版湾级治理接口构建情景分位，并登记实施时滞先验。"""

    lever_columns = {
        "u_G1": "G1_active_stock_share",
        "u_G2": "G2_active_stock_share",
        "u_G3": "G3_active_stock_share",
        "eta_impl": "implementation_potential_midpoint",
        "u_feedback": "adaptive_feedback_share",
        "u_synergy": "synergy_share",
    }
    rows: list[dict] = []
    for lever, column in lever_columns.items():
        values = pd.to_numeric(panel[column], errors="coerce").dropna()
        lower = float(values.min())
        upper = float(values.max())
        for setting, quantile in [
            ("P25", 0.25),
            ("P50", 0.50),
            ("P75", 0.75),
            ("P90", 0.90),
        ]:
            rows.append(
                {
                    "row_type": "empirical_quantile",
                    "scenario": "",
                    "lever": lever,
                    "setting": setting,
                    "value": float(values.quantile(quantile)),
                    "historical_support_min": lower,
                    "historical_support_max": upper,
                    "support_status": "formal83_bay_year_2011_2023",
                    "observation_count": int(len(values)),
                    "interpretation": (
                        "text-derived governance supply or implementation "
                        "potential; not realized policy effect"
                    ),
                }
            )
        rows.append(
            {
                "row_type": "normative_stress_bound",
                "scenario": "",
                "lever": lever,
                "setting": "above_historical_max",
                "value": float(np.clip(upper + (upper - lower), 0.02, 0.99)),
                "historical_support_min": lower,
                "historical_support_max": upper,
                "support_status": "normative_pressure_test_not_prediction",
                "observation_count": int(len(values)),
                "interpretation": (
                    "outside historical support; supplementary stress test only"
                ),
            }
        )

    # 政策实施调整时间缺少莱州湾可观测结果时滞，按已登记的同行研究先验
    # 给出宽区间；该量只用于情景目标调整，不参与历史因果识别。
    for setting, value in [
        ("P25", 1.0),
        ("P50", 2.0),
        ("P75", 3.0),
        ("P90", 4.0),
        ("below_historical_min_fast_response", 0.5),
    ]:
        rows.append(
            {
                "row_type": (
                    "normative_stress_bound"
                    if setting == "below_historical_min_fast_response"
                    else "registered_prior_quantile"
                ),
                "scenario": "",
                "lever": "tau_impl",
                "setting": setting,
                "value": value,
                "historical_support_min": 0.5,
                "historical_support_max": 4.0,
                "support_status": "registered_literature_prior",
                "observation_count": np.nan,
                "interpretation": (
                    "implementation-adjustment time in years; structural prior"
                ),
            }
        )
    return pd.DataFrame(rows)


def main() -> None:
    cfg.ensure_directories()
    states = pd.read_csv(cfg.STATE_FILE)
    ecology = pd.read_csv(cfg.ECOLOGY_EXTRACT_FILE).rename(
        columns={
            "年份": "year",
            "CEI": "CEI_workbook",
            "DIN（mg/L）": "DIN_mg_L_workbook",
            "DIP（mg/L）": "DIP_mg_L_workbook",
            "COD（mg/L）": "COD_mg_L_workbook",
            "RDIN": "RDIN_workbook",
            "SST（℃）": "SST_C",
            "chl-a（mg/L）": "Chl_a_ug_L",
            "RNDia": "RNDia_workbook",
            "赤潮发生次数": "red_tide_events",
            "DO（μg/L）": "DO_mg_L",
        }
    )
    ecology["year"] = pd.to_numeric(ecology["year"], errors="raise").astype(int)
    for column in ecology.columns:
        if column not in {"year", "CEI等级"}:
            ecology[column] = pd.to_numeric(ecology[column], errors="coerce")

    policy = pd.read_csv(cfg.POLICY_SYSTEM_FILE)
    policy = policy[policy["year"].between(2011, 2023)].copy()
    policy["year"] = policy["year"].astype(int)
    policy["G_flow_total"] = policy["new_policy_count"]
    policy["G_stock_legal"] = policy["active_policy_count"]
    policy["exit_flow_total"] = policy["stock_exit_policy_count"]
    policy["implementation_potential_midpoint"] = policy[
        "active_explicit_governance_response_proxy_policy_share"
    ]
    policy["adaptive_feedback_share"] = policy[
        "active_explicit_feedback_signal_policy_share"
    ]
    policy["risk_signal_share"] = policy[
        "active_any_risk_signal_policy_share"
    ]
    policy["synergy_share"] = np.sqrt(
        policy["stock_network_joint_issue_policy_share"].clip(lower=0.0)
        * policy["stock_network_vertical_relation_weight_share"].clip(lower=0.0)
    )
    policy["risk_response"] = np.sqrt(
        policy["risk_signal_share"].clip(lower=0.0)
        * policy["adaptive_feedback_share"].clip(lower=0.0)
    )
    policy["explicit_response_lag_years"] = np.nan

    panel = states.merge(ecology, on="year", how="left", validate="one_to_one")
    panel = panel.merge(
        policy[
            [
                "year",
                "G_flow_total",
                "G_stock_legal",
                "exit_flow_total",
                "implementation_potential_midpoint",
                "explicit_response_lag_years",
                "G1_new_flow",
                "G1_active_stock",
                "G2_new_flow",
                "G2_active_stock",
                "G3_new_flow",
                "G3_active_stock",
                "adaptive_feedback_share",
                "risk_signal_share",
                "synergy_share",
                "risk_response",
                "G1_active_stock_share",
                "G2_active_stock_share",
                "G3_active_stock_share",
            ]
        ],
        on="year",
        how="left",
        validate="one_to_one",
        suffixes=("", "_formal83"),
    )
    panel = panel.sort_values("year").reset_index(drop=True)
    assert panel["year"].tolist() == cfg.HISTORICAL_YEARS
    assert panel["SST_C"].notna().all()

    # 工作簿与状态模块的年度生态原始量应一致；以工作簿字段作为正式单位别名。
    raw_checks = {
        "DIN": float(
            np.nanmax(np.abs(panel["DIN_mg_L"] - panel["DIN_mg_L_workbook"]))
        ),
        "DIP": float(
            np.nanmax(np.abs(panel["DIP_mg_L"] - panel["DIP_mg_L_workbook"]))
        ),
        "COD": float(
            np.nanmax(np.abs(panel["COD_mg_L"] - panel["COD_mg_L_workbook"]))
        ),
        "Chl-a": float(
            np.nanmax(
                np.abs(panel["Chl_a_原表单位mg_L_待核"] - panel["Chl_a_ug_L"])
            )
        ),
        "DO": float(
            np.nanmax(np.abs(panel["DO_原表单位ug_L_待核"] - panel["DO_mg_L"]))
        ),
        "CEI": float(np.nanmax(np.abs(panel["CEI"] - panel["CEI_workbook"]))),
        "RDIN": float(np.nanmax(np.abs(panel["RDIN"] - panel["RDIN_workbook"]))),
        "RNDia": float(np.nanmax(np.abs(panel["RNDia"] - panel["RNDia_workbook"]))),
        "red_tide": float(
            np.nanmax(np.abs(panel["赤潮次数"] - panel["red_tide_events"]))
        ),
    }
    if max(raw_checks.values()) > 1e-8:
        raise AssertionError(f"年度生态原始量不一致: {raw_checks}")

    panel["RDIN_recomputed"] = (panel["DIN_mg_L"] / 16.0) / (
        panel["DIN_mg_L"] / 16.0 + panel["DIP_mg_L"]
    )
    panel["RDIN_abs_error"] = np.abs(panel["RDIN"] - panel["RDIN_recomputed"])
    if panel["RDIN_abs_error"].max() > 1e-10:
        raise AssertionError("RDIN复算未通过。")

    calibration_mask = panel["year"].isin(cfg.CALIBRATION_YEARS)
    scaling_specs: dict[str, dict[str, float]] = {}

    # 治理使用最终83版正式活动库存，以校准期中位库存作为饱和尺度，
    # 保留2023年以后的提升空间。
    for channel in ["G1", "G2", "G3"]:
        raw_column = f"{channel}_active_stock"
        half_saturation = float(panel.loc[calibration_mask, raw_column].median())
        panel[channel] = panel[raw_column] / (panel[raw_column] + half_saturation)
        scaling_specs[channel] = {
            "mapping": "x/(x+K)",
            "K": half_saturation,
            "fit_period": "2011-2020",
            "source_version": "policy_semantic_network_evolution_83_20260724",
        }

    # 社会状态只用训练期拟合映射，防止验证期信息泄漏。
    panel["SP"], scaling_specs["SP"] = calibration_scaler(
        panel["S_pressure"], calibration_mask
    )
    panel["SC"], scaling_specs["SC"] = calibration_scaler(
        panel["S_capacity"], calibration_mask
    )

    # 水质三维重新构建：RDIN不进入任何独立权重。
    for raw, scaled in [
        ("DIN_mg_L", "DIN_stress"),
        ("DIP_mg_L", "DIP_stress"),
        ("COD_mg_L", "COD_stress"),
        ("DO_mg_L", "DO_support"),
        ("Chl_a_ug_L", "Chl_a_stress"),
        ("RNDia", "RNDia_stress"),
        ("red_tide_events", "red_tide_stress"),
    ]:
        panel[scaled], scaling_specs[scaled] = calibration_scaler(
            panel[raw], calibration_mask
        )
    panel["NS"] = panel[["DIN_stress", "DIP_stress"]].mean(axis=1)
    panel["OS"] = pd.concat(
        [panel["COD_stress"], 1.0 - panel["DO_support"]], axis=1
    ).mean(axis=1)
    panel["BS"] = panel[
        ["Chl_a_stress", "RNDia_stress", "red_tide_stress"]
    ].mean(axis=1)

    # 生境支持保留潮滩与盐沼两个库存；2023上下界按面积构成比例分配。
    panel["TF"], scaling_specs["TF"] = calibration_scaler(
        panel["tidal_flat_area_km2"], calibration_mask
    )
    panel["SM"], scaling_specs["SM"] = calibration_scaler(
        panel["salt_marsh_area_km2"], calibration_mask
    )
    total_area = panel["tidal_flat_area_km2"] + panel["salt_marsh_area_km2"]
    tf_share = panel["tidal_flat_area_km2"] / total_area
    sm_share = panel["salt_marsh_area_km2"] / total_area
    panel["tidal_flat_lower_km2"] = (
        panel["habitat_area_lower_raw_km2"] * tf_share
    )
    panel["tidal_flat_upper_km2"] = (
        panel["habitat_area_upper_raw_km2"] * tf_share
    )
    panel["salt_marsh_lower_km2"] = (
        panel["habitat_area_lower_raw_km2"] * sm_share
    )
    panel["salt_marsh_upper_km2"] = (
        panel["habitat_area_upper_raw_km2"] * sm_share
    )
    panel["TF_lower"] = _apply_scaler(
        panel["tidal_flat_lower_km2"], scaling_specs["TF"]
    )
    panel["TF_upper"] = _apply_scaler(
        panel["tidal_flat_upper_km2"], scaling_specs["TF"]
    )
    panel["SM_lower"] = _apply_scaler(
        panel["salt_marsh_lower_km2"], scaling_specs["SM"]
    )
    panel["SM_upper"] = _apply_scaler(
        panel["salt_marsh_upper_km2"], scaling_specs["SM"]
    )
    panel["habitat_weight"] = np.where(panel["year"] == 2023, 0.35, 1.0)

    # 外生扰动均用训练期口径映射，保留原单位列。
    panel["PPT"], scaling_specs["PPT"] = calibration_scaler(
        panel["precipitation_raw_mm"], calibration_mask
    )
    panel["RUNOFF"], scaling_specs["RUNOFF"] = calibration_scaler(
        panel["runoff_raw_mm"], calibration_mask
    )
    panel["SST"], scaling_specs["SST"] = calibration_scaler(
        panel["SST_C"], calibration_mask
    )
    panel["ND"] = panel[["PPT", "RUNOFF", "SST"]].mean(axis=1)
    panel["COMPOUND"] = (
        panel[["PPT", "RUNOFF", "SST"]].clip(0.001).prod(axis=1) ** (1.0 / 3.0)
    )

    # 文本实施潜力仅为潜力分数，不等于实际执行率。
    panel["ETA_POTENTIAL"], scaling_specs["ETA_POTENTIAL"] = calibration_scaler(
        panel["implementation_potential_midpoint"], calibration_mask
    )
    sc_gate = hill(panel["SC"].to_numpy(float), 0.30, 2.0)
    sc_factor = 0.12 + 0.88 * sc_gate
    panel["IM"] = np.clip(
        panel["ETA_POTENTIAL"]
        * hill(panel["G3"].to_numpy(float), 0.45, 2.2)
        * sc_factor
        / (1.0 + 0.75 * panel["SP"]),
        0.001,
        0.999,
    )

    panel["WQ"] = geometric_mean_columns(
        pd.DataFrame(
            {
                "N": 1.0 - panel["NS"],
                "O": 1.0 - panel["OS"],
                "B": 1.0 - panel["BS"],
            }
        ),
        ["N", "O", "B"],
    )
    panel["H"] = geometric_mean_columns(panel, ["TF", "SM"])
    panel["ES"] = geometric_mean_columns(panel, ["WQ", "H"])
    panel["SR"] = geometric_mean_columns(
        pd.DataFrame({"pressure_support": 1.0 - panel["SP"], "SC": panel["SC"]}),
        ["pressure_support", "SC"],
    )
    panel["RISK_SIGNAL"] = (
        panel["SP"] + (1.0 - panel["WQ"]) + (1.0 - panel["H"])
    ) / 3.0
    panel["PRS"] = panel["SP"].ewm(alpha=0.45, adjust=False).mean()
    ecological_risk_signal = (
        (1.0 - panel["WQ"]) + (1.0 - panel["H"])
    ) / 2.0
    panel["PRE"] = ecological_risk_signal.ewm(alpha=0.45, adjust=False).mean()
    panel["PR"] = (panel["PRS"] + 2.0 * panel["PRE"]) / 3.0

    # CEI只作独立锚点。
    panel["CEI_stress"], scaling_specs["CEI_stress"] = calibration_scaler(
        panel["CEI"], calibration_mask
    )
    panel["phase"] = np.where(
        panel["year"].isin(cfg.CALIBRATION_YEARS),
        "calibration",
        "holdout_validation",
    )
    panel["governance_source_version"] = (
        "policy_semantic_network_evolution_83_20260724"
    )
    panel["ecology_source_version"] = "数据需求表(1).xlsx:年度数据"
    panel["unit_corrected_DO"] = 1
    panel["unit_corrected_Chl_a"] = 1

    keep = [
        "year",
        "phase",
        "G1",
        "G2",
        "G3",
        "SP",
        "SC",
        "NS",
        "OS",
        "BS",
        "TF",
        "SM",
        "PR",
        "PRS",
        "IM",
        "PRE",
        "WQ",
        "H",
        "ES",
        "SR",
        "PPT",
        "RUNOFF",
        "SST",
        "precipitation_raw_mm",
        "runoff_raw_mm",
        "SST_C",
        "ND",
        "COMPOUND",
        "ETA_POTENTIAL",
        "CEI_stress",
        "CEI",
        "DIN_mg_L",
        "DIP_mg_L",
        "COD_mg_L",
        "DO_mg_L",
        "Chl_a_ug_L",
        "RNDia",
        "red_tide_events",
        "RDIN",
        "RDIN_recomputed",
        "RDIN_abs_error",
        "tidal_flat_area_km2",
        "salt_marsh_area_km2",
        "TF_lower",
        "TF_upper",
        "SM_lower",
        "SM_upper",
        "habitat_weight",
        "observation_status",
        "G_flow_total",
        "G_stock_legal",
        "exit_flow_total",
        "G1_new_flow",
        "G1_active_stock",
        "G2_new_flow",
        "G2_active_stock",
        "G3_new_flow",
        "G3_active_stock",
        "implementation_potential_midpoint",
        "explicit_response_lag_years",
        "adaptive_feedback_share",
        "risk_signal_share",
        "synergy_share",
        "risk_response",
        "G1_active_stock_share",
        "G2_active_stock_share",
        "G3_active_stock_share",
        "governance_source_version",
        "ecology_source_version",
        "unit_corrected_DO",
        "unit_corrected_Chl_a",
    ]
    model_input = panel[keep].copy()
    model_input.to_csv(cfg.DATA_DIR / "model_input_2011_2023.csv", index=False)
    scenario_bounds = _build_scenario_bounds(panel)
    scenario_bounds.to_csv(cfg.SCENARIO_BOUNDS_FILE, index=False)
    write_json(cfg.INTERMEDIATE_DIR / "normalization_parameters.json", scaling_specs)

    variable_rows = [
        ("G1", "Governance", "Active pressure-control governance supply", "0-1", "higher is stronger potential supply", "stock"),
        ("G2", "Governance", "Active habitat-restoration governance supply", "0-1", "higher is stronger potential supply", "stock"),
        ("G3", "Governance", "Active monitoring/adaptive governance supply", "0-1", "higher is stronger potential supply", "stock"),
        ("SP", "Social", "Social pressure", "0-1", "higher is worse", "stock"),
        ("SC", "Social", "Social adaptive capacity", "0-1", "higher is better", "stock"),
        ("NS", "Ecological: water quality", "Nutrient stress from DIN and DIP", "0-1", "higher is worse", "stock"),
        ("OS", "Ecological: water quality", "Organic-oxygen stress from COD and inverse DO", "0-1", "higher is worse", "stock"),
        ("BS", "Ecological: water quality", "Biological-symptom stress", "0-1", "higher is worse", "stock"),
        ("TF", "Ecological: habitat", "Tidal-flat support", "0-1", "higher is better", "stock"),
        ("SM", "Ecological: habitat", "Salt-marsh support", "0-1", "higher is better", "stock"),
        ("PR", "SES feedback", "Perceived risk memory", "0-1", "higher is worse", "stock"),
        ("PRS", "SES feedback", "Social-source perceived-risk memory", "0-1", "higher is worse", "auxiliary_stock"),
        ("IM", "Governance-social interface", "Realized implementation stock", "0-1", "higher is stronger realized implementation", "auxiliary_stock"),
        ("PRE", "SES feedback", "Ecological-source perceived-risk memory", "0-1", "higher is worse", "derived"),
        ("WQ", "Ecological", "Water-quality support", "0-1", "higher is better", "derived"),
        ("H", "Ecological", "Habitat support", "0-1", "higher is better", "derived"),
        ("ES", "Ecological", "Blue-carbon stability support conditions", "0-1", "higher is better", "derived"),
        ("SR", "Social", "Social resilience", "0-1", "higher is better", "derived"),
        ("SST", "External natural forcing", "Sea-surface temperature stress", "0-1", "higher is warmer", "exogenous"),
        ("PPT", "External natural forcing", "Annual precipitation", "0-1", "higher is wetter", "exogenous"),
        ("RUNOFF", "External natural forcing", "Annual runoff", "0-1", "higher is greater runoff", "exogenous"),
        ("RDIN", "Diagnostic", "Study-specific relative DIN contribution", "dimensionless", "not independently oriented", "diagnostic_only"),
        ("CEI", "Validation", "Composite eutrophication index", "index", "higher is worse", "validation_only"),
        ("DIN_mg_L", "Raw water quality", "Dissolved inorganic nitrogen", "mg/L", "higher is worse", "raw_observation"),
        ("DIP_mg_L", "Raw water quality", "Dissolved inorganic phosphorus", "mg/L", "higher is worse", "raw_observation"),
        ("COD_mg_L", "Raw water quality", "Chemical oxygen demand", "mg/L", "higher is worse", "raw_observation"),
        ("DO_mg_L", "Raw water quality", "Dissolved oxygen; corrected unit alias with unchanged values", "mg/L", "higher is better", "raw_observation"),
        ("Chl_a_ug_L", "Raw water quality", "Chlorophyll-a; corrected unit alias with unchanged values", "ug/L (mg/m3)", "higher is worse", "raw_observation"),
        ("precipitation_raw_mm", "External natural forcing", "Annual precipitation in source data", "mm/year", "higher is wetter", "raw_observation"),
        ("runoff_raw_mm", "External natural forcing", "Annual runoff depth in source data", "mm/year", "higher is greater runoff", "raw_observation"),
        ("SST_C", "External natural forcing", "Sea-surface temperature", "degree C", "higher is warmer", "raw_observation"),
    ]
    dictionary = pd.DataFrame(
        variable_rows,
        columns=[
            "symbol",
            "subsystem",
            "definition",
            "unit",
            "orientation",
            "model_role",
        ],
    )
    dictionary.to_csv(cfg.OUTPUT_ROOT / "variable_dictionary.csv", index=False)

    merge_qa = {
        "rows": int(len(model_input)),
        "year_min": int(model_input["year"].min()),
        "year_max": int(model_input["year"].max()),
        "year_unique": bool(model_input["year"].is_unique),
        "sst_complete": bool(model_input["SST"].notna().all()),
        "formal83_governance_complete": bool(
            model_input[["G1", "G2", "G3"]].notna().all().all()
        ),
        "phase_boundary_pass": bool(
            model_input.loc[
                model_input["phase"] == "calibration", "year"
            ].tolist()
            == cfg.CALIBRATION_YEARS
            and model_input.loc[
                model_input["phase"] == "holdout_validation", "year"
            ].tolist()
            == cfg.VALIDATION_YEARS
        ),
        "unit_alias_values_unchanged": bool(
            raw_checks["Chl-a"] <= 1e-12 and raw_checks["DO"] <= 1e-12
        ),
        "governance_source_version": (
            "policy_semantic_network_evolution_83_20260724"
        ),
        "raw_ecology_reconciliation_max_error": max(raw_checks.values()),
        "rdin_max_error": float(model_input["RDIN_abs_error"].max()),
        "water_support_recomputed_without_rdin_weight": True,
        "risk_source_identity_max_error": float(
            np.max(
                np.abs(
                    model_input["PR"]
                    - (model_input["PRS"] + 2.0 * model_input["PRE"]) / 3.0
                )
            )
        ),
        "scenario_bounds_sha256": sha256_file(cfg.SCENARIO_BOUNDS_FILE),
        "confidential_station_data_present": False,
        "model_input_sha256": sha256_file(
            cfg.DATA_DIR / "model_input_2011_2023.csv"
        ),
        "status": "PASS",
    }
    write_json(cfg.QA_DIR / "merge_and_input_qa.json", merge_qa)
    print("SD input preparation completed.")


if __name__ == "__main__":
    main()
