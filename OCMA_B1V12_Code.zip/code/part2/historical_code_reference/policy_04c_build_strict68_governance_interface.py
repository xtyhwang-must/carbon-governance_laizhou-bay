"""Build the strict-68 governance stock--flow interface for trend analysis.

The V4 interface is intentionally limited to the immutable 68 formal full
texts.  A document with no observable G1--G3 action remains in the policy
universe and is represented by G0/zero action contribution rather than being
dropped from a denominator.  The frozen SD package is not read or modified.
"""

from __future__ import annotations

import json
from importlib import import_module

import numpy as np
import pandas as pd


CFG = import_module("00_config")
G_CODES = ["G1", "G2", "G3"]
HISTORY_YEARS = list(range(CFG.HISTORICAL_START, CFG.HISTORICAL_END + 1))
MODEL_YEARS = list(range(2011, CFG.HISTORICAL_END + 1))


def active_bounds(row: pd.Series) -> tuple[int, int, int | None]:
    """Return inclusive stock years and the first inactive transition year."""

    publication = pd.to_datetime(row.get("publication_date"), errors="coerce")
    effective = pd.to_datetime(row.get("effective_date"), errors="coerce")
    end = pd.to_datetime(row.get("end_or_replacement_date"), errors="coerce")
    publication_year = int(row["publication_year"])
    start = (
        int(effective.year)
        if not pd.isna(effective)
        else int(publication.year)
        if not pd.isna(publication)
        else publication_year
    )
    raw_end = int(end.year) if not pd.isna(end) else CFG.HISTORICAL_END
    start = max(start, CFG.HISTORICAL_START)
    finish = min(raw_end, CFG.HISTORICAL_END)
    exit_transition = raw_end + 1 if not pd.isna(end) and raw_end < CFG.HISTORICAL_END else None
    return start, finish, exit_transition


def numeric(frame: pd.DataFrame, columns: list[str]) -> pd.DataFrame:
    copied = frame.copy()
    for column in columns:
        copied[column] = pd.to_numeric(copied[column], errors="coerce").fillna(0.0)
    return copied


def build_ledger(master: pd.DataFrame, summary: pd.DataFrame) -> pd.DataFrame:
    required_master = {
        "policy_id", "publication_year", "publication_date", "effective_date",
        "end_or_replacement_date", "phase", "admin_level", "title",
        "semantic_analysis_eligible", "text_evidence_grade", "text_complete",
    }
    required_summary = {
        "policy_id", "semantic_codable", "action_unit_count_all", "g_action_unit_count",
        *[f"{code}_share" for code in G_CODES],
    }
    missing_master = required_master.difference(master.columns)
    missing_summary = required_summary.difference(summary.columns)
    if missing_master or missing_summary:
        raise RuntimeError(
            f"Strict-68 interface input is incomplete; master={sorted(missing_master)}, "
            f"summary={sorted(missing_summary)}"
        )
    if len(master) != 68 or not master["semantic_analysis_eligible"].eq(1).all():
        raise RuntimeError("The V4 governance interface must contain exactly 68 formal full texts")

    columns = [
        "policy_id", "semantic_codable", "action_unit_count_all", "g_action_unit_count",
        *[f"{code}_share" for code in G_CODES],
    ]
    ledger = master.merge(summary[columns], on="policy_id", how="left", validate="one_to_one")
    ledger = numeric(ledger, ["semantic_codable", "action_unit_count_all", "g_action_unit_count", *[f"{code}_share" for code in G_CODES]])
    ledger["semantic_codable"] = ledger["semantic_codable"].astype(int)
    ledger["G0_no_observable_target_action"] = (1 - ledger["semantic_codable"]).astype(int)
    for code in G_CODES:
        ledger.loc[ledger["semantic_codable"].eq(0), f"{code}_share"] = 0.0

    bounds = ledger.apply(active_bounds, axis=1, result_type="expand")
    bounds.columns = ["stock_start_year", "stock_end_year", "stock_exit_transition_year"]
    ledger = pd.concat([ledger, bounds], axis=1)
    ledger["stock_exit_transition_year"] = ledger["stock_exit_transition_year"].astype("Int64")
    ledger["open_ended_through_2023"] = ledger["end_or_replacement_date"].isna().astype(int)
    ledger["publication_to_stock_entry_lag_years"] = ledger["stock_start_year"] - ledger["publication_year"].astype(int)
    ledger["sample_universe"] = "strict_68_formal_full_texts"
    ledger["G0_rule"] = "Retained in the formal-text denominator with zero G1-G3 contribution"
    ledger = ledger.sort_values(["publication_year", "stock_start_year", "policy_id"]).reset_index(drop=True)
    return ledger


def build_history(ledger: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, object]] = []
    for year in HISTORY_YEARS:
        flow = ledger.loc[ledger["publication_year"].eq(year)].copy()
        active = ledger.loc[
            ledger["stock_start_year"].le(year) & ledger["stock_end_year"].ge(year)
        ].copy()
        entries = ledger.loc[ledger["stock_start_year"].eq(year)].copy()
        exits = ledger.loc[ledger["stock_exit_transition_year"].eq(year)].copy()
        row: dict[str, object] = {
            "year": year,
            "phase": CFG.phase_for_year(year),
            "sample_universe": "strict_68_formal_full_texts",
            "new_policy_count": int(len(flow)),
            "active_policy_count": int(len(active)),
            "new_semantic_codable_count": int(flow["semantic_codable"].sum()),
            "active_semantic_codable_count": int(active["semantic_codable"].sum()),
            "new_G0_policy_count": int(flow["G0_no_observable_target_action"].sum()),
            "active_G0_policy_count": int(active["G0_no_observable_target_action"].sum()),
            "stock_entry_policy_count": int(len(entries)),
            "stock_exit_policy_count": int(len(exits)),
            "stock_entry_G0_policy_count": int(entries["G0_no_observable_target_action"].sum()),
            "stock_exit_G0_policy_count": int(exits["G0_no_observable_target_action"].sum()),
        }
        for code in G_CODES:
            row[f"{code}_new_flow"] = float(flow[f"{code}_share"].sum())
            row[f"{code}_active_stock"] = float(active[f"{code}_share"].sum())
            row[f"{code}_stock_entry"] = float(entries[f"{code}_share"].sum())
            row[f"{code}_stock_exit"] = float(exits[f"{code}_share"].sum())
            row[f"{code}_active_stock_share_all_formal"] = (
                float(row[f"{code}_active_stock"] / len(active)) if len(active) else np.nan
            )
            row[f"{code}_active_stock_share_codable"] = (
                float(row[f"{code}_active_stock"] / active["semantic_codable"].sum())
                if int(active["semantic_codable"].sum()) else np.nan
            )
        row["new_semantic_coding_coverage"] = (
            float(row["new_semantic_codable_count"] / len(flow)) if len(flow) else np.nan
        )
        row["active_semantic_coding_coverage"] = (
            float(row["active_semantic_codable_count"] / len(active)) if len(active) else np.nan
        )
        rows.append(row)
    history = pd.DataFrame(rows)
    for code in G_CODES:
        history[f"{code}_active_stock_net_change"] = history[f"{code}_active_stock"].diff()
    history["active_policy_stock_net_change"] = history["active_policy_count"].diff()
    return history


def stock_identity_errors(history: pd.DataFrame) -> dict[str, float]:
    errors: dict[str, float] = {}
    later = history.index >= 1
    for code in G_CODES:
        expected = (
            history[f"{code}_active_stock"].shift(1)
            + history[f"{code}_stock_entry"]
            - history[f"{code}_stock_exit"]
        )
        errors[f"{code}_stock_identity_max_abs_error"] = float(
            (history.loc[later, f"{code}_active_stock"] - expected.loc[later]).abs().max()
        )
    expected_count = (
        history["active_policy_count"].shift(1)
        + history["stock_entry_policy_count"]
        - history["stock_exit_policy_count"]
    )
    errors["policy_stock_identity_max_abs_error"] = float(
        (history.loc[later, "active_policy_count"] - expected_count.loc[later]).abs().max()
    )
    return errors


def write_manifest(ledger: pd.DataFrame, history: pd.DataFrame, audit: dict[str, object]) -> None:
    text = f"""# Strict-68 governance interface for trend analysis and future SD synchronization

## Scope

- Formal policy universe: exactly 68 eligible 2000-2023 full texts.
- Historical stock warm-up: 2000-2023.
- Trend-model interface: 2011-2023.
- G0 handling: {int((ledger['semantic_codable'] == 0).sum())} formal text(s) without an observable G1-G3 action remain in every formal-text denominator and contribute zero to G1-G3.

## Construction

- Publication year defines new-policy flow.
- Effective date defines stock entry; publication date/year is a fallback.
- Recorded end/replacement year is inclusive; absence of an end date means active through 2023.
- G1-G3 are document-balanced shares from the strict formal-text coding. No summary-only, interpretation-only, or non-full-text policy is present.

## Future SD handoff

The frozen SD package was intentionally not modified in V4. A future SD rerun must consume `governance_strict68_interface_2011_2023.csv` and `governance_strict68_policy_stock_events_2000_2023.csv`, record their SHA-256 values, and then recalibrate before generating scenarios.

## QA

- 68-policy sample: {audit['strict_policy_n']}.
- G-observable texts: {audit['semantic_codable_policy_n']}.
- G0 retained texts: {audit['G0_policy_n']}.
- Years: {history['year'].min()}-{history['year'].max()}.
- Maximum stock-identity error: {audit['max_stock_identity_error']:.3g}.
"""
    (CFG.TEXT_DIR / "strict68_governance_interface_manifest.md").write_text(text, encoding="utf-8")


def main() -> None:
    CFG.ensure_dirs()
    master = pd.read_csv(CFG.OUTPUT_ROOT / "policy_master_68.csv")
    summary = pd.read_csv(CFG.OUTPUT_ROOT / "policy_G_tool_summary.csv")
    ledger = build_ledger(master, summary)
    history = build_history(ledger)
    interface = history.loc[history["year"].isin(MODEL_YEARS)].copy()
    identities = stock_identity_errors(history)
    active_2023 = int(interface.loc[interface["year"].eq(2023), "active_policy_count"].iloc[0])
    audit = {
        "status": "PASS",
        "sample_universe": "strict_68_formal_full_texts",
        "strict_policy_n": int(len(ledger)),
        "semantic_codable_policy_n": int(ledger["semantic_codable"].sum()),
        "G0_policy_n": int(ledger["G0_no_observable_target_action"].sum()),
        "historical_years": [int(history["year"].min()), int(history["year"].max())],
        "interface_years": [int(interface["year"].min()), int(interface["year"].max())],
        "active_policy_count_2023": active_2023,
        "nonformal_policy_n": 0,
        "max_stock_identity_error": float(max(identities.values())),
        "stock_identity_errors": identities,
        "G0_has_zero_G_contribution": bool(
            ledger.loc[ledger["G0_no_observable_target_action"].eq(1), [f"{code}_share" for code in G_CODES]].eq(0).all().all()
        ),
        "future_SD_action": "Recalibrate and rerun from this strict-68 interface; frozen SD remains unmodified in V4.",
    }
    if (
        audit["strict_policy_n"] != 68
        or audit["nonformal_policy_n"] != 0
        or not audit["G0_has_zero_G_contribution"]
        or audit["max_stock_identity_error"] > 1e-10
    ):
        raise RuntimeError("Strict-68 governance interface QA failed")

    sample_audit = ledger[
        [
            "policy_id", "publication_year", "effective_date", "end_or_replacement_date", "phase",
            "title", "text_evidence_grade", "semantic_codable", "G0_no_observable_target_action",
            "action_unit_count_all", "g_action_unit_count", *[f"{code}_share" for code in G_CODES],
            "stock_start_year", "stock_end_year", "stock_exit_transition_year", "sample_universe", "G0_rule",
        ]
    ].copy()
    source_registry = pd.DataFrame(
        [
            {
                "artifact": "strict_formal_policy_manifest",
                "path": str(CFG.OUTPUT_ROOT / "policy_master_68.csv"),
                "sha256": CFG.sha256_bytes(CFG.OUTPUT_ROOT / "policy_master_68.csv"),
                "role": "Only policy universe for V4 governance, trend, and future SD synchronization",
            },
            {
                "artifact": "strict_action_design_summary",
                "path": str(CFG.OUTPUT_ROOT / "policy_G_tool_summary.csv"),
                "sha256": CFG.sha256_bytes(CFG.OUTPUT_ROOT / "policy_G_tool_summary.csv"),
                "role": "Document-balanced G1-G3 shares and G0 coding status",
            },
        ]
    )
    CFG.write_csv(ledger, CFG.OUTPUT_ROOT / "governance_strict68_policy_stock_events_2000_2023.csv")
    CFG.write_csv(history, CFG.OUTPUT_ROOT / "governance_strict68_history_2000_2023.csv")
    CFG.write_csv(interface, CFG.OUTPUT_ROOT / "governance_strict68_interface_2011_2023.csv")
    CFG.write_csv(sample_audit, CFG.QA_DIR / "strict68_policy_sample_audit.csv")
    CFG.write_csv(source_registry, CFG.OUTPUT_ROOT / "governance_strict68_source_registry.csv")
    CFG.write_json(audit, CFG.QA_DIR / "strict68_governance_interface_audit.json")
    write_manifest(ledger, history, audit)
    print(json.dumps(audit, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
