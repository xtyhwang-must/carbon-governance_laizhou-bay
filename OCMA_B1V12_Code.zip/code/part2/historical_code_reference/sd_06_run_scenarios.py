"""运行基线+六个政策情景、补充压力检验、排序与非线性响应面。"""

from __future__ import annotations

import json
from functools import lru_cache
from importlib import import_module
from typing import Any

import numpy as np
import pandas as pd

cfg = import_module("00_config")
model = import_module("03_sd_model")
from common import write_json


SCENARIO_LABELS = {
    "S0": "Continuation",
    "S1": "Pressure-control strengthening",
    "S2": "Habitat-restoration strengthening",
    "S3": "Adaptive-governance strengthening",
    "S4": "Integrated adaptive governance",
    "S5": "High policy supply–low implementation",
    "S6": "Water-quality–habitat co-management",
    "S8": "Out-of-support stress test",
}

SCENARIO_PROPAGATION_COUNT = 600
RESPONSE_SURFACE_PARAMETER_COUNT = 24
RESPONSE_SURFACE_GRID_SIZE = 13
POLICY_PROJECTION_BOOTSTRAP_DRAWS = 200
POLICY_FLOW_ROBUSTNESS_PARAMETER_COUNT = 50
POLICY_FLOW_ROBUSTNESS_DRAWS = 10
RANKING_EQUIVALENCE_BAND = 5e-4


def load_lever_lookup() -> tuple[dict[tuple[str, str], float], pd.DataFrame]:
    bounds = pd.read_csv(cfg.SCENARIO_BOUNDS_FILE)
    quantiles = bounds[
        bounds["row_type"].isin(
            [
                "empirical_quantile",
                "registered_prior_quantile",
                "normative_stress_bound",
            ]
        )
    ]
    lookup = {
        (row["lever"], row["setting"]): float(row["value"])
        for _, row in quantiles.iterrows()
    }
    return lookup, bounds


def scenario_settings(lookup: dict[tuple[str, str], float]) -> dict[str, dict[str, Any]]:
    def values(
        g1="P50",
        g2="P50",
        g3="P50",
        eta="P50",
        tau="P50",
        feedback="P50",
        synergy="P50",
        shock=True,
        stress=False,
    ):
        return {
            "u_G1": lookup[("u_G1", g1)],
            "u_G2": lookup[("u_G2", g2)],
            "u_G3": lookup[("u_G3", g3)],
            "eta": lookup[("eta_impl", eta)],
            "tau": lookup[("tau_impl", tau)],
            "feedback": lookup[("u_feedback", feedback)],
            "synergy": lookup[("u_synergy", synergy)],
            "shock": shock,
            "stress": stress,
            "settings": {
                "u_G1": g1,
                "u_G2": g2,
                "u_G3": g3,
                "eta_impl": eta,
                "tau_impl": tau,
                "u_feedback": feedback,
                "u_synergy": synergy,
            },
        }

    return {
        "S0": values(),
        "S1": values(g1="P75"),
        "S2": values(g2="P75"),
        "S3": values(g3="P75"),
        "S4": values(
            g1="P75",
            g2="P75",
            g3="P75",
            eta="P75",
            tau="P25",
            feedback="P75",
            synergy="P75",
        ),
        "S5": values(
            g1="P75",
            g2="P75",
            g3="P75",
            eta="P25",
            tau="P75",
            feedback="P50",
            synergy="P50",
        ),
        "S6": values(
            g1="P75",
            g2="P75",
            eta="P75",
            synergy="P75",
        ),
        "S8": values(
            g1="above_historical_max",
            g2="above_historical_max",
            g3="above_historical_max",
            eta="above_historical_max",
            tau="below_historical_min_fast_response",
            feedback="above_historical_max",
            synergy="above_historical_max",
            shock=True,
            stress=True,
        ),
    }


def map_to_unit(value: float, lower: float, upper: float) -> float:
    if upper <= lower:
        return 0.5
    return float(np.clip(0.02 + 0.96 * (value - lower) / (upper - lower), 0.02, 0.98))


@lru_cache(maxsize=1)
def policy_duration_inputs() -> tuple[
    dict[int, np.ndarray], np.ndarray, np.ndarray
]:
    """读取已知到期安排，并提取生效延迟与有效期经验分布。"""
    events = pd.read_csv(cfg.POLICY_FLOW_FILE)
    duration_frame = events[
        events["stock_start_year"].notna()
        & events["stock_end_year"].notna()
        & (events["open_ended_through_2023"] != True)
    ].copy()
    duration_frame["duration_years"] = (
        pd.to_numeric(duration_frame["stock_end_year"], errors="coerce")
        - pd.to_numeric(duration_frame["stock_start_year"], errors="coerce")
        + 1.0
    )
    duration_frame = duration_frame[duration_frame["duration_years"] >= 1.0]
    durations = np.clip(
        np.rint(duration_frame["duration_years"].to_numpy(float)),
        1,
        20,
    ).astype(int)
    if len(durations) == 0:
        raise ValueError("No empirical policy-duration observations available")
    effective_lags = np.clip(
        pd.to_numeric(
            events["publication_to_stock_entry_lag_years"], errors="coerce"
        )
        .dropna()
        .to_numpy(float),
        0,
        3,
    ).astype(int)
    if len(effective_lags) == 0:
        raise ValueError("No empirical policy effective-lag observations available")

    scheduled: dict[int, np.ndarray] = {}
    exiting = events[
        pd.to_numeric(
            events["stock_exit_transition_year"], errors="coerce"
        ).isin(cfg.SCENARIO_YEARS)
    ]
    for _, row in exiting.iterrows():
        exit_year = int(row["stock_exit_transition_year"])
        if exit_year not in cfg.SCENARIO_YEARS:
            continue
        contribution = np.nan_to_num(
            pd.to_numeric(
                pd.Series(
                    [
                        row.get("G1_share", 0.0),
                        row.get("G2_share", 0.0),
                        row.get("G3_share", 0.0),
                    ]
                ),
                errors="coerce",
            ).to_numpy(float),
            nan=0.0,
        )
        scheduled[exit_year] = (
            scheduled.get(exit_year, np.zeros(3, dtype=float)) + contribution
        )
    return scheduled, durations, effective_lags


def block_sample_sequence(
    values: np.ndarray,
    length: int,
    block_length: int,
    rng: np.random.Generator,
) -> np.ndarray:
    """从有序经验序列中按连续区块抽样，保留阶段性聚集。"""
    values = np.asarray(values)
    block = max(1, min(int(block_length), len(values)))
    sampled: list[float] = []
    while len(sampled) < length:
        last_start = max(len(values) - block, 0)
        start = int(rng.integers(0, last_start + 1))
        sampled.extend(values[start : start + block].tolist())
    return np.asarray(sampled[:length])


def empirical_climate_sequence(
    input_frame: pd.DataFrame, rng: np.random.Generator
) -> pd.DataFrame:
    hist = input_frame[["PPT", "RUNOFF", "SST"]].reset_index(drop=True)
    rows = []
    while len(rows) < len(cfg.SCENARIO_YEARS):
        start = int(rng.integers(0, max(len(hist) - 2, 1)))
        rows.extend(hist.iloc[start : start + 3].to_dict("records"))
    result = pd.DataFrame(rows[: len(cfg.SCENARIO_YEARS)])
    result.insert(0, "year", cfg.SCENARIO_YEARS)
    return result


def apply_compound_shock(
    climate: pd.DataFrame,
    input_frame: pd.DataFrame,
    intensity: float = 1.0,
) -> pd.DataFrame:
    result = climate.copy()
    historical = input_frame[["PPT", "RUNOFF", "SST", "COMPOUND"]].sort_values(
        "COMPOUND", ascending=False
    )
    worst_triplets = historical[["PPT", "RUNOFF", "SST"]].head(3).to_numpy(float)
    shock_years = [2026, 2027, 2028]
    for position, year in enumerate(shock_years):
        target = worst_triplets[position % len(worst_triplets)]
        current = result.loc[result["year"] == year, ["PPT", "RUNOFF", "SST"]].to_numpy(float)[0]
        # 保留历史联合三元组，不对单个分量作逐项max重组；否则会制造
        # 从未共同出现的“经验冲击”。
        blended = (1.0 - intensity) * current + intensity * target
        result.loc[result["year"] == year, ["PPT", "RUNOFF", "SST"]] = np.clip(
            blended, 0.02, 0.999
        )
    return result


def project_governance(
    setting: dict[str, Any],
    input_frame: pd.DataFrame,
    normalization: dict,
    bound_frame: pd.DataFrame,
    policy_flow_mode: str = "recent_median",
    rng: np.random.Generator | None = None,
    policy_block_length: int = 3,
) -> pd.DataFrame:
    final = input_frame.sort_values("year").iloc[-1]
    raw_stocks = np.array(
        [final["G1_active_stock"], final["G2_active_stock"], final["G3_active_stock"]],
        dtype=float,
    )
    recent = input_frame[input_frame["year"].between(2021, 2023)]
    (
        scheduled_existing_exits,
        empirical_durations,
        empirical_effective_lags,
    ) = policy_duration_inputs()

    horizon = len(cfg.SCENARIO_YEARS)
    if policy_flow_mode == "recent_median":
        annual_flows = np.repeat(
            float(recent["G_flow_total"].median()), horizon
        )
        annual_durations = np.repeat(
            int(np.rint(np.median(empirical_durations))), horizon
        )
        annual_effective_lags = np.repeat(
            int(np.rint(np.median(empirical_effective_lags))), horizon
        )
    elif policy_flow_mode == "empirical_block_bootstrap":
        if rng is None:
            raise ValueError("rng is required for empirical policy-flow bootstrap")
        annual_flows = block_sample_sequence(
            input_frame["G_flow_total"].to_numpy(float),
            horizon,
            policy_block_length,
            rng,
        )
        annual_durations = block_sample_sequence(
            empirical_durations,
            horizon,
            policy_block_length,
            rng,
        )
        annual_effective_lags = block_sample_sequence(
            empirical_effective_lags,
            horizon,
            policy_block_length,
            rng,
        )
    else:
        raise ValueError(f"Unknown policy_flow_mode: {policy_flow_mode}")

    p50 = np.array(
        [
            bound_frame[
                (bound_frame["row_type"] == "empirical_quantile")
                & (bound_frame["lever"] == f"u_G{i}")
                & (bound_frame["setting"] == "P50")
            ]["value"].iloc[0]
            for i in [1, 2, 3]
        ],
        dtype=float,
    )
    p75 = np.array(
        [
            bound_frame[
                (bound_frame["row_type"] == "empirical_quantile")
                & (bound_frame["lever"] == f"u_G{i}")
                & (bound_frame["setting"] == "P75")
            ]["value"].iloc[0]
            for i in [1, 2, 3]
        ],
        dtype=float,
    )
    levers = np.array([setting["u_G1"], setting["u_G2"], setting["u_G3"]])
    # u_G1—u_G3是政策构成/强度分位，直接相除会把P50→P75压缩成约
    # 3%—5%的无实质情景差。这里以P50为延续基线、P75为45%的政策流量
    # 强化，保持排序和经验支持边界；S8仍允许受控的样本外压力检验。
    standardized_shift = (levers - p50) / np.maximum(p75 - p50, 1e-6)
    flow_multiplier = np.clip(1.0 + 0.45 * standardized_shift, 0.45, 2.50)
    continuation_shares = p50 / p50.sum()
    channel_shares = continuation_shares * flow_multiplier

    rows = []
    new_policy_exits: dict[int, np.ndarray] = {}
    pending_admissions: dict[int, np.ndarray] = {}
    for position, year in enumerate(cfg.SCENARIO_YEARS):
        channel_publications = annual_flows[position] * channel_shares
        effective_lag = max(0, int(np.rint(annual_effective_lags[position])))
        admission_year = int(year + effective_lag)
        if admission_year <= cfg.SCENARIO_YEARS[-1]:
            pending_admissions[admission_year] = (
                pending_admissions.get(
                    admission_year, np.zeros(3, dtype=float)
                )
                + channel_publications
            )
        channel_admissions = pending_admissions.get(
            year, np.zeros(3, dtype=float)
        )
        prior_stocks = raw_stocks.copy()
        existing_exit_requested = scheduled_existing_exits.get(
            year, np.zeros(3, dtype=float)
        ).copy()
        new_exit_requested = new_policy_exits.get(
            year, np.zeros(3, dtype=float)
        ).copy()
        requested_exit = existing_exit_requested + new_exit_requested
        actual_exit = np.minimum(prior_stocks, requested_exit)
        exit_realization_ratio = np.divide(
            actual_exit,
            requested_exit,
            out=np.ones(3, dtype=float),
            where=requested_exit > 0,
        )
        existing_exit_actual = (
            existing_exit_requested * exit_realization_ratio
        )
        new_exit_actual = new_exit_requested * exit_realization_ratio
        exit_excess = requested_exit - actual_exit
        exit_truncated = exit_excess > 1e-12
        ending_stocks = prior_stocks + channel_admissions - actual_exit
        identity_residual = ending_stocks - (
            prior_stocks + channel_admissions - actual_exit
        )
        if (ending_stocks < -1e-12).any():
            raise AssertionError(
                f"Negative governance stock after explicit exit accounting in {year}"
            )
        raw_stocks = ending_stocks
        duration = max(1, int(np.rint(annual_durations[position])))
        expiry_year = int(admission_year + duration)
        if expiry_year <= cfg.SCENARIO_YEARS[-1]:
            new_policy_exits[expiry_year] = (
                new_policy_exits.get(expiry_year, np.zeros(3, dtype=float))
                + channel_publications
            )
        mapped = [
            raw_stocks[i] / (raw_stocks[i] + normalization[f"G{i+1}"]["K"])
            for i in range(3)
        ]
        record: dict[str, Any] = {
            "year": year,
            "G1_TARGET": mapped[0],
            "G2_TARGET": mapped[1],
            "G3_TARGET": mapped[2],
            # 保留既有聚合列；projected_policy_exit现在明确表示实际退出，
            # 请求退出及超额量由新增审计列单独报告。
            "projected_policy_flow": float(channel_publications.sum()),
            "projected_policy_admission": float(channel_admissions.sum()),
            "projected_policy_exit": float(actual_exit.sum()),
            "projected_policy_existing_exit_requested": float(
                existing_exit_requested.sum()
            ),
            "projected_policy_new_exit_requested": float(
                new_exit_requested.sum()
            ),
            "projected_policy_existing_exit_actual": float(
                existing_exit_actual.sum()
            ),
            "projected_policy_new_exit_actual": float(
                new_exit_actual.sum()
            ),
            "projected_policy_requested_exit": float(requested_exit.sum()),
            "projected_policy_exit_excess": float(exit_excess.sum()),
            "projected_policy_stock_previous": float(prior_stocks.sum()),
            "projected_policy_stock_end": float(ending_stocks.sum()),
            "projected_policy_identity_residual": float(
                identity_residual.sum()
            ),
            "projected_effective_lag": effective_lag,
            "projected_policy_duration": duration,
            "policy_flow_mode": policy_flow_mode,
        }
        for channel_index, channel in enumerate(["G1", "G2", "G3"]):
            record.update(
                {
                    f"{channel}_stock_previous": float(
                        prior_stocks[channel_index]
                    ),
                    f"{channel}_publication": float(
                        channel_publications[channel_index]
                    ),
                    f"{channel}_admission": float(
                        channel_admissions[channel_index]
                    ),
                    f"{channel}_existing_exit_requested": float(
                        existing_exit_requested[channel_index]
                    ),
                    f"{channel}_new_policy_exit_requested": float(
                        new_exit_requested[channel_index]
                    ),
                    f"{channel}_existing_exit_actual": float(
                        existing_exit_actual[channel_index]
                    ),
                    f"{channel}_new_policy_exit_actual": float(
                        new_exit_actual[channel_index]
                    ),
                    f"{channel}_exit_requested": float(
                        requested_exit[channel_index]
                    ),
                    f"{channel}_exit_actual": float(
                        actual_exit[channel_index]
                    ),
                    f"{channel}_exit_truncated": int(
                        exit_truncated[channel_index]
                    ),
                    f"{channel}_exit_excess": float(
                        exit_excess[channel_index]
                    ),
                    f"{channel}_stock_end": float(
                        ending_stocks[channel_index]
                    ),
                    f"{channel}_stock_identity_residual": float(
                        identity_residual[channel_index]
                    ),
                }
            )
        rows.append(record)
    return pd.DataFrame(rows)


def make_forcing(
    setting: dict[str, Any],
    input_frame: pd.DataFrame,
    climate: pd.DataFrame,
    normalization: dict,
    bound_frame: pd.DataFrame,
    shock_override: bool | None = None,
    shock_intensity: float = 1.0,
    policy_flow_mode: str = "recent_median",
    policy_rng: np.random.Generator | None = None,
    policy_block_length: int = 3,
) -> model.AnnualForcing:
    use_shock = setting["shock"] if shock_override is None else shock_override
    climate_used = (
        apply_compound_shock(climate, input_frame, intensity=shock_intensity)
        if use_shock
        else climate.copy()
    )
    governance = project_governance(
        setting,
        input_frame,
        normalization,
        bound_frame,
        policy_flow_mode=policy_flow_mode,
        rng=policy_rng,
        policy_block_length=policy_block_length,
    )
    future = governance.merge(climate_used, on="year", validate="one_to_one")

    eta_spec = normalization["ETA_POTENTIAL"]
    future["ETA_POTENTIAL"] = map_to_unit(
        setting["eta"], eta_spec["lower"], eta_spec["upper"]
    )
    # tau_impl在情景文件中是文本目标期限（年），不是0—1强度或已观测
    # 生态时滞；保持其年单位进入一阶治理目标调整，避免二次无量纲映射。
    future["POLICY_TAU"] = float(np.clip(setting["tau"], 0.25, 8.0))
    feedback_values = bound_frame[
        (bound_frame["lever"] == "u_feedback")
        & (
            bound_frame["row_type"].isin(
                [
                    "empirical_quantile",
                    "registered_prior_quantile",
                    "normative_stress_bound",
                ]
            )
        )
    ]
    feedback_min = float(feedback_values["historical_support_min"].dropna().iloc[0])
    feedback_max = float(feedback_values["historical_support_max"].dropna().iloc[0])
    future["FEEDBACK_STRENGTH"] = map_to_unit(
        setting["feedback"], feedback_min, feedback_max
    )
    future["SYNERGY_LEVER"] = float(setting["synergy"])

    first = input_frame.sort_values("year").iloc[-1]
    continuity = pd.DataFrame(
        [
            {
                "year": 2023,
                "G1_TARGET": first["G1"],
                "G2_TARGET": first["G2"],
                "G3_TARGET": first["G3"],
                "PPT": first["PPT"],
                "RUNOFF": first["RUNOFF"],
                "SST": first["SST"],
                "ETA_POTENTIAL": first["ETA_POTENTIAL"],
                "POLICY_TAU": 0.50,
                "FEEDBACK_STRENGTH": 0.0,
                "SYNERGY_LEVER": first["synergy_share"],
            }
        ]
    )
    forcing = pd.concat(
        [
            continuity,
            future[
                [
                    "year",
                    "G1_TARGET",
                    "G2_TARGET",
                    "G3_TARGET",
                    "PPT",
                    "RUNOFF",
                    "SST",
                    "ETA_POTENTIAL",
                    "POLICY_TAU",
                    "FEEDBACK_STRENGTH",
                    "SYNERGY_LEVER",
                ]
            ],
        ],
        ignore_index=True,
    )
    return model.AnnualForcing(forcing)


def recovery_metric(frame: pd.DataFrame) -> tuple[float, bool]:
    pre_shock = float(frame.loc[frame["year"] == 2025, "ES"].iloc[0])
    target = 0.95 * pre_shock
    post = frame[frame["year"] >= 2029].sort_values("year")
    meets = post["ES"].to_numpy(float) >= target
    # 恢复必须在首次达标后至少连续两个年度输出点保持，避免把单年反弹
    # 误判为系统恢复。若2030年才首次达标，因缺少后续确认而视为右删失。
    for index in range(max(len(meets) - 1, 0)):
        if bool(meets[index]) and bool(meets[index + 1]):
            recovery_year = float(post.iloc[index]["year"])
            return recovery_year - 2028.0, False
    return np.nan, True


def scenario_metrics(frame: pd.DataFrame) -> dict[str, float | bool]:
    final = frame.loc[frame["year"] == 2030].iloc[0]
    recovery, censored = recovery_metric(frame)
    shock_period = frame[frame["year"].between(2026, 2030)]
    return {
        "SR2030": float(final["SR"]),
        "WQ2030": float(final["WQ"]),
        "H2030": float(final["H"]),
        "ES2030": float(final["ES"]),
        "minimum_ES": float(shock_period["ES"].min()),
        "cumulative_ES_loss": float(
            np.maximum(0.0, float(frame.loc[frame["year"] == 2025, "ES"].iloc[0]) - shock_period["ES"]).sum()
        ),
        "recovery_time": recovery,
        "recovery_censored": censored,
    }


def rank_common_shock(draw_metrics: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    equivalence_band = RANKING_EQUIVALENCE_BAND
    s0 = draw_metrics[draw_metrics["scenario"] == "S0"][
        ["parameter_set_id", "SR2030"]
    ].rename(columns={"SR2030": "SR2030_S0"})
    paired = draw_metrics.merge(s0, on="parameter_set_id", validate="many_to_one")
    paired["delta_SR2030"] = paired["SR2030"] - paired["SR2030_S0"]
    aggregate = (
        paired.groupby(["scenario", "scenario_label"], as_index=False)
        .agg(
            delta_SR2030=("delta_SR2030", "median"),
            minimum_ES=("minimum_ES", "median"),
            recovery_time=("recovery_time", "median"),
            recovery_censored_probability=("recovery_censored", "mean"),
            ES2030=("ES2030", "median"),
            P_delta_SR_nonnegative=("delta_SR2030", lambda x: float(np.mean(x >= 0))),
            P_social_noninferior=(
                "delta_SR2030",
                lambda x: float(np.mean(x >= -equivalence_band)),
            ),
        )
    )
    aggregate["social_gate"] = np.where(
        aggregate["delta_SR2030"] >= -equivalence_band, "Pass", "Fail"
    )
    aggregate["recovery_time_conditional_on_recovery"] = aggregate["recovery_time"]
    aggregate["recovery_time"] = np.where(
        aggregate["recovery_censored_probability"] >= 0.5,
        np.nan,
        aggregate["recovery_time"],
    )
    eligible = aggregate[aggregate["social_gate"] == "Pass"].copy()
    eligible = eligible.sort_values(
        ["minimum_ES", "ES2030"],
        ascending=[False, False],
    )
    # 数值/实质等价带防止把小于求解器等价误差的差异解释为严格排序。
    tiers: list[int] = []
    tier = 0
    anchor_min = np.nan
    anchor_end = np.nan
    for _, row in eligible.iterrows():
        if (
            tier == 0
            or abs(float(row["minimum_ES"]) - anchor_min) > equivalence_band
            or abs(float(row["ES2030"]) - anchor_end) > equivalence_band
        ):
            tier += 1
            anchor_min = float(row["minimum_ES"])
            anchor_end = float(row["ES2030"])
        tiers.append(tier)
    eligible["decision_tier"] = tiers
    eligible["final_rank"] = eligible["decision_tier"]
    aggregate = aggregate.merge(
        eligible[
            ["scenario", "decision_tier", "final_rank"]
        ],
        on="scenario",
        how="left",
    )
    aggregate["equivalence_band"] = equivalence_band

    # 每次配对抽样均重新执行社会非劣门槛和等价层级；同属首层的情景
    # 平分该次抽样的首位概率，避免行顺序制造唯一赢家。
    winner_counts = {
        scenario: 0.0 for scenario in aggregate["scenario"]
    }
    total_draws = 0
    for _, block in paired.groupby("parameter_set_id"):
        block = block[
            block["delta_SR2030"].ge(-equivalence_band)
        ].copy()
        if block.empty:
            continue
        block = block.sort_values(
            ["minimum_ES", "ES2030"],
            ascending=[False, False],
        )
        anchor = block.iloc[0]
        first_tier = block[
            block["minimum_ES"]
            .sub(float(anchor["minimum_ES"]))
            .abs()
            .le(equivalence_band)
            & block["ES2030"]
            .sub(float(anchor["ES2030"]))
            .abs()
            .le(equivalence_band)
        ]
        shared_probability = 1.0 / len(first_tier)
        for scenario in first_tier["scenario"].astype(str):
            winner_counts[scenario] += shared_probability
        total_draws += 1
    aggregate["P_rank_1"] = aggregate["scenario"].map(
        lambda value: winner_counts.get(value, 0) / max(total_draws, 1)
    )
    return aggregate, paired


def run_main_scenarios(
    input_frame: pd.DataFrame,
    ensemble: pd.DataFrame,
    settings: dict[str, dict[str, Any]],
    normalization: dict,
    bounds: pd.DataFrame,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    # 2023观测锚定优先于历史拟合轨迹，避免把校准残差带入政策情景初值。
    observed_initial = input_frame.loc[
        input_frame["year"] == 2023, cfg.STATE_NAMES
    ].iloc[0].to_numpy(float)
    rng = np.random.default_rng(cfg.SEED + 201)
    trajectory_records = []
    metric_records = []
    ranking_records = []
    times = np.arange(2023, 2031, dtype=float)

    for _, parameter_row in ensemble.iterrows():
        parameter_set_id = parameter_row["parameter_set_id"]
        values = parameter_row[cfg.PARAMETER_NAMES].to_numpy(float)
        initial = observed_initial.copy()
        climate = empirical_climate_sequence(input_frame, rng)

        for scenario, setting in settings.items():
            forcing = make_forcing(
                setting, input_frame, climate, normalization, bounds
            )
            result = model.simulate(values, forcing, times, initial)
            result.insert(0, "scenario_label", SCENARIO_LABELS[scenario])
            result.insert(0, "scenario", scenario)
            result.insert(0, "parameter_set_id", parameter_set_id)
            trajectory_records.append(result)
            metrics = scenario_metrics(result)
            metrics.update(
                {
                    "parameter_set_id": parameter_set_id,
                    "scenario": scenario,
                    "scenario_label": SCENARIO_LABELS[scenario],
                }
            )
            metric_records.append(metrics)
            if scenario in {"S0", "S1", "S2", "S3", "S4", "S5", "S6"}:
                ranking_records.append(dict(metrics))

    trajectories = pd.concat(trajectory_records, ignore_index=True)
    metrics = pd.DataFrame(metric_records)
    ranking_draws = pd.DataFrame(ranking_records)
    return trajectories, metrics, ranking_draws


def governance_projection_ledgers(
    input_frame: pd.DataFrame,
    settings: dict[str, dict[str, Any]],
    normalization: dict,
    bounds: pd.DataFrame,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """保存主规格和政策流量自助规格的库存—流量审计台账。"""
    main_records = []
    for scenario, setting in settings.items():
        projection = project_governance(
            setting, input_frame, normalization, bounds
        )
        projection.insert(0, "scenario", scenario)
        main_records.append(projection)
    main_ledger = pd.concat(main_records, ignore_index=True)

    rng = np.random.default_rng(cfg.SEED + 251)
    bootstrap_records = []
    s0 = settings["S0"]
    for draw_id in range(1, POLICY_PROJECTION_BOOTSTRAP_DRAWS + 1):
        projection = project_governance(
            s0,
            input_frame,
            normalization,
            bounds,
            policy_flow_mode="empirical_block_bootstrap",
            rng=rng,
            policy_block_length=3,
        )
        projection.insert(0, "draw_id", draw_id)
        bootstrap_records.append(projection)
    bootstrap_ledger = pd.concat(bootstrap_records, ignore_index=True)
    return main_ledger, bootstrap_ledger


def policy_flow_robustness(
    input_frame: pd.DataFrame,
    ensemble: pd.DataFrame,
    settings: dict[str, dict[str, Any]],
    normalization: dict,
    bounds: pd.DataFrame,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """以参数集×固定自助抽样的严格交叉设计比较S0政策流量规格。"""
    observed_initial = input_frame.loc[
        input_frame["year"] == 2023, cfg.STATE_NAMES
    ].iloc[0].to_numpy(float)
    parameter_count = min(
        POLICY_FLOW_ROBUSTNESS_PARAMETER_COUNT, len(ensemble)
    )
    if parameter_count == 0:
        raise ValueError("Policy-flow robustness requires parameter sets")
    parameter_subset = ensemble.iloc[
        np.linspace(
            0,
            len(ensemble) - 1,
            parameter_count,
            dtype=int,
        )
    ].copy()
    times = np.arange(2023, 2031, dtype=float)
    records: list[dict[str, Any]] = []
    for draw_id in range(1, POLICY_FLOW_ROBUSTNESS_DRAWS + 1):
        climate_seed = cfg.SEED + 2600 + draw_id
        policy_seed = cfg.SEED + 2700 + draw_id
        climate = empirical_climate_sequence(
            input_frame, np.random.default_rng(climate_seed)
        )
        # 一个draw对应一组冻结气候和一条冻结政策自助路径；同一draw与
        # 全部参数集交叉，且每个cell中的两种政策流规格共享气候和参数。
        forcing_by_mode = {
            "recent_median": make_forcing(
                settings["S0"],
                input_frame,
                climate,
                normalization,
                bounds,
                shock_override=True,
                policy_flow_mode="recent_median",
            ),
            "empirical_block_bootstrap": make_forcing(
                settings["S0"],
                input_frame,
                climate,
                normalization,
                bounds,
                shock_override=True,
                policy_flow_mode="empirical_block_bootstrap",
                policy_rng=np.random.default_rng(policy_seed),
                policy_block_length=3,
            ),
        }
        for _, row in parameter_subset.iterrows():
            parameter_set_id = row["parameter_set_id"]
            initial = observed_initial.copy()
            pair_cell_id = f"{parameter_set_id}__{draw_id:02d}"
            for flow_mode, forcing in forcing_by_mode.items():
                result = model.simulate(
                    row[cfg.PARAMETER_NAMES].to_numpy(float),
                    forcing,
                    times,
                    initial,
                )
                metrics = scenario_metrics(result)
                metrics.update(
                    {
                        "pair_cell_id": pair_cell_id,
                        "draw_id": draw_id,
                        "parameter_set_id": parameter_set_id,
                        "policy_flow_mode": flow_mode,
                        "policy_block_length": (
                            3
                            if flow_mode
                            == "empirical_block_bootstrap"
                            else 0
                        ),
                        "climate_seed": climate_seed,
                        "policy_bootstrap_seed": (
                            policy_seed
                            if flow_mode
                            == "empirical_block_bootstrap"
                            else np.nan
                        ),
                    }
                )
                records.append(metrics)
    draws = pd.DataFrame(records)
    draws["recovery_time_capped"] = np.where(
        draws["recovery_censored"],
        3.0,
        draws["recovery_time"],
    )
    delta_metrics = [
        "WQ2030",
        "H2030",
        "ES2030",
        "minimum_ES",
        "recovery_time_capped",
    ]
    recent = draws[
        draws["policy_flow_mode"] == "recent_median"
    ][["pair_cell_id", *delta_metrics]].rename(
        columns={
            metric: f"{metric}_recent_median"
            for metric in delta_metrics
        }
    )
    draws = draws.merge(
        recent,
        on="pair_cell_id",
        how="left",
        validate="many_to_one",
    )
    for metric in delta_metrics:
        draws[f"delta_{metric}_vs_recent_median"] = (
            draws[metric] - draws[f"{metric}_recent_median"]
        )
    summary = (
        draws.groupby("policy_flow_mode", as_index=False)
        .agg(
            WQ2030=("WQ2030", "median"),
            H2030=("H2030", "median"),
            ES2030=("ES2030", "median"),
            minimum_ES=("minimum_ES", "median"),
            recovery_time_capped=("recovery_time_capped", "median"),
            recovery_censored_probability=("recovery_censored", "mean"),
            n_parameter_sets=("parameter_set_id", "nunique"),
            n_bootstrap_draws=("draw_id", "nunique"),
            paired_cells=("pair_cell_id", "nunique"),
        )
    )
    for metric in delta_metrics:
        paired_delta = (
            draws.groupby("policy_flow_mode")[
                f"delta_{metric}_vs_recent_median"
            ]
            .median()
            .to_dict()
        )
        summary[f"delta_{metric}_vs_recent_median"] = summary[
            "policy_flow_mode"
        ].map(paired_delta)
        summary[f"median_paired_delta_{metric}"] = summary[
            f"delta_{metric}_vs_recent_median"
        ]
    return draws, summary


def summarise_scenarios(
    trajectories: pd.DataFrame, metrics: pd.DataFrame
) -> tuple[pd.DataFrame, pd.DataFrame]:
    trajectory_summary = (
        trajectories.groupby(["scenario", "scenario_label", "year"])
        .agg(
            ES_q05=("ES", lambda x: np.quantile(x, 0.05)),
            ES_median=("ES", "median"),
            ES_q95=("ES", lambda x: np.quantile(x, 0.95)),
            SR_median=("SR", "median"),
            WQ_median=("WQ", "median"),
            H_median=("H", "median"),
        )
        .reset_index()
    )
    s0 = metrics[metrics["scenario"] == "S0"][
        ["parameter_set_id", "SR2030", "WQ2030", "H2030", "ES2030"]
    ].rename(
        columns={
            "SR2030": "SR2030_S0",
            "WQ2030": "WQ2030_S0",
            "H2030": "H2030_S0",
            "ES2030": "ES2030_S0",
        }
    )
    paired = metrics.merge(s0, on="parameter_set_id", validate="many_to_one")
    for state in ["SR", "WQ", "H", "ES"]:
        paired[f"delta_{state}2030"] = (
            paired[f"{state}2030"] - paired[f"{state}2030_S0"]
        )
    summary = (
        paired.groupby(["scenario", "scenario_label"], as_index=False)
        .agg(
            delta_SR2030=("delta_SR2030", "median"),
            delta_WQ2030=("delta_WQ2030", "median"),
            delta_H2030=("delta_H2030", "median"),
            delta_ES2030=("delta_ES2030", "median"),
            minimum_ES=("minimum_ES", "median"),
            recovery_time=("recovery_time", "median"),
            recovery_censored_probability=("recovery_censored", "mean"),
            P_ES_above_S0=(
                "delta_ES2030",
                lambda x: float(
                    np.mean(x > RANKING_EQUIVALENCE_BAND)
                ),
            ),
            P_ES_equivalent_to_S0=(
                "delta_ES2030",
                lambda x: float(
                    np.mean(
                        np.abs(x)
                        <= RANKING_EQUIVALENCE_BAND
                    )
                ),
            ),
        )
    )
    summary["recovery_time_conditional_on_recovery"] = summary["recovery_time"]
    summary["recovery_time"] = np.where(
        summary["recovery_censored_probability"] >= 0.5,
        np.nan,
        summary["recovery_time"],
    )
    return trajectory_summary, summary


def governance_synergy(
    metric_frame: pd.DataFrame, comparison_context: str
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """计算综合政策包相对三个单通道变化之和的条件溢价。"""
    required = ["S0", "S1", "S2", "S3", "S4"]
    pivot = metric_frame[
        metric_frame["scenario"].isin(required)
    ].pivot(index="parameter_set_id", columns="scenario", values="ES2030")
    missing = sorted(set(required) - set(pivot.columns))
    if missing:
        raise ValueError(f"Cannot calculate governance synergy; missing {missing}")
    pivot = pivot.dropna(subset=required).copy()
    pivot["governance_synergy_ES2030"] = (
        (pivot["S4"] - pivot["S0"])
        - (
            (pivot["S1"] - pivot["S0"])
            + (pivot["S2"] - pivot["S0"])
            + (pivot["S3"] - pivot["S0"])
        )
    )
    draw_level = (
        pivot.reset_index()[
            ["parameter_set_id", "governance_synergy_ES2030"]
        ]
        .assign(comparison_context=comparison_context)
    )
    draw_level["estimand_label"] = "integrated_bundle_premium_not_pure_synergy"
    values = draw_level["governance_synergy_ES2030"].to_numpy(float)
    summary = pd.DataFrame(
        [
            {
                "comparison_context": comparison_context,
                "metric": "Integrated governance bundle premium in ES2030",
                "estimand_label": (
                    "conditional non-additivity; not a pure synergy coefficient"
                ),
                "formula": (
                    "(ES_S4-ES_S0)-[(ES_S1-ES_S0)+(ES_S2-ES_S0)"
                    "+(ES_S3-ES_S0)]"
                ),
                "q05": float(np.quantile(values, 0.05)),
                "median": float(np.median(values)),
                "q95": float(np.quantile(values, 0.95)),
                "P_positive": float(np.mean(values > 0.0)),
                "n_parameter_sets": int(len(values)),
            }
        ]
    )
    return draw_level, summary


def response_surface(
    input_frame: pd.DataFrame,
    ensemble: pd.DataFrame,
    settings: dict[str, dict[str, Any]],
    normalization: dict,
    bounds: pd.DataFrame,
) -> pd.DataFrame:
    observed_initial = input_frame.loc[
        input_frame["year"] == 2023, cfg.STATE_NAMES
    ].iloc[0].to_numpy(float)
    subset_count = min(RESPONSE_SURFACE_PARAMETER_COUNT, len(ensemble))
    subset = ensemble.iloc[
        np.linspace(0, len(ensemble) - 1, subset_count, dtype=int)
    ].copy()
    rng = np.random.default_rng(cfg.SEED + 301)
    climate = empirical_climate_sequence(input_frame, rng)
    times = np.arange(2023, 2031, dtype=float)
    grid = np.linspace(0.0, 1.0, RESPONSE_SURFACE_GRID_SIZE)
    lookup, _ = load_lever_lookup()
    rows = []
    for governance_intensity in grid:
        custom = dict(settings["S0"])
        custom["settings"] = dict(settings["S0"]["settings"])
        for lever in ["u_G1", "u_G2", "u_G3", "eta_impl", "u_feedback", "u_synergy"]:
            key = "eta" if lever == "eta_impl" else (
                "feedback" if lever == "u_feedback" else (
                    "synergy" if lever == "u_synergy" else lever
                )
            )
            start = lookup[(lever, "P50")]
            end = lookup[(lever, "P90")]
            custom[key] = start + governance_intensity * (end - start)
        custom["tau"] = lookup[("tau_impl", "P50")] + governance_intensity * (
            lookup[("tau_impl", "P25")] - lookup[("tau_impl", "P50")]
        )
        for disturbance_intensity in grid:
            values_min = []
            values_end = []
            for _, row in subset.iterrows():
                parameter_set_id = row["parameter_set_id"]
                initial = observed_initial.copy()
                forcing = make_forcing(
                    custom,
                    input_frame,
                    climate,
                    normalization,
                    bounds,
                    shock_override=True,
                    shock_intensity=float(disturbance_intensity),
                )
                result = model.simulate(
                    row[cfg.PARAMETER_NAMES].to_numpy(float),
                    forcing,
                    times,
                    initial,
                )
                metric = scenario_metrics(result)
                values_min.append(metric["minimum_ES"])
                values_end.append(metric["ES2030"])
            rows.append(
                {
                    "governance_intensity": governance_intensity,
                    "disturbance_intensity": disturbance_intensity,
                    "minimum_ES_q05": np.quantile(values_min, 0.05),
                    "minimum_ES_median": np.median(values_min),
                    "minimum_ES_q95": np.quantile(values_min, 0.95),
                    "ES2030_q05": np.quantile(values_end, 0.05),
                    "ES2030_median": np.median(values_end),
                    "ES2030_q95": np.quantile(values_end, 0.95),
                    "n_parameter_sets": len(subset),
                }
            )
    surface = pd.DataFrame(rows)
    pivot = surface.pivot(
        index="disturbance_intensity",
        columns="governance_intensity",
        values="minimum_ES_median",
    )
    gy, gx = np.gradient(pivot.to_numpy(float), grid, grid)
    magnitude = np.sqrt(gx**2 + gy**2)
    gradient_long = (
        pd.DataFrame(
            magnitude,
            index=pivot.index,
            columns=pivot.columns,
        )
        .stack()
        .rename("transition_gradient")
        .reset_index()
    )
    surface = surface.merge(
        gradient_long,
        on=["disturbance_intensity", "governance_intensity"],
        validate="one_to_one",
    )
    threshold = float(surface["transition_gradient"].quantile(0.90))
    surface["transition_zone"] = surface["transition_gradient"] >= threshold
    return surface


def main() -> None:
    input_frame = pd.read_csv(cfg.DATA_DIR / "model_input_2011_2023.csv")
    accepted_ensemble = pd.read_csv(
        cfg.MODELS_DIR / "accepted_parameter_ensemble.csv"
    )
    propagation_count = min(SCENARIO_PROPAGATION_COUNT, len(accepted_ensemble))
    ensemble = accepted_ensemble.iloc[
        np.linspace(
            0,
            len(accepted_ensemble) - 1,
            propagation_count,
            dtype=int,
        )
    ].copy()
    normalization = json.loads(
        (cfg.INTERMEDIATE_DIR / "normalization_parameters.json").read_text(
            encoding="utf-8"
        )
    )
    lookup, bounds = load_lever_lookup()
    settings = scenario_settings(lookup)
    write_json(cfg.INTERMEDIATE_DIR / "scenario_settings_resolved.json", settings)
    main_policy_ledger, bootstrap_policy_ledger = governance_projection_ledgers(
        input_frame, settings, normalization, bounds
    )
    main_policy_ledger.to_csv(
        cfg.RESULTS_DIR / "scenario_governance_projection.csv", index=False
    )
    bootstrap_policy_ledger.to_csv(
        cfg.INTERMEDIATE_DIR
        / "s0_policy_projection_bootstrap_ledger.csv",
        index=False,
    )

    trajectories, metrics, ranking_draws = run_main_scenarios(
        input_frame, ensemble, settings, normalization, bounds
    )
    trajectories.to_csv(cfg.RESULTS_DIR / "scenario_trajectories_long.csv", index=False)
    metrics.to_csv(cfg.RESULTS_DIR / "scenario_metrics_by_parameter_set.csv", index=False)
    ranking_draws.to_csv(
        cfg.RESULTS_DIR / "common_shock_ranking_draws.csv", index=False
    )

    trajectory_summary, scenario_summary = summarise_scenarios(trajectories, metrics)
    trajectory_summary.to_csv(
        cfg.RESULTS_DIR / "scenario_trajectory_summary.csv", index=False
    )
    trajectory_summary[
        trajectory_summary["scenario"].isin(
            ["S0", "S1", "S2", "S3", "S4", "S5", "S6"]
        )
    ].to_csv(
        cfg.RESULTS_DIR / "common_shock_trajectory_summary.csv",
        index=False,
    )
    scenario_summary.to_csv(cfg.RESULTS_DIR / "scenario_outcome_summary.csv", index=False)

    ranking, paired = rank_common_shock(ranking_draws)
    ranking.to_csv(cfg.RESULTS_DIR / "resilience_scenario_ranking.csv", index=False)
    paired.to_csv(cfg.INTERMEDIATE_DIR / "resilience_ranking_paired.csv", index=False)

    synergy_common_draws, synergy_common = governance_synergy(
        ranking_draws, "common compound disturbance"
    )
    synergy_common_draws.to_csv(
        cfg.INTERMEDIATE_DIR / "governance_synergy_by_parameter_set.csv",
        index=False,
    )
    synergy_summary = synergy_common.copy()
    synergy_summary.to_csv(
        cfg.RESULTS_DIR / "governance_synergy_summary.csv", index=False
    )

    policy_draws, policy_summary = policy_flow_robustness(
        input_frame, ensemble, settings, normalization, bounds
    )
    policy_draws.to_csv(
        cfg.INTERMEDIATE_DIR / "policy_flow_robustness_draws.csv",
        index=False,
    )
    policy_summary.to_csv(
        cfg.RESULTS_DIR / "policy_flow_robustness_summary.csv",
        index=False,
    )

    surface = response_surface(
        input_frame, ensemble, settings, normalization, bounds
    )
    surface.to_csv(cfg.RESULTS_DIR / "nonlinear_response_surface.csv", index=False)

    expected_scenarios = set(SCENARIO_LABELS)
    expected_ranking_scenarios = {
        "S0", "S1", "S2", "S3", "S4", "S5", "S6"
    }
    propagated_parameter_sets = int(
        trajectories["parameter_set_id"].nunique()
    )
    scenario_parameter_counts = metrics.groupby("scenario")[
        "parameter_set_id"
    ].nunique()
    ranking_parameter_counts = ranking_draws.groupby("scenario")[
        "parameter_set_id"
    ].nunique()

    governance_ledgers = pd.concat(
        [
            main_policy_ledger.assign(ledger_specification="main"),
            bootstrap_policy_ledger.assign(
                ledger_specification="bootstrap"
            ),
        ],
        ignore_index=True,
    )
    identity_columns = [
        f"{channel}_stock_identity_residual"
        for channel in ["G1", "G2", "G3"]
    ]
    excess_columns = [
        f"{channel}_exit_excess"
        for channel in ["G1", "G2", "G3"]
    ]
    truncated_columns = [
        f"{channel}_exit_truncated"
        for channel in ["G1", "G2", "G3"]
    ]
    governance_identity_max_abs = float(
        governance_ledgers[identity_columns].abs().to_numpy(float).max()
    )
    governance_exit_excess_max = float(
        governance_ledgers[excess_columns].abs().to_numpy(float).max()
    )
    governance_exit_truncation_count = int(
        governance_ledgers[truncated_columns].to_numpy(int).sum()
    )

    policy_pair_counts = policy_draws.groupby("pair_cell_id").agg(
        mode_count=("policy_flow_mode", "nunique"),
        row_count=("policy_flow_mode", "size"),
    )
    policy_paired_cells = int(len(policy_pair_counts))
    policy_pairing_complete = bool(
        policy_paired_cells >= 500
        and policy_pair_counts["mode_count"].eq(2).all()
        and policy_pair_counts["row_count"].eq(2).all()
        and policy_draws["parameter_set_id"].nunique()
        >= POLICY_FLOW_ROBUSTNESS_PARAMETER_COUNT
        and policy_draws["draw_id"].nunique()
        >= POLICY_FLOW_ROBUSTNESS_DRAWS
    )
    paired_delta_columns = [
        f"median_paired_delta_{metric}"
        for metric in [
            "WQ2030",
            "H2030",
            "ES2030",
            "minimum_ES",
            "recovery_time_capped",
        ]
    ]

    required_output_files = [
        cfg.RESULTS_DIR / "scenario_governance_projection.csv",
        cfg.RESULTS_DIR / "scenario_trajectories_long.csv",
        cfg.RESULTS_DIR / "common_shock_trajectory_summary.csv",
        cfg.RESULTS_DIR / "scenario_metrics_by_parameter_set.csv",
        cfg.RESULTS_DIR / "common_shock_ranking_draws.csv",
        cfg.RESULTS_DIR / "resilience_scenario_ranking.csv",
        cfg.RESULTS_DIR / "governance_synergy_summary.csv",
        cfg.RESULTS_DIR / "policy_flow_robustness_summary.csv",
        cfg.RESULTS_DIR / "nonlinear_response_surface.csv",
        cfg.INTERMEDIATE_DIR / "policy_flow_robustness_draws.csv",
    ]
    social_fields = {
        "delta_SR2030",
        "social_gate",
        "decision_tier",
        "final_rank",
    }
    synergy_contexts = set(synergy_summary["comparison_context"])
    checks = {
        "accepted_parameter_sets_at_least_500": bool(
            len(accepted_ensemble) >= 500
        ),
        "scenario_parameter_propagation_at_least_500": bool(
            propagated_parameter_sets >= 500
            and not scenario_parameter_counts.empty
            and scenario_parameter_counts.min() >= 500
        ),
        "all_main_scenarios_present": bool(
            set(trajectories["scenario"]) == expected_scenarios
            and set(metrics["scenario"]) == expected_scenarios
        ),
        "all_ranking_scenarios_present_and_paired": bool(
            set(ranking_draws["scenario"])
            == expected_ranking_scenarios
            and not ranking_parameter_counts.empty
            and ranking_parameter_counts.nunique() == 1
            and ranking_parameter_counts.min() >= 500
        ),
        "first_tier_probability_coherent": bool(
            ranking["P_rank_1"].between(0.0, 1.0).all()
            and np.isclose(
                ranking["P_rank_1"].sum(),
                1.0,
                atol=1e-10,
            )
        ),
        "social_constraint_fields_present": bool(
            social_fields.issubset(ranking.columns)
            and ranking["social_gate"].isin(["Pass", "Fail"]).all()
            and ranking["social_gate"].eq("Pass").any()
        ),
        "governance_ledger_identity_pass": bool(
            governance_identity_max_abs <= 1e-10
        ),
        "governance_ledger_no_exit_truncation": bool(
            governance_exit_excess_max <= 1e-10
            and governance_exit_truncation_count == 0
        ),
        "policy_flow_pairing_at_least_500": policy_pairing_complete,
        "policy_flow_paired_delta_summary_present": bool(
            set(paired_delta_columns).issubset(policy_summary.columns)
            and policy_summary[paired_delta_columns]
            .apply(np.isfinite)
            .all()
            .all()
        ),
        "response_surface_complete": bool(
            len(surface)
            == RESPONSE_SURFACE_GRID_SIZE**2
            and {
                "transition_gradient",
                "transition_zone",
                "minimum_ES_median",
                "ES2030_median",
            }.issubset(surface.columns)
            and surface["n_parameter_sets"].min() > 0
        ),
        "synergy_outputs_complete": bool(
            synergy_contexts == {"common compound disturbance"}
            and not synergy_common_draws.empty
        ),
        "required_scenario_files_exist": bool(
            all(path.exists() and path.stat().st_size > 0 for path in required_output_files)
        ),
        "stress_test_excluded_from_main_ranking": bool(
            "S8" not in set(ranking_draws["scenario"])
        ),
    }
    failed_checks = [
        name for name, passed in checks.items() if not passed
    ]
    truncation_check = "governance_ledger_no_exit_truncation"
    hard_failed_checks = [
        name for name in failed_checks if name != truncation_check
    ]
    if hard_failed_checks:
        qa_status = "FAIL"
    elif truncation_check in failed_checks:
        # 已知到期请求超过可用库存时保留完整超额记录，不以截断制造守恒
        # 假象；该情形需要人工核查版本族和库存口径，因此标记REVIEW。
        qa_status = "REVIEW"
    else:
        qa_status = "PASS"
    qa = {
        "parameter_sets": int(len(ensemble)),
        "accepted_parameter_sets_total": int(len(accepted_ensemble)),
        "propagated_parameter_sets": propagated_parameter_sets,
        "main_scenarios": sorted(set(metrics["scenario"])),
        "ranking_scenarios": sorted(set(ranking_draws["scenario"])),
        "paired_common_shock": checks[
            "all_ranking_scenarios_present_and_paired"
        ],
        "social_constraint": cfg.RANKING_RULE["social_constraint"],
        "social_constraint_fields": sorted(
            social_fields.intersection(ranking.columns)
        ),
        "ranking_method": cfg.RANKING_RULE["method"],
        "ranking_equivalence_band": 5e-4,
        "stress_test_in_main_ranking": "S8"
        in set(ranking_draws["scenario"]),
        "synergy_formula": (
            "(ES_S4-ES_S0)-[(ES_S1-ES_S0)+(ES_S2-ES_S0)"
            "+(ES_S3-ES_S0)]"
        ),
        "synergy_common_shock_median": float(
            synergy_common.iloc[0]["median"]
        ),
        "policy_flow_main_specification": "recent_median",
        "policy_flow_robustness_specification": (
            "empirical_block_bootstrap"
        ),
        "policy_flow_robustness_parameter_sets": int(
            policy_summary["n_parameter_sets"].min()
        ),
        "policy_flow_robustness_bootstrap_draws": int(
            policy_draws["draw_id"].nunique()
        ),
        "policy_flow_robustness_paired_cells": policy_paired_cells,
        "policy_flow_robustness_pairing_complete": policy_pairing_complete,
        "policy_projection_bootstrap_draws": (
            POLICY_PROJECTION_BOOTSTRAP_DRAWS
        ),
        "governance_identity_max_abs": governance_identity_max_abs,
        "governance_exit_excess_max": governance_exit_excess_max,
        "governance_exit_truncation_count": (
            governance_exit_truncation_count
        ),
        "surface_grid_points": int(len(surface)),
        "surface_parameter_sets_per_point": int(surface["n_parameter_sets"].iloc[0]),
        "qa_checks": checks,
        "failed_checks": failed_checks,
        "hard_failed_checks": hard_failed_checks,
        "status": qa_status,
    }
    write_json(cfg.QA_DIR / "scenario_qa.json", qa)
    if qa_status == "FAIL":
        raise AssertionError(
            "Scenario QA failed: " + ", ".join(hard_failed_checks)
        )
    if qa_status == "REVIEW":
        print(
            "Scenario QA requires review: nonzero requested-exit "
            "truncation/excess is retained in the governance ledger."
        )
    print("Scenario simulation and resilience ranking completed.")


if __name__ == "__main__":
    main()
