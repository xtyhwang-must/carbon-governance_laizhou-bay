"""Frozen HT share bridge; dates, raw observations and text proxies stay distinct."""
from pathlib import Path
import hashlib,json
import pandas as pd,numpy as np,yaml
ROOT=Path(__file__).resolve().parents[1];P=ROOT/'02_policy/reconstructed';SRC=ROOT/'01_sources/part1_current'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(df,p):p.parent.mkdir(parents=True,exist_ok=True);df.to_csv(p,index=False,encoding='utf-8-sig',float_format='%.15g')
def main():
 contract=yaml.safe_load((ROOT/'00_contract/baseline_contract.yaml').read_text('utf8'));K=contract['policy']['K']
 ht=pd.read_csv(SRC/'G_POLICY_DESCRIPTIVE_68.csv');dates=pd.read_csv(P/'policy_validity_decisions.csv');old=pd.read_csv(P/'policy_function_shares_B1.csv')
 assert len(ht)==len(dates)==68 and ht.policy_id.is_unique and dates.policy_id.is_unique
 joined=dates.merge(ht,on='policy_id',validate='one_to_one');assert set(old.policy_id)==set(ht.policy_id)
 vals=ht[[g+'_HT_share' for g in K]].to_numpy(float);assert np.isfinite(vals).all() and (vals>=0).all() and np.allclose(vals.sum(1),1)
 # No fabricated clause counts: only policy-level composition is passed downstream.
 shares=joined[['policy_id','publication_year']].copy()
 for g in K:shares[g+'_share']=joined[g+'_HT_share']
 shares['coding_origin']='FROZEN_PART1_POST_AUDIT_HT_COMPOSITION';shares['author_review_status']='AUTHOR_ADOPTED_PART1';shares['policy_composition_defined']=True
 write(shares,P/'policy_function_shares_HT.csv')
 risk=pd.read_csv(P/'risk_signal_policy_summary_B1.csv').set_index('policy_id');relations=pd.read_csv(P/'relation_events_B1.csv')
 # Reuse dated, locatable text proxies; no use of old network node/edge/centrality results.
 import build_policy_interface as bridge
 common,legacy=bridge.load_legacy_kernels()
 rows=[];exp=[];annual=[]
 for y in range(2000,2031):
  active=joined[joined.independent_stock_policy & joined.stock_start_year.le(y) & joined.future_exposure_end_year.ge(y)]
  entry=joined[joined.independent_stock_policy & joined.stock_start_year.eq(y)];exit_=joined[joined.independent_stock_policy & joined.stock_exit_transition_year.eq(y)]
  for r in joined.itertuples():exp.append(dict(policy_id=r.policy_id,year=y,active=bool(r.independent_stock_policy and r.stock_start_year<=y<=r.future_exposure_end_year),independent_stock_policy=bool(r.independent_stock_policy),start_rule=r.start_rule,end_rule=r.end_rule))
  a={'year':y,'active_policy_count':len(active)}
  for g in K:
   n=float(active[g+'_HT_share'].sum());ent=float(entry[g+'_HT_share'].sum());ex=float(exit_[g+'_HT_share'].sum())
   rows.append(dict(year=y,channel=g,active_formal_policy_count=len(active),active_valid_policy_stock=n,new_effective_admissions=ent,exits_at_transition=ex,stock_K=K[g],G_observed_supply=n/(n+K[g]),active_policy_ids='|'.join(active.policy_id),annual_exposure_status='HT_WEIGHTED_FIXED_DATE_LEDGER'))
   a[g+'_active_stock']=n;a[g]=n/(n+K[g])
  selected=risk.reindex(active.policy_id)
  if len(active) and selected.explicit_governance_response_proxy_present.isna().any():raise ValueError('Missing located proxy')
  a['eta_raw']=float(selected.explicit_governance_response_proxy_present.sum()/len(active)) if len(active) else 0.
  a['feedback_raw']=float(selected.explicit_feedback_signal_present.sum()/len(active)) if len(active) else 0.
  rel=relations[relations.policy_id.isin(active.policy_id)];weight=rel.institutional_collaboration_event_weight
  joint=rel[rel.relation_type.eq('observed_joint_issuance')].policy_id.nunique()/len(active) if len(active) else 0.
  vert=rel.loc[rel.relation_type.eq('vertical_administrative_linkage'),'institutional_collaboration_event_weight'].sum()/weight.sum() if weight.sum()>0 else 0.
  a['synergy_raw']=float(np.sqrt(joint*vert));annual.append(a)
 stock=pd.DataFrame(rows);err=[]
 for g,z in stock.groupby('channel'):
  v=z.active_valid_policy_stock.to_numpy();delta=v[1:]-v[:-1]-z.new_effective_admissions.to_numpy()[1:]+z.exits_at_transition.to_numpy()[1:];err.append(float(abs(delta).max()))
 assert max(err)<1e-10
 write(stock,P/'policy_stock_by_year_B1.csv');write(pd.DataFrame(exp),P/'policy_exposure_2000_2030_B1.csv')
 a=pd.DataFrame(annual);write(a,P/'annual_policy_interface_2000_2030_HT.csv');a=a[a.year.between(2011,2023)].reset_index(drop=True)
 a['ETA_POTENTIAL']=common.calibration_scaler(a.eta_raw,a.year.le(2020))[0].to_numpy(float);a['SYNERGY_LEVER']=a.synergy_raw;a['synergy_share']=a.synergy_raw
 write(a,P/'annual_policy_interface_B1.csv')
 quant=[]
 for name in ['eta_raw','feedback_raw','synergy_raw','ETA_POTENTIAL','G1','G2','G3']:
  z=a[name];quant.append(dict(interface=name,source_years='2011-2023',P25=z.quantile(.25),P50=z.quantile(.5),P75=z.quantile(.75),min=z.min(),max=z.max(),degenerate_P75_P50=bool(np.isclose(z.quantile(.75),z.quantile(.5)))))
 write(pd.DataFrame(quant),P/'interface_quantiles_B1.csv')
 proxy=pd.DataFrame([dict(interface=n,identity=i,source=s) for n,i,s in [('G1_G2_G3','FIXED_FRAME_POST_AUDIT_HT_SHARE_WEIGHTED_FORMAL_STOCK','G_POLICY_DESCRIPTIVE_68.csv + frozen dates'),('eta','LOCATED_RESPONSE_TEXT_PROXY_NOT_MEASURED_IMPLEMENTATION','risk_signal_policy_summary_B1.csv'),('feedback','LOCATED_FEEDBACK_TEXT_PROXY_NOT_IDENTIFIED_EFFECT','risk_signal_policy_summary_B1.csv'),('synergy','CONDITIONAL_RELATION_DECLARATION_PROXY_NOT_REVALIDATED_NETWORK','relation_events_B1.csv')]])
 write(proxy,P/'interface_evidence_identity.csv')
 (P/'HT_bridge_status.json').write_text(json.dumps(dict(complete=True,policies=68,independent_stock_policies=int(joined.independent_stock_policy.sum()),stock_identity_max=max(err),ht_sha256=sha(SRC/'G_POLICY_DESCRIPTIVE_68.csv'),dates_sha256=sha(P/'policy_validity_decisions.csv'),proxy_identity='REUSED_LOCATED_TEXT_AND_CONDITIONAL_RELATION_PROXY',T2_required=False),indent=2),'utf8')
 # Explicit source completeness follows current status; do not assert all texts complete.
 write(ht[['policy_id','source_category','source_unresolved_spans','full_policy_body_validated']],P/'current_source_status.csv')
 print('HT bridge:68 policies,67 independent stock sources; stock identity',max(err))
if __name__=='__main__':main()
