from pathlib import Path
import pandas as pd,numpy as np,json
R=Path(__file__).resolve().parents[1];O=R/'07_publication';T=O/'tables';T.mkdir(exist_ok=True)
def rd(rel):return pd.read_csv(R/rel)
ass=rd('06_runs/ses/associations_and_sensitivities.csv');tr=rd('06_runs/ses/state_trends_and_endpoints.csv')
frames={
 'Table3':tr[tr.state.isin(['G','SR','ES'])],
 'Table4':ass[(ass.state_a=='G')&(ass.state_b=='ES')&(ass['mode']=='level')],
 'TableS2':rd('04_model/equation_registry.csv'),
 'TableS3':ass,
 'TableS4':rd('07_publication/Table_S4_parameter_summary.csv'),
 'TableS6':rd('06_runs/formal_main/attribution/shapley_summary.csv'),
 'TableS15':rd('07_publication/Table_S15_model_vs_baselines.csv'),
 'Structures':rd('06_runs/structure_compare/internal_fold_structure_scores.csv'),
 'Five_seed_fits':rd('06_runs/formal_main/calibration/five_seed_fit_summary.csv'),
 'Candidate_screen':rd('06_runs/formal_main/calibration/candidate_source_screen.csv'),
 'Scenarios':rd('06_runs/formal_main/scenarios/scenario_summary.csv'),
 'Paired_scenarios':rd('06_runs/formal_main/scenarios/all_pair_tolerance_summary.csv'),
 'Retrospective':rd('06_runs/formal_main/evaluation/retrospective_state_summary.csv'),
 'Parameter_coverage':rd('06_runs/formal_main/evaluation/pure_parameter_coverage.csv'),
 'Numerical_QA':rd('06_runs/formal_main/qa/paired_step_size_audit.csv')}
rob=rd('06_runs/formal_main/robustness/robustness_metrics_by_vector.csv');extra=rd('06_runs/formal_main/additional_sensitivity/all_additional_metrics.csv');sens=pd.concat([rob,extra],ignore_index=True).groupby('specification_id').agg(parameter_sets=('parameter_set_id','nunique'),climate_paths=('forcing_draw_id','nunique'),scenario_cells=('scenario','size')).reset_index();sens['identity']=np.where(sens.specification_id.str.contains('REFIT'),'LIMITED_REFITTED_POINT','FIXED_PARAMETER_DYNAMICS');report=rd('06_runs/formal_main/robustness/reporting_only_metrics.csv').groupby('specification_id').agg(parameter_sets=('parameter_set_id','nunique'),climate_paths=('forcing_draw_id','nunique'),scenario_cells=('scenario','size')).reset_index();report['identity']='REPORTING_ONLY_REUSED_TRAJECTORIES';frames['TableS5']=pd.concat([sens,report],ignore_index=True)
frames['Table1']=rd('03_indicators/indicator_dictionary.csv') if (R/'03_indicators/indicator_dictionary.csv').exists() else rd('03_indicators/indicator_lineage.csv').drop_duplicates('state_id')[['state_id','raw_unit','transformation','evidence_type']]
# Include S1 variable/lineage and current policy interface evidence without making a second competing input.
frames['TableS1']=frames['Table1'].copy()
payload=[]
for name,f in frames.items():
 p=T/(name+'_source.csv');f.to_csv(p,index=False,encoding='utf-8-sig');data=[f.columns.tolist()]+f.astype(object).where(pd.notnull(f),None).values.tolist();payload.append(dict(name=name,source=str(p.resolve()),rows=data))
(O/'tables_payload.json').write_text(json.dumps(payload,ensure_ascii=False,allow_nan=False),'utf8');print('Tables',len(payload))
