"""Execute cache failure modes without touching the frozen OCMA run."""
from pathlib import Path
import tempfile
import pandas as pd
from cache_safety import ChunkCache, signature


def main(output: Path):
    rows = []
    with tempfile.TemporaryDirectory() as root_string:
        root = Path(root_string)
        code = root / 'engine.py'
        config = root / 'contract.yaml'
        source = root / 'input.csv'
        code.write_text('result = 1\n', encoding='utf-8')
        config.write_text('tau: 2\n', encoding='utf-8')
        source.write_text('year,value\n2024,0.5\n', encoding='utf-8')

        def make(values):
            key, material = signature([code, config, source], {'parameter_set_id': 'P001',
                                                       'parameter_values': values,
                                                       'input_hash': 'source_A'}, root=root)
            return ChunkCache(root / 'cache', key, material)

        base = make([0.2, 0.4])
        data = pd.DataFrame({'cache_row_id': ['P001:2024', 'P001:2025'],
                             'year': [2024, 2025], 'ES': [0.2, 0.3]})
        spec = ('scenario', data.cache_row_id.tolist(), ['cache_row_id', 'year', 'ES'])
        rows.append({'case': 'new_generation_not_complete', 'pass': not base.complete.exists()})
        base.commit(*[spec[0], data, spec[1], spec[2]])
        rows.append({'case': 'interruption_before_complete', 'pass': not base.complete.exists() and base.load(*spec) is not None})
        base.finalize([spec])
        rows.append({'case': 'complete_after_verified_chunk', 'pass': base.complete.exists()})
        rows.append({'case': 'unchanged_dependencies_reuse', 'pass': make([0.2, 0.4]).load(*spec) is not None})

        code.write_text('result = 2\n', encoding='utf-8')
        newer = make([0.2, 0.4])
        rows.append({'case': 'code_change_invalidates', 'pass': newer.path != base.path and newer.load(*spec) is None})
        code.write_text('result = 1\n', encoding='utf-8')
        config.write_text('tau: 3\n', encoding='utf-8')
        newer = make([0.2, 0.4])
        rows.append({'case': 'config_change_invalidates', 'pass': newer.path != base.path and newer.load(*spec) is None})
        config.write_text('tau: 2\n', encoding='utf-8')
        newer = make([0.2, 0.5])
        rows.append({'case': 'same_id_changed_vector_invalidates', 'pass': newer.path != base.path and newer.load(*spec) is None})

        source.write_text('year,value\n2024,0.6\n', encoding='utf-8')
        newer = make([0.2, 0.4])
        rows.append({'case': 'source_data_change_invalidates', 'pass': newer.path != base.path and newer.load(*spec) is None})
        source.write_text('year,value\n2024,0.5\n', encoding='utf-8')

        data_path, _ = base.chunk_paths('scenario')
        data_path.write_text('cache_row_id,year,ES\nP001:2024,2024,0.9\nP001:2025,2025,0.8\n', encoding='utf-8')
        rows.append({'case': 'tampered_chunk_rejected', 'pass': base.load(*spec) is None})
        # A valid old COMPLETE file cannot authorize a corrupted chunk.
        rows.append({'case': 'complete_cannot_override_bad_chunk', 'pass': base.complete.exists() and base.load(*spec) is None})

    result = pd.DataFrame(rows)
    output.parent.mkdir(parents=True, exist_ok=True)
    result.to_csv(output, index=False, encoding='utf-8-sig')
    if not result['pass'].all():
        raise AssertionError(result.loc[~result['pass']].to_string(index=False))
    print(f'{len(result)} cache cases passed')


if __name__ == '__main__':
    main(Path(__file__).resolve().parent / 'cache_dependency_test.csv')
