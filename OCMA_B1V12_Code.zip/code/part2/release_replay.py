"""Light independent replay of released inputs, best history, seven scenarios and summary."""
from __future__ import annotations
import json,sys
from pathlib import Path
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'05_code/engine'),str(ROOT/'05_code')]
import sd_model as model
import engine_config as cfg
from numeric_analysis import one_scenario,load_settings,climate_path

def main():
    frame=pd.read_csv(ROOT/'03_indicators/model_input_B1.csv').sort_values('year')
    assert frame.input_complete.all() and len(frame)==13
    best=json.loads((ROOT/'06_runs/B1_v1_1/calibration/best_parameter_set.json').read_text(encoding='utf-8'))['parameters']
    history=model.simulate(best,model.historical_forcing(frame),frame.year.to_numpy(float),model.initial_state(frame,year=2011))
    saved=pd.read_csv(ROOT/'06_runs/B1_v1_1/calibration/best_prediction_2011_2023.csv')
    historical_error=float(np.max(np.abs(history[cfg.STATE_NAMES+['ES','SR']].to_numpy(float)-saved[cfg.STATE_NAMES+['ES','SR']].to_numpy(float))))
    assert historical_error<1e-10
    ensemble=pd.read_csv(ROOT/'06_runs/B1_v1_1/calibration/accepted_parameter_ensemble.csv')
    assert len(ensemble)>0
    r=ensemble.iloc[0];pid=r.parameter_set_id
    params={n:float(r[n]) for n in cfg.PARAMETER_NAMES}
    climate=pd.read_csv(ROOT/'06_runs/B1_v1_1/scenarios/common_climate_draw_001.csv')
    actual,_=one_scenario((pid,params,frame,load_settings(),climate))
    prior=pd.read_csv(ROOT/'06_runs/B1_v1_1/scenarios/scenario_trajectories_long.csv')
    prior=prior[prior.parameter_set_id.eq(pid)].sort_values(['scenario','year']).reset_index(drop=True)
    actual=actual.sort_values(['scenario','year']).reset_index(drop=True)
    assert len(actual)==len(prior)==49
    scenario_error=float(np.max(np.abs(actual[cfg.STATE_NAMES+['ES','SR']].to_numpy(float)-prior[cfg.STATE_NAMES+['ES','SR']].to_numpy(float))))
    assert scenario_error<1e-10
    metrics=pd.read_csv(ROOT/'06_runs/B1_v1_1/scenarios/scenario_metrics_by_parameter.csv')
    summary=pd.read_csv(ROOT/'06_runs/B1_v1_1/scenarios/scenario_summary.csv')
    recomputed=metrics.groupby('scenario').ES_2030.median()
    summary_error=float(max(abs(recomputed[s]-summary.set_index('scenario').loc[s,'ES_2030_median']) for s in recomputed.index))
    assert summary_error<1e-10
    result={'replay':'PASS','input_rows':len(frame),'replayed_history_rows':len(history),
      'replayed_scenario_rows':len(actual),'historical_max_abs_error':historical_error,
      'scenario_max_abs_error':scenario_error,'summary_max_abs_error':summary_error,
      'scope':'fixed_parameter_replay_not_full_recalibration'}
    print(json.dumps(result,ensure_ascii=False))
    return result

if __name__=='__main__':main()
