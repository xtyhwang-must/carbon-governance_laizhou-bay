"""Read-only, mode-aware diagnostics of the unchanged numerical rhs.

The private trace adds a local-variable return to an in-memory copy of rhs.
It never changes sd_model.rhs, the accelerated kernel, or model parameters.
"""
from __future__ import annotations
import ast,copy,inspect,json
import numpy as np
import sd_model as m

_TRACE=None

def trace_rhs(time,state,parameters,forcing,reference,mode,structure):
    global _TRACE
    if _TRACE is None:
        tree=ast.parse(inspect.getsource(m.rhs));fn=tree.body[0]
        fn.name='_diagnostic_rhs_locals'
        fn.body[-1]=ast.Return(value=ast.Call(func=ast.Name(id='locals',ctx=ast.Load()),args=[],keywords=[]))
        ast.fix_missing_locations(tree);namespace=dict(m.__dict__)
        exec(compile(tree,'<unchanged_rhs_diagnostic_trace>','exec'),namespace)
        _TRACE=namespace['_diagnostic_rhs_locals']
    p=m.parameter_dict(parameters,structure=structure)
    return _TRACE(float(time),np.asarray(state,float),p,forcing,reference,mode,structure)

def terms(state,exo,baseline,p,structure,mode=None):
    """Compatibility schema plus actual final conversion and boundary fields."""
    mode=mode or m.ModelMode()
    class PointForcing:
        def at(self,time):return exo
    t=trace_rhs(0.,state,p,PointForcing(),baseline,mode,structure)
    rows=[]
    for name,index,stem in [('SP',3,'sp'),('SC',4,'sc'),('NS',5,'ns'),('OS',6,'os'),('BS',7,'bs'),('TF',8,'tf'),('SM',9,'sm')]:
        signal=float(t[stem+'_signal']);target=float(t[stem+'_target'])
        rate=t['params']['r_social'] if name in ['SP','SC'] else t['params']['r_water'] if name in ['NS','OS','BS'] else t[stem+'_rate']
        conversion=-float(t.get('conversion_tf_units',0.)) if name=='TF' else float(t.get('conversion_sm_units',0.)) if name=='SM' else 0.
        pure=float(rate*(target-t['state'][index]));final=pure+conversion
        raw=np.asarray(state,float)
        guard=bool((raw[index]<=0 and final<0) or (raw[index]>=1 and final>0))
        if guard:final=0.
        intercept=t['params']['alpha_AC'] if name=='SC' and structure in ['M1_AC_INTERCEPT','M2_AC_SM_INTERCEPTS','M3_AC_SM_TF_INTERCEPTS'] else t['params']['alpha_SM'] if name=='SM' and structure in ['M2_AC_SM_INTERCEPTS','M3_AC_SM_TF_INTERCEPTS'] else t['params']['alpha_TF'] if name=='TF' and structure=='M3_AC_SM_TF_INTERCEPTS' else float(m.logit(baseline[name]))
        rows.append(dict(state=name,state_index=index,observed=float(raw[index]),target_logit_intercept=float(intercept),
          target_signal=signal,target_state=target,adjustment_rate=float(rate),conversion_term=conversion,
          reconstructed_derivative=final,actual_derivative=float(t['derivative'][index]),boundary_guard=guard,
          driver_terms_json=json.dumps({'complete_signal_minus_intercept':signal-intercept}),
          G1=float(t['g1']),G2=float(t['g2']),G3=float(t['g3']),IM=float(t['im']),A1=float(t['a1']),A2=float(t['a2']),A3=float(t['a3']),
          implementation_ops=float(t['im']),implementation_capacity=float(t['icap']) if 'icap' in t else float(m._actions(t['action_state'],exo,t['params'],mode)[4]),
          WQ=float(t['wq']),H=float(t['habitat']),risk_memory_PR=float(t['pr']),social_risk_memory_PRS=float(t['prs']),
          raw_state_clipped_for_RHS=bool(raw[index]<.001 or raw[index]>.999),mode_midpoint=mode.sc_gate_midpoint))
    return rows
