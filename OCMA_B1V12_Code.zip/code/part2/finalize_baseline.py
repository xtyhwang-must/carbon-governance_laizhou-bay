"""Write factual B1 handoff and decision documents from finished run artifacts."""
from __future__ import annotations
import json
from pathlib import Path
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]
RUN=ROOT/'06_runs/B1_v1_1'
VERSION='B1_v1.1.0_source_reconstructed'

def load(relative):return json.loads((RUN/relative).read_text(encoding='utf-8'))
def write(path,text):(ROOT/path).write_text(text,encoding='utf-8')

def main():
    cal=load('calibration/calibration_status.json')
    ev=load('evaluation/evaluation_status.json')
    sc=load('scenarios/scenario_status.json')
    at=load('attribution/attribution_status.json')
    qa=load('baseline_qa_report.json')
    if not all([cal['complete'],ev['complete'],sc['complete'],at['complete'],qa['passed']]):
        raise RuntimeError('Cannot finalize an incomplete or failed B1 run')
    clauses=pd.read_csv(ROOT/'02_policy/reconstructed/coded_clauses_B1.csv')
    dates=pd.read_csv(ROOT/'02_policy/reconstructed/policy_validity_decisions.csv')
    relations=pd.read_csv(ROOT/'02_policy/reconstructed/relation_events_B1.csv')
    input_frame=pd.read_csv(ROOT/'03_indicators/model_input_B1.csv')
    compare=pd.read_csv(ROOT/'00_contract/baseline_vs_submission.csv')
    metrics=pd.read_csv(RUN/'evaluation/holdout_state_metrics_by_parameter.csv')
    coverage=pd.read_csv(RUN/'evaluation/holdout_coverage.csv')
    baselines=pd.read_csv(RUN/'evaluation/simple_baselines.csv')
    paired=pd.read_csv(RUN/'scenarios/paired_differences.csv')
    scenario_summary=pd.read_csv(RUN/'scenarios/scenario_summary.csv')
    reach=pd.read_csv(RUN/'evaluation/AC_SM_reachability_diagnostics.csv')
    ac_reach=reach.set_index('state').loc['AC']
    ac_bound=float(ac_reach.global_target_upper_bound)
    ac_observed=float(ac_reach.observed_max_2011_2020)
    ac_adequacy=not bool(ac_reach.observed_exceeds_global_target_bound)
    accepted=cal['propagated_count'];total=cal['candidate_count']
    qualified=int(clauses.b1_qualified.sum())
    holdout=metrics[metrics.estimated_2023_treatment.eq('weighted')].groupby('state').NRMSE.median().sort_values()
    pure=coverage[coverage.interval_kind.eq('pure_parameter') & coverage.estimated_2023_treatment.eq('weighted')]
    pure_zero=bool(pure.weighted_coverage.eq(0).all())
    sm_persistence=float(baselines[baselines.state.eq('SM') & baselines.benchmark.eq('persistence')].NRMSE.iloc[0])
    comparison=paired[paired.contrast.eq('S4-S6')].D_ES_2030
    s4s6=float(comparison.median());fraction=float((comparison>0).mean())
    ranking=scenario_summary.sort_values('ES_2030_median',ascending=False).scenario.tolist()
    gate=accepted>0
    status='READY_FOR_REVISION_WITH_LIMITATIONS'
    summary={'version':VERSION,'computation_complete':True,'fixed_acceptance_gate_pass':bool(gate),
      'behavioral_adequacy_pass':False,'pure_parameter_coverage_zero_all_states':pure_zero,
      'structural_AC_adequacy_pass':bool(ac_adequacy),
      'AC_observed_training_max':ac_observed,'AC_global_target_upper_bound':ac_bound,
      'author_review_status':'PENDING','submission_ready':False,
      'release_decision':status,'candidate_count':total,'accepted_before_cap':cal['accepted_before_cap'],
      'propagated_parameter_sets':accepted,'climate_draws':sc['climate_draws'],
      'attribution_parameter_sets':at['parameter_sets'],'qualified_new_units':qualified,
      'strict_median_ES2030_order':ranking,'S4_minus_S6_ES2030_median':s4s6,
      'S4_above_S6_fraction':fraction,'holdout_median_NRMSE_by_state':holdout.to_dict()}
    (RUN/'final_status.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
    write('BASELINE_README.md',f'''# {VERSION}

本目录是独立的来源重建计算基准，**不是原投稿历史运行**。原单人编码字段保留空值；新条款编码身份为 `CODEX_SOURCE_RECONSTRUCTION`，作者核验状态 `PENDING`。提交稿件状态：`false`。

## 同版对应链

1. `00_contract/source_manifest.csv`：捕获来源、附件、定向补取正文、代码、哈希与确认身份。
2. `02_policy/policy_registry.csv`、`02_policy/reconstructed/coded_clauses_B1.csv`：68 篇政策、{len(clauses):,} 个新文本单元、{qualified:,} 个合格单元及逐条原文定位；`policy_validity_decisions.csv` 与 `policy_stock_by_year_B1.csv` 将日期事实和开放暴露假设分开。
3. `03_indicators/indicator_dictionary.csv`、`indicator_lineage.csv`：原值、变换、支持范围和证据类型；唯一主输入为 `model_input_B1.csv`，覆盖 2011—2023 年 {len(input_frame)} 行。
4. `04_model/equation_registry.csv`：原稿/附录公式与代码函数对应。
5. `04_model/parameter_registry.csv`：九参数范围、固定参数及身份。
6. `04_model/calibration_protocol.yaml`：固定校准、评价、候选和接受规则。
7. `04_model/scenario_registry.csv`、`scenario_lever_audit.csv`：S0—S6 原尺度、模型尺度及实际 2030 治理增量。
8. `00_contract/analysis_traceability.csv`：来源/条款/年度值到变换、方程、函数和结果文件的关联。

## 实际计算

五个固定种子完成 2011—2020 九参数校准；筛查 {total:,} 个候选，固定门槛下接受 {cal['accepted_before_cap']:,} 个，传播 {accepted:,} 个。2021—2023 回顾性评价、七情景配对、社会筛选和两个匹配 Shapley 比较均生成。共同气候样本数为 {sc['climate_draws']}，归因参数样本数为 {at['parameter_sets']}；两者不能当作全部不确定性。纯参数包络与残差扩展分开。

结果文件分别位于 `06_runs/B1_v1_1/calibration`、`evaluation`、`scenarios`、`attribution`。事后原稿核对在 `00_contract/baseline_vs_submission.csv`。检查日志为 `06_runs/B1_v1_1/test_log.csv`；发布与解包复算记录在 `07_release`。

`06_runs/B1_v1_1/policy_input_sensitivity` 提供两个已登记编码备选对年度 G 输入的影响；这是输入敏感性，不是情景或模型输出敏感性。
`06_runs/B1_v1_1/figures` 提供英文参数分布和局部训练损失剖面图（SVG/PDF/PNG）、对应 CSV 与图形说明；这些是校准诊断，不是参数置信区间。

## 运行命令

在本目录安装 `requirements_B1.txt` 后执行：

```powershell
python 05_code/run_baseline.py --stage all
```

独立轻量检查和固定参数回放：

```powershell
python 05_code/run_baseline.py --stage verify-input
python 05_code/release_replay.py
```

原投稿/B0 仅作事后参照，不能用这些数值替换 B1 输入。具体限制与下一轮工作分别见 `model_limitations.md` 和 `revision_handoff.md`。
''')
    write('baseline_release_decision.md',f'''# B1 发布判定

- 计算完整：**是**。五种子校准、{total:,} 个候选筛查、回顾评价、S0—S6、配对差、社会筛选与匹配 Shapley 均已执行。
- 固定候选筛选门槛：**{'通过' if gate else '未通过'}**。{total:,} 个候选中 {cal['accepted_before_cap']:,} 个达标，按预定上限传播 {accepted:,} 个；高接受率显示门槛区分力弱。最优训练平均 NRMSE={cal['best_mean_nrmse']:.4f}，方向一致率={cal['best_trend_hit']:.4f}。
- 模型行为充分性：**未通过**。七个状态的纯参数包络在三年留出期覆盖率{'均为零' if pure_zero else '见评价表'}；SM 模型 NRMSE 中位数 {holdout['SM']:.3f}，简单持久性基准 {sm_persistence:.3f}。
- 结构可达性：**{'通过' if ac_adequacy else '未通过'}**。在登记的参数范围、状态界限和初值下，AC 目标项上界为 {ac_bound:.4f}，2011—2020 观测最大值为 {ac_observed:.4f}；这限制了历史拟合和预测解释，即使候选筛选门槛通过也不能视为模型行为充分。
- 作者真实核验：**未完成**；新编码及关系/日期决定仍为 `PENDING`。
- 可以提交稿件：**否**，`submission_ready=false`。
- 版本状态：`{status}`。它只表示计算交付状态，不表示原稿结论已获验证。

按 ES 2030 中位数的严格数值排序为 {' > '.join(ranking)}。S4−S6 的配对中位数为 {s4s6:.6f}，S4 高于 S6 的参数比例为 {fraction:.3f}；按登记的 0.0005 容差，S1 与 S2 不可区分。`cross_spec_robustness.csv` 仅比较同一气候区块有/无复合冲击的 {sc['cross_spec_parameter_sets']} 组参数，不能代替广泛气候和政策假设稳健性。全部 21 对情景的容差审计在 `all_pair_tolerance_audit.csv`，数值步长检查见 QA 日志。
''')
    write('model_limitations.md',f'''# 模型与证据限制

1. 原投稿的逐条人工编码和原始联合参数向量没有恢复。{len(clauses):,} 个 CODEX 文本单元是本轮独立重建，不能称为原单人编码或第二人工编码；作者审核仍待完成。
2. {int(dates.start_rule.str.contains('FALLBACK').sum())} 项起始年采用可追溯发布年回退，{int(dates.end_rule.eq('OPEN_ENDED_ASSUMED_THROUGH_2030').sum())} 项开放政策按假设持续至 2030；未见退出日不代表现实中永远有效。2004 年山东海洋环境条例的 2016/2018 修正文本归档，但尚未做逐版本年度条款重编码。
3. 年度 eta、反馈和协同来自政策文本与关系事件的重建代理，不是直接观察到的实施效果。IM 与 PR/PRS 是模型辅助初值或记忆状态，不是额外实测变量。历史反馈强度置零避免双计，情景反馈的原统计量采用登记的 B1 最小重建映射。
4. 2023 生境面积是桥接估计，0.35 只用于指定评价。水质单位元数据和 SST 采样时间支持仍需确认。
5. 回顾期只有三年，纯参数包络没有覆盖结构误差；七个状态的纯参数覆盖率{'均为零' if pure_zero else '不充分'}。按状态的回顾期 NRMSE 中位数：{', '.join(f'{k}={v:.3f}' for k,v in holdout.items())}。SM 的简单持久性基准 NRMSE 为 {sm_persistence:.3f}，数值上低于模型 {holdout['SM']:.3f}。趋势基准与单独标记的残差扩展见评价目录；不能把训练拟合当预测可靠性证明。
   AC 在登记的参数盒与状态界限下，其目标项全局上界为 {ac_bound:.4f}，低于训练期观测最大值 {ac_observed:.4f}；因此原方程不能追踪该状态的高值。SM 的最优参数局部目标项也远低于观测，但目前没有全局不可达性证明。逐年目标项与推导见 `06_runs/B1_v1_1/evaluation/AC_SM_reachability_diagnostics.csv`。
6. 主情景共享一个三年区块抽样气候路径和 2026—2028 联合扰动；另以 {sc['cross_spec_parameter_sets']} 个参数比较相同区块下不加复合扰动。严格排序仍条件于这些路径、同一 2023 初值及政策流假设。Shapley 对 {at['parameter_sets']} 个接受参数作匹配析因，不是因果归因或全部参数/气候不确定性。
7. TF/SM 归一化面积转换代表模型内生境组成变化，不等于实测碳储量、碳通量或新增固碳量。
''')
    write('revision_handoff.md',f'''# 下一轮返修调用

当前同版计算已形成。先由作者核查 `02_policy/reconstructed/author_positive_evidence_index.csv`、`author_ambiguity_index.csv`、有效期事实和关系事件；如修改任何编码/日期，重跑 `python 05_code/run_baseline.py --stage all`，并重新发布，不能只替换图表。

然后以 `06_runs/B1_v1_1/evaluation` 的真实 2021—2023 误差、覆盖与简单基准限制预测措辞；以 `06_runs/B1_v1_1/scenarios/paired_differences.csv` 与 `attribution/matched_shapley_by_parameter.csv` 更新原稿排序、社会筛选和机制讨论。`00_contract/baseline_vs_submission.csv` 仅用于列出与原投稿差异。

当前提交门禁：作者审核 `PENDING`，`submission_ready=false`。若审核发现关键正文、版本或有效期变化，应创建新 B1 修订版本，不改动本目录已发布文件。
''')
    items=pd.read_csv(ROOT/'00_contract/unresolved_items.csv')
    result=[]
    for stage,path in [('calibration','calibration/calibration_status.json'),('evaluation','evaluation/evaluation_status.json'),('scenarios','scenarios/scenario_status.json'),('attribution','attribution/attribution_status.json'),('qa','baseline_qa_report.json')]:
        result.append({'deliverable':stage,'status':'COMPLETE','path':'06_runs/B1_v1_1/'+path})
    result.append({'deliverable':'author_review','status':'PENDING','path':'02_policy/review'})
    pd.DataFrame(result).to_csv(ROOT/'00_contract/result_status.csv',index=False,encoding='utf-8-sig')
    print(json.dumps(summary,ensure_ascii=False))

if __name__=='__main__':main()
