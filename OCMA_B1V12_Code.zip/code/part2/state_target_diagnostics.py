"""Compatibility CLI for the current mode-aware target diagnostic.

The superseded nine-parameter implementation is preserved in the R1 and
pre-cleanup archives. This entry uses the current structure and explicit mode.
"""
from diagnose_targets_v12 import main

if __name__=='__main__':main()
