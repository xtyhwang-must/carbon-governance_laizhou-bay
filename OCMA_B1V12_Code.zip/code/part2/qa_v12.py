"""Independent source, numerical, matching and completion QA for B1 v1.2."""
from __future__ import annotations
import hashlib,json,sys
from pathlib import Path
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'05_code/engine'),str(ROOT/'05_code')]
import engine_config as cfg
import sd_model as model
from cache_safety import atomic_json
from revised_core import validate_metric

OUT=ROOT/'06_runs/formal_main/qa'
CAL=ROOT/'06_runs/formal_main/calibration'
SCEN=ROOT/'06_runs/formal_main/scenarios'
ROB=ROOT/'06_runs/formal_main/robustness'
ATTR=ROOT/'06_runs/formal_main/attribution'

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest().upper()
def read(path):return json.loads(Path(path).read_text(encoding='utf-8'))

def legacy_main():
    OUT.mkdir(parents=True,exist_ok=True)
    checks=[]
    def check(name,truth,detail=''):
        checks.append({'check':name,'pass':bool(truth),'detail':str(detail)})
        if not truth:print('FAIL',name,detail,flush=True)
    author=read(ROOT/'00_contract/author_confirmation.json')
    check('author_confirmed_adoption',author['status']=='CONFIRMED_BY_AUTHOR' and
        author['coding_origin']=='CODEX_SOURCE_RECONSTRUCTION' and
        not author['original_human_code_recovered'] and not author['second_independent_human_coder'])
    for rel,expected in author['confirmed_file_sha256'].items():
        check('author_confirmed_hash_'+Path(rel).stem,sha(ROOT/rel)==expected,rel)
    corpus=pd.read_csv(ROOT/'02_policy/reconstructed/text_source_audit.csv')
    clauses=pd.read_csv(ROOT/'02_policy/reconstructed/coded_clauses_B1.csv')
    dates=pd.read_csv(ROOT/'02_policy/reconstructed/policy_validity_decisions.csv')
    stock=pd.read_csv(ROOT/'02_policy/reconstructed/policy_stock_by_year_B1.csv')
    interface=pd.read_csv(ROOT/'02_policy/reconstructed/annual_policy_interface_B1.csv')
    check('68_source_target_bodies',len(corpus)==68 and corpus.policy_id.is_unique and corpus.clean_text_sha256.notna().all())
    check('clause_corpus_not_fabricated_human',clauses.policy_id.nunique()==68 and clauses.unit_id.is_unique and
        clauses.coding_origin.eq('CODEX_SOURCE_RECONSTRUCTION').all() and
        clauses[[c for c in clauses if c.startswith('original_')]].isna().all().all(),len(clauses))
    current_clauses=pd.read_csv(ROOT/'02_policy/coded_clauses.csv')
    current_registry=pd.read_csv(ROOT/'02_policy/policy_registry.csv')
    confirmed_hash=author['confirmed_file_sha256']['02_policy/reconstructed/coded_clauses_B1.csv']
    check('v12_author_adoption_overlay',current_clauses.author_review_status.eq('CONFIRMED_BY_AUTHOR').all() and
        current_registry.author_review_status.eq('CONFIRMED_BY_AUTHOR').all() and
        current_clauses.author_confirmation_source_sha256.eq(confirmed_hash).all() and
        current_registry.author_confirmation_source_sha256.eq(confirmed_hash).all())
    texts={r.policy_id:(ROOT/r.clean_text_relative_path).read_text(encoding='utf-8') for r in corpus.itertuples(index=False)}
    check('all_coded_clause_anchors',all(texts[r.policy_id][int(r.clean_start):int(r.clean_end)]==r.exact_evidence_text
        for r in clauses.itertuples(index=False)))
    check('date_facts_distinct_from_open_assumptions',len(dates)==68 and
        dates.end_rule.eq('OPEN_ENDED_ASSUMED_THROUGH_2030').any())
    check('stock_years_and_channels',set(stock.year)==set(range(2000,2031)) and set(stock.channel)=={'G1','G2','G3'})
    for ch,g in stock.groupby('channel'):
        g=g.sort_values('year')
        error=(np.diff(g.active_valid_policy_stock.to_numpy(float))-
            g.new_effective_admissions.to_numpy(float)[1:]+g.exits_at_transition.to_numpy(float)[1:])
        check('stock_accounting_'+ch,np.max(np.abs(error))<1e-9,float(np.max(np.abs(error))))
    check('eta_raw_denominator',np.allclose(interface.eta_raw,
        interface.active_explicit_governance_response_proxy_policy_count/interface.active_formal_policy_denominator))
    check('feedback_raw_denominator',np.allclose(interface.feedback_raw,
        interface.active_explicit_feedback_signal_policy_count/interface.active_formal_policy_denominator))
    check('synergy_raw_denominators',np.allclose(interface.synergy_raw,np.sqrt(
        interface.stock_network_joint_issue_policy_share*interface.stock_network_vertical_relation_weight_share)))
    frame=pd.read_csv(ROOT/'03_indicators/model_input_B1.csv')
    check('unique_2011_2023_input',frame.year.tolist()==list(range(2011,2024)) and frame.input_complete.all())
    check('synergy_schema',np.allclose(frame.SYNERGY_LEVER,frame.synergy_share,atol=1e-12) and
        np.allclose(frame.SYNERGY_LEVER,interface.SYNERGY_LEVER,atol=1e-12))
    check('social_definition',np.allclose(frame.AC,frame.SC) and
        np.allclose(frame.SR,np.sqrt((1-frame.SP)*frame.AC)))
    check('ecological_definition',np.allclose(frame.WQ,((1-frame.NS)*(1-frame.OS)*(1-frame.BS))**(1/3)) and
        np.allclose(frame.H,np.sqrt(frame.TF*frame.SM)) and np.allclose(frame.ES,np.sqrt(frame.WQ*frame.H)))
    gate=frame.AC.to_numpy(float)**2/(.30**2+frame.AC.to_numpy(float)**2)
    g3=frame.G3.to_numpy(float)**2.2/(.45**2.2+frame.G3.to_numpy(float)**2.2)
    check('IM_derived_not_measured',np.allclose(frame.IM,np.clip(frame.ETA_POTENTIAL*g3*(.12+.88*gate)/
        (1+.75*frame.SP),.001,.999),atol=1e-12))
    check('state_bounds',frame[cfg.STATE_NAMES].ge(0).all().all() and frame[cfg.STATE_NAMES].le(1).all().all())
    check('explicit_year_selection',np.allclose(model.initial_state(frame,year=2023),
        frame.loc[frame.year.eq(2023),cfg.STATE_NAMES].iloc[0].to_numpy(float)) and
        not np.allclose(model.initial_state(frame,year=2011),model.initial_state(frame,year=2023)))
    denominator=validate_metric([0,0],[0,0],[2021,2022],np.arange(10.))['calibration_P95_minus_P5']
    check('training_reference_NRMSE_denominator',np.isclose(denominator,8.1),denominator)
    contract=cfg.CONTRACT
    check('035_evaluation_only',contract['ecology']['2023_evaluation_weight']==.35 and
        not contract['ecology']['2023_initial_state_blend'])
    sample_params={n:float(sum(cfg.PARAMETER_BOUNDS[n])/2) for n in cfg.PARAMETER_NAMES}
    forcing=model.historical_forcing(frame)
    initial11=model.initial_state(frame,year=2011)
    initial23=model.initial_state(frame,year=2023)
    baseline=model._baseline_context(initial11,forcing.at(2011.),
        model.parameter_dict(sample_params),model.ModelMode())
    d_on=model.rhs(2023.,initial23,model.parameter_dict(sample_params),forcing,baseline,
        model.ModelMode(),'M0_FIXED_REFERENCE')
    d_off=model.rhs(2023.,initial23,model.parameter_dict(sample_params),forcing,baseline,
        model.ModelMode(tf_sm_conversion=False),'M0_FIXED_REFERENCE')
    conversion_error=float(abs(cfg.TF_TO_SM_AREA_SCALE_RATIO*(d_on[8]-d_off[8])+(d_on[9]-d_off[9])))
    check('TF_SM_raw_area_conversion_identity',conversion_error<1e-12,conversion_error)
    lev=pd.read_csv(ROOT/'04_model/scenario_lever_audit.csv')
    check('seven_scenarios_49_levers',len(lev)==49 and lev.scenario_id.nunique()==7 and
        not lev.duplicated(['scenario_id','lever']).any())
    unchanged=lev.actual_intervention_status.eq('UNCHANGED')
    degenerate=lev.actual_intervention_status.eq('DEGENERATE_LEVER')
    enhanced=lev.actual_intervention_status.eq('NONZERO_DEFINED_LEVER')
    check('unchanged_vs_degenerate',unchanged.sum()==30 and enhanced.sum()==19 and
        not ((unchanged)&((lev.raw_delta.abs()>1e-12)|(lev.model_delta.abs()>1e-12))).any() and
        not ((degenerate)&((lev.raw_delta.abs()<=1e-12)|(lev.model_delta.abs()>1e-12))).any() and
        not ((enhanced)&((lev.raw_delta.abs()<=1e-12)|(lev.model_delta.abs()<=1e-12))).any())
    decision=read(ROOT/'06_runs/structure_compare/model_selection.json')
    check('selection_not_scenario_tuned',decision['selection_rule_locked_before_fit'] and
        decision['holdout_not_used_for_selection'])
    status=read(CAL/'formal_calibration_status.json')
    check('formal_structure_equals_locked_selection',status['structure']==decision['selected_structure'] and
        status['structure_selection_status']==decision['status'])
    ensemble=pd.read_csv(CAL/'accepted_parameter_ensemble.csv')
    candidates=pd.read_csv(CAL/'candidate_screen_all.csv')
    names=model.parameter_names(status['structure'])
    check('formal_five_seeds_11600_candidates',status['five_seed_count']==5 and len(candidates)==11600)
    check('candidate_vector_unique',candidates.parameter_vector_sha256.is_unique)
    check('gate_identity',np.array_equal(candidates.legacy_acceptance.to_numpy(bool),
        (candidates.loss<=1.35*status['best_training_loss']+.025)&
        (candidates.mean_nrmse<=.52)&(candidates.trend_hit>=.43)))
    check('accepted_count_real_and_capped',len(ensemble)==status['propagated_count'] and
        len(ensemble)<=600 and ensemble.parameter_set_id.is_unique and
        ensemble.parameter_vector_sha256.is_unique)
    refs=pd.read_csv(CAL/'accepted_reference_contexts.csv')
    check('per_vector_training_reference_recorded',len(refs)==len(ensemble) and
        refs.parameter_set_id.is_unique and refs.reference_year.eq(2011).all())
    for n in names:
        lo,hi=(cfg.PARAMETER_BOUNDS[n] if n in cfg.PARAMETER_BOUNDS else cfg.STRUCTURAL_PARAMETER_BOUNDS[n])
        check('parameter_bounds_'+n,ensemble[n].between(lo,hi).all())
    evalstatus=read(ROOT/'06_runs/formal_main/evaluation/evaluation_status.json')
    metric=pd.read_csv(ROOT/'06_runs/formal_main/evaluation/retrospective_metrics_by_parameter.csv')
    check('same_version_history_evaluation',evalstatus['complete'] and evalstatus['parameter_sets']==len(ensemble) and
        evalstatus['input_sha256'].upper()==sha(ROOT/'03_indicators/model_input_B1.csv') and
        metric.state_role.eq('BASIC').sum()==len(ensemble)*7*3)
    coverage_year=pd.read_csv(ROOT/'06_runs/formal_main/evaluation/pure_parameter_coverage_by_year.csv')
    check('coverage_year_numerators_denominators',len(coverage_year)==11*3*3 and
        coverage_year.covered_numerator.le(coverage_year.covered_denominator).all() and
        coverage_year.covered_denominator.isin([0,1]).all())
    scenstatus=read(SCEN/'scenario_status.json')
    trajectory=pd.read_csv(SCEN/'scenario_trajectories_long.csv')
    scenmetrics=pd.read_csv(SCEN/'scenario_metrics_by_parameter.csv')
    check('full_main_scenario_cells',scenstatus['complete'] and len(scenmetrics)==7*len(ensemble) and
        len(trajectory)==7*7*len(ensemble))
    check('matched_parameter_forcing_initial',scenmetrics.groupby('parameter_set_id').scenario.nunique().eq(7).all() and
        trajectory.groupby('parameter_set_id').initial_state_hash.nunique().eq(1).all())
    check('scenario_reference_matches_calibration',trajectory.groupby('parameter_set_id').reference_context_sha256.nunique().eq(1).all() and
        trajectory[['parameter_set_id','reference_context_sha256']].drop_duplicates().merge(
            refs[['parameter_set_id','reference_context_sha256']],on='parameter_set_id',validate='one_to_one',
            suffixes=('_scenario','_fit')).eval('reference_context_sha256_scenario == reference_context_sha256_fit').all())
    shock=trajectory[trajectory.year.between(2026,2030)].groupby(['parameter_set_id','scenario']).ES.min()
    got=scenmetrics.set_index(['parameter_set_id','scenario']).min_ES_2026_2030
    check('min_ES_within_each_path_before_pairing',np.allclose(shock.loc[got.index],got))
    social=pd.read_csv(SCEN/'social_screen_summary.csv')
    check('terminal_social_screen_rule',np.array_equal(social.main_screen_pass.to_numpy(bool),
        social.median_D_SR_2030.to_numpy(float)>=-.0005))
    tolerance=pd.read_csv(SCEN/'ecological_tolerance_sensitivity.csv')
    check('three_registered_ecological_tolerances',len(tolerance)==2*21*3 and
        set(np.round(tolerance.epsilon_ES,6))=={0.,.0005,.001} and
        np.array_equal(tolerance.median_distinguishable.to_numpy(bool),
            tolerance.median_a_minus_b.abs().to_numpy(float)>tolerance.epsilon_ES.to_numpy(float)))
    attrstatus=read(ATTR/'attribution_status.json')
    endpoints=pd.read_csv(ATTR/'endpoint_matches.csv');phi=pd.read_csv(ATTR/'shapley_by_parameter.csv')
    check('full_matched_shapley',attrstatus['complete'] and attrstatus['parameter_sets']==len(ensemble) and
        attrstatus['coalition_rows']==24*len(ensemble) and endpoints['pass'].all() and
        phi.closure_error.abs().max()<=1e-10)
    robust=read(ROB/'robustness_status.json')
    rmetrics=pd.read_csv(ROB/'robustness_metrics_by_vector.csv')
    check('climate_and_habitat_structure_robustness',robust['complete'] and robust['joint_climate_draws']==20 and
        robust['sample_parameter_sets']==min(100,len(ensemble)) and
        len(rmetrics)==robust['sample_parameter_sets']*(40+2+4)*7)
    check('robust_internal_scenario_matching',rmetrics.groupby(['specification_id','forcing_draw_id','parameter_set_id']).scenario.nunique().eq(7).all())
    dynamic_robust=rmetrics[~rmetrics.specification_id.str.startswith('REPORTING_')]
    check('dynamic_robustness_keeps_training_reference',dynamic_robust.merge(
        refs[['parameter_set_id','reference_context_sha256']],on='parameter_set_id',
        validate='many_to_one',suffixes=('_robust','_fit')).eval(
        'reference_context_sha256_robust == reference_context_sha256_fit').all())
    primary_robust=rmetrics[rmetrics.specification_id.eq('CLIMATE_compound')&
        rmetrics.forcing_draw_id.eq('CLIM_01')]
    same=primary_robust.merge(scenmetrics,on=['parameter_set_id','scenario'],validate='one_to_one',
        suffixes=('_robust','_main'))
    primary_error=max(float(np.max(np.abs(same[f'{m}_robust']-same[f'{m}_main'])))
        for m in ['min_ES_2026_2030','ES_2030','SR_2030'])
    check('robust_primary_draw_equals_main',len(same)==7*robust['sample_parameter_sets'] and
        primary_error<1e-10,primary_error)
    mechanism=read(ROOT/'06_runs/formal_main/mechanisms/mechanism_status.json')
    check('six_direction_three_reciprocal_mechanisms',mechanism['complete'] and
        mechanism['directional_ablations']==6 and mechanism['reciprocal_pair_ablations']==3 and
        mechanism['parameter_sets']==min(100,len(ensemble)))
    ablation=pd.read_csv(ROOT/'06_runs/formal_main/mechanisms/ablation_scenario_metrics.csv')
    check('ablations_keep_main_training_reference',ablation.merge(
        refs[['parameter_set_id','reference_context_sha256']],on='parameter_set_id',
        validate='many_to_one',suffixes=('_ablation','_fit')).eval(
        'reference_context_sha256_ablation == reference_context_sha256_fit').all())
    surface=read(ROOT/'06_runs/formal_main/mechanisms/response_surface/response_surface_status.json')
    check('registered_grid_surface',surface['complete'] and surface['grid_points']==169 and
        surface['parameter_sets']==min(24,len(ensemble)) and surface['all_main_endpoints_match'])
    cache_generations=[
        ('calibration',CAL/'candidate_cache',status['candidate_cache_signature'],39),
        ('scenarios',SCEN/'cache',scenstatus['cache_signature'],len(ensemble)),
        ('robustness',ROB/'cache',robust['cache_signature'],robust['sample_parameter_sets']),
        ('attribution',ATTR/'cache',attrstatus['cache_signature'],len(ensemble)),
        ('mechanisms',ROOT/'06_runs/formal_main/mechanisms/cache',mechanism['cache_signature'],
            mechanism['parameter_sets']),
        ('surface',ROOT/'06_runs/formal_main/mechanisms/response_surface/cache',surface['cache_signature'],
            surface['parameter_sets'])]
    for name,base,key,count in cache_generations:
        marker=base/('run_'+key)/'COMPLETE.json'
        complete=read(marker) if marker.is_file() else {}
        check('complete_cache_generation_'+name,complete.get('status')=='COMPLETE' and
            complete.get('signature')==key and len(complete.get('chunks',[]))==count)
    numeric=read(OUT/'numerical_qa_status.json')
    check('numeric_step_gate',numeric['complete'] and numeric['all_005_match_main'] and numeric['numeric_error_gate_pass'])
    check('source_grounded_new_diagnostic_figures',all((ROOT/p).is_file() for p in [
        '07_publication/figures/B12_parameter_spread.svg',
        '07_publication/figures/B12_local_loss_profiles.svg',
        '07_publication/figures/B12_response_surface.svg',
        '07_publication/figures/parameter_distribution_source_data.csv',
        '07_publication/figures/calibration_loss_profile_source_data.csv']))
    check('editable_English_result_tables',(ROOT/'07_publication/tables/B1_v12_editable_results_tables.docx').is_file() and
        (ROOT/'07_publication/tables/Table_5_source.csv').is_file())
    testfiles=['06_runs/P0_legacy_structure_correct_initial/initialization_tests.json',
        '06_runs/P0_legacy_structure_correct_initial/cache_negative_tests.json',
        '06_runs/P1_structure_diagnostics/structure_reference_tests.json']
    for rel in testfiles:check('regression_test_'+Path(rel).stem,(ROOT/rel).is_file())
    trace=pd.read_csv(ROOT/'00_contract/analysis_traceability.csv')
    same=trace[trace.version.eq('B1_v1.2.0_definition_consistent')]
    check('eight_link_same_version_result_trace',len(same)==172 and
        all((ROOT/rel).is_file() for rel in same.result_file.unique()))
    report={'version':contract['version'],'all_checks_pass':all(x['pass'] for x in checks),
        'checks_passed':sum(x['pass'] for x in checks),'checks_total':len(checks),
        'author_confirmation':author['status'],'calibration_structure':status['structure'],
        'accepted_vectors':len(ensemble),'checks':checks}
    atomic_json(OUT/'qa_report.json',report)
    print(json.dumps({k:v for k,v in report.items() if k!='checks'},ensure_ascii=False),flush=True)
    if not report['all_checks_pass']:raise SystemExit(1)

def main():
    if (ROOT/'00_contract/part2_run.json').exists():
        from part2_report_qa import main as current_main
        return current_main()
    return legacy_main()

if __name__=='__main__':main()
