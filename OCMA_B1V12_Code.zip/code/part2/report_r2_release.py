"""Package the read-only R2 report; CURRENT is committed only after complete QA."""
from pathlib import Path
import argparse,ast,hashlib,json,os,re,shutil,subprocess,sys,zipfile
import numpy as np
import pandas as pd
import report_r2 as core

O=core.OUT;R=core.ROOT;C=core.CODE
BUNDLED=Path.home()/'.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'

def pdf_merge():
    # This function is executed by bundled Python solely for neutral PDF handling.
    from pypdf import PdfReader,PdfWriter
    names=[f'Figure{i}' for i in range(3,12)]+[f'Figure_S{i}' for i in range(2,8)]
    writer=PdfWriter();records=[]
    for name in names:
        p=O/'figures'/f'{name}.pdf';reader=PdfReader(p);assert len(reader.pages)==1
        page=reader.pages[0];w,h=float(page.mediabox.width),float(page.mediabox.height)
        writer.add_page(page);writer.add_outline_item(name,len(records))
        svg=(O/'figures'/f'{name}.svg').read_text('utf8');vw=float(re.search(r'<svg[^>]*width="([\d.]+)pt"',svg).group(1));vh=float(re.search(r'<svg[^>]*height="([\d.]+)pt"',svg).group(1))
        records.append(dict(figure=name,width_pt=w,height_pt=h,svg_pdf_ratio_difference=abs(vw/vh-w/h)))
    out=O/'B1_V1.2_Figure3-11_and_supplements_R2.pdf'
    with out.open('wb') as f:writer.write(f)
    merged=PdfReader(out)
    for i,row in enumerate(records):
        p=merged.pages[i];row['merge_width_error_pt']=float(p.mediabox.width)-row['width_pt'];row['merge_height_error_pt']=float(p.mediabox.height)-row['height_pt']
        if max(abs(row['merge_width_error_pt']),abs(row['merge_height_error_pt']))>1e-6:raise ValueError('PDF page geometry altered')
    compare=PdfWriter()
    for n in range(3,12):
        old=(core.PART1/'Figure4_updated.pdf') if n==4 else core.R1/'figures'/f'Figure{n}.pdf'
        for label,p in [('R1 previous',old),('R2 current',O/'figures'/f'Figure{n}.pdf')]:
            page=PdfReader(p).pages[0];compare.add_page(page);compare.add_outline_item(f'Figure{n}: {label}',len(compare.pages)-1)
    with (O/'Figure3-11_R1_R2_comparison.pdf').open('wb') as f:compare.write(f)
    core.js(dict(merged_pages=len(records),comparison_pages=len(compare.pages),page_records=records,merge_transforms_applied=False,all_page_geometry_retained=True,method='pypdf_direct_add_page_no_rescale',cross_format_note='New R2 pages use fixed physical canvas; frozen exports retain their original text tight-crop metrics.'),O/'PDF_GEOMETRY_QA.json')

def targeted_checks():
    logs=[]
    env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONIOENCODING='utf-8')
    # Dynamic import is isolated and denies filesystem mutation/subprocess creation.
    script="""import sys,json,pathlib,platform
sys.dont_write_bytecode=True
platform.uname()
import numpy,pandas,scipy.optimize,scipy.stats,numba,yaml
sys.path[:0]=[sys.argv[1],sys.argv[1]+'/engine']
def hook(event,args):
 if event=='open' and len(args)>1 and isinstance(args[1],str) and any(x in args[1] for x in 'wax+'):raise RuntimeError('import attempted write: '+str(args[0]))
 if event in ['os.mkdir','os.remove','os.rename','os.rmdir','subprocess.Popen']:raise RuntimeError('import attempted mutation: '+event)
sys.addaudithook(hook)
import importlib
for name in ['run_v12','numeric_analysis','build_policy_interface','part2_tables','state_target_diagnostics','diagnose_targets_v12']:
 importlib.import_module(name)
import build_policy_interface
common,legacy=build_policy_interface.load_legacy_kernels()
assert callable(legacy.build_risk_signal_trace) and callable(legacy.aggregate_signal_counts) and callable(legacy.build_collaboration_history)
print(json.dumps({'imports':'PASS','numerical_calls':0,'input_build_calls':0}))
"""
    p=subprocess.run([sys.executable,'-c',script,str(C)],cwd=O,capture_output=True,text=True,encoding='utf8',env=env)
    logs.append(dict(check='Isolated dynamic imports with mutation denied',returncode=p.returncode,stdout=p.stdout,stderr=p.stderr))
    if p.returncode:
        core.js(logs,O/'ENTRY_DEPENDENCY_FAILED_CHECK.json')
        raise RuntimeError('Dynamic import check failed; '+p.stderr[-2000:])
    for name in ['report_revision_20261029.py','run_v12.py','diagnose_targets_v12.py']:
        p=subprocess.run([sys.executable,str(C/name),'--help'],cwd=R.parents[1],capture_output=True,text=True,encoding='utf8',env=env)
        logs.append(dict(check='CLI help '+name,returncode=p.returncode,stdout=p.stdout,stderr=p.stderr))
        if p.returncode:raise RuntimeError('Help check failed '+name)
    for wd in [R.parents[1],Path(os.environ.get('TEMP',str(O)))]:
        p=subprocess.run([sys.executable,str(C/'report_revision_20261029.py'),'--stage','verify'],cwd=wd,capture_output=True,text=True,encoding='utf8',env=env)
        logs.append(dict(check='Report verify cwd='+str(wd),returncode=p.returncode,stdout=p.stdout,stderr=p.stderr))
        if p.returncode:raise RuntimeError('Cwd independent verification failed '+p.stderr[-1000:])
    core.js(logs,O/'ENTRY_DEPENDENCY_EXECUTION_CHECKS.json')
    tree=ast.parse((C/'run_v12.py').read_text('utf8'))
    stage_map=next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='SCRIPTS' for t in n.targets))
    rows=[]
    for stage,name in stage_map.items():
        path=C/name
        if not path.is_file():raise FileNotFoundError('Retained numerical stage lost its dependency '+stage)
        rows.append(dict(stage=stage,path=str(path),sha256=core.sha(path),validation='EXISTS_AND_AST_PARSE;NOT_EXECUTED'))
    for name in ['sd_common.py','sd_01b_build_strict68_sd_bridge.py']:
        p=R/'00_handoff/historical_code_reference'/name
        rows.append(dict(stage='DYNAMIC_HISTORICAL_PURE_KERNEL',path=str(p),sha256=core.sha(p),validation='ISOLATED_IMPORT_SUCCEEDED;NO_INPUT_BUILD'))
    core.csvout(pd.DataFrame(rows),O/'NUMERICAL_REPRODUCTION_DEPENDENCIES.csv')

def portable_check():
    # The actual unpacked-source replay is recorded separately from numerical reproduction.
    return

def release():
    core.protected();targeted_checks()
    if not BUNDLED.is_file():raise FileNotFoundError('Bundled pypdf runtime unavailable')
    env=dict(os.environ,PYTHONIOENCODING='utf-8')
    p=subprocess.run([str(BUNDLED),str(Path(__file__)),'--pdf-only'],capture_output=True,text=True,encoding='utf8',env=env)
    (O/'PDF_MERGE_LOG.txt').write_text(p.stdout+p.stderr,encoding='utf8')
    if p.returncode:raise RuntimeError('Neutral PDF merge failed '+p.stderr)
    (O/'MANUSCRIPT_REPLACEMENT_LIST.md').write_text('''# Main text and supplement replacements

| Location | Previous wording/display issue | Current replacement and limitation |
|---|---|---|
| Figure3 | Ambiguous state/derived quantities or apparent observed network | Triangular model-defined structure; circles13states,derived boxes; explicit PR/PRS/PRE identity; no institutional-network validation claim |
| Figure4/Table2 | Mixing67stock sources with68texts or Taylor with Bootstrap | Preserve frozen ternary68policies and Figure4Taylor; Table2 retains registered policyBootstrap;67 refers only to independent stock sources |
| Figure5 | Historical series shown as fitted model output |13constructed levels+12adjacent changes; only2023ESis marked as habitat-estimated |
| Figure6 | Repeated forest intervals obscure annual observations | Six point clouds with full/exclude2023rho,n;LOYO stays descriptive in sourceCSV |
| Figure7/Table4 |5km claimed weaker; G2–H replaced by G–ES | G2–H nine settings remainpositive;5km rho≈0.593 exceeds10km≈0.305(all/GradeA);Scope membership and input ranks checked separately;2023endpoints in separate G–EScard |
| Figure8 | Structural signs confused with ablation effect; nonadditivity medians subtracted | Six signedES2030ablation chords; per-vector annual effects andJ; real24×13×13grid; conditional model effects,not empirical causality |
| Figure9 | S5 omitted or uncertainty interpreted as forecast probability | All7medians retained; main600ranges remainFigureS7; annual straight segments |
| Figure10/TableS6 | Only S4−S0attribution or sums of medians treated as closure | Both4-groupS4−S0and3-groupS4−S6minimumESswarms,actual true totals; SR−0.0005shown as−0.5on×10⁻³axis |
| Figure11/TableS5/S16 | Main600,init100,gate12or climate-path counts mixed | Exact sample identities per row/panel; continuation and gate0.40adverse outcome retained; all original specifications shown |
| FigureS4/S5/S7 | Poor fit,weak identification or collection ranges hidden | All states/baselines retained; scans are fixed-other-parameter,not profile-likelihood; seven complete envelopes retained |
| Conclusions | Attractive figures imply predictive reliability | Retain six-of-sevenbaseline failures,conditional initialization ranking,finite SMlocal scope,source proxies and ecological estimate limitations |

Full Word manuscript editing remains deferred. These replacements accompany the existing R1 substantive text; they do not claim that the manuscript has been updated.
''',encoding='utf8')
    # Copy only current report modules and configuration, not numerical caches/venv/old packages.
    packed=O/'05_code';packed.mkdir(exist_ok=True)
    for name in ['report_revision_20261029.py','report_r2.py','report_r2_figures.py','report_r2_release.py','report_result_map.json','report_style.json','code_cleanup_20261029.py']:
        shutil.copy2(C/name,packed/name)
    shutil.copy2(R/'requirements_B1.txt',O/'requirements_numerical_context.txt')
    (O/'requirements_report.txt').write_text('numpy\npandas\nscipy\nmatplotlib\nPyYAML\nopenpyxl\npypdf\n',encoding='utf8')
    core.cleanup_log()
    cleanup=core.table(O/'CODE_CLEANUP_LOG.csv');changed=cleanup[cleanup.before_sha256!=cleanup.after_sha256]
    bounds=json.loads((O/'FIGURE_TEXT_BOUNDS.json').read_text('utf8'))
    outside=[r for r in bounds if r['text_outside_page']]
    visual=O/'VISUAL_REVIEW.json'
    if not visual.is_file():raise RuntimeError('Every final figure must be visually inspected before release')
    reviewed=json.loads(visual.read_text('utf8'))
    image_binding=all(core.sha(O/row['path'])==row['sha256'] for row in reviewed.get('pages',[]))
    if not reviewed.get('all_final_pages_reviewed') or not image_binding or outside:raise ValueError('Figure review incomplete / text outside page '+str(outside))
    q=core.table(O/'REPORT_QA.csv')
    if not q.passed.all():raise RuntimeError('Current report QA failed')
    core.js(dict(report_complete=True,numerical_run=core.RUN,formal_numerical_changed=False,new_ode_calls=0,new_optimizer_calls=0,new_simulations=0,
      original_diagnostic_SM72_reused=True,original_gate216_reused=True,original_init100_reused=True,checks=len(q),actual_deleted_files=int((cleanup.action=='DELETE_FILE').sum()),
      changed_or_added_files=len(changed),Word_full_text_updated=False,submission_readiness_not_inferred=True,isolated_fixed_parameter_replay='NOT_NEEDED_REPORT_LAYER_ONLY;NONE_EXECUTED'),O/'REPORT_STATUS.json')
    (O/'R2_DELIVERY_SUMMARY.md').write_text(f'''# 本轮R2实际交付

正式数值运行仍为 `{core.RUN}`。M3十二参数、最佳点、主600参数、原输入、情景、机制、Shapley及R1诊断结果保持。
本轮新增ODE、优化器、校准、抽样及联盟计算次数均为0；72条SM、216门控单元和100组初始化结果均为复用。

实际删除活动目录的R1专用PDF脚本和工作簿构建器；移除build_evidence不可达的旧缺口/空表分支、
legacy_main九参数诊断、legacy_terms重复目标式及R1被替代的绘图/发布实现。
保留正式run_v12、M0/M1/M2比较实现、输入构建、回放、测试及确有依赖的历史纯函数。
代码与说明逐项差异、删除前后哈希、恢复位置及未查清依赖见CODE_CLEANUP_LOG.csv。
原M0进度说明已从当前PROGRESS移至快照；历史失败结果与原manifest未改写。

Figure3三角机制图；4冻结三元图/Taylor区间；5年度轨迹+变化色带；6六面板原始关联散点；
7气泡矩阵+精确结果卡；8有向剔除弦图+热图+逐参数联合J+真实三维网格；
9七情景中位轨迹；10雨云配对差+两组Shapley蜂群；11规格矩阵+100组初始化散点+12组门控矩阵。
FiguresS2–S7沿用R1有效导出。Table2冻结HT/政策Bootstrap数据另附，不能和Figure4的Taylor区间互换。

当前报告核验{len(q)}项通过；工作簿按实际20页、9543数据单元格完整回读而非以数量作为通过门槛。
实际执行了语法、CLI帮助、隔离动态导入及历史纯函数加载、项目根与其他cwd报告核验、
原数值哈希、逐轨迹最低值后配对、逐参数Shapley闭合/端点、逐参数联合J及年度/终点效应一致性。
没有执行固定参数数值回放，因为本轮没有改动数值公共计算路径。
所有最终15张单图已通过PNG视觉核查；合集直接合并原PDF页，不做拉伸。

G2–H九设置保留。当前全体政策均为A级，不能把二者视为独立验证；10/20km的H、TF、ES值有差异，
但H/ES相关排序一致，解释相同Spearman，而不是错误声称所有数组相同。

报告完成不提升模型预测资格。六个基础状态仍不能同时优于全部简单基准；初始化依赖、负贡献、
稀弱识别、来源代理和2023估计均保留。Word全文仍暂缓，仅提供图注、替换清单和证据对应。
本包可复建图表，不是包含所有原始载体的新机完整校准包。原数值代码快照和历史核函数依赖有本地索引。
''',encoding='utf8')
    # Table rows supplement the per-panel figure map without recomputation.
    fmap=core.table(O/'FIGURE_TABLE_DATA_MAP.csv');fmap=fmap[fmap.panel_id!='table']
    table_rows=[]
    for f in (O/'tables').glob('*_source.csv'):
        table_rows.append(dict(artifact_id=f.stem.replace('_source',''),panel_id='table',source_file=f.relative_to(O).as_posix(),source_hash=core.sha(f),run_id=core.RUN,filter_rule='EXACT_R1_RECONCILED_SOURCE_TABLE_REUSE',metric_definition='see actual column names',aggregation_order='UNCHANGED_R1_TABLE_DEFINITION',parameter_population='see original actual n fields',year_range='TABLE_SPECIFIC',display_unit='ORIGINAL_UNITS',interval_identity='TABLE_SPECIFIC_NOT_INTERCHANGEABLE',output_file='B1_V1.2_PART2_R2_results.xlsx'))
    core.csvout(pd.concat([fmap,pd.DataFrame(table_rows)],ignore_index=True),O/'FIGURE_TABLE_DATA_MAP.csv')
    # Do not bundle bulky historical snapshots: retain precise local restore index and hashes.
    files=[]
    for base,dirs,names in os.walk(O,followlinks=False):
        dirs[:]=[d for d in dirs if d not in ['archive_before_cleanup','__pycache__','portable_replay'] and not (Path(base)/d).is_symlink()]
        for name in names:
            p=Path(base)/name
            if name in ['REPORT_MANIFEST.json'] or p.suffix=='.zip':continue
            files.append(dict(path=p.relative_to(O).as_posix(),bytes=p.stat().st_size,sha256=core.sha(p)))
    original=json.loads((O/'PRE_CLEANUP_SNAPSHOT.json').read_text('utf8'))
    core.js(dict(report_revision='R2_FIGURE_CLEANUP_20261029',numerical_run=core.RUN,original_numerical_manifest_sha256=original['original_current']['manifest_sha256'],
        original_numerical_source=str(core.R1/'archive_pre_revision'),report_source_code='05_code',report_code_was_original_calibration_code=False,
        restoration_snapshot_index='PRE_CLEANUP_SNAPSHOT.json',archive_in_zip=False,archive_local_path=str(O/'archive_before_cleanup'),files=files),O/'REPORT_MANIFEST.json')
    zip_path=R.parents[1]/'outputs/B1_V1.2_PART2_R2_代码清理与图表更新_20261029.zip';temp=zip_path.with_suffix('.tmp')
    with zipfile.ZipFile(temp,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for rec in files:z.write(O/rec['path'],rec['path'])
        z.write(O/'REPORT_MANIFEST.json','REPORT_MANIFEST.json')
    with zipfile.ZipFile(temp) as z:
        if z.testzip() is not None:raise ValueError('ZIP CRC failed')
        for rec in files:
            if hashlib.sha256(z.read(rec['path'])).hexdigest()!=rec['sha256']:raise ValueError('ZIP member SHA mismatch '+rec['path'])
    os.replace(temp,zip_path)
    # Atomic CURRENT update after complete files, report checks and checked ZIP exist.
    pointer=R.parent/'PART2_CURRENT.json';cur=json.loads(pointer.read_text('utf8'))
    cur.update(report_revision='R2_FIGURE_CLEANUP_20261029',current_report_directory=str(O),report_manifest=str(O/'REPORT_MANIFEST.json'),report_manifest_sha256=core.sha(O/'REPORT_MANIFEST.json'),report_code_used_in_original_calibration=False)
    tmp=pointer.with_suffix('.tmp');core.js(cur,tmp);os.replace(tmp,pointer)
    core.js(dict(path=str(zip_path),bytes=zip_path.stat().st_size,sha256=core.sha(zip_path),CRC_pass=True,member_SHA256_pass=True,entries=len(files)+1),zip_path.with_name(zip_path.stem+'_QA.json'))
    print('Released read-only report:',len(files),'files; CURRENT atomically updated',flush=True)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--pdf-only',action='store_true');a=ap.parse_args()
    if a.pdf_only:pdf_merge()
