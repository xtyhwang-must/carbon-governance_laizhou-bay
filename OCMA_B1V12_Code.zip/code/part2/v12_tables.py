"""Editable English three-rule Word tables from the frozen B1 v1.2 CSVs."""
from __future__ import annotations
from pathlib import Path
import pandas as pd
from docx import Document
from docx.shared import Inches,Pt
from docx.shared import RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'07_publication/tables'

def edge(table,which='top',val='single',size='9'):
    tbl_pr=table._tbl.tblPr
    borders=tbl_pr.first_child_found_in('w:tblBorders')
    if borders is None:
        borders=OxmlElement('w:tblBorders');tbl_pr.append(borders)
    el=borders.find(qn('w:'+which))
    if el is None:el=OxmlElement('w:'+which);borders.append(el)
    el.set(qn('w:val'),val);el.set(qn('w:sz'),size)
    el.set(qn('w:color'),'000000')

def bottom_cell(cell,size='6'):
    tc_pr=cell._tc.get_or_add_tcPr()
    borders=tc_pr.first_child_found_in('w:tcBorders')
    if borders is None:borders=OxmlElement('w:tcBorders');tc_pr.append(borders)
    e=OxmlElement('w:bottom');e.set(qn('w:val'),'single');e.set(qn('w:sz'),size)
    e.set(qn('w:color'),'000000');borders.append(e)

def font_all(doc):
    normal=doc.styles['Normal'];normal.font.name='Times New Roman';normal.font.size=Pt(10.5)
    normal._element.rPr.rFonts.set(qn('w:eastAsia'),'Times New Roman')
    for section in doc.sections:
        section.top_margin=Inches(.8);section.bottom_margin=Inches(.8)
        section.left_margin=Inches(.67);section.right_margin=Inches(.67)

def make_table(doc,columns,records):
    table=doc.add_table(rows=1,cols=len(columns));table.autofit=True
    for i,value in enumerate(columns):
        c=table.rows[0].cells[i];c.text=str(value);c.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
        bottom_cell(c)
        for p in c.paragraphs:
            p.alignment=WD_ALIGN_PARAGRAPH.CENTER
            for run in p.runs:run.bold=True;run.font.name='Times New Roman';run.font.size=Pt(10.5)
    table.rows[0]._tr.get_or_add_trPr().append(OxmlElement('w:tblHeader'))
    for rec in records:
        cells=table.add_row().cells
        for i,value in enumerate(rec):
            cells[i].text=str(value)
            cells[i].vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
            for p in cells[i].paragraphs:
                p.alignment=WD_ALIGN_PARAGRAPH.LEFT if i==0 else WD_ALIGN_PARAGRAPH.CENTER
                for run in p.runs:run.font.name='Times New Roman';run.font.size=Pt(10.5)
    edge(table,'top','single','9');edge(table,'bottom','single','9')
    for typ in ['left','right','insideH','insideV']:edge(table,typ,'nil','0')
    return table

def legacy_main():
    OUT.mkdir(parents=True,exist_ok=True)
    policy=pd.read_csv(ROOT/'02_policy/reconstructed/annual_policy_interface_B1.csv')
    phase=[]
    for name,g in policy.groupby('phase',sort=True):
        g=g.sort_values('year')
        phase.append({'Phase':name,'New policies':int(g.new_policy_count.sum()),
            'Active at phase end':int(g.active_policy_count.iloc[-1]),
            'Response share median':float(g.active_explicit_governance_response_proxy_policy_share_all_formal.median()),
            'Joint share median':float(g.stock_network_joint_issue_policy_share.median()),
            'Vertical share median':float(g.stock_network_vertical_relation_weight_share.median()),
            'Synergy median':float(g.stock_network_synergy_equal_event_share.median())})
    phase=pd.DataFrame(phase)
    phase.to_csv(OUT/'Table_2_Panel_B_source.csv',index=False,encoding='utf-8-sig')
    summary=pd.read_csv(ROOT/'06_runs/formal_main/scenarios/scenario_summary.csv')
    screening=pd.read_csv(ROOT/'06_runs/formal_main/scenarios/social_screen_summary.csv')
    metrics=pd.read_csv(ROOT/'06_runs/formal_main/scenarios/scenario_metrics_by_parameter.csv')
    paired=metrics.pivot(index='parameter_set_id',columns='scenario',values='min_ES_2026_2030')
    rows=[]
    for r in summary.sort_values('scenario').itertuples(index=False):
        delta=float((paired[r.scenario]-paired['S0']).median())*1e4
        rows.append({'Scenario':r.scenario,'Terminal SR screen':'Pass' if r.main_screen_pass else 'Fail',
            'Median min ES 2026–2030':r.min_ES_median,
            'Median ES 2030':r.ES_2030_median,
            'Median Δ min ES vs S0 ×10−4':delta,
            'Rank after screen':int(r.main_rank) if pd.notna(r.main_rank) else '—'})
    table5=pd.DataFrame(rows)
    table5.to_csv(OUT/'Table_5_source.csv',index=False,encoding='utf-8-sig')
    doc=Document();font_all(doc)
    title=doc.add_paragraph(style='Title');title.add_run('B1 Revision Tables')
    title.runs[0].font.name='Times New Roman';title.runs[0].font.color.rgb=RGBColor(0,0,0)
    intro=doc.add_paragraph('Editable table candidates from the same B1 v1.2 input, parameter ensemble, and scenario run. Values are model-conditional and require manuscript wording review.')
    doc.add_paragraph('Table 2 Panel B  Source reconstructed policy and network indicators',style='Heading 1')
    cols=['Phase','New policies','Active at end','Response share','Joint share','Vertical share','Synergy']
    records=[[r['Phase'],r['New policies'],r['Active at phase end'],
        f"{r['Response share median']:.3f}",f"{r['Joint share median']:.3f}",
        f"{r['Vertical share median']:.3f}",f"{r['Synergy median']:.3f}"]
        for r in phase.to_dict('records')]
    make_table(doc,cols,records)
    doc.add_paragraph('Notes. Counts refer to the 68 admitted policy documents. Shares are medians of annual active-policy measures within each phase. Synergy is a text-derived relation proxy; it is not an observed implementation effect.')
    doc.add_page_break()
    doc.add_paragraph('Table 5  Matched scenario outcomes and terminal social screen',style='Heading 1')
    cols=['Scenario','SR screen','Median min ES','Median ES 2030','Δ min ES vs S0 ×10−4','Rank']
    records=[[r['Scenario'],r['Terminal SR screen'],f"{r['Median min ES 2026–2030']:.5f}",
        f"{r['Median ES 2030']:.5f}",f"{r['Median Δ min ES vs S0 ×10−4']:.2f}",r['Rank after screen']]
        for r in table5.to_dict('records')]
    make_table(doc,cols,records)
    doc.add_paragraph('Notes. The screen uses the across-parameter median of SR(2030) minus S0 SR(2030), with tolerance −0.0005. Each annual minimum is taken within a trajectory over 2026–2030 before pairing. Ranks follow the screen, median minimum ES, then ES(2030). The 0.0005 ES distinguishability tolerance and cross-specification checks are reported in the companion CSVs; rank numbers alone do not establish a robust policy winner.')
    path=OUT/'B1_v12_editable_results_tables.docx';doc.save(path)
    print({'table2_rows':len(phase),'table5_rows':len(table5),'docx':str(path)},flush=True)

def main():
    if (ROOT/'00_contract/part2_run.json').exists():
        from part2_tables import main as current_main
        return current_main()
    return legacy_main()

if __name__=='__main__':main()
