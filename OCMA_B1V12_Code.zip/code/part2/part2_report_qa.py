"""Independent Part2 invariants; failures do not get converted to quality approval."""
from pathlib import Path
import sys,json,hashlib,tempfile
import numpy as np,pandas as pd
ROOT=Path(__file__).resolve().parents[1];sys.path[:0]=[str(ROOT/'05_code/engine'),str(ROOT/'05_code')]
import sd_model as m,engine_config as cfg
import numeric_analysis as na
from revised_core import simple_baselines,adjacent_differences
from v12_scenario_summary import test_definitions
from cache_safety import ChunkCache
OUT=ROOT/'06_runs/formal_main/qa';OUT.mkdir(parents=True,exist_ok=True)
def main():
 checks=[]
 def check(n,v,kind='REAL_DATA'):checks.append(dict(check=n,passed=bool(v),identity=kind))
 contract=json.loads((ROOT/'00_contract/part2_run.json').read_text('utf8'));sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
 check('Part1 all protected files unchanged',all(sha(p)==h for p,h in contract['frozen_part1_files'].items()))
 f=pd.read_csv(ROOT/'03_indicators/model_input_B1.csv');stock=pd.read_csv(ROOT/'02_policy/reconstructed/policy_stock_by_year_B1.csv');ht=pd.read_csv(ROOT/'01_sources/part1_current/G_POLICY_DESCRIPTIVE_68.csv');dates=pd.read_csv(ROOT/'02_policy/reconstructed/policy_validity_decisions.csv');j=ht.merge(dates,on='policy_id',validate='one_to_one')
 check('13 unique input years and all finite basic states',f.year.tolist()==list(range(2011,2024)) and np.isfinite(f[cfg.STATE_NAMES]).all().all())
 check('SC AC identical',np.allclose(f.SC,f.AC))
 for g,k in cfg.CONTRACT['policy']['K'].items():
  z=stock[stock.channel.eq(g)].sort_values('year');independent=[]
  for y in z.year:
   sel=j[j.independent_stock_policy&j.stock_start_year.le(y)&j.future_exposure_end_year.ge(y)];independent.append(sum(float(v) for v in sel[g+'_HT_share']))
  check('Independent HT stock '+g,np.allclose(independent,z.active_valid_policy_stock,atol=1e-11))
  check('Stock identity '+g,np.max(abs(np.diff(z.active_valid_policy_stock)-z.new_effective_admissions.to_numpy()[1:]+z.exits_at_transition.to_numpy()[1:]))<1e-10)
  check('History and stock mapping '+g,np.allclose(f[g],z.set_index('year').loc[f.year,'G_observed_supply']))
 check('68 texts 67 independent sources',len(j)==68 and j.independent_stock_policy.sum()==67)
 check('No fabricated qualified clause totals in HT composition','qualified_action_units' not in pd.read_csv(ROOT/'02_policy/reconstructed/policy_function_shares_HT.csv'))
 # In-process input substitution detects stale projection constants without mutating real data.
 original=na.STOCK
 with tempfile.TemporaryDirectory() as temp:
  altered=stock.copy();altered.loc[altered.channel.eq('G1'),'active_valid_policy_stock']+=1.;p=Path(temp)/'stock.csv';altered.to_csv(p,index=False)
  x=na.projection_constants()['G1'][0];na.STOCK=p;y=na.projection_constants()['G1'][0];na.STOCK=original
  check('Projection responds to changed contents in same process',np.isclose(y-x,1),'SYNTHETIC_SUBSTITUTED_STOCK')
 check('Explicit 2011 initial exact',np.allclose(m.initial_state(f,year=2011),f[f.year.eq(2011)][cfg.STATE_NAMES].iloc[0]))
 check('Explicit 2023 initial exact',np.allclose(m.initial_state(f.sample(frac=1,random_state=4),year=2023),f[f.year.eq(2023)][cfg.STATE_NAMES].iloc[0]))
 failed=0
 for bad in [f[f.year.ne(2023)],pd.concat([f,f[f.year.eq(2023)]])]:
  try:m.initial_state(bad,year=2023)
  except ValueError:failed+=1
 check('Missing duplicate year rejected',failed==2,'SYNTHETIC_NEGATIVE_CASES')
 baseline=simple_baselines(np.array([2011,2020]),np.array([.1,.9]),np.array([2021,2022,2023]));check('Endpoint drift bounded and accurately named',np.allclose(baseline['training_endpoint_drift'],[.9888888888888889,.999,.999]),'SYNTHETIC_BASELINE')
 check('Differences cannot bridge gaps',not adjacent_differences(f[f.year.ne(2015)],['G1']).year.isin([2015,2016]).any())
 check('Paired extrema and terminal screen definitions',all(test_definitions().values()),'SYNTHETIC_DIFFERENT_EXTREMA')
 ses=pd.read_csv(ROOT/'06_runs/ses/SES_states_2011_2023.csv');check('SES observation rows preserve calendar order and endpoints',all(np.allclose(ses[c],f[c],atol=1e-14) for c in cfg.STATE_NAMES))
 trends=pd.read_csv(ROOT/'06_runs/ses/state_trends_and_endpoints.csv');err=0.
 for row in trends.itertuples():
  values=ses[row.state].to_numpy();years=ses.year.to_numpy();slopes=[(values[j]-values[i])/(years[j]-years[i]) for i in range(len(values)) for j in range(i+1,len(values))]
  err=max(err,abs(float(np.median(slopes))-row.Theil_Sen),abs(values[0]-row.initial),abs(values[-1]-row.terminal))
 check('Independent pairwise median slopes and endpoints',err<1e-12)
 cal=json.loads((ROOT/'06_runs/formal_main/calibration/formal_calibration_status.json').read_text('utf8'));ens=pd.read_csv(ROOT/'06_runs/formal_main/calibration/accepted_parameter_ensemble.csv');check('Actual parameter count/range/unique vectors',len(ens)<=cfg.CONTRACT['calibration']['propagation_max'] and not ens[m.parameter_names(cal['structure'])].duplicated().any())
 attr=json.loads((ROOT/'06_runs/formal_main/attribution/attribution_status.json').read_text('utf8'));check('All coalition endpoints and closure',attr['all_endpoints_match'] and attr['max_closure_error']<1e-10)
 # Dummy zero effect groups stay allowed; all actual differences must still be covered.
 from v12_attribution import shapley
 coal=pd.DataFrame({'coalition_mask':range(4),'metric':[0.,1.,0.,1.]});phis=shapley(coal,['active','zero'],'metric');check('Null group Shapley allowed',abs(dict(phis[1])['zero'])<1e-12 and abs(phis[0]-1)<1e-12,'SYNTHETIC_NULL_FACTOR_FUNCTION_EXECUTED')
 numeric=json.loads((OUT/'numerical_qa_status.json').read_text('utf8'));check('Step-size audit completed',numeric['complete'])
 history=pd.read_csv(ROOT/'06_runs/formal_main/evaluation/historical_ensemble_trajectories.csv');check('Historical free-run finite and bounded',np.isfinite(history[cfg.STATE_NAMES]).all().all() and history[cfg.STATE_NAMES].min().min()>=0 and history[cfg.STATE_NAMES].max().max()<=1)
 yearly=ROOT/'06_runs/formal_main/mechanisms/ablation_annual_trajectories.csv';check('Ablation annual states actually saved',yearly.exists() and set(pd.read_csv(yearly).year)==set(range(2023,2031)))
 eff=pd.read_csv(ROOT/'06_runs/formal_main/mechanisms/ablation_effects_by_parameter.csv');annual=pd.read_csv(ROOT/'06_runs/formal_main/mechanisms/ablation_annual_effects.csv');a=annual[(annual.metric=='ES')&(annual.year==2030)].rename(columns={'link':'disabled_link_spec'});e=eff[eff.metric=='ES_2030'];merged=a.merge(e,on=['parameter_set_id','disabled_link_spec']);check('Annual ES endpoint effects equal metric summaries',np.max(abs(merged.effect-merged.contribution_full_minus_ablated))<1e-10)
 eq=pd.read_csv(ROOT/'04_model/equation_registry.csv');check('Selected intercept equations registered',eq.formula.str.contains('alpha_TF',regex=False).any())
 # Same cache identity reproduces chunks; content mismatch invalidates them.
 with tempfile.TemporaryDirectory() as t:
  c=ChunkCache(Path(t),'a',{'input':'A'});d=pd.DataFrame({'cache_row_id':['1'],'value':[2.]});c.commit('x',d,['1'],['value']);check('Cache valid block reuse',c.load('x',['1'],['value']) is not None,'SYNTHETIC_CACHE');c2=ChunkCache(Path(t),'a',{'input':'B'});check('Same ID changed contents rejected',c2.load('x',['1'],['value']) is None,'SYNTHETIC_CACHE');check('Incomplete cache no COMPLETE',not c.complete.exists(),'SYNTHETIC_CACHE')
 result={'checks':checks,'all_checks_pass':all(x['passed'] for x in checks),'qa_scope':'THIS_RUN_REAL_AND_SYNTHETIC_DISTINGUISHED','model_reliability_inferred_from_QA':False}
 (OUT/'qa_report.json').write_text(json.dumps(result,indent=2),'utf8');print(json.dumps({'checks':len(checks),'passed':result['all_checks_pass']}))
 if not result['all_checks_pass']:raise SystemExit(1)
if __name__=='__main__':main()
