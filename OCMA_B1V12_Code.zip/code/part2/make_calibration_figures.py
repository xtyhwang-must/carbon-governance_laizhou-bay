"""Source-grounded parameter spread and local training-loss profile figures."""
from __future__ import annotations
import json,sys
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib as mpl
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'05_code/engine'),str(ROOT/'05_code')]
import numeric_calibration as cal
import engine_config as cfg
from revised_core import parameter_diagnostics

OUT=ROOT/'06_runs/B1_v1_1/figures'
SELECT=['r_social','k_governance','k_restore']

def save(fig,name):
    for ext,kw in [('svg',{}),('pdf',{}),('png',{'dpi':450})]:
        fig.savefig(OUT/(name+'.'+ext),bbox_inches='tight',facecolor='white',**kw)
    plt.close(fig)

def main():
    OUT.mkdir(parents=True,exist_ok=True)
    ensemble=pd.read_csv(ROOT/'06_runs/B1_v1_1/calibration/accepted_parameter_ensemble.csv')
    best=json.loads((ROOT/'06_runs/B1_v1_1/calibration/best_parameter_set.json').read_text(encoding='utf-8'))
    if ensemble.empty:raise RuntimeError('No accepted parameters to depict')
    diag=parameter_diagnostics(ensemble,cfg.PARAMETER_BOUNDS)
    diag.to_csv(OUT/'parameter_distribution_source_data.csv',index=False,encoding='utf-8-sig')
    cal.context()
    rows=[];best_vec=np.array([best['parameters'][name] for name in cfg.PARAMETER_NAMES],float)
    baseline=cal.evaluate(best_vec)
    if abs(baseline-best['diagnostics']['loss'])>1e-9:
        raise AssertionError('Figure loss profile does not use the calibrated B1 input and loss')
    for name in SELECT:
        index=cfg.PARAMETER_NAMES.index(name)
        low,high=cfg.PARAMETER_BOUNDS[name]
        for value in np.linspace(low,high,31):
            vec=best_vec.copy();vec[index]=value
            loss=float(cal.evaluate(vec))
            rows.append({'parameter':name,'fixed_others_at_best':True,'value':float(value),
                         'training_loss':loss,
                         'delta_from_best_loss':loss-baseline,
                         'best_value':float(best_vec[index]),'best_loss':float(baseline),
                         'not_a_confidence_interval':True})
    profile=pd.DataFrame(rows)
    profile.to_csv(OUT/'calibration_loss_profile_source_data.csv',index=False,encoding='utf-8-sig')
    mpl.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Arial','DejaVu Sans','sans-serif'],
        'svg.fonttype':'none','pdf.fonttype':42,'font.size':8,'axes.spines.right':False,
        'axes.spines.top':False,'axes.linewidth':.8,'legend.frameon':False})
    names=cfg.PARAMETER_NAMES
    fig,ax=plt.subplots(figsize=(7.3,4.7),constrained_layout=True)
    normalized=[]
    for name in names:
        lo,hi=cfg.PARAMETER_BOUNDS[name]
        normalized.append((ensemble[name].to_numpy(float)-lo)/(hi-lo))
    if len(ensemble)>1 and all(np.std(v)>1e-9 for v in normalized):
        violin=ax.violinplot(normalized,positions=np.arange(len(names)),vert=False,
            showmeans=False,showmedians=False,showextrema=False,widths=.72)
        for i,body in enumerate(violin['bodies']):
            body.set_facecolor('#2b7a78' if i<3 else '#607f99')
            body.set_alpha(.50);body.set_edgecolor('none')
    for i,v in enumerate(normalized):
        q5,q50,q95=np.quantile(v,[.05,.5,.95])
        ax.plot([q5,q95],[i,i],color='#183b45',lw=2.2,solid_capstyle='round')
        ax.scatter([q50],[i],s=23,color='#152d35',zorder=4)
    ax.set_yticks(np.arange(len(names)),names)
    ax.invert_yaxis();ax.set_xlim(-.02,1.02)
    ax.set_xlabel('Position within registered parameter bounds (0–1)')
    ax.set_title('B1 accepted parameter spread',loc='left',fontweight='bold',pad=12)
    ax.text(1.0,1.025,f'n = {len(ensemble)} accepted sets; thick line = P5–P95, dot = median',
            transform=ax.transAxes,ha='right',va='bottom',fontsize=7,color='#4d6068')
    ax.grid(axis='x',color='#dce5e8',lw=.55);ax.set_axisbelow(True)
    for i,name in enumerate(names):
        lo,hi=cfg.PARAMETER_BOUNDS[name]
        ax.text(1.025,i,f'{lo:g}–{hi:g}',va='center',ha='left',fontsize=6.8,color='#657980',clip_on=False)
    save(fig,'B1_parameter_distribution')
    fig,axes=plt.subplots(3,1,figsize=(6.8,6.4),sharex=False,constrained_layout=True)
    fig.suptitle('Local calibration-loss profiles',x=.075,ha='left',fontweight='bold',fontsize=10)
    for ax,name in zip(axes,SELECT):
        data=profile[profile.parameter.eq(name)]
        ax.plot(data.value,data.delta_from_best_loss,color='#2b7a78',lw=1.9)
        ax.axhline(0,color='#8d9aa0',lw=.7)
        ax.axvline(data.best_value.iloc[0],color='#bc6c47',lw=1.,ls='--')
        ax.scatter([data.best_value.iloc[0]],[0],s=18,color='#bc6c47',zorder=3)
        ax.set_ylabel('Δ training loss')
        ax.set_xlabel(name+' (registered units)')
        ax.text(.99,.93,'others fixed at fitted vector',transform=ax.transAxes,
                ha='right',va='top',fontsize=6.8,color='#596970')
        ax.grid(axis='y',color='#e1e8eb',lw=.55);ax.set_axisbelow(True)
    save(fig,'B1_calibration_loss_profiles')
    (OUT/'figure_notes.md').write_text('''# B1 diagnostic figure contract

Core statement: The accepted-set spread and one-at-a-time loss curvature document parameter uncertainty under the fixed B1 training protocol. They do not establish parameter confidence intervals, causal mechanisms, forecast reliability, or the submitted run.

Evidence: distribution uses `accepted_parameter_ensemble.csv`; profiles recompute the actual 2011–2020 loss while holding eight other parameters at the fitted vector. The profile sample is a deterministic 31-point grid for three registered parameters. Figure source tables are the two CSV files in this directory.

Archetype: quantitative diagnostics with a horizontal distribution field and a separate vertical profile stack, visually distinct from trajectory panels. Exports: editable SVG/PDF plus high-resolution PNG; all figure text is English.
''',encoding='utf-8')
    print({'accepted_sets':len(ensemble),'profile_rows':len(profile),'figure_files':6})

if __name__=='__main__':main()
