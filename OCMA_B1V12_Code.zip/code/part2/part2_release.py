"""Release current numerical results and figure/table delivery, with Word text deferred."""
from pathlib import Path
import hashlib,json,zipfile,shutil,sys
import pandas as pd
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'07_publication';RUN=ROOT/'06_runs/formal_main';WS=ROOT.parent

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
 qa=json.loads((RUN/'qa/qa_report.json').read_text('utf8'));assert qa['all_checks_pass']
 cal=json.loads((RUN/'calibration/formal_calibration_status.json').read_text('utf8'));screen=pd.read_csv(RUN/'scenarios/scenario_summary.csv');rank=screen[screen.main_rank.notna()].sort_values('main_rank');pairs=pd.read_csv(RUN/'scenarios/all_pair_tolerance_summary.csv');matrix=pd.read_csv(OUT/'figures/Figure11_source.csv')
 attrs=json.loads((RUN/'attribution/attribution_status.json').read_text('utf8'));numeric=json.loads((RUN/'qa/numerical_qa_status.json').read_text('utf8'))
 identity=json.loads((ROOT/'00_contract/part2_run.json').read_text('utf8'));assert all(sha(p)==v for p,v in identity['frozen_part1_files'].items())
 # Each figure references actual, same-run CSVs, not an obsolete manuscript figure.
 sources={3:'05_code/engine/sd_model.py',5:'06_runs/ses/SES_states_2011_2023.csv',6:'06_runs/ses/associations_and_sensitivities.csv',7:'06_runs/ses/associations_and_sensitivities.csv',8:'06_runs/formal_main/mechanisms/ablation_effects_by_parameter.csv|06_runs/formal_main/mechanisms/ablation_annual_effects.csv|06_runs/formal_main/mechanisms/reciprocal_nonadditivity_annual.csv|06_runs/formal_main/mechanisms/response_surface/response_surface_summary.csv',9:'06_runs/formal_main/scenarios/scenario_trajectories_long.csv',10:'06_runs/formal_main/scenarios/four_primary_paired_differences.csv|06_runs/formal_main/attribution/shapley_summary.csv',11:'07_publication/figures/Figure11_source.csv'}
 maps=[dict(artifact_id='Figure '+str(k),manuscript_location='Part2 graphics; Word text deferred',source_csv=v,definition='Model-defined links' if k==3 else 'Current same-run numerical results',input_sha256=cal['input_sha256'],model_sha256=cal['model_code_sha256'],run_id=identity['run_id'],generator='part2_figures.main',update_action='EXPORTED_SVG_PDF_PNG') for k,v in sources.items()]
 for n,source in [('S2','06_runs/ses/associations_and_sensitivities.csv'),('S3','06_runs/ses/SES_states_2011_2023.csv'),('S4','06_runs/formal_main/evaluation/historical_ensemble_trajectories.csv'),('S5','07_publication/figures/parameter_distribution_source_data.csv|07_publication/figures/calibration_loss_profile_source_data.csv')]:maps.append(dict(maps[0],artifact_id='Figure '+n,source_csv=source,definition='See caption and actual parameter count'))
 for p in (OUT/'tables').glob('*_source.csv'):maps.append(dict(maps[0],artifact_id=p.stem.replace('_source',''),source_csv=str(p.relative_to(ROOT)),generator='export_part2_result_tables.py',update_action='CSV_AND_XLSX_EXPORT'))
 pd.DataFrame(maps).to_csv(OUT/'MANUSCRIPT_ARTIFACT_MAP.csv',index=False,encoding='utf-8-sig')
 caps='''# Figure and table definitions

All graphics are based on B1V12_PART2_HT_20261028. Historical observational series have13 years. Original Part1 Figure4/Table2/S1/S7–S14 remain frozen.

Figure3: model-defined governance–social–ecological directional links, not an observed institutional network. Intercepts are constant target backgrounds, not additional causal arrows.
Figure5: current annual G/SR/ES states;2023 habitat estimated.
Figure6: level n=13 and adjacent-year-change n=12 Spearman associations. Lines show leave-one-year range, not95% confidence intervals.
Figure7: habitat supports share the registered10km reference; policy scopes use the same K.2023 lower/upper bridge endpoints and exclusion are separate sensitivities. Lines show leave-one-year ranges.
Figure8:100-vector directional and reciprocal ablations;24-vector13×13 simulated surface. The contrast effect is(S4full−S0full)−(S4without−S0without). Annual effects, endpoint effects and minima are distinct. Non-additivity is joint minus both singles. Surface axes interpolate the entire S0→S4 governance combination and same-block disturbance amplitude. No empirical ecological threshold or causal policy effect is identified.
Figure9:600-vector main common-climate trajectories; band=P5–P95 across retained vectors, not a validated prediction interval. Disturbance2026–2028.
Figure10:600-vector matched differences and four-group S4−S0 Shapley. MinimumES is taken separately per trajectory before subtraction; SRscreen is median terminal difference≥−0.0005. Ranges=P5–P95. Group medians need not sum to the median total. S4−S6 attribution uses actual G3/tau/feedback groups and is delivered in CSV.
Figure11: A=reporting-only variants;B=fixed-parameter dynamics;C=one finite coder-swap refit point. Climate rows summarize medians across20 paths; main structural/habitat stress tests use100 vectors; extra one-factor/coder fixed-input stress tests use12;Cuses1 refitted point. Values are paired contrasts, not success probabilities. Historical-continuation initialization reverses the S4−S6 point difference within0.0005 tolerance.
FigureS2: current component correlations; leave-one-year ranges.
FigureS3: HT-weighted annual governance and ecological components.
FigureS4: seven basic states, observed/derived values vs continuous2011 free runs. Vertical line separates training and previously viewed conditional retrospective period. Bands are pure parameter ranges.2023 TF/SM are estimated.
FigureS5: accepted-parameter P5/median/P95 within numerical bounds and three one-parameter loss scans with all other parameters fixed. These are not posterior intervals, profile likelihoods or full identification proofs.

Tables1/S1 give definitions and source identity;Table3 gives endpoints and Theil–Sen slopes;Table4 andS3 give descriptive associations and support sensitivities;S2gives executable target and derivative formulas;S4actual12-parameter ranges/spread/boundaries;S5only executed specifications with actual counts;S6matched Shapley;S15model-vs-persistence/endpoint-drift error. Additional sheets preserve all candidate, retrospective, coverage and numerical checks. All quantities are normalized proxies unless otherwise stated. Presentation rounding does not enter ranking or closure.
'''
 (OUT/'FIGURE_TABLE_CAPTIONS.md').write_text(caps,'utf8')
 review=[['R1/R3 ecological boundary','ES is water-quality/habitat support, no carbon measurement','FIGURE_TABLE_CAPTIONS.md'],['R1 aggregation/social construction','reporting-only ES/SR aggregation and weights; component definitions','TableS1_source.csv;TableS5_source.csv'],['R1/R2 source/coding','Frozen Part1 HT and67 independent stock sources','HT_bridge_status.json'],['R1/R2 scale and2023 habitat','Common-reference5/10/20km,2023exclude/lower/upper','Table4_source.csv;TableS3_source.csv'],['R3 short series/model reliability','Free-run retrospective, simple benchmarks,12-parameter finite comparison','TableS15_source.csv;Retrospective_source.csv'],['R3 small scenario differences','Paired minima, tolerances,20climates,continuation initial','Figure11_source.csv;Paired_scenarios_source.csv'],['R2 Figure3 readability','Simplified six model links, no institutional-network revival','Figure3.svg'],['R2 data/code availability','Runtime source/result hashes and actual independent replay','PART2_MANIFEST.json;independent_replay.log'],['R2 abstract/conclusion caution','Word prose deferred by author','NOT_DELIVERED_THIS_ROUND']]
 pd.DataFrame(review,columns=['reviewer_issue','actual_change','evidence']).to_csv(OUT/'reviewer_change_evidence.csv',index=False,encoding='utf-8-sig')
 (OUT/'PATCHLOG.md').write_text('''# 本轮实际更改
HT份额接续冻结期限与67项独立库存；全链重建历史/投影库存、分位数、IM和模型输入。保留可定位文本及条件性关系代理身份。
取消无参数投影缓存；统一持久性/有界首末点漂移；修正整体内部误差选择规则。条件增加TF截距，选定M3(原9参数+AC/SM/TF3截距)。Numba仅加速RK4，经4结构/3开关与Python对照；原方程代码仍可用环境变量B1_SD_BACKEND=python运行。
首次候选缓存写入触及Windows长路径，已加扩展路径并重入，复用五个已完成拟合。保留失败日志。SES统计传参改为副本，修正SciPy临时数组排序对端点/留一输出影响；独立枚举斜率核验。原模型输入和拟合不受此报告修复影响。
实际完成5种子、11600候选、600传播、100×20气候、有无冲击、7主情景、600组匹配归因、100组反馈剔除、24组13×13响应面、额外12组单因素及1个第二编码有限重拟合点。额外规格不参与主模型选择。
本轮步长实际执行.05/.02；没有触发.01。独立目录重建输入并回放一个向量的历史/7情景/16+8联盟，未再次全量优化。
按作者最新指示，Word文字交付暂缓；当前发布仅图表、源数据、代码和计算证据，不把未渲染草稿作为交付物。
''','utf8')
 status={'run_id':identity['run_id'],'runtime':str(ROOT),'numerical_computation_completed':True,'figures_tables_delivered':True,'Word_text_update_deferred_by_author':True,'behavioral_support':'LIMITED; six of seven basic-state median RMSEs fail at least one simple baseline','scenario_scope':'CONDITIONAL; main S4 first, historical-continuation S4-S6 within tolerance and point reversal','model_structure':cal['structure'],'retained_parameters':cal['propagated_count'],'full_manuscript_updated':False,'coding_retrained':False}
 # All numeric inputs and outputs are versioned; large caches are not needed for table inspection.
 sourcefiles=[]
 for folder in ['00_contract','01_sources','02_policy/reconstructed','03_indicators','04_model','05_code']:
  for p in (ROOT/folder).rglob('*'):
   if p.is_file() and '__pycache__' not in p.parts and p.suffix not in ['.pyc','.nbc','.nbi']:sourcefiles.append(p)
 resultfiles=[p for p in (ROOT/'06_runs').rglob('*') if p.is_file() and not any('cache' in part.lower() for part in p.parts)]
 reportfiles=[p for p in OUT.rglob('*') if p.is_file() and not any(x in p.parts for x in ['workbook_build','deferred_word_drafts','table_previews','visual_qa']) and p.name not in ['PART2_MANIFEST.json','PART2_CURRENT.json','README_图表结果与复算.md']]
 manifest={'status':status,'source_files':[{'path':str(p.relative_to(ROOT)),'sha256':sha(p)} for p in sourcefiles],'outputs':[{'path':str(p.relative_to(ROOT)),'sha256':sha(p)} for p in resultfiles+reportfiles],'QA':qa,'numerical_step_QA':numeric,'grouped_attribution':attrs,'scope':'LOCAL_FULL_RUNTIME_RECOMPUTATION_AND_INDEPENDENT_FIXED_VECTOR_REPLAY;NOT_A_NEW_MACHINE_INSTALLATION_TEST'}
 (OUT/'PART2_MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),'utf8');pointer={**status,'manifest_sha256':sha(OUT/'PART2_MANIFEST.json')};(WS/'PART2_CURRENT.json').write_text(json.dumps(pointer,ensure_ascii=False,indent=2),'utf8')
 readme='''# B1 V1.2 第二部分图表结果交付

主结构M3_AC_SM_TF_INTERCEPTS，12参数。HT政策份额接入67项独立政策库存，原始社会/生态/气候观测不变。四候选开发比较、五种子正式校准、候选筛选、历史与回顾评价、七情景、稳健性和归因已实际执行。

请先看更新结果表.xlsx、Figure5–11和FigureS4，再看主路径排序。主路径S4领先，但历史模拟延续初值下S4−S6最低ES差约−0.000419，在0.0005容差内；六个基础状态未同时优于简单基准。不能把更好训练拟合或主路径排序称为已验证预测可靠性。

图形导出SVG/PDF/450dpiPNG；CSV保留完整精度。参数集合范围、审定政策Bootstrap、审核设计区间、气候路径和生境端点各自有不同身份。详细定义及实际n见FIGURE_TABLE_CAPTIONS.md。Word正文按作者要求暂缓，不作为本轮交付。

本地完整工作区，在项目根目录运行：
```powershell
& .\\OCMA_empirical_revision_workspace_B1_20261026\\.venv\\Scripts\\python.exe .\\OCMA_empirical_revision_workspace_B1_20261026\\p2\\05_code\\run_v12.py --stage all
```
该入口实际各计算阶段已逐阶段执行；此all整串未在发布后重复执行。已有相同依赖可复用缓存。p2/01_sources及旧基准b1是当前部分输入审计/对照依赖；不得仅解压图片包后运行此命令。

轻量QA（已执行）：
```powershell
& .\\OCMA_empirical_revision_workspace_B1_20261026\\.venv\\Scripts\\python.exe .\\OCMA_empirical_revision_workspace_B1_20261026\\p2\\05_code\\run_v12.py --stage report-qa
```
独立p2check重建输入和固定参数回放已经实际执行，日志在p2/logs/independent_input_rebuild.log与independent_replay.log。该回放不是再次全量校准。
'''
 (OUT/'README_图表结果与复算.md').write_text(readme,'utf8')
 # README is written after the initial inventory; bind it explicitly.
 manifest['outputs'].append({'path':str((OUT/'README_图表结果与复算.md').relative_to(ROOT)),'sha256':sha(OUT/'README_图表结果与复算.md')});(OUT/'PART2_MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),'utf8');pointer['manifest_sha256']=sha(OUT/'PART2_MANIFEST.json');(WS/'PART2_CURRENT.json').write_text(json.dumps(pointer,ensure_ascii=False,indent=2),'utf8')
 print(json.dumps(status,ensure_ascii=False))
if __name__=='__main__':main()
