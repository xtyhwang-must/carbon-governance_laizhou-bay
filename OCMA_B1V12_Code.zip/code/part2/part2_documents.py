"""Update latest Part1 working-copy OOXML using current Part2 CSVs, preserving Part1."""
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
from copy import deepcopy
import json,csv,re,hashlib
import pandas as pd,numpy as np
from lxml import etree as E
from docx import Document
from docx.shared import Pt
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'07_publication';SRC=ROOT/'01_sources/part1_current';RUN=ROOT/'06_runs/formal_main'
NS={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main','a':'http://schemas.openxmlformats.org/drawingml/2006/main','r':'http://schemas.openxmlformats.org/officeDocument/2006/relationships','wp':'http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing'};W='{'+NS['w']+'}'
def rd(p):return pd.read_csv(p)
def txt(p):return ''.join(p.xpath('.//w:t/text()',namespaces=NS))
def settext(p,s):
 pr=p.find(W+'pPr');pr=deepcopy(pr) if pr is not None else None
 for x in list(p):p.remove(x)
 if pr is not None:p.append(pr)
 r=E.SubElement(p,W+'r');E.SubElement(r,W+'t').text=s

def table(df):
 d=Document();t=d.add_table(rows=1,cols=len(df.columns));t.autofit=True
 for c,n in zip(t.rows[0].cells,df.columns):c.text=str(n)
 for row in df.itertuples(index=False,name=None):
  for c,v in zip(t.add_row().cells,row):c.text=f'{v:.4g}' if isinstance(v,(float,np.floating)) else str(v)
 for row in t.rows:
  E.SubElement(row._tr.get_or_add_trPr(),W+'cantSplit')
  for c in row.cells:
   for p in c.paragraphs:
    p.paragraph_format.space_after=Pt(2);p.paragraph_format.line_spacing=1
    for r in p.runs:r.font.name='Times New Roman';r.font.size=Pt(9)
 E.SubElement(t.rows[0]._tr.get_or_add_trPr(),W+'tblHeader')
 borders=E.SubElement(t._tbl.tblPr,W+'tblBorders')
 for n in ['top','bottom']:
  e=E.SubElement(borders,W+n);e.set(W+'val','single');e.set(W+'sz','8')
 for c in t.rows[0].cells:
  b=E.SubElement(c._tc.get_or_add_tcPr(),W+'tcBorders');e=E.SubElement(b,W+'bottom');e.set(W+'val','single');e.set(W+'sz','6')
 return deepcopy(t._tbl)
def main():
 cal=json.loads((RUN/'calibration/formal_calibration_status.json').read_text('utf8'));structure=cal['structure'];n=cal['propagated_count'];tr=rd(ROOT/'06_runs/ses/state_trends_and_endpoints.csv');ass=rd(ROOT/'06_runs/ses/associations_and_sensitivities.csv');ev=rd(RUN/'evaluation/retrospective_state_summary.csv');sc=rd(RUN/'scenarios/scenario_summary.csv');pairs=rd(RUN/'scenarios/all_pair_tolerance_summary.csv');sh=rd(RUN/'attribution/shapley_summary.csv')
 q=ass[(ass.scope=='FULL_2011_2023')&(ass['mode']=='level')].iloc[:3]
 assoc_text='; '.join(f"{r.state_a}–{r.state_b}: rho={r.rho:.3f}, n={r.n}" for r in q.itertuples())
 best=sc[sc.main_rank.notna()].sort_values('main_rank').iloc[0]
 summary=f'All annual quantities use the same HT-weighted governance input. Over 2011–2023, {assoc_text}. These are bay-scale temporal correspondences with short and mixed-support series; leave-one-year ranges and annual-change analyses are reported separately (Figs. 5–7; Tables 3–4). Habitat in 2023 is a bridge estimate, and excluding it does not create additional observed years.'
 evaltext=f'The finite training-internal comparison selected {structure} under the registered overall seven-state criterion. The specification contains three constant target-background intercepts for AC, SM and TF in addition to the original nine parameters. These are revision assumptions with numeric logit bounds, not independently observed backgrounds. Five fixed seeds were fitted on 2011–2020; {cal["candidate_count"]} candidates were screened, {cal["accepted_before_cap"]} passed the unchanged legacy gates, and {n} were propagated. The best training mean NRMSE was {cal["best_training_mean_NRMSE"]:.3f}, with directional agreement {cal["best_training_direction"]:.3f}. Retrospective 2021–2023 errors and bounded persistence/endpoint-drift benchmarks are given in Table S15. This period had been viewed previously. Pure parameter ranges and residual additions are descriptive and do not establish probability forecast coverage.'
 scenario_text=f'Under the main common climate path, the strict ranking after the terminal social screen placed {best.scenario} first (Fig. 9). Ranking uses each trajectory’s 2026–2030 minimum ES before its 2030 ES endpoint. Matched scenario differences and tolerance diagnostics, rather than separate scenario medians, are reported in Fig. 10. These are conditional scenarios initialized at the observed/derived 2023 state; they do not constitute current forecasts or empirical policy effects. Figure 11 reports specification sensitivity, including climate, habitat endpoints, reporting aggregation and fixed-parameter model switches. Directional ablations and non-additivity in Fig. 8 refer to changes in the S4-minus-S0 contrast, not causal effects identified from observations.'
 methods_ses='Annual governance supply was rebuilt as the sum of active independent policies weighted by their frozen policy-level HT G shares, transformed by S/(S+K) with fixed K=(6.608,6.605,7.936). The corpus contains 68 texts and 67 independent stock sources because the Dongying amendment is not counted twice. Dates and open-expiry conventions are retained from the dated ledger. SP averages population, industrial and agricultural pressure, with grain and meat equally weighted within agriculture; AC (SC in code) averages fiscal and educational capacity. SR=sqrt((1-SP)AC), WQ=((1-NS)(1-OS)(1-BS))^(1/3), H=sqrt(TF SM), and ES=sqrt(WQ H). The frozen 2011–2020 reference scale was retained. Theil–Sen slopes, leave-one-year ranges and Spearman associations were computed from the current annual input. Annual changes require adjacent calendar years. Spatial supports and policy-source scopes are descriptive sensitivities and not county-level causal comparisons.'
 methods_sd=f'The selected {structure} model used explicit 2011 historical initialization and a parameter-specific 2011 reference context. Scenarios reset the state to 2023 while retaining that training reference. DE followed by Powell fitted seven basic states only, with the original nine-parameter regularization unchanged. New intercepts replace target logit backgrounds without resetting observed initial states. Internal development folds trained through 2016/2018 and diagnosed 2017–2018/2019–2020; M0, M1, M2 and the conditional TF-intercept candidate were compared on the same finite budget. Retrospective errors use the training P95-minus-P5 denominator and two within-period annual direction changes. The 0.35 weight applies only to designated estimated 2023 habitat evaluations, with unweighted and excluded-year counterparts. All S0–S6 paths share parameter vectors, initial state, reference and climate; terminal median SR difference versus S0 must be at least -0.0005 before ecological ranking. Grouped Shapley uses four groups for S4–S0 and the three possible differences G3/tau/feedback for S4–S6, allowing null effects. Link ablation effect is (S4full−S0full)−(S4without−S0without); reciprocal non-additivity is the joint effect minus both single effects. Areas are converted using the frozen TF/SM scale ratio. Full equations and numeric bounds are in Table S2 and the executable registry.'
 captions={3:'Figure 3. Conditional governance–society–ecology feedback structure. The revised target backgrounds are constants, not new causal links. Full equations, 2011 training reference and 2023 initialization are given in Table S2.',5:'Figure 5. Same-input annual G, SR and ES states, 2011–2023. Habitat components in 2023 are estimated.',6:'Figure 6. Same-year and adjacent-year-change Spearman associations. Lines show leave-one-year ranges, not 95% confidence intervals; actual n is displayed.',7:'Figure 7. Habitat-support and policy-scope sensitivity using registered reference scales. Lines are leave-one-year ranges; 2023 bridge estimates are treated separately.',8:'Figure 8. Fixed-parameter link ablation. (a) ES2030 directional contrast effects. (b) Annual ES contrast effects. (c) ES2030 joint-minus-single non-additivity. (d) Simulated 13×13 governance-combination/disturbance response surface. Ablation uses 100 parameter vectors and the response surface 24. Effects are conditional S4−S0 contrast changes, in the displayed units; no empirical causal effects or observed ecological thresholds are identified.',9:f'Figure 9. S0–S6 ecological-support scenarios conditional on 2023 initialization and the common climate path. Bands are P5–P95 across {n} retained parameter vectors, not probability prediction intervals. Shading marks the 2026–2028 disturbance.',10:f'Figure 10. Matched minimum-ES differences and grouped Shapley contributions. Parameter-wise minima precede subtraction. Main attribution uses {n} vectors and the same climate, initial state and reference; component medians need not sum to the median total.',11:'Figure 11. Specification sensitivity of the paired S4−S0 minimum-ES contrast. Reporting-only aggregation changes, fixed-parameter stress tests and re-calibrated input comparisons have distinct identities.'}
 changelog=[];maps=[]
 for name,outname,supp in [('Manuscript_PART1_updated.docx','Manuscript_B1_V1.2_PART2_updated.docx',False),('Supplementary_PART1_updated.docx','Supplementary_B1_V1.2_PART2_updated.docx',True)]:
  with ZipFile(SRC/name) as z:parts={k:z.read(k) for k in z.namelist()}
  xml=E.fromstring(parts['word/document.xml']);body=xml.find(W+'body');ps=body.findall(W+'p');tables=body.findall(W+'tbl')
  def change(p,new):changelog.append(dict(document=outname,before=txt(p),after=new));settext(p,new)
  if not supp:
   # Clear only prose inside updated sections; preserve all drawings, captions, equations and tables.
   mode=None;first={}
   for p in ps:
    t=txt(p).strip()
    if re.match(r'3\.2\.2\.',t):mode='methods_ses';continue
    if re.match(r'3\.2\.3\.',t):mode='methods_sd';continue
    if re.match(r'4\.2\.',t):mode='ses';continue
    if re.match(r'4\.3\.',t):mode='eval';continue
    if re.match(r'4\.4\.',t):mode='scenario';continue
    if re.match(r'(4\.|5\.|References)',t):mode=None
    if mode and t and not t.startswith(('Figure ','Table ')) and not p.xpath('.//a:blip|.//m:oMath',namespaces={**NS,'m':'http://schemas.openxmlformats.org/officeDocument/2006/math'}):
     text={'methods_ses':methods_ses,'methods_sd':methods_sd,'ses':summary,'eval':evaltext,'scenario':scenario_text}[mode] if mode not in first else ''
     first[mode]=True;change(p,text)
   for p in ps:
    t=txt(p).strip()
    if t in [methods_ses,methods_sd,summary,evaltext,scenario_text]:continue
    match=re.match(r'Figure (\d+)\.',t)
    if match and int(match.group(1)) in captions:change(p,captions[int(match.group(1))])
    elif t.startswith('Blue carbon governance depends'):change(p,f'Blue-carbon governance in Laizhou Bay was examined using formal policies, annual social–ecological indicators and a conditional system dynamics model. Frozen policy-level HT compositions were connected to dated, independent policy stocks. Annual governance, social resilience and ecological support showed weak temporal correspondence across 13 observations. Finite training-internal comparisons selected a model with constant AC, SM and TF target backgrounds, followed by five-seed calibration and propagation of {n} retained parameter vectors. Retrospective performance remained limited and was compared with persistence and endpoint-drift benchmarks. Under the main common disturbance path, {best.scenario} ranked first after the terminal social screen; paired differences, structural stress tests, coder sensitivity and climate paths qualified that ordering. Matched factorial attribution and feedback ablation describe model-conditional contributions. The results concern documented governance supply and water-quality/habitat support, rather than observed implementation, carbon stocks or causal policy effects. The framework provides a reproducible basis for comparing conditional pathways while exposing the consequences of data support and modelling assumptions.')
    elif any(term in t for term in ['S4','73.6%','44.2%','largest median contribution','predicted 2030 endpoint']):
     sentences=re.split(r'(?<=[.!?])\s+',t);kept=[];replaced=False
     for sentence in sentences:
      if any(term in sentence for term in ['S4','73.6%','44.2%','largest median contribution','predicted 2030 endpoint']):
       if not replaced:kept.append('The current conditional pathway ranking and matched contribution estimates are reported in Figs. 9–11; retrospective errors and sensitivity qualify their interpretation.');replaced=True
      else:kept.append(sentence)
     change(p,' '.join(kept))
   # Main tables 1,3,4; preserve existing Table2 XML exactly.
   variable=pd.DataFrame([['G1–G3','HT-share-weighted active independent stocks','Fixed K; formal supply proxy'],['SP','Population, real industry, grain/meat','Frozen 2011–2020 scale'],['AC / SC','Fiscal and education','SC is code alias'],['SR','sqrt((1-SP) AC)','Constructed resilience proxy'],['WQ','NS,OS,BS complement geometric mean','Mixed water-quality support'],['TF / SM','10-km habitat, 2023 bridge estimate','Frozen area reference'],['ES','sqrt(WQ sqrt(TF SM))','Ecological support, not carbon'],['PPT / RUNOFF / SST','Annual climate / modeled runoff','External forcing; not river loads']],columns=['Variable','Definition / source','Identity'])
   body.replace(tables[0],table(variable));body.replace(tables[2],table(tr[tr.state.isin(['G','SR','ES'])][['state','initial','terminal','net_change','Theil_Sen','loo_min','loo_max']]))
   ss=ass[(ass['mode']=='level')&(ass.state_a=='G')&(ass.state_b=='ES')][['scope','n','rho','loo_min','loo_max']];body.replace(tables[3],table(ss))
  else:
   variable=pd.DataFrame([['Governance','sum(active × independent × HT_share)/(stock+K)','Formal supply,67 independent stocks'],['eta / feedback','Frozen located-text response/risk proxies','Not measured implementation/effect'],['synergy','Conditional relation-declaration proxy','Not revalidated network'],['SP / AC / SC','Population/industry/agriculture; fiscal/education','SC equals AC'],['WQ / H / ES / SR','Registered geometric formulas','Not carbon stock or causal resilience'],['Initial/reference','2011 train reference;2023 scenario initial','Explicit independent roles']],columns=['Component','Definition','Evidence / support'])
   eq=rd(ROOT/'04_model/equation_registry.csv');eq=eq[eq.variable.isin(['sc_signal','sm_signal','tf_signal','dsc','dsm','dtf','dim','dg'])].copy();eq['formula']=eq.formula.str.replace('baseline','b').str.replace('params','p');eq=eq[['variable','formula']]
   # Long executable formulas remain machine-readable; Word gives explicit structural form.
   eqtable=pd.DataFrame([['AC target','logistic(alpha_AC + k_adaptive ΔA3 + .55 ΔH − .78 ΔSP − .20 k_compound Δcompound)'],['SM target','logistic(alpha_SM + 1.20 k_restore ΔA2 − .82 k_natural Δhabitat_driver + .30 k_adaptive ΔAC)'],['TF target','logistic(alpha_TF + k_restore ΔA2 − k_natural Δhabitat_driver + .22 k_adaptive ΔAC)'],['Reference','All Δ terms relative to parameter-specific observed 2011 context; full registry retained'],['Dynamics','dx/dt=adjustment_rate × (target−state); TF/SM conversion added with area ratio'],['Initial','Historical2011; scenario2023; no0.35 blend'],['Bounds','Original9 parameter ranges plus alpha_AC/SM/TF numeric logit(.001) to logit(.999)'],['TF–SM','Conversion=.12 A2 TF(1−SM); SM receives TF_scale/SM_scale times transfer']],columns=['Term','Selected-model equation / definition'])
   body.replace(tables[0],table(variable));body.replace(tables[1],table(eqtable))
   small=ass[['scope','mode','state_a','state_b','n','rho','loo_min','loo_max']];body.replace(tables[2],table(small[(small.scope=='FULL_2011_2023')&(small['mode']=='level')]));body.replace(tables[3],table(small[(small.scope=='FULL_2011_2023')&(small['mode']=='annual_change')]))
   body.replace(tables[4],table(rd(OUT/'Table_S4_parameter_summary.csv')[['parameter','lower','upper','P5','P50','P95','near_1pct_boundary_fraction']]))
   rob=rd(RUN/'robustness/specification_rankings.csv');extra=rd(RUN/'additional_sensitivity/all_additional_metrics.csv');rob=pd.concat([rob,extra],ignore_index=True);sens=rob.groupby('specification_id').agg(parameter_paths=('scenario','size')).reset_index();sens['identity']=np.where(sens.specification_id.str.contains('REFIT'),'LIMITED_REFIT_POINT',np.where(sens.specification_id.str.startswith('REPORTING'),'REPORTING_ONLY','FIXED_PARAMETER_DYNAMICS'));body.replace(tables[5],table(sens))
   body.replace(tables[6],table(sh[['contrast','metric','group','median']]))
   for p in ps:
    t=txt(p)
    if t.startswith('Figure S2.'):change(p,'Figure S2. Same-version G–component Spearman associations with leave-one-year ranges; n=13. Ranges are not 95% confidence intervals.')
    if t.startswith('Figure S3.'):change(p,'Figure S3. Annual HT-weighted governance and ecological-support components from the current unique input.')
    if t.startswith('Figure S4.'):change(p,'Figure S4. Seven-state historical free runs and conditional 2021–2023 retrospective evaluation. Shading is the P5–P95 parameter-set range; dashed line marks the training-period boundary.')
   sect=body.find(W+'sectPr');new=E.Element(W+'p');settext(new,'Table S15. Same-version basic-state model errors and bounded simple baselines; retrospective2021–2023.');body.insert(list(body).index(sect),new);body.insert(list(body).index(sect),table(rd(OUT/'Table_S15_model_vs_baselines.csv')))
  # Replace each relevant original image using caption-to-preceding-image mapping.
  rel=E.fromstring(parts['word/_rels/document.xml.rels']);rels={r.get('Id'):r.get('Target') for r in rel}
  for i,p in enumerate(ps):
   match=re.match(r'Figure (S?)(\d+)\.',txt(p).strip())
   if not match:continue
   pref,num=match.groups();num=int(num)
   if not supp and num not in [5,6,7,8,9,10] or supp and num not in [2,3,4]:continue
   image=next((x for x in reversed(ps[:i]) if x.xpath('.//a:blip',namespaces=NS)),None)
   if image is None:raise ValueError('Caption image not found')
   png=OUT/'figures'/('Figure_S'+str(num)+'.png' if supp else 'Figure'+str(num)+'.png');rid=image.xpath('.//a:blip',namespaces=NS)[0].get('{'+NS['r']+'}embed');target='word/'+rels[rid];parts[target]=png.read_bytes()
   from PIL import Image
   with Image.open(png) as im:ratio=im.height/im.width
   for ext in image.xpath('.//wp:extent|.//a:xfrm/a:ext',namespaces=NS):ext.set('cy',str(int(int(ext.get('cx'))*ratio)))
   maps.append(dict(artifact_id='Figure '+pref+str(num),document=outname,source_csv='see figure source mapping',run_id='B1V12_PART2_HT_20261028',update_action='EMBEDDED_NEW_CURRENT_FIGURE',generator='part2_figures.main'))
  if not supp:
   template=next(p for p in ps if p.xpath('.//a:blip',namespaces=NS));newp=deepcopy(template)
   rid='rIdPART2Figure11';
   for docpr in newp.xpath('.//wp:docPr',namespaces=NS):docpr.set('id',str(max([int(x.get('id','0')) for x in body.xpath('.//wp:docPr',namespaces=NS)]+[0])+1))
   newp.xpath('.//a:blip',namespaces=NS)[0].set('{'+NS['r']+'}embed',rid)
   relnode=E.SubElement(rel,'{http://schemas.openxmlformats.org/package/2006/relationships}Relationship');relnode.set('Id',rid);relnode.set('Type','http://schemas.openxmlformats.org/officeDocument/2006/relationships/image');relnode.set('Target','media/part2_figure11.png')
   imagefile=OUT/'figures/Figure11.png';parts['word/media/part2_figure11.png']=imagefile.read_bytes();parts['word/_rels/document.xml.rels']=E.tostring(rel,xml_declaration=True,encoding='UTF-8',standalone=True)
   from PIL import Image
   with Image.open(imagefile) as im:ratio=im.height/im.width
   for ext in newp.xpath('.//wp:extent|.//a:xfrm/a:ext',namespaces=NS):ext.set('cy',str(int(int(ext.get('cx'))*ratio)))
   discussion=next(p for p in ps if txt(p).strip().startswith('5. Discussion'));pos=list(body).index(discussion);cap=E.Element(W+'p');settext(cap,captions[11]);body.insert(pos,newp);body.insert(pos+1,cap)
  parts['word/document.xml']=E.tostring(xml,xml_declaration=True,encoding='UTF-8',standalone=True)
  with ZipFile(OUT/outname,'w',ZIP_DEFLATED) as z:
   for k,v in parts.items():z.writestr(k,v)
 (OUT/'PART2_DOCUMENT_CHANGE_LOG.json').write_text(json.dumps(changelog,ensure_ascii=False,indent=2),'utf8');pd.DataFrame(maps).to_csv(OUT/'MANUSCRIPT_ARTIFACT_MAP.csv',index=False,encoding='utf-8-sig')
 print('Updated current Part1 copy with Part2 figures/tables/prose; protected Part1 retained')
if __name__=='__main__':main()
