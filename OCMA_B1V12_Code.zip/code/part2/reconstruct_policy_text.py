"""Extract 68 target policy bodies from captured originals and verified attachments.

This is a new text layer. The old candidate clause file is not used as coding.
PDF gazettes and short notices have explicit target-body source choices below.
"""
from __future__ import annotations

import hashlib
import html
import json
from pathlib import Path
import re
import subprocess
import sys
import unicodedata

from bs4 import BeautifulSoup
from charset_normalizer import from_bytes
import pandas as pd
from pypdf import PdfReader

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / '01_sources/policy'
DEST = ROOT / '02_policy/reconstructed'
TEXT_DIR = DEST / 'clean_text'
OFFICIAL_URLS = {
    'NAT_2021_CARBON_PEAK_01':'https://app.www.gov.cn/govdata/gov/202110/26/477466/article.html',
    'NAT_2018_BOHAI_ACTION_01':'https://www.mee.gov.cn/xxgk2018/xxgk/xxgk03/201812/t20181211_684232.html',
    'NAT_2022_AQUATIC_RES_01':'https://app.www.gov.cn/govdata/gov/202212/05/494935/article.html',
}
ATTACHMENT_BODY = {
    'YT_2020_AQ_PLAN_01':'YT_2020_AQ_PLAN_01_ATT01.pdf',
    'WF_2022_AQ_PLAN_01':'WF_2022_AQ_PLAN_01_ATT01.pdf',
}


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def decode(path: Path) -> tuple[str, str]:
    raw = path.read_bytes()
    for enc in ['utf-8-sig','utf-8','gb18030']:
        try:
            return raw.decode(enc),enc
        except UnicodeDecodeError:
            pass
    guess = from_bytes(raw).best()
    if guess is None:
        raise ValueError(f'No text encoding: {path}')
    return str(guess),str(guess.encoding)


def html_text(path: Path) -> tuple[str,str]:
    raw,enc = decode(path)
    soup = BeautifulSoup(raw,'lxml')
    for tag in soup(['script','style','noscript','nav','footer','aside']):
        tag.decompose()
    body = soup.body or soup
    lines = [re.sub(r'\s+',' ',x).strip() for x in body.get_text('\n').splitlines()]
    return '\n'.join(x for x in lines if x),enc


def pdf_text(path: Path, page_range=None) -> tuple[str,int,int,int]:
    reader = PdfReader(path)
    pages = list(page_range) if page_range else list(range(1,len(reader.pages)+1))
    output=[]
    for number in pages:
        text=(reader.pages[number-1].extract_text() or '').replace('\x00','')
        # PDF text layers frequently break a Chinese sentence at visual line
        # boundaries. Join those wraps before making analytic clause units.
        text=re.sub(r'(?<=[\u4e00-\u9fff，,])\n(?=[\u4e00-\u9fff])','',text)
        output.append(f'[PAGE:{number}]\n{text}')
    return '\n'.join(output), len(reader.pages),pages[0],pages[-1]


def doc_text(path: Path, policy_id: str) -> str:
    out=DEST / 'word_text' / (policy_id+'.txt')
    if not out.exists():
        subprocess.run(['powershell','-NoProfile','-File',str(Path(__file__).with_name('extract_legacy_doc.ps1')),
                        '-InputPath',str(path),'-OutputPath',str(out)],check=True,timeout=90)
    return out.read_text(encoding='utf-8')


def json_text(path: Path) -> str:
    data=json.loads(decode(path)[0])
    chunks=[]
    def walk(value):
        if isinstance(value,str) and len(value.strip())>20:
            chunks.append(value)
        elif isinstance(value,dict):
            for item in value.values():walk(item)
        elif isinstance(value,list):
            for item in value:walk(item)
    walk(data)
    return '\n'.join(chunks)


def normalize(text: str) -> str:
    text=unicodedata.normalize('NFKC',text.replace('\r','\n'))
    text=re.sub(r'[ \t\u00a0]+',' ',text)
    text=re.sub(r'\n{3,}','\n\n',text)
    return text.strip()


def segment(body: str, policy_id: str, source_hash: str):
    rows=[]
    offset=0
    page='HTML_OR_TEXT'
    for line in body.splitlines(keepends=True):
        match=re.match(r'\[PAGE:(\d+)\]',line.strip())
        if match:
            page='PDF_PAGE_'+match.group(1)
            offset+=len(line)
            continue
        if not line.strip():
            offset+=len(line)
            continue
        # Break at substantive sentence/semicolon boundaries, not at raw keyword hits.
        pieces=re.split(r'(?<=[。；;!?])',line.rstrip('\n'))
        consumed=0
        for piece in pieces:
            if not piece:
                continue
            clean=piece.strip()
            start=offset+consumed+len(piece)-len(piece.lstrip())
            consumed+=len(piece)
            if len(clean)<2:
                continue
            while len(clean)>1500:
                cut=max(clean.rfind('，',500,1200),clean.rfind(',',500,1200))
                if cut<500:cut=1200
                part=clean[:cut+1].strip()
                if part:
                    rows.append((part,start,start+len(part),page,'LONG_UNIT_SPLIT_AT_COMMA'))
                rest=clean[cut+1:]
                start+=cut+1+len(rest)-len(rest.lstrip())
                clean=rest.lstrip()
            if clean:
                rows.append((clean,start,start+len(clean),page,'SENTENCE_OR_HEADING'))
        offset+=len(line)
    return [{'policy_id':policy_id,'policy_version_id':policy_id+'_CAPTURED_VERSION',
             'unit_id':f'{policy_id}__B1U{i:05d}','source_hash':source_hash,
             'source_location':f'{loc};clean_chars={begin}:{end}',
             'clean_start':begin,'clean_end':end,'exact_evidence_text':text,
             'segmentation_rule':rule}
            for i,(text,begin,end,loc,rule) in enumerate(rows,1)]


def main():
    TEXT_DIR.mkdir(parents=True,exist_ok=True)
    admission=pd.read_csv(SOURCE/'admission_68.csv').set_index('policy_id')
    manifest=pd.read_csv(ROOT/'00_contract/source_manifest.csv').set_index('source_id')
    audits=[];units=[]
    for policy_id,row in admission.iterrows():
        capture=ROOT/manifest.loc['policy_text_'+policy_id,'relative_path']
        assert sha(capture)==manifest.loc['policy_text_'+policy_id,'sha256']
        chosen=capture
        relation='CAPTURED_SOURCE_BODY'
        boundary='entire_record'
        pages=None
        enc='binary_or_doc'
        if policy_id in OFFICIAL_URLS:
            chosen=SOURCE/'official_targeted_retrieval'/(policy_id+'.html')
            assert chosen.exists()
            relation='TARGETED_OFFICIAL_HTML_RETRIEVAL_FROM_CAPTURED_GAZETTE'
            boundary='official_article_body_with_metadata'
        elif policy_id=='EARLY-SHD-2004-25':
            # The captured file is a mislabelled Jiangsu regulation. Use the
            # dated 2004 Shandong original, and retain the mismatch in audit.
            chosen=SOURCE/'official_targeted_retrieval/EARLY-SHD-2004-25_2004_ORIGINAL.pdf'
            relation='CAPTURED_FILE_WRONG_PROVINCE_REPLACED_BY_2004_SHANDONG_TEXT'
            boundary='2004_original_text;later_amendments_version_review_pending'
        elif policy_id in ATTACHMENT_BODY:
            chosen=SOURCE/'attachments'/ATTACHMENT_BODY[policy_id]
            assert chosen.exists()
            relation='CAPTURED_NOTICE_PLUS_OFFICIAL_BACKUP_ATTACHMENT_BODY'
            boundary='attachment_full_text'
        elif policy_id=='YT_2019_COAST_REG_01':
            pages=range(28,35)
            boundary='gazette_pages_28_34_until_next_article'
        if chosen.suffix.lower()=='.html':
            text,enc=html_text(chosen)
        elif chosen.suffix.lower()=='.pdf':
            text,total,first,last=pdf_text(chosen,pages)
            if policy_id=='YT_2019_COAST_REG_01':
                text=text.split('烟台市中级人民法院\n关于办案质量检查情况')[0]
            boundary+=f';pdf_pages_{first}_{last}_of_{total}'
        elif chosen.suffix.lower()=='.doc':
            text=doc_text(chosen,policy_id)
        elif chosen.suffix.lower()=='.json':
            text=json_text(chosen)
        else:
            text,enc=decode(chosen)
        if policy_id=='HT_2018_WETLAND_REPAIR_01':
            # The archived search page contains one complete plain-text body,
            # then a highlighted result list and duplicate escaped HTML.
            marker="<font color='red'>"
            cut=text.find(marker)
            if cut<5000 or '寒亭区湿地保护修复实施方案' not in text[:cut]:
                raise ValueError('Hanting target-body boundary could not be verified')
            text=html.unescape(text[:cut])
            boundary='complete_plain_target_body_before_highlighted_search_results'
        body=normalize(text)
        out=TEXT_DIR/(policy_id+'.txt')
        out.write_text(body,encoding='utf-8')
        title=re.sub(r'\s+','',str(row['政策标题']))
        body_compact=re.sub(r'\s+','',body)
        title_head=title[:min(10,len(title))]
        title_match=title_head in body_compact
        record={'policy_id':policy_id,'publication_year':int(row['publication_year']),
                'expected_title':str(row['政策标题']),'title_head_present':bool(title_match),
                'captured_source_relative_path':capture.relative_to(ROOT).as_posix(),
                'captured_source_sha256':sha(capture),'body_source_relative_path':chosen.relative_to(ROOT).as_posix(),
                'body_source_sha256':sha(chosen),'body_source_relation':relation,
                'body_boundary':boundary,'body_encoding':enc,'clean_text_relative_path':out.relative_to(ROOT).as_posix(),
                'clean_text_sha256':sha(out),'clean_chars':len(body),
                'author_review_status':'PENDING','capture_batch':'2026-10-25'}
        if policy_id in OFFICIAL_URLS:record['body_source_url']=OFFICIAL_URLS[policy_id]
        audits.append(record)
        units.extend(segment(body,policy_id,sha(chosen)))
        print(policy_id,len(body),len(units),relation,flush=True)
    audit=pd.DataFrame(audits)
    assert len(audit)==68 and audit.policy_id.is_unique
    pd.DataFrame(units).to_csv(DEST/'text_units_B1.csv',index=False,encoding='utf-8-sig')
    audit.to_csv(DEST/'text_source_audit.csv',index=False,encoding='utf-8-sig')
    print(json.dumps({'policies':len(audit),'text_units':len(units),'title_head_present':int(audit.title_head_present.sum()),
                      'body_chars':int(audit.clean_chars.sum())},ensure_ascii=False))


if __name__=='__main__':main()
