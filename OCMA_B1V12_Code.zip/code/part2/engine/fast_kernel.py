"""Generated algebra-equivalent scalar/array RK4 kernel; verified against Python rhs."""
import numpy as np
from numba import njit
@njit(cache=True)
def clip(v,low,high):return np.minimum(np.maximum(v,low),high)
@njit(cache=True)
def bounded(v,low=.001,high=.999):return clip(v,low,high)
@njit(cache=True)
def logit(v):
 v=bounded(v);return np.log(v/(1-v))
@njit(cache=True)
def logistic(v):return 1/(1+np.exp(-clip(v,-35.,35.)))
@njit(cache=True)
def hill(v,midpoint=.5,exponent=2.4):
 v=np.maximum(v,0.);n=np.power(v,exponent);return n/(n+midpoint**exponent)
@njit(cache=True)
def reporting_states(s):
 w=((1-s[5])*(1-s[6])*(1-s[7]))**(1/3);h=np.sqrt(s[8]*s[9]);return {'WQ':w,'H':h,'ES':np.sqrt(w*h)}

@njit(cache=True)
def _implementation_potentials(state, forcing, mode):
    """返回操作性实施潜力与能力建设实施潜力。"""
    (g3, sp, sc) = (state[2], state[3], state[4])
    if mode[7]:
        gate = float(hill(sc, mode[12], 2.0))
        sc_factor = mode[13] + (1.0 - mode[13]) * gate
        capacity_factor = 0.25 + 0.75 * gate
    else:
        sc_factor = 1.0
        capacity_factor = 1.0
    operations = forcing[6] * hill(g3, 0.45, 2.2) * sc_factor / (1.0 + 0.75 * sp)
    capacity = forcing[6] * hill(g3, 0.45, 2.2) * capacity_factor / (1.0 + 0.5 * sp)
    return (float(clip(operations, 0.0, 1.0)), float(clip(capacity, 0.0, 1.0)))

@njit(cache=True)
def _actions(state, forcing, params, mode):
    (g1, g2, g3, sp, sc) = state[:5]
    (operations_potential, capacity_potential) = _implementation_potentials(state, forcing, mode)
    implementation_ops = float(clip(state[12], 0.0, 1.0))
    implementation_capacity = float(clip(0.5 * implementation_ops + 0.5 * capacity_potential, 0.0, 1.0))
    synergy = float(np.cbrt(max(g1 * g2 * g3, 0.0)))
    synergy_multiplier = 1.0 + params[10] * forcing[9] * synergy if mode[8] else 1.0
    a1 = implementation_ops * float(hill(g1, 0.45, 2.1)) * synergy_multiplier
    a2 = implementation_ops * float(hill(g2, 0.45, 2.1)) * synergy_multiplier
    a3 = implementation_capacity * float(hill(g3, 0.45, 2.1))
    (a1, a2, a3) = clip(np.array([a1, a2, a3]), 0.0, 1.0)
    return (float(a1), float(a2), float(a3), implementation_ops, implementation_capacity)

@njit(cache=True)
def rhs(time, raw_state, params, forcing, baseline, mode, structure='M0_RUN_SPECIFIC', area_ratio=1.5687953135133381):
    state = bounded(np.asarray(raw_state, dtype=np.float64))
    (g1, g2, g3, sp, sc, ns, os_, bs, tf, sm, pr, prs, im) = state
    exo = forcing
    report = reporting_states(state)
    (wq, habitat, es) = (float(report['WQ']), float(report['H']), float(report['ES']))
    feedback_strength = exo[8] if mode[0] else 0.0
    pre = float(clip((3.0 * pr - prs) / 2.0, 0.0, 1.0))
    feedback_shift = feedback_strength * (1.0 / 3.0 * (prs - baseline[15] if mode[2] else 0.0) + 2.0 / 3.0 * (pre - baseline[14] if mode[4] else 0.0))
    g_targets = clip(np.array([exo[0] + 0.13 * feedback_shift, exo[1] + 0.17 * feedback_shift, exo[2] + 0.21 * feedback_shift]), 0.01, 0.99)
    dg = (g_targets - state[:3]) / 0.18
    action_state = state.copy()
    if not mode[2]:
        action_state[3] = baseline[18]
        action_state[4] = baseline[16]
    (operations_potential, _) = _implementation_potentials(action_state, exo, mode)
    dim = (operations_potential - im) / max(exo[7], 0.25)
    (a1, a2, a3, _, _) = _actions(action_state, exo, params, mode)
    nd = float((exo[3]+exo[4]+exo[5])/3)
    compound = float(np.cbrt(max(exo[3] * exo[4] * exo[5], 1e-09)))
    ecological_risk = float((1.0 - wq + (1.0 - habitat)) / 2.0)
    risk = float((sp + 2.0 * ecological_risk) / 3.0)
    memory_tau = max(params[11], 0.25)
    dpr = (risk - pr) / memory_tau
    dprs = (sp - prs) / memory_tau
    social_feedback_memory = (prs + 2.0 * (pre if mode[6] else baseline[14])) / 3.0
    governance_to_social_a1 = a1 - baseline[0] if mode[1] else 0.0
    governance_to_social_a3 = a3 - baseline[2] if mode[1] else 0.0
    sp_signal = logit(baseline[18]) + params[4] * (social_feedback_memory - baseline[13]) + 0.3 * params[6] * (nd - baseline[8]) + 0.25 * params[9] * (compound - baseline[5]) - params[3] * governance_to_social_a1 - 0.5 * params[5] * (sc - baseline[16])
    sp_target = float(logistic(sp_signal))
    dsp = params[0] * (sp_target - sp)
    sc_signal = (params[12] if structure in ('M1_AC_INTERCEPT', 'M2_AC_SM_INTERCEPTS', 'M3_AC_SM_TF_INTERCEPTS') else logit(baseline[16])) + params[5] * governance_to_social_a3 + 0.55 * (habitat - baseline[6] if mode[6] else 0.0) - 0.78 * (sp - baseline[18]) - 0.2 * params[9] * (compound - baseline[5])
    sc_target = float(logistic(sc_signal))
    dsc = params[0] * (sc_target - sc)
    ecology_sp = sp if mode[5] else baseline[18]
    ecology_sc = sc if mode[5] else baseline[16]
    nutrient_driver = 0.58 * ecology_sp + 0.42 * exo[4]
    governance_to_ecology_a1 = a1 - baseline[0] if mode[3] else 0.0
    governance_to_ecology_a2 = a2 - baseline[1] if mode[3] else 0.0
    ns_signal = logit(baseline[9]) + params[6] * (nutrient_driver - baseline[10]) + params[9] * (compound - baseline[5]) - params[3] * governance_to_ecology_a1
    ns_target = float(logistic(ns_signal))
    dns = params[1] * (ns_target - ns)
    oxygen_driver = 0.34 * ecology_sp + 0.23 * exo[4] + 0.23 * bs + 0.2 * exo[5]
    os_signal = logit(baseline[11]) + 0.82 * params[6] * (oxygen_driver - baseline[12]) + 0.52 * params[9] * (compound - baseline[5]) - 0.78 * params[3] * governance_to_ecology_a1
    os_target = float(logistic(os_signal))
    dos = params[1] * (os_target - os_)
    bloom_trigger = float(hill(ns, 0.48, 3.0)) if mode[9] else ns
    bloom_driver = bloom_trigger * (0.5 * exo[5] + 0.3 * os_ + 0.2 * exo[4])
    bs_signal = logit(baseline[4]) + params[7] * (bloom_driver - baseline[3]) + 0.55 * params[9] * (compound - baseline[5]) - 0.58 * params[3] * governance_to_ecology_a1
    bs_target = float(logistic(bs_signal))
    dbs = params[1] * (bs_target - bs)
    habitat_driver = 0.6 * ecology_sp + 0.4 * compound
    tf_signal = (params[14] if structure=='M3_AC_SM_TF_INTERCEPTS' else logit(baseline[19])) + params[8] * governance_to_ecology_a2 - params[6] * (habitat_driver - baseline[7]) + 0.22 * params[5] * (ecology_sc - baseline[16])
    sm_signal = (params[13] if structure in ('M2_AC_SM_INTERCEPTS','M3_AC_SM_TF_INTERCEPTS') else logit(baseline[17])) + 1.2 * params[8] * governance_to_ecology_a2 - 0.82 * params[6] * (habitat_driver - baseline[7]) + 0.3 * params[5] * (ecology_sc - baseline[16])
    tf_target = float(logistic(tf_signal))
    sm_target = float(logistic(sm_signal))
    tf_rate = params[2] * (1.7 if mode[10] and tf_target < tf else 1.0)
    sm_rate = params[2] * (1.55 if mode[10] and sm_target < sm else 1.0)
    dtf = tf_rate * (tf_target - tf)
    dsm = sm_rate * (sm_target - sm)
    if mode[11]:
        conversion_action = a2 if mode[3] else baseline[1]
        conversion_rate = mode[14] * float(conversion_action)
        conversion_tf_units = conversion_rate * tf * (1.0 - sm)
        conversion_sm_units = area_ratio * conversion_tf_units
        dtf -= conversion_tf_units
        dsm += conversion_sm_units
    derivative = np.array([dg[0], dg[1], dg[2], dsp, dsc, dns, dos, dbs, dtf, dsm, dpr, dprs, dim], dtype=np.float64)
    derivative = np.where((raw_state <= 0.0) & (derivative < 0.0), 0.0, derivative)
    derivative = np.where((raw_state >= 1.0) & (derivative > 0.0), 0.0, derivative)
    return derivative

@njit(cache=True)
def integrate(times,initial,p,baseline,mode,structure,area_ratio,forcing_years,forcing_values,max_step):
 state=initial.copy();out=np.empty((len(times),len(state)));out[0]=state
 for i in range(1,len(times)):
  start=times[i-1];steps=max(1,int(np.ceil((times[i]-start)/max_step)));h=(times[i]-start)/steps
  for j in range(steps):
   t=start+j*h;ex=np.empty((3,forcing_values.shape[1]))
   for k in range(forcing_values.shape[1]):
    for u in range(3):ex[u,k]=np.interp(t+u*.5*h,forcing_years,forcing_values[:,k])
   k1=rhs(t,state,p,ex[0],baseline,mode,structure,area_ratio)
   k2=rhs(t+.5*h,state+.5*h*k1,p,ex[1],baseline,mode,structure,area_ratio)
   k3=rhs(t+.5*h,state+.5*h*k2,p,ex[1],baseline,mode,structure,area_ratio)
   k4=rhs(t+h,state+h*k3,p,ex[2],baseline,mode,structure,area_ratio)
   state=state+h/6*(k1+2*k2+2*k3+k4)
  out[i]=state
 return out

PARAMETER_KEYS=['r_social', 'r_water', 'r_habitat', 'k_governance', 'k_pressure_feedback', 'k_adaptive', 'k_natural', 'k_bloom', 'k_restore', 'k_compound', 'k_synergy', 'tau_risk', 'alpha_AC', 'alpha_SM', 'alpha_TF']
BASELINE_KEYS=['A1', 'A2', 'A3', 'BLOOM_DRIVER', 'BS', 'COMPOUND', 'H', 'HABITAT_DRIVER', 'ND', 'NS', 'NUTRIENT_DRIVER', 'OS', 'OXYGEN_DRIVER', 'PR', 'PRE', 'PRS', 'SC', 'SM', 'SP', 'TF']
MODE_KEYS=['adaptive_feedback', 'g_to_s', 's_to_g', 'g_to_e', 'e_to_g', 's_to_e', 'e_to_s', 'sc_implementation', 'governance_synergy', 'nonlinear_water', 'asymmetric_habitat', 'tf_sm_conversion', 'sc_gate_midpoint', 'sc_execution_floor', 'tf_sm_conversion_scale']
EXO_KEYS=['G1_TARGET', 'G2_TARGET', 'G3_TARGET', 'PPT', 'RUNOFF', 'SST', 'ETA_POTENTIAL', 'POLICY_TAU', 'FEEDBACK_STRENGTH', 'SYNERGY_LEVER']

