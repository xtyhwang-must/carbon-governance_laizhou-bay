"""通用数据、文件与统计工具。"""

from __future__ import annotations

import hashlib
import json
import math
import platform
import sys
from pathlib import Path
from typing import Any, Iterable

import numpy as np
import pandas as pd


def write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2, default=json_default),
        encoding="utf-8",
    )


def json_default(value: Any) -> Any:
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating,)):
        return float(value)
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, Path):
        return str(value)
    raise TypeError(f"无法JSON序列化: {type(value)!r}")


def sha256_file(path: Path, chunk_size: int = 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(chunk_size):
            digest.update(chunk)
    return digest.hexdigest()


def hash_json(payload: Any) -> str:
    raw = json.dumps(payload, ensure_ascii=False, sort_keys=True, default=json_default)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def bounded(value: np.ndarray | float, low: float = 0.001, high: float = 0.999):
    return np.clip(value, low, high)


def logit(value: np.ndarray | float):
    value = bounded(value)
    return np.log(value / (1.0 - value))


def logistic(value: np.ndarray | float):
    return 1.0 / (1.0 + np.exp(-np.clip(value, -35.0, 35.0)))


def hill(value: np.ndarray | float, midpoint: float = 0.5, exponent: float = 2.4):
    value = np.clip(value, 0.0, None)
    numerator = np.power(value, exponent)
    denominator = np.power(midpoint, exponent) + numerator
    return np.divide(
        numerator,
        denominator,
        out=np.zeros_like(np.asarray(numerator, dtype=float)),
        where=denominator > 0,
    )


def calibration_scaler(
    series: pd.Series,
    calibration_mask: pd.Series,
    lower_q: float = 0.05,
    upper_q: float = 0.95,
) -> tuple[pd.Series, dict[str, float]]:
    """只用校准期拟合稳健映射，再应用到完整历史期。"""

    train = pd.to_numeric(series[calibration_mask], errors="coerce").dropna()
    lower = float(train.quantile(lower_q))
    upper = float(train.quantile(upper_q))
    if not np.isfinite(lower) or not np.isfinite(upper) or math.isclose(lower, upper):
        lower = float(train.min())
        upper = float(train.max())
    if math.isclose(lower, upper):
        mapped = pd.Series(0.5, index=series.index, dtype=float)
    else:
        mapped = 0.02 + 0.96 * (pd.to_numeric(series, errors="coerce") - lower) / (
            upper - lower
        )
        mapped = mapped.clip(0.02, 0.98)
    return mapped, {
        "lower_q": lower_q,
        "upper_q": upper_q,
        "lower": lower,
        "upper": upper,
        "fit_period": "2011-2020",
    }


def geometric_mean_columns(frame: pd.DataFrame, columns: list[str]) -> pd.Series:
    values = frame[columns].clip(0.001, 0.999).to_numpy(float)
    return pd.Series(np.exp(np.mean(np.log(values), axis=1)), index=frame.index)


def nrmse(observed: np.ndarray, predicted: np.ndarray) -> float:
    observed = np.asarray(observed, dtype=float)
    predicted = np.asarray(predicted, dtype=float)
    mask = np.isfinite(observed) & np.isfinite(predicted)
    if mask.sum() == 0:
        return float("nan")
    scale = np.nanpercentile(observed[mask], 95) - np.nanpercentile(
        observed[mask], 5
    )
    if not np.isfinite(scale) or scale < 1e-8:
        scale = max(float(np.nanstd(observed[mask])), 1e-6)
    return float(np.sqrt(np.mean((observed[mask] - predicted[mask]) ** 2)) / scale)


def direction_hit(observed: np.ndarray, predicted: np.ndarray) -> float:
    observed = np.asarray(observed, dtype=float)
    predicted = np.asarray(predicted, dtype=float)
    if len(observed) < 2:
        return float("nan")
    obs_diff = np.diff(observed)
    pred_diff = np.diff(predicted)
    mask = np.isfinite(obs_diff) & np.isfinite(pred_diff)
    if mask.sum() == 0:
        return float("nan")
    return float(np.mean(np.sign(obs_diff[mask]) == np.sign(pred_diff[mask])))


def environment_payload() -> dict[str, Any]:
    import matplotlib
    import networkx
    import scipy
    import seaborn

    try:
        import SALib

        salib_version = getattr(SALib, "__version__", "1.4.7")
    except Exception:
        salib_version = None
    return {
        "python": sys.version,
        "platform": platform.platform(),
        "numpy": np.__version__,
        "pandas": pd.__version__,
        "scipy": scipy.__version__,
        "matplotlib": matplotlib.__version__,
        "seaborn": seaborn.__version__,
        "networkx": networkx.__version__,
        "SALib": salib_version,
    }


def dataframe_to_markdown(frame: pd.DataFrame, digits: int = 3) -> str:
    formatted = frame.copy()
    numeric = formatted.select_dtypes(include=[np.number]).columns
    formatted[numeric] = formatted[numeric].round(digits)
    return formatted.to_markdown(index=False)


def safe_quantile(values: Iterable[float], q: float) -> float:
    array = np.asarray(list(values), dtype=float)
    array = array[np.isfinite(array)]
    return float(np.quantile(array, q)) if len(array) else float("nan")
