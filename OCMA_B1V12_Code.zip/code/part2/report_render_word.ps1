param([string]$ReportDir,[switch]$Originals)
$ErrorActionPreference='Stop'
$reportRoot=(Resolve-Path -LiteralPath $ReportDir).Path
$app=New-Object -ComObject Word.Application
$app.Visible=$false
$app.DisplayAlerts=0
try {
 if($Originals){
  $root=Split-Path (Split-Path $reportRoot)
  $files=@((Join-Path $root '01_sources/submission/Manuscript.docx'),(Join-Path $root '01_sources/submission/supplementary material.docx'))
 } else {$files=@('Main_Result_Tables_2_4.docx','Supplementary_Tables_S1_S7.docx','Supplementary_Methods_equations.docx') | ForEach-Object {Join-Path $reportRoot $_}}
 $rows=@()
 foreach($file in $files){
  $doc=$app.Documents.Open($file,$false,$true)
  try {
   $pdf=if($Originals){Join-Path $reportRoot ('qa_previews/original_'+[IO.Path]::GetFileNameWithoutExtension($file)+'.pdf')}else{[IO.Path]::ChangeExtension($file,'.pdf')}
   $doc.ExportAsFixedFormat($pdf,17)
   $rows+=@{file=$file;pdf=$pdf;pages=$doc.ComputeStatistics(2);engine='Microsoft Word native PDF export';source_read_only=$true}
   Write-Output "Rendered $pdf"
  } finally {$doc.Close(0)}
 }
 $name=if($Originals){'ORIGINAL_RENDER_QA.json'}else{'DOCX_RENDER_QA.json'}
 $rows | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $reportRoot $name) -Encoding utf8
} finally {$app.Quit();[void][Runtime.InteropServices.Marshal]::ReleaseComObject($app)}
