"""Editable table and equation fragments, derived from retained manuscript styles."""
from pathlib import Path
import os,json,copy
from docx import Document
from docx.shared import Pt,Inches,RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT,WD_CELL_VERTICAL_ALIGNMENT
ROOT=Path(__file__).resolve().parents[1]
O=Path(os.environ.get('B1_REPORT_DIR',str(ROOT/'07_publication/R3_FIGURE_TABLE_POLISH_20261029')))
payload=json.loads((O/'tables_payload_R3.json').read_text('utf8'))
audit=json.loads((O/'TABLE_STYLE_SOURCE_AUDIT.json').read_text('utf8'))
def init(kind):
    d=Document(audit[kind]['path'])
    for ch in list(d.element.body):
        if ch.tag!=qn('w:sectPr'):d.element.body.remove(ch)
    for s in d.sections:
        for el in list(s._sectPr):
            if el.tag==qn('w:lnNumType'):s._sectPr.remove(el)
        # Detached table fragments have no inherited manuscript running text.
        for hf in [s.header,s.footer]:
            for p in hf.paragraphs:p.text=''
    return d
def para(d,text,bold=False,size=11,keep=False):
    p=d.add_paragraph();p.alignment=WD_ALIGN_PARAGRAPH.LEFT
    p.paragraph_format.first_line_indent=Pt(0);p.paragraph_format.space_after=Pt(5);p.paragraph_format.space_before=Pt(0);p.paragraph_format.line_spacing=1.0;p.paragraph_format.keep_with_next=keep
    ind=p._p.get_or_add_pPr().find(qn('w:ind'))
    if ind is not None:ind.attrib.clear();ind.set(qn('w:firstLine'),'0');ind.set(qn('w:left'),'0');ind.set(qn('w:right'),'0')
    r=p.add_run(text);r.font.name='Times New Roman';r.font.size=Pt(size);r.font.color.rgb=RGBColor(0,0,0);r.bold=bold
    return p
def table(d,item,supp=False):
    cols=item['columns'];rows=item['rows'];t=d.add_table(rows=1,cols=len(cols));t.alignment=WD_TABLE_ALIGNMENT.CENTER;t.autofit=False
    width=d.sections[-1].page_width-d.sections[-1].left_margin-d.sections[-1].right_margin
    ww=item['widths'] or [1/len(cols)]*len(cols)
    for col,w in zip(t.columns,ww):col.width=int(width*w)
    for i,values in enumerate([cols]+rows):
        cells=t.rows[0].cells if i==0 else t.add_row().cells
        trpr=cells[0]._tc.getparent().get_or_add_trPr();trpr.append(OxmlElement('w:cantSplit'))
        if i==0:trpr.append(OxmlElement('w:tblHeader'))
        for j,(cell,value,w) in enumerate(zip(cells,values,ww)):
            cell.width=int(width*w);cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
            cell.text=str(value);p=cell.paragraphs[0];p.alignment=WD_ALIGN_PARAGRAPH.CENTER if i==0 or j>0 else WD_ALIGN_PARAGRAPH.LEFT
            p.paragraph_format.first_line_indent=Pt(0);p.paragraph_format.space_before=Pt(3);p.paragraph_format.space_after=Pt(3);p.paragraph_format.line_spacing=1.;p.paragraph_format.keep_with_next=(i==0)
            ind=p._p.get_or_add_pPr().find(qn('w:ind'))
            if ind is not None:ind.attrib.clear();ind.set(qn('w:firstLine'),'0');ind.set(qn('w:left'),'0');ind.set(qn('w:right'),'0')
            # Neutralize inherited character-based indentation from the source template.
            for attr in ['firstLineChars','leftChars','rightChars']:ind.set(qn('w:'+attr),'0')
            for r in p.runs:r.font.name='Times New Roman';r.font.size=Pt(10.5 if supp else 11);r.bold=(i==0);r.font.color.rgb=RGBColor(0,0,0)
            pr=cell._tc.get_or_add_tcPr();b=OxmlElement('w:tcBorders')
            for edge in ['top','left','bottom','right']:
                el=OxmlElement('w:'+edge);val='single' if (i==0 and edge in ['top','bottom']) or (i==len(rows) and edge=='bottom') else 'nil';el.set(qn('w:val'),val);el.set(qn('w:sz'),'4');el.set(qn('w:color'),'000000');b.append(el)
            pr.append(b);mar=OxmlElement('w:tcMar')
            for edge in ['left','right']:
                e=OxmlElement('w:'+edge);e.set(qn('w:w'),'65');e.set(qn('w:type'),'dxa');mar.append(e)
            pr.append(mar)
    para(d,item['note'],size=10.5 if supp else 10.5)
    return t
def build_tables(supp=False):
    d=init('supplement' if supp else 'manuscript');items=[i for i in payload if i['id'].startswith('TableS')==supp];last=None
    for i in items:
        if i['id']!=last:
            if last is not None:d.add_page_break()
            id=i['id'].replace('TableS','Table S') if supp else i['id'].replace('Table','Table ')
            para(d,id+'. '+i['title'],bold=True,size=11,keep=True)
        if supp and i['id']==last and i['id'] in ['TableS2','TableS5','TableS6']:
            d.add_page_break();para(d,i['id'].replace('TableS','Table S')+' (continued)',bold=True,keep=True)
        if i['part_title']:para(d,i['part_title'],bold=True,size=10.5,keep=True)
        table(d,i,supp);last=i['id']
    name='Supplementary_Tables_S1_S7' if supp else 'Main_Result_Tables_2_4';d.save(O/(name+'.docx'))
    return name
METHODS=[
('Scope and evidence', 'This fragment documents the frozen M3 numerical run and the final display and portable-package revision. No recalibration was executed. Reporting uses frozen results; the separate portability test replayed three fixed vectors and one vector of 24 attribution coalitions without replacing the formal run. G composition is a post-audit HT estimate for a fixed extracted-unit frame. The 528 primary units and 106 nested second-coder units do not establish complete policy-body coverage. T2 remains unknown; G-only results do not validate a full six-tool configuration.',[]),
('Policy composition and uncertainty','Within each policy, fixed valid evidence is combined with the design-weighted audit-domain total. Function shares use G assignment counts, allowing multiple functions per unit. Stage means give every policy equal weight. The 68 texts form stage groups of 11, 13, 16 and 28. The 67 independent annual stock sources are a different denominator. π denotes the original inclusion probability. Taylor design SE, coder-disagreement sensitivity and within-stage policy Bootstrap are reported separately; none absorbs frame omissions.',[
'T̂ₚg = Tₚg,fixed + ∑ᵤ∈sₚ yᵤg / πᵤ',
'q̂ₚg = T̂ₚg / ∑ₕ₌₁³ T̂ₚh ;   q̄ₖg = (1/nₖ) ∑ₚ∈k q̂ₚg',
'V̂(T̂ₚ) = ∑ₕ Nₕ² (1 − nₕ/Nₕ) Sₕ / nₕ',
'∇qₚg = (e_g Dₚ − Tₚg 1) / Dₚ² ;   V̂(q̂ₚg) ≈ ∇qₚgᵀ V̂(T̂ₚ) ∇qₚg']),
('Constructed inputs and formal governance stock','S is the sum of active independent policy shares under the registered date ledger. A 2023 amendment does not become a second independent stock. Known expiry facts and open-ended exposure conventions remain distinct. Scaling uses the frozen 2011–2020 reference; no second normalization of SR is applied. Ratios aggregate county numerators and denominators before scaling. η, feedback and synergy are frozen text/relation proxies, not observed causal strengths. Full mappings, quantiles, time ledger and input rows are indexed in Data S1/S2.',[
'S_g(t) = ∑ₚ Iₚ(t) q̂ₚg ;   G_g,exo(t) = S_g(t) / [S_g(t) + K_g]',
'(K₁,K₂,K₃) = (6.608, 6.605, 7.936)',
'z(x) = clip₀.₀₂,₀.₉₈ {0.02 + 0.96 (x − L)/(U − L)}',
'SP = [z(population) + z(real industry) + {z(grain)+z(meat)}/2]/3',
'SC = AC = [z(revenue/expenditure) + z(teachers/pupils × 1000)]/2']),
('States and reporting quantities','The 13 integrated states are G1, G2, G3, SP, SC, NS, OS, BS, TF, SM, PR, PRS and IM. Other indices are derived. The equations below describe the main M3 mode; structural removals substitute the fixed 2011 reference only along their specified pathway. σ is logistic; ℓ is logit; h is a Hill response. Bounded numerical inputs are used before logarithms. Δ denotes a current value minus its parameter-specific 2011 reference, not an annual difference.',[
'σ(z) = 1/(1 + exp(−z));   ℓ(x) = log[x/(1−x)];   h(x;k,n) = xⁿ/(kⁿ+xⁿ)',
'G = (G₁+G₂+G₃)/3 ;   WQ = [(1−NS)(1−OS)(1−BS)]^(1/3)',
'H = √(TF·SM);   ES = √(WQ·H);   SR = √[(1−SP)·SC]']),
('Implementation potential and actions','The capacity floor avoids treating a low standardized SC as near-zero real capacity. Historical τ is 0.5 years; scenario delays enter IM only, not a second legal-stock delay. All potentials/actions are clipped to [0,1]. The main SC gate midpoint is 0.30 and execution floor is 0.12.',[
'b = h(SC;0.30,2);   f_op = 0.12 + 0.88 b;   f_cap = 0.25 + 0.75 b',
'I_op = η h(G₃;0.45,2.2) f_op/(1+0.75 SP)',
'I_cap = η h(G₃;0.45,2.2) f_cap/(1+0.50 SP)',
'dIM/dt = (I_op − IM)/max(τ,0.25);   I_c = clip₀,₁[(IM+I_cap)/2]',
'm = 1 + 0.6·synergy·(G₁G₂G₃)^(1/3)',
'A₁ = clip₀,₁[IM h(G₁;0.45,2.1)m];   A₂ = clip₀,₁[IM h(G₂;0.45,2.1)m]',
'A₃ = clip₀,₁[I_c h(G₃;0.45,2.1)]']),
('Governance adjustment and risk memory','β is the registered feedback forcing. It is zero in the historical trajectory to avoid double-counting observed responses; scenario values use the registered frozen mapping. Main fixed risk delay is 1.5 years. PR is combined risk memory, PRS social memory and PRE a derived ecological decomposition.',[
'PRE = clip₀,₁[(3PR−PRS)/2];   R_E = [(1−WQ)+(1−H)]/2',
'dPR/dt = [(SP+2R_E)/3−PR]/1.5 ;   dPRS/dt = (SP−PRS)/1.5',
'F = β[(PRS−PRS₀)/3 + 2(PRE−PRE₀)/3]',
'G_g* = clip₀.₀₁,₀.₉₉[G_g,exo + a_g F],   (a₁,a₂,a₃)=(0.13,0.17,0.21)',
'dG_g/dt = (G_g*−G_g)/0.18']),
('Environmental drivers','P, R and T denote normalized precipitation, runoff and SST. Fixed compound coefficient k_c = 0.75; the three other fixed constants are k_synergy = 0.6, τ_risk = 1.5 years and the TF/SM area-scale ratio 1.5687953135133381. Intercepts and the original nine estimated coefficients are listed in Table S3.',[
'ND = (P+R+T)/3 ;   C = max(PRT,10⁻⁹)^(1/3)',
'D_N = 0.58 SP + 0.42 R ;   D_O = 0.34 SP+0.23 R+0.23 BS+0.20 T',
'D_B = h(NS;0.48,3)(0.50 T+0.30 OS+0.20 R);   D_H = 0.60 SP+0.40 C']),
('Social and water-quality dynamics','For each signal z, target x* = σ(z). Here k_pressure denotes k_pressure_feedback in Table S3. Original rates apply to the corresponding state groups. The three intercepts are revision structure adjustments, not recovered historical observation parameters. All reference constants retain their 2011 values during future RESET and CONTINUATION comparisons.',[
'U_SP = 0.30 k_natural ΔND+0.25 k_c ΔC−k_governance ΔA₁−0.50 k_adaptive ΔSC',
'z_SP = ℓ(SP₀)+k_pressure Δ[(PRS+2PRE)/3]+U_SP',
'z_SC = α_AC+k_adaptive ΔA₃+0.55 ΔH−0.78 ΔSP−0.20 k_c ΔC',
'dSP/dt = r_social[σ(z_SP)−SP];   dSC/dt = r_social[σ(z_SC)−SC]',
'z_NS = ℓ(NS₀)+k_natural ΔD_N+k_c ΔC−k_governance ΔA₁',
'z_OS = ℓ(OS₀)+0.82 k_natural ΔD_O+0.52 k_c ΔC−0.78 k_governance ΔA₁',
'z_BS = ℓ(BS₀)+k_bloom ΔD_B+0.55 k_c ΔC−0.58 k_governance ΔA₁',
'dx/dt = r_water[σ(z_x)−x],   x ∈ {NS, OS, BS}']),
('Final habitat equations and area conversion','Habitat restoration uses state-specific relaxation, asymmetry during decline and a small explicit TF-to-SM conversion. The complete derivative includes conversion after target relaxation. Conversion conserves the implied area transfer between the two frozen scales, not the sum of normalized indices or carbon stock. Derivatives pointing out of [0,1] at its boundaries are set to zero; numerical output clipping is not used to conceal unstable trajectories.',[
'z_TF = α_TF+k_restore ΔA₂−k_natural ΔD_H+0.22 k_adaptive ΔSC',
'z_SM = α_SM+1.20 k_restore ΔA₂−0.82 k_natural ΔD_H+0.30 k_adaptive ΔSC',
'r_TF = r_habitat × {1.70 if σ(z_TF)<TF; 1 otherwise}',
'r_SM = r_habitat × {1.55 if σ(z_SM)<SM; 1 otherwise}',
'C_TF = 0.12 A₂ TF(1−SM);   C_SM = 1.5687953135133381 C_TF',
'dTF/dt = r_TF[σ(z_TF)−TF]−C_TF',
'dSM/dt = r_SM[σ(z_SM)−SM]+C_SM']),
('Initialization and structure removals','Each initial vector is selected by an explicit unique year. History starts from 2011. Main future trajectories RESET to the constructed 2023 vector; this is not evidence that the model predicted it. The same parameter-specific 2011 reference is reused for main scenarios, coalitions and removals. CONTINUATION uses the original-vector historical endpoint. The 0.35 habitat weight never blends initial conditions. Annual forcing is linearly interpolated. G→S removals set ΔA1/ΔA3 to zero only in social targets; G→E removals set ΔA1/ΔA2 to zero in ecological targets and freeze conversion action at A2₀. S→G freezes SP/SC in implementation and removes the PRS feedback term; E→G removes PRE feedback. S→E freezes SP/SC in ecological drivers; E→S freezes H/PRE in social feedback. Governance synergy, SC gate, nonlinear water, asymmetry and TF/SM transfer retain their documented separate switches.',[]),
('Calibration and retained-set evaluation','The existing development comparison used 2011–2016/2017–2018 and 2011–2018/2019–2020 windows with fixed development scales; it was not strictly blind cross-validation. M3 was selected for limited exploration, not certified behavioral adequacy. Formal calibration used seven base states in 2011–2020 and five seeds 20261024–20261028; differential evolution maxiter 35, popsize 10, tol 10⁻⁶, then Powell maxiter 600, xtol 10⁻⁶, ftol 10⁻⁸. For the behavior loss, d denotes the end-minus-start change and direction_g is the recorded directional agreement; hats denote model output. Original nine coefficients alone enter regularization. Of 11,600 candidates (600 global plus 4,500/3,500/3,000 bounded local candidates), 11,015 met the legacy gates; 600 were propagated using the recorded subsample seed 20261029. This high acceptance rate is not quality certification. Full failures and source counts remain in Data S3.',[
'L = MSE₇×₁₀ + 0.18 B + 0.006 (1/9)∑ⱼ₌₁⁹[(θⱼ−midⱼ)/(upperⱼ−lowerⱼ)]²',
'B = 0.5 mean_g[(d̂_g−d_g)²+0.04(1−direction_g)]',
'L ≤ 1.35 L_best + 0.025;   mean NRMSE ≤ 0.52;   mean direction ≥ 0.43',
'NRMSE_g = RMSE_g / [P95_train,g−P5_train,g]']),
('Conditional evaluation and scenarios','Previously viewed 2021–2023 data are evaluated after model selection. Errors are calculated separately for each retained vector, then summarized. Designated 2023 estimated habitat contributions receive weight 0.35, with unweighted/excluded comparisons retained. Pure parameter coverage and descriptive training residuals do not constitute validated forecast probability intervals. S0 uses reference levers; S1/S2/S3 strengthen G1/G2/G3 respectively, without unintended feedback enhancement. S4 strengthens all G functions, η, feedback and synergy with τ=1; S5 strengthens G but reduces η with τ=3; S6 strengthens G1/G2, η and synergy with τ=2. S0/S1/S2/S3/S6 use τ=2. η/feedback/synergy use their registered P50/P75/P25 mappings, and 0.45 inflow intensification is a scenario assumption. All paths share the matched joint climate forcing and 2026–2028 compound disturbance; exact lever increments, forcing arrays and mapping rules are in Data S4.',[
'm_i,s = minₜ∈{2026,…,2030} ES_i,s(t);   Δm_i = m_i,a−m_i,b',
'Social screen: median_i[SR_i,s(2030)−SR_i,S0(2030)] ≥ −0.0005']),
('Paired attribution and robustness','Shapley is computed within each parameter/initial/reference/forcing match. S4−S0 uses {G1,G2,G3}, {η,τ}, feedback and synergy (16 coalitions); S4−S6 uses G3, τ and feedback (8 coalitions). Empty/full endpoints match the main paths and closure is checked per vector. Directional ablations, joint interactions and prior response surfaces are model-conditional sensitivity, not independent policy causality. Bootstrap, Taylor intervals, parameter ranges and specification ranges remain distinct. The maximum recorded Shapley closure residual is approximately 2.1×10⁻¹⁶; no attribution was recomputed in R3.',[
'φ_i,j = ∑_{S⊆N∖{j}} [|S|!(k−|S|−1)!/k!] {v_i(S∪{j})−v_i(S)}',
'∑ⱼ φ_i,j = v_i(N)−v_i(∅)',
'E_i,l = ΔES_i,full−ΔES_i,without l ;   J_i,ab = E_i,ab−E_i,a−E_i,b'])]
def methods():
    d=init('manuscript');sec=d.sections[0];sec.left_margin=Inches(.85);sec.right_margin=Inches(.85)
    p=para(d,'Supplementary Methods',bold=True,size=14,keep=True);p.style=d.styles['Title']
    lines=['# Supplementary Methods'];n=0
    for h,t,eqs in METHODS:
        para(d,h,bold=True,size=11,keep=True);para(d,t,size=11);lines+=['','## '+h,'',t]
        for eq in eqs:
            n+=1;p=d.add_paragraph();p.paragraph_format.first_line_indent=Pt(0);p.paragraph_format.line_spacing=1.;p.paragraph_format.space_after=Pt(6);p.paragraph_format.keep_together=True
            math=OxmlElement('m:oMath');r=OxmlElement('m:r');pr=OxmlElement('m:rPr');sty=OxmlElement('m:sty');sty.set(qn('m:val'),'p');pr.append(sty);r.append(pr);txt=OxmlElement('m:t');txt.text=eq;r.append(txt);math.append(r);p._p.append(math);p.add_run(f'   ({n})').font.size=Pt(10)
            lines+=['',f'({n}) {eq}']
    d.save(O/'Supplementary_Methods_equations.docx');(O/'Supplementary_Methods_equations.md').write_text('\n'.join(lines),'utf8')
    return n
def main():
    spec=dict(reference_main=audit['manuscript']['path'],reference_main_sha256=audit['manuscript']['sha256'],reference_supplement=audit['supplement']['path'],reference_supplement_sha256=audit['supplement']['sha256'],font='Times New Roman',main_table_pt=11,supplement_pt=10.5,main_page='Original portrait A4 and margins',supplement_page='Original landscape A4 and margins',rules='Three-line tables; no fills, vertical rules or striped rows; repeat headers; do not split rows',caption='Original title location above table; keep with header',notes='Below each table; 10.5pt',deviations=['Explicit bold headers for consistent readability (some original main headers inherit rather than explicitly specify bold)','Column counts/widths revised for requested compact display','Equation fragment margins 0.85in; editable linear OMML math, not bitmap formulas','No full manuscript content or original file overwritten'],full_XML_evidence='TABLE_STYLE_SOURCE_AUDIT.json')
    (O/'TABLE_STYLE_SPEC.json').write_text(json.dumps(spec,ensure_ascii=False,indent=2),'utf8')
    (O/'artifact.md').write_text('Reference authority: original manuscript Table2–4 and original landscape supplement. Preserve Times New Roman, black text, three horizontal rules, caption above and notes below. Requested display columns replace original slots; repeat table headers and prevent split rows. Full style XML and source hashes: TABLE_STYLE_SOURCE_AUDIT.json. Standalone table/method fragments only, no manuscript overwrite.','utf8')
    print(build_tables(False));print(build_tables(True));print('OMML equations',methods())
if __name__=='__main__':main()
