"""Recompute a fixed 30-vector original-structure control after the 2023 reset fix."""
from __future__ import annotations
import hashlib,json,sys
from concurrent.futures import ProcessPoolExecutor,as_completed
from pathlib import Path
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'05_code/engine'),str(ROOT/'05_code')]
import engine_config as cfg
import sd_model as model
from numeric_analysis import one_scenario,load_settings,climate_path,factorial_one
from v12_scenario_summary import metrics_from_trajectories,summarize,test_definitions

def main():
    test_definitions()
    frame=pd.read_csv(ROOT/'03_indicators/model_input_B1.csv')
    ensemble=pd.read_csv(ROOT/'00_reference_v1_1/calibration/accepted_parameter_ensemble.csv')
    chosen=ensemble.iloc[:30].copy()
    assert chosen.parameter_set_id.is_unique and len(chosen)==30
    settings=load_settings();climate=climate_path(frame)
    initial=model.initial_state(frame,year=2023)
    jobs=[(r.parameter_set_id,{n:float(getattr(r,n)) for n in cfg.PARAMETER_NAMES},frame,settings,climate)
          for r in chosen.itertuples(index=False)]
    trajectories=[]
    with ProcessPoolExecutor(max_workers=4) as pool:
        for future in as_completed([pool.submit(one_scenario,j) for j in jobs]):
            trajectories.append(future.result()[0])
    traj=pd.concat(trajectories,ignore_index=True).sort_values(['parameter_set_id','scenario','year'])
    metrics=metrics_from_trajectories(traj)
    social,screen,ranking,pairs=summarize(metrics)
    out=ROOT/'06_runs/P0_legacy_structure_correct_initial';out.mkdir(parents=True,exist_ok=True)
    for name,data in [('scenario_trajectories_30.csv',traj),('scenario_metrics_30.csv',metrics),
        ('social_screen_terminal_30.csv',social),('social_screen_summary_30.csv',screen),
        ('primary_ranking_30.csv',ranking),('all_pair_tolerance_30.csv',pairs)]:
        data.to_csv(out/name,index=False,encoding='utf-8-sig')
    old=pd.read_csv(ROOT/'00_reference_v1_1/scenarios/legacy_scenario_metrics_by_parameter.csv')
    compare=metrics.merge(old[['parameter_set_id','scenario','ES_2030','SR_2030','min_ES_2026_2030']],
        on=['parameter_set_id','scenario'],suffixes=('_correct_2023','_old_2011'),validate='one_to_one')
    for field in ['ES_2030','SR_2030','min_ES_2026_2030']:
        compare['D_'+field+'_initialization_fix']=compare[field+'_correct_2023']-compare[field+'_old_2011']
    compare.to_csv(out/'old_vs_correct_initial_30.csv',index=False,encoding='utf-8-sig')
    # A bounded factorial control checks two same-vector S4/S6 endpoints.
    controls=[]
    for j in jobs[:2]:
        pid,params,_,_,_=j
        controls.extend(factorial_one((pid,params,frame,climate,'S6','S4',['G3','tau','feedback'])))
    factors=pd.DataFrame(controls);factors.to_csv(out/'S4_S6_factorial_control_2.csv',index=False,encoding='utf-8-sig')
    for (pid,metric),g in factors.groupby(['parameter_set_id','metric']):
        expected=metrics[(metrics.parameter_set_id.eq(pid)) & metrics.scenario.isin(['S4','S6'])].set_index('scenario')
        assert abs(g.endpoint_base.iloc[0]-expected.loc['S6',metric])<1e-10
        assert abs(g.endpoint_target.iloc[0]-expected.loc['S4',metric])<1e-10
        assert abs(g.shapley.sum()-g.total_paired_difference.iloc[0])<1e-10
    status={'complete':True,'structure':'M0_RUN_SPECIFIC','parameter_source':'frozen_v1_1_first_30_accepted_vectors',
      'parameter_sets':30,'scenario_cells':len(metrics),'factorial_parameter_sets':2,
      'initial_year':2023,'initial_hash':hashlib.sha256(initial.tobytes()).hexdigest(),
      'median_delta_ES2030_from_old':float(compare.D_ES_2030_initialization_fix.median()),
      'main_screen_pass':dict(zip(screen.scenario,screen.main_screen_pass.astype(bool))),
      'comparison_role':'P0_CONTROL_NOT_REFITTED_MAIN_BASELINE'}
    (out/'p0_status.json').write_text(json.dumps(status,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(status,ensure_ascii=False))

if __name__=='__main__':main()
