"""Independent P1 structure checks before candidate calibration."""
from __future__ import annotations
import json,sys
from pathlib import Path
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'05_code/engine'),str(ROOT/'05_code')]
import engine_config as cfg
import sd_model as m

def main():
    frame=pd.read_csv(ROOT/'03_indicators/model_input_B1.csv')
    best=json.loads((ROOT/'00_reference_v1_1/calibration/best_parameter_set.json').read_text(encoding='utf-8'))['parameters']
    forcing=m.historical_forcing(frame);initial=m.initial_state(frame,year=2011)
    ref=m.make_training_reference_context(frame,best,structure='M0_FIXED_REFERENCE')
    years=np.arange(2011,2021,dtype=float)
    run=m.simulate(best,forcing,years,initial,structure='M0_RUN_SPECIFIC')
    fixed=m.simulate(best,forcing,years,initial,structure='M0_FIXED_REFERENCE',reference_context=ref)
    original_error=float(np.max(abs(run[cfg.STATE_NAMES].to_numpy()-fixed[cfg.STATE_NAMES].to_numpy())))
    assert original_error<1e-12
    m1=best|{'alpha_AC':float(m.logit(ref['SC']))}
    a=m.simulate(m1,forcing,years,initial,structure='M1_AC_INTERCEPT',reference_context=ref)
    m1_error=float(np.max(abs(a[cfg.STATE_NAMES].to_numpy()-fixed[cfg.STATE_NAMES].to_numpy())))
    assert m1_error<1e-12
    m2=m1|{'alpha_SM':float(m.logit(ref['SM']))}
    b=m.simulate(m2,forcing,years,initial,structure='M2_AC_SM_INTERCEPTS',reference_context=ref)
    m2_error=float(np.max(abs(b[cfg.STATE_NAMES].to_numpy()-fixed[cfg.STATE_NAMES].to_numpy())))
    assert m2_error<1e-12
    shifted=m1|{'alpha_AC':m1['alpha_AC']+1.0}
    result=m.simulate(shifted,forcing,years,initial,structure='M1_AC_INTERCEPT',reference_context=ref)
    assert np.allclose(result.iloc[0][cfg.STATE_NAMES].to_numpy(float),initial,atol=1e-12)
    assert abs(result.SC.iloc[-1]-a.SC.iloc[-1])>1e-3
    first=m.parameter_dict(m1,structure='M1_AC_INTERCEPT')
    signal_a=m.rhs(2011.,initial,first,forcing,ref,m.ModelMode(),'M1_AC_INTERCEPT')[4]
    signal_b=m.rhs(2011.,initial,m.parameter_dict(shifted,structure='M1_AC_INTERCEPT'),forcing,ref,m.ModelMode(),'M1_AC_INTERCEPT')[4]
    assert signal_b>signal_a
    rest=m.simulate(m1,forcing,np.arange(2015,2021,dtype=float),a.loc[a.year.eq(2015),cfg.STATE_NAMES].iloc[0].to_numpy(float),
         structure='M1_AC_INTERCEPT',reference_context=ref)
    restart_error=float(np.max(abs(rest[cfg.STATE_NAMES].to_numpy()-a[a.year.ge(2015)][cfg.STATE_NAMES].to_numpy())))
    assert restart_error<1e-10,restart_error
    failed=False
    try:m.simulate(m1,forcing,years,initial,structure='M1_AC_INTERCEPT')
    except ValueError:failed=True
    assert failed
    report={'M0_fixed_matches_run_specific_historical_max_abs':original_error,
        'M1_alpha_at_old_logit_matches_M0_max_abs':m1_error,
        'M2_both_alphas_at_old_logits_matches_M0_max_abs':m2_error,
        'fixed_reference_restart_max_abs':restart_error,
        'alpha_AC_changes_target_and_trajectory':True,
        'missing_fixed_reference_rejected':True}
    out=ROOT/'06_runs/P1_structure_diagnostics';out.mkdir(parents=True,exist_ok=True)
    (out/'structure_reference_tests.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps(report))

if __name__=='__main__':main()
