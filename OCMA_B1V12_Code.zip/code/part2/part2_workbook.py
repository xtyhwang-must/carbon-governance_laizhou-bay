from pathlib import Path
import json,subprocess,math,time,hashlib
import openpyxl
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'07_publication'
def main():
 node=Path('C:/Users/Mario/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe')
 started=time.time()
 result=subprocess.run([str(node),str(ROOT/'05_code/part2_build_tables.mjs')])
 generation=json.loads((OUT/'workbook_generation.json').read_text('utf8'));assert generation['completed'] and generation['payload_sha256']==hashlib.sha256((OUT/'tables_payload.json').read_bytes()).hexdigest()
 target=OUT/'B1_V1.2_PART2_更新结果表.xlsx';assert target.stat().st_mtime>=started,'Stale workbook cannot satisfy failed authoring';data=json.loads((OUT/'tables_payload.json').read_text('utf8'));w=openpyxl.load_workbook(target,data_only=True);mismatch=[];cells=0
 for entry in data:
  sheet=w[entry['name']]
  for i,row in enumerate(entry['rows'],1):
   for j,e in enumerate(row,1):
    a=sheet.cell(i,j).value;cells+=1
    same=math.isclose(a,e,rel_tol=1e-12,abs_tol=1e-14) if isinstance(e,(float,int)) and not isinstance(e,bool) and isinstance(a,(float,int)) else a==e
    if not same:mismatch.append([entry['name'],i,j])
 assert not mismatch,mismatch[:5]
 assert w['TableS15']['D2'].number_format=='0.0000'
 (OUT/'WORKBOOK_QA.json').write_text(json.dumps(dict(sheets=len(data),all_cells_roundtrip_checked=cells,mismatches=0,baseline_RMSE_display='four decimal places',authoring_exit_code=result.returncode,exit_note='Artifact process emitted inspect and exited nonzero after saving; freshness, generation hash and every saved cell separately verified' if result.returncode else 'normal',visual_scope='All18 sheet first10row previews rendered; relevant final changes inspected'),indent=2),'utf8')
 print('Saved workbook verified:',cells,'cells')
if __name__=='__main__':main()
