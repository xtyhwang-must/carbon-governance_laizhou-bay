"""Portable executable stages for the actual B1 source-reconstructed baseline."""
from __future__ import annotations
import argparse,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
CODE=Path(__file__).resolve().parent

def run(script,*args):
    command=[sys.executable,str(CODE/script),*args]
    subprocess.run(command,cwd=ROOT,check=True)

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--stage',required=True,choices=['reconstruct','build','coding-sensitivity','verify-input','calibrate','figures','evaluate','scenarios','attribution','verify','verify-release','release','status','all'])
    stage=p.parse_args().stage
    if stage=='reconstruct':
        for script in ['reconstruct_policy_text.py','reconstruct_policy_codes.py','reconstruct_policy_times.py',
                       'reconstruct_policy_relations.py','build_policy_interface.py']:
            run(script)
    elif stage=='build':
        run('refresh_source_manifest_B1.py')
        run('build_evidence.py')
        run('audit_comparisons.py')
    elif stage=='coding-sensitivity':run('coding_ambiguity_input_sensitivity.py')
    elif stage=='verify-input':run('qa_baseline.py','--input-only')
    elif stage=='calibrate':run('numeric_calibration.py')
    elif stage=='figures':run('make_calibration_figures.py')
    elif stage=='evaluate':
        run('numeric_analysis.py','evaluate')
        run('state_target_diagnostics.py')
    elif stage=='scenarios':
        run('numeric_analysis.py',stage)
        run('ranking_tolerance_audit.py')
    elif stage=='attribution':run('numeric_analysis.py',stage)
    elif stage=='verify':run('qa_baseline.py')
    elif stage=='verify-release':
        run('qa_baseline.py')
        run('release_replay.py')
    elif stage=='release':
        run('finalize_baseline.py')
        run('refresh_source_manifest_B1.py')
        run('release_candidate.py')
    elif stage=='status':
        import json
        paths={k:ROOT/'06_runs/B1_v1_1'/v for k,v in {
            'calibration':'calibration/calibration_status.json','evaluation':'evaluation/evaluation_status.json',
            'scenarios':'scenarios/scenario_status.json','attribution':'attribution/attribution_status.json',
            'qa':'baseline_qa_report.json'}.items()}
        completed={k:v.exists() for k,v in paths.items()}
        if completed['qa']:
            report=json.loads(paths['qa'].read_text(encoding='utf-8'))
            completed['qa']=bool(report.get('passed') and all(report.get('numerical_stages_present',{}).values()))
        print(json.dumps({'version':'B1_v1.1.0_source_reconstructed',
          'stages_complete':completed,
          'author_review_status':'PENDING','submission_ready':False},ensure_ascii=False))
    else:
        for name in ['reconstruct','build','coding-sensitivity','verify-input','calibrate','figures','evaluate','scenarios','attribution','verify','release']:
            subprocess.run([sys.executable,str(CODE/'run_baseline.py'),'--stage',name],cwd=ROOT,check=True)

if __name__=='__main__':main()
