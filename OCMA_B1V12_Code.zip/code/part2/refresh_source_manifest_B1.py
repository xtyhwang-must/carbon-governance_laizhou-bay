"""Register new captured evidence and B1-adapted code without losing origins."""
from __future__ import annotations

import hashlib
from pathlib import Path
import pandas as pd

ROOT=Path(__file__).resolve().parents[1]
FILE=ROOT/'00_contract/source_manifest.csv'
URLS={
 'NAT_2021_CARBON_PEAK_01.html':'https://app.www.gov.cn/govdata/gov/202110/26/477466/article.html',
 'NAT_2018_BOHAI_ACTION_01.html':'https://www.mee.gov.cn/xxgk2018/xxgk/xxgk03/201812/t20181211_684232.html',
 'NAT_2022_AQUATIC_RES_01.html':'https://app.www.gov.cn/govdata/gov/202212/05/494935/article.html',
 'EARLY-SHD-2004-25_2004_ORIGINAL.pdf':'https://faolex.fao.org/docs/pdf/chn136792.pdf',
 'EARLY-SHD-2004-25_2016_REVISION.html':'https://policy.mofcom.gov.cn/claw/clawContent.shtml?id=53541',
 'EARLY-SHD-2004-25_2018_REVISION.html':'https://policy.mofcom.gov.cn/claw/clawContent.shtml?id=65865',
}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    df=pd.read_csv(FILE,keep_default_na=False)
    # Historical source_sha256 remains the captured predecessor for adapted
    # code; sha256 records the code actually used by this B1 workspace.
    for idx,row in df.iterrows():
        if str(row.relative_path).startswith('05_code/'):
            path=ROOT/row.relative_path
            if sha(path)!=row.sha256:
                df.at[idx,'sha256']=sha(path)
                df.at[idx,'bytes']=path.stat().st_size
                df.at[idx,'availability']='ADAPTED_LOCAL_CODE'
                df.at[idx,'confirmation_status']='B1_V1_1_ADAPTED_CODE_SOURCE_HASH_RETAINED'
                df.at[idx,'version']='B1_v1.1.0_source_reconstructed'
        if row.source_id=='policy_text_EARLY-SHD-2004-25':
            df.at[idx,'confirmation_status']='WRONG_JIANGSU_TEXT_EXCLUDED_REPLACED_BY_DATED_SHANDONG_ORIGINAL'
    add=[]
    for folder,kind in [('01_sources/policy/attachments','POLICY_ATTACHMENT_BACKUP'),
                        ('01_sources/policy/official_targeted_retrieval','TARGETED_BODY_OR_VERSION_RETRIEVAL')]:
        for path in sorted((ROOT/folder).iterdir()):
            if not path.is_file():continue
            sid=('attachment_' if kind.startswith('POLICY') else 'targeted_')+path.name
            if sid in set(df.source_id):continue
            add.append({'source_id':sid,'relative_path':path.relative_to(ROOT).as_posix(),
                        'sha256':sha(path),'source_sha256':sha(path),'bytes':path.stat().st_size,
                        'version':'capture_2026-10-25','material_type':path.suffix.lower().lstrip('.').upper(),
                        'source_locator':URLS.get(path.name,'local project attachment backup'),
                        'evidence_locator':'full file, target body selection in 02_policy/reconstructed/text_source_audit.csv',
                        'availability':'COPIED_HASH_MATCH','confirmation_status':kind})
    registered=set(df.relative_path)|{x['relative_path'] for x in add}
    for path in sorted((ROOT/'05_code').rglob('*.py')):
        if '__pycache__' in path.parts:continue
        rel=path.relative_to(ROOT).as_posix()
        if rel in registered:continue
        add.append({'source_id':'code_B1_'+path.stem,'relative_path':rel,
                    'sha256':sha(path),'source_sha256':'','bytes':path.stat().st_size,
                    'version':'B1_v1.1.0_source_reconstructed','material_type':'PY',
                    'source_locator':'new B1 workspace implementation',
                    'evidence_locator':'source code body','availability':'ADAPTED_LOCAL_CODE',
                    'confirmation_status':'B1_NEW_EXECUTABLE_CODE'})
        registered.add(rel)
    if add:df=pd.concat([df,pd.DataFrame(add)],ignore_index=True)
    assert df.source_id.is_unique
    df.to_csv(FILE,index=False,encoding='utf-8-sig')
    print({'source_records':len(df),'new_evidence_records':len(add),'adapted_code_records':int(df.availability.eq('ADAPTED_LOCAL_CODE').sum())})


if __name__=='__main__':main()
