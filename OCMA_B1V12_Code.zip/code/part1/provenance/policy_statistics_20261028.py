"""Bounded Methods 3.2.1 supplement; frozen conditional labels, never fit a model.

Policy bootstrap is composition sensitivity, not a coding-error model.
Run with the existing project venv. Outputs are separate from immutable C2.
"""
import argparse, bisect, csv, hashlib, json, math, re, sys, time
from pathlib import Path
from zipfile import ZipFile
import xml.etree.ElementTree as ET
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
WS = ROOT / 'OCMA_empirical_revision_workspace_B1_20261026'
BASE = WS / '05_revision_work/R1_20261026/01_coding/coding_pipeline_completion'
ACTIVE = json.loads((BASE/'CURRENT_ACTIVE_PIPELINE.json').read_text('utf-8-sig'))
sys.path.insert(0, ACTIVE['active_code'])
from common import Context, longpath, sha

G = ['G1','G2','G3']; T = ['T1','T2','T3','T4','T5','T6']
STAGES = ['2000-2010','2011-2016','2017-2020','2021-2023']
SCOPES = ['INCLUDE_ALL','EXCLUDE_SOURCE_UNRESOLVED']
VARIANTS = ['A_LEGACY','B_UNKNOWN_PRIMARY','C_UNKNOWN_ZERO_ASSUMPTION','D_UNKNOWN_ONE_ASSUMPTION']
VERSION = 'B1_V1.2_POLICY_STATISTICS_20261028_v1'
SEED = 20261028
B = 2000

def read(p):
    return pd.read_csv(longpath(p), keep_default_na=False, dtype=str, encoding='utf-8-sig')

def write(p, d):
    pd.DataFrame(d).to_csv(longpath(p), index=False, encoding='utf-8-sig', float_format='%.12g', na_rep='NA')

def jout(p, x):
    longpath(p).write_text(json.dumps(x, ensure_ascii=False, indent=2, allow_nan=False), 'utf-8')

def ratio(n,d):
    return n/d if d else np.nan

def truth(s):
    return s.astype(str).str.lower().eq('true')

def require(x,msg):
    if not x: raise ValueError(msg)

def extract_docx(p):
    ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
    with ZipFile(p) as z: root=ET.fromstring(z.read('word/document.xml'))
    ps=[''.join(x.itertext()) for x in []]
    ps=[''.join(t.text or '' for t in x.findall('.//w:t',ns)) for x in root.findall('.//w:p',ns)]
    tables=[]
    for table in root.findall('.//w:tbl',ns):
        tables.append([[''.join(t.text or '' for t in c.findall('.//w:t',ns)) for c in row.findall('./w:tc',ns)] for row in table.findall('./w:tr',ns)])
    return ps,tables

def contract():
    return dict(version=VERSION, seed=SEED, bootstrap_replicates=B,
      stages=STAGES, policy_weight='equal within each stage; policy G/T assignment shares first',
      resampling='independent within-stage SRSWR of n policies, n draws; same draw IDs across labels/specifications',
      interval='numpy quantile(method=linear), .025/.975; sample-composition sensitivity only',
      stage_difference='later minus earlier; independently resampled stages, common replicate index',
      missing='never drop undefined policies silently; stage point/interval NA if any policy share undefined',
      G='sum unit G_k assignments / all G assignments within policy; eligibility fixed to frozen C2',
      T='same assignment denominator; B has unknown machine T2, hence whole T vector undefined unless no eligible T2 unknown',
      cocoding='one count per G-T pair per eligible source unit, multilabel outer product; normalized within each G row',
      cocoding_aggregation='policy counts primary; equal-policy row proportions secondary; pooled counts descriptive and separately labelled',
      counting='sentence/clause source units; no universal independent-action-ID gate; no automatic parent or label merge',
      sources=SCOPES, T2_variants=VARIANTS,
      coding_uncertainty='C/D T2-only conditional bounds; not confidence intervals and not bounds for gate/G3/other errors',
      selection='no model/threshold/label selection; original 600/49 judgments never read',
      RESEARCH_USE_QUALITY_SUPPORTED=False, PART1_COMPLETED=False, part2_started=False)

def build_policy(matrix):
    """Recompute directly from frozen field matrix, not old aggregate outputs."""
    rows=[]
    for scope in SCOPES:
        for pid,z0 in matrix.groupby('policy_id',sort=True):
            z=z0 if scope=='INCLUDE_ALL' else z0[truth(z0.source_scope_verified)]
            q=z[z.C2_eligibility.eq('1')]
            counts={k:int(pd.to_numeric(q['C2_'+k],errors='coerce').sum()) for k in G+T}
            known=int(pd.to_numeric(q.C2_T2,errors='coerce').sum())
            u=int(q.C2_T2.eq('').sum())
            variants={'A_LEGACY':int(pd.to_numeric(q.T2_LEGACY_DIAGNOSTIC).sum()),
                      'B_UNKNOWN_PRIMARY':known if not u else None,
                      'C_UNKNOWN_ZERO_ASSUMPTION':known,'D_UNKNOWN_ONE_ASSUMPTION':known+u}
            for variant in VARIANTS:
                for group,labs in [('G',G),('T',T)]:
                    c=counts.copy();c['T2']=variants[variant]
                    den=sum(c[k] for k in labs) if all(c[k] is not None for k in labs) else None
                    for lab in labs:
                        rows.append(dict(policy_id=pid,stage=z0.iloc[0].stage,source_scope=scope,scenario=variant,
                          group=group,label=lab,eligible_units=len(q),unknown_T2_eligible=u,
                          assignment_count=c[lab] if c[lab] is not None else np.nan,
                          denominator=den if den is not None else np.nan,
                          share=ratio(c[lab],den) if den is not None else np.nan,
                          status='T2_UNIDENTIFIED' if den is None else 'NO_ELIGIBLE_UNIT' if not len(q) else 'ZERO_GROUP_DENOMINATOR' if den==0 else 'DEFINED',
                          measurement='FROZEN_SENTENCE_CLAUSE_PROXY_NO_ATOMIC_ACTION_ID_GATE',
                          evidence='MODEL_CONDITIONAL_NOT_SEMANTICALLY_VALIDATED'))
    return pd.DataFrame(rows)

def bootstrap_and_loo(policy,out):
    """One reusable sample draw per stage; entire policies sampled, never clauses."""
    # Sampling specification is written before any results; all stages are fixed in advance.
    ids={s:sorted(policy.loc[policy.stage.eq(s),'policy_id'].unique()) for s in STAGES}
    draws={s:np.random.default_rng(np.random.SeedSequence([SEED,i])).integers(0,len(ids[s]),size=(B,len(ids[s]))) for i,s in enumerate(STAGES)}
    np.savez_compressed(longpath(out/'bootstrap_policy_indices.npz'),**{f'stage_{i}':draws[s] for i,s in enumerate(STAGES)})
    jout(out/'bootstrap_policy_index_map.json',ids)
    result=[];loo=[];diff=[];rep={}
    for keys,z in policy.groupby(['source_scope','scenario','group','label'],sort=False):
        scope,variant,group,lab=keys
        for stage in STAGES:
            q=z[z.stage.eq(stage)].set_index('policy_id').reindex(ids[stage]);x=q.share.to_numpy(float)
            n=len(x);finite=np.isfinite(x);full=bool(finite.all())
            mean=float(x.mean()) if full else np.nan
            vals=x[draws[stage]].mean(axis=1) if full else np.full(B,np.nan)
            rep[(*keys,stage)]=vals
            lo,hi=np.quantile(vals,[.025,.975],method='linear') if full else [np.nan,np.nan]
            result.append(dict(source_scope=scope,scenario=variant,group=group,label=lab,stage=stage,
               policy_universe_n=n,defined_policy_n=int(finite.sum()),undefined_policy_ids=';'.join(q.index[~finite]),
               mean_share=mean,p025=lo,p975=hi,bootstrap_replicates=B if full else 0,
               planned_bootstrap_replicates=B,seed=SEED,status='DEFINED' if full else 'UNDEFINED_FULL_STAGE',
               interval_identity='POLICY_SAMPLE_COMPOSITION_NOT_CODING_ERROR',
               policy_ids=';'.join(ids[stage])))
            for j,pid in enumerate(ids[stage]):
                remain=np.delete(x,j);v=float(remain.mean()) if len(remain) and np.isfinite(remain).all() else np.nan
                loo.append(dict(source_scope=scope,scenario=variant,group=group,label=lab,stage=stage,removed_policy_id=pid,
                  full_mean=mean,leave_one_out_mean=v,delta_from_full=v-mean,remaining_policy_n=len(remain),
                  full_stage_defined=full,status='DEFINED' if np.isfinite(v) else 'UNDEFINED_REMAINING_POLICY_SHARES'))
        for a,b in zip(STAGES[:-1],STAGES[1:]):
            xa=z[z.stage.eq(a)].share.to_numpy(float);xb=z[z.stage.eq(b)].share.to_numpy(float)
            full=np.isfinite(xa).all() and np.isfinite(xb).all()
            v=rep[(*keys,b)]-rep[(*keys,a)]
            lo,hi=np.quantile(v,[.025,.975],method='linear') if full else [np.nan,np.nan]
            diff.append(dict(source_scope=scope,scenario=variant,group=group,label=lab,earlier_stage=a,later_stage=b,
               earlier_mean=xa.mean() if np.isfinite(xa).all() else np.nan,later_mean=xb.mean() if np.isfinite(xb).all() else np.nan,
               later_minus_earlier=xb.mean()-xa.mean() if full else np.nan,p025=lo,p975=hi,
               bootstrap_replicates=B if full else 0,earlier_policy_n=len(xa),later_policy_n=len(xb),
               interval_identity='POLICY_SAMPLE_COMPOSITION_DIFFERENCE_NOT_CODING_ERROR',status='DEFINED' if full else 'T2_UNIDENTIFIED_OR_ZERO_DENOMINATOR'))
    # Raw replicates allow independent exact replay of intervals without 2000*wide CSV duplication.
    np.savez_compressed(longpath(out/'bootstrap_share_replicates.npz'),**{'|'.join(k):v for k,v in rep.items()})
    return pd.DataFrame(result),pd.DataFrame(loo),pd.DataFrame(diff)

def cocoding(matrix):
    rows=[]
    for scope in SCOPES:
        for pid,z0 in matrix.groupby('policy_id',sort=True):
            z=z0 if scope=='INCLUDE_ALL' else z0[truth(z0.source_scope_verified)]
            z=z[z.C2_eligibility.eq('1')]
            for g in G:
                q=z[z['C2_'+g].eq('1')];u=int(q.C2_T2.eq('').sum())
                known={t:int(pd.to_numeric(q['C2_'+t],errors='coerce').sum()) for t in T}
                other=sum(known[t] for t in T if t!='T2')
                variants={'A_LEGACY':int(pd.to_numeric(q.T2_LEGACY_DIAGNOSTIC).sum()),'B_UNKNOWN_PRIMARY':known['T2'] if not u else None,
                   'C_UNKNOWN_ZERO_ASSUMPTION':known['T2'],'D_UNKNOWN_ONE_ASSUMPTION':known['T2']+u}
                for variant,t2 in variants.items():
                    den=other+t2 if t2 is not None else None
                    for t in T:
                        n=t2 if t=='T2' else known[t]
                        c=ratio(known[t],other+known['T2']);d=ratio(known[t]+(u if t=='T2' else 0),other+known['T2']+u)
                        finite=[v for v in [c,d] if np.isfinite(v)]
                        # If C has denominator zero but D defined, proportions over defined assignments are still meaningful.
                        rows.append(dict(policy_id=pid,stage=z0.iloc[0].stage,source_scope=scope,scenario=variant,G=g,T=t,
                          eligible_units=len(z),G_positive_units=len(q),known_positive_joint_count=known[t],
                          unknown_T2_with_this_G=u,raw_joint_count=n if n is not None else np.nan,
                          raw_joint_lower=known[t],raw_joint_upper=known[t]+(u if t=='T2' else 0),
                          row_joint_assignment_denominator=den if den is not None else np.nan,
                          conditional_T_share_given_G=ratio(n,den) if den is not None else np.nan,
                          conditional_share_lower=min(finite) if finite else np.nan,conditional_share_upper=max(finite) if finite else np.nan,
                          zero_row_denominator_possible=(other+known['T2']==0),
                          pair_prevalence_per_eligible_unit=ratio(n,len(z)) if n is not None else np.nan,
                          status='T2_UNIDENTIFIED_ROW_NORMALIZATION' if den is None else 'ZERO_ROW_DENOMINATOR' if not den else 'DEFINED',
                          identity='MULTILABEL_OUTER_PRODUCT_WITHIN_FROZEN_SOURCE_UNIT;NOT_CAUSAL;NOT_ALL_FIELDS_VALIDATED'))
    return pd.DataFrame(rows)

def aggregate_cocoding(d):
    rows=[]
    for keys,z in d.groupby(['source_scope','scenario','G','T'],sort=False):
        scope,variant,g,t=keys
        for stage in STAGES+['ALL_2000_2023']:
            q=z if stage=='ALL_2000_2023' else z[z.stage.eq(stage)]
            x=q.conditional_T_share_given_G.to_numpy(float)
            # Absence of G is genuinely undefined, not a zero tool mix; explicit support is saved.
            gx=q.G_positive_units.gt(0)
            unidentified=q.loc[gx,'status'].eq('T2_UNIDENTIFIED_ROW_NORMALIZATION').any()
            vals=x[np.isfinite(x)]
            den=pd.to_numeric(q.row_joint_assignment_denominator,errors='coerce')
            pooled=ratio(q.raw_joint_count.sum(),den.sum()) if not unidentified else np.nan
            rows.append(dict(source_scope=scope,scenario=variant,stage=stage,G=g,T=t,policy_universe_n=len(q),
               policies_with_G=int(gx.sum()),defined_policy_row_n=len(vals),
               equal_policy_mean_T_given_G=float(vals.mean()) if len(vals) and not unidentified else np.nan,
               pooled_joint_count=float(q.raw_joint_count.sum()) if q.raw_joint_count.notna().all() else np.nan,
               pooled_T_given_G=pooled,known_joint_count=int(q.known_positive_joint_count.sum()),
               unknown_T2_G_units=int(q.unknown_T2_with_this_G.sum()),
               support='POLICIES_WITH_DEFINED_G_ROW;ABSENT_G_NOT_ZERO',status='T2_UNIDENTIFIED' if unidentified else 'DEFINED_CONDITIONAL'))
    return pd.DataFrame(rows)

def g0_audit(matrix,corpus,admission,historical):
    """Do not infer historical original G0 membership from current predictions."""
    hist=historical.set_index('policy_id');rows=[]
    for pid,a in admission.set_index('policy_id').iterrows():
        z=matrix[matrix.policy_id.eq(pid)];pos=z.C2_eligibility.eq('1');neg=~pos
        model=z.origin_eligibility.str.contains('MODEL|MACHINE',case=False,regex=True)
        allzero=(z[['C2_'+g for g in G]].astype(int).sum(axis=1)==0)&pos
        h=hist.loc[pid] if pid in hist.index else None
        rows.append(dict(policy_id=pid,stage=z.iloc[0].stage,title=a['政策标题'],admitted_68=True,
          original_manuscript_codable_status='INFERRED_CODABLE_FROM_FULL_STAGE_COUNT_NOT_ORIGINAL_RECORD' if z.iloc[0].stage!='2021-2023' else 'ONE_OF_28_HISTORICAL_27_CODABLE_ID_NOT_RECOVERED',
          manuscript_stage_formal_n={'2000-2010':11,'2011-2016':13,'2017-2020':16,'2021-2023':28}[z.iloc[0].stage],
          manuscript_stage_codable_n={'2000-2010':11,'2011-2016':13,'2017-2020':16,'2021-2023':27}[z.iloc[0].stage],
          earlier_B1_reconstruction_G0=h.G0_no_observable_target_action if h is not None else 'UNKNOWN',
          earlier_reconstruction_identity='CODEX_RECONSTRUCTION_NOT_ORIGINAL_67_LIST',
          source_units=len(z),eligible_units=int(pos.sum()),G_assignment_total=int(z.loc[pos,['C2_'+g for g in G]].astype(int).sum().sum()),
          eligible_G_allzero=int(allzero.sum()),eligible_G_allzero_model=int((allzero&model).sum()),eligible_G_allzero_existing=int((allzero&~model).sum()),
          model_negative_gate_units=int((neg&model).sum()),existing_ineligible_units=int((neg&~model).sum()),
          negative_gate_GT_zero_fields=int((neg&model).sum()*9),
          source_unresolved_units=int((~truth(z.source_scope_verified)).sum()),
          current_proxy_codable=bool(pos.any()),current_G0_supported=bool(neg.all() and not model.any()),
          current_G0_identity='NOT_G0_CURRENT_CONDITIONAL_POSITIVE' if pos.any() else 'ALL_MODEL_NEGATIVE_NOT_PROVEN_G0' if model.any() else 'EXISTING_NEGATIVE_EVIDENCE',
          policy_action='PRESERVE_ALL_68_NO_FORCED_G0;ORIGINAL_67_NOT_RECREATED'))
    return pd.DataFrame(rows)

def audit_units(matrix,corpus,recovery,mapping,out):
    """Recover exact reading excerpts; no invented labels or automatic sentence OR."""
    m=matrix.set_index('unit_id');rec=recovery.set_index('unit_id');mp=mapping.set_index('unit_id');rows=[];texts={}
    # Repeated text at different real locations is not physical duplicate evidence.
    physical=corpus.groupby(['policy_id','policy_version_id','source_clean_sha256','clean_start','clean_end']).unit_id.transform('size')
    repeats=corpus.groupby(['policy_id','policy_version_id','exact_evidence_text']).unit_id.transform('size')
    for i,r in corpus.iterrows():
        p=Path(r.source_clean_path)
        if str(p) not in texts:texts[str(p)]=(longpath(p).read_text('utf-8-sig'),sha(p))
        text,h=texts[str(p)];s=int(r.clean_start);e=int(r.clean_end);rr=rec.loc[r.unit_id];v=m.loc[r.unit_id]
        exact=(text[s:e]==r.exact_evidence_text and h==r.source_clean_sha256)
        a=int(rr.source_block_start);b=int(rr.source_block_end)
        restored=text[a:b];valid=exact and restored==rr.source_reading_text and h==rr.source_clean_sha256
        starts=[x.start() for x in re.finditer(r'(?m)^\s*第[一二三四五六七八九十百零〇\d]+条',text[s:e])]
        crosses=len(starts)>1
        expanded=(a,b)!=(s,e)
        # Explicitly flag pure metadata-like positives; never rewrite genuine author labels.
        short=r.exact_evidence_text.strip()
        metadata=bool(re.match(r'^(?:【(?:信息来源|发布部门|发布文号|效力级别|时效状态|发布日期|实施日期)|来源[:：]|责任编辑[:：]|打印|关闭窗口)',short))
        approved=bool(mp.loc[r.unit_id].approved_action_unit_id)
        rows.append(dict(unit_id=r.unit_id,policy_id=r.policy_id,policy_version_id=r.policy_version_id,
          original_start=s,original_end=e,source_clean_sha256=h,target_text_sha256=r.target_text_sha256,
          source_location=r.source_location,source_interval_verified=exact,
          source_sentence_reading_start=a,source_sentence_reading_end=b,source_sentence_reading_verified=valid,
          reading_text_sha256=hashlib.sha256(restored.encode('utf-8')).hexdigest(),
          reading_text=restored,original_text=short,reading_repair_applied=expanded,
          physical_span_duplicates=int(physical.iloc[i]),exact_text_repetitions_distinct_locations=int(repeats.iloc[i]),
          crosses_multiple_numbered_articles=crosses,possible_multiple_source_items=rr.possible_multiple_items,
          eligibility=int(v.C2_eligibility),eligibility_origin=v.origin_eligibility,
          source_scope_verified=v.source_scope_verified,approved_action_boundary=approved,
          pure_metadata_pattern_positive=metadata and v.C2_eligibility=='1',
          counting_identity='FROZEN_SENTENCE_CLAUSE_PROXY',
          independent_action_id_required=False,same_parent_merge=False,labels_changed=False,count_merge_applied=False,
          status='SOURCE_ERROR' if not valid else 'MULTI_ARTICLE_REQUIRES_TARGETED_CHECK' if crosses else 'READING_REPAIRED_LABEL_UNIT_UNCHANGED' if expanded else 'SOURCE_UNIT_PRESERVED',
          remaining_limitation='READING_CONTEXT_NOT_SEMANTIC_APPROVAL;NEVER_PROPAGATE_NEIGHBOUR_ACTION'))
    d=pd.DataFrame(rows)
    require(d.source_interval_verified.all() and d.source_sentence_reading_verified.all(),'Source offsets/hash failed')
    # No duplicate physical spans in this snapshot. Future nonzero requires explicit decision, not silent deduplication.
    require(d.physical_span_duplicates.eq(1).all(),'Physical duplicate measurement requires explicit mapped correction')
    write(out/'source_hashes.csv',[dict(path=str(p),sha256=h) for p,(_,h) in texts.items()])
    return d

def manuscript_consistency(boot,co,units,g0,paragraphs,tables):
    rows=[]
    table=tables[1]
    for cells in table[1:]:
        stage=cells[0]
        for j,g in enumerate(G):
            vals=[float(x)/100 for x in re.findall(r'[\d.]+',cells[3+j])]
            x=boot[(boot.stage==stage)&(boot.label==g)&(boot.scenario=='B_UNKNOWN_PRIMARY')&(boot.source_scope=='INCLUDE_ALL')].iloc[0]
            rows.append(dict(item='Table2_'+stage+'_'+g,manuscript_location='Manuscript.docx/Table2;Results paragraph110',
              original_text=cells[3+j],original_point=vals[0],original_lower=vals[1],original_upper=vals[2],
              current_point=x.mean_share,current_lower=x.p025,current_upper=x.p975,current_minus_original=x.mean_share-vals[0],
              current_result_within_original_interval=vals[1]<=x.mean_share<=vals[2],
              status='CHANGED_POINT_AND_INTERVAL_CONDITIONAL_CODING',
              inference='Interval overlap is not coding validation; original observations/labels not overwritten',
              evidence='stage_policy_bootstrap.csv;G0_policy_consistency.csv'))
    for stage in STAGES:
        q=boot[(boot.stage==stage)&boot.label.isin(G)&(boot.scenario=='B_UNKNOWN_PRIMARY')&(boot.source_scope=='INCLUDE_ALL')]
        order=q.sort_values('mean_share',ascending=False).label.tolist();old={'2000-2010':'G3','2011-2016':'G3','2017-2020':'G2','2021-2023':'G3'}[stage]
        rows.append(dict(item='function_dominance_'+stage,manuscript_location='Results4.1 paragraph110',original_text=old+' largest',
          current_text=' > '.join(order),status='SUPPORTED_ONLY_UNDER_CONDITIONAL_CODING' if order[0]==old else 'CHANGED_DOMINANT_FUNCTION',
          evidence='stage_policy_bootstrap.csv',inference='G3 recall and unit/source errors not covered by bootstrap'))
    for g,t,target in [('G1','T1',.782),('G2','T1',.589),('G2','T3',.27),('G3','T4',.669),('G3','T5',.068),('G3','T6',.02)]:
        q=co[(co.stage=='ALL_2000_2023')&(co.G==g)&(co['T']==t)&(co.source_scope=='INCLUDE_ALL')]
        a=q[q.scenario=='A_LEGACY'].iloc[0];c=q[q.scenario=='C_UNKNOWN_ZERO_ASSUMPTION'].iloc[0];d=q[q.scenario=='D_UNKNOWN_ONE_ASSUMPTION'].iloc[0]
        rows.append(dict(item='function_tool_'+g+'_'+t,manuscript_location='Results4.1 paragraph147;Fig4b;FigS1',
          original_text=f'{target*100:g}%',original_point=target,current_point=np.nan,
          legacy_A_equal_policy_point=a.equal_policy_mean_T_given_G,
          conditional_C_equal_policy=c.equal_policy_mean_T_given_G,conditional_D_equal_policy=d.equal_policy_mean_T_given_G,
          conditional_C_pooled=c.pooled_T_given_G,conditional_D_pooled=d.pooled_T_given_G,
          status='NOT_IDENTIFIABLE_FULL_T_CONFIGURATION_T2_UNKNOWN',
          inference='Original function-tool denominator aggregation not uniquely documented; equal-policy and pooled both reported, no choice by agreement',
          evidence='function_tool_cocoding.csv;function_tool_stage_summary.csv'))
    extras=[
      ('formal_policy_count','68',str(len(g0)),'SUPPORTED_FIXED_ADMISSION'),
      ('codable_policy_count','67 (2021-2023:27)','68 proxy (2021-2023:28)','CHANGED_AND_HISTORICAL_G0_ID_NOT_RECOVERED'),
      ('policy_tool_composition','T1-T6 composition','B whole-vector NA for stages with eligible unknown T2','NOT_IDENTIFIABLE_T2'),
      ('bootstrap_method','2000 within-stage policy bootstrap; equal policy mean','Executed with seed20261028 and percentile linear','METHOD_RESTORED_NOT_QUALITY_CERTIFICATE'),
      ('leave_one_policy_out','separate policy sample sensitivity','Each policy removed once within own stage','METHOD_EXECUTED'),
      ('coding_unit_definition','Sentences/clauses; compound and multilabel permitted',f'{len(units)} source units preserved; no universal atomic action-ID gate','READING_REPAIRED_COUNTING_SEMANTICS_NOT_FULLY_VALIDATED'),
      ('institutional_network_counts','16/16/35/40 actors and 64/47/245/301 ties','Not recomputed; outside this task','OUT_OF_SCOPE_NOT_CHECKED'),
      ('main_claim_reliability','Functional evolution and differentiated configurations','G3/negative gate/source units and T2 remain conditional','RESEARCH_USE_QUALITY_NOT_SUPPORTED')]
    for name,old,new,status in extras:
        rows.append(dict(item=name,manuscript_location='Methods3.2.1;Results4.1;Supplement T1-T6/G0',original_text=old,current_text=new,status=status,evidence='README.md;QA.json',inference='No reverse fitting or label changes'))
    return pd.DataFrame(rows)

def independent_numeric_check(matrix,policy,boot,loo,coc,draws_path):
    """Independent plain csv records/count loops; does not call production aggregators."""
    from collections import defaultdict
    q=defaultdict(lambda:dict(G=[0,0,0],T=[0]*6,u=0,e=0,legacy=0))
    for r in matrix.to_dict('records'):
        if r['C2_eligibility']!='1':continue
        for scope in SCOPES:
            if scope=='EXCLUDE_SOURCE_UNRESOLVED' and r['source_scope_verified'].lower()!='true':continue
            v=q[(scope,r['policy_id'])];v['e']+=1
            for j,g in enumerate(G):v['G'][j]+=int(r['C2_'+g])
            for j,t in enumerate(T):
                if r['C2_'+t]!='':v['T'][j]+=int(r['C2_'+t])
            v['u']+=int(r['C2_T2']=='');v['legacy']+=int(r['T2_LEGACY_DIAGNOSTIC'])
    maxerr=0
    for r in policy.itertuples():
        v=q[(r.source_scope,r.policy_id)]
        if r.group=='G': vals=v['G'];den=sum(vals);n=vals[G.index(r.label)]
        else:
            vals=v['T'].copy()
            if r.scenario=='A_LEGACY':vals[1]=v['legacy']
            elif r.scenario=='D_UNKNOWN_ONE_ASSUMPTION':vals[1]+=v['u']
            elif r.scenario=='B_UNKNOWN_PRIMARY' and v['u']:
                require(not np.isfinite(r.share),'B unknown became point');continue
            den=sum(vals);n=vals[T.index(r.label)]
        expected=n/den if den else float('nan')
        require(np.isfinite(expected)==np.isfinite(r.share),'Mismatch definedness')
        if np.isfinite(expected):maxerr=max(maxerr,abs(expected-r.share))
    require(maxerr<1e-12,'Independent policy ratios failed')
    saved=np.load(longpath(draws_path));idx=json.loads(longpath(draws_path.parent/'bootstrap_policy_index_map.json').read_text('utf-8'))
    maxboot=0;maxloo=0
    for r in boot.itertuples():
        z=policy[(policy.source_scope==r.source_scope)&(policy.scenario==r.scenario)&(policy.group==r.group)&(policy.label==r.label)&(policy.stage==r.stage)].set_index('policy_id')
        x=[float(z.loc[p,'share']) for p in idx[r.stage]]
        if not all(math.isfinite(v) for v in x):continue
        ii=STAGES.index(r.stage)
        means=sorted(sum(x[int(j)] for j in draw)/len(x) for draw in saved[f'stage_{ii}'])
        # Manual linear quantile independent of np.quantile.
        def quant(prob):
            h=(len(means)-1)*prob;i=int(math.floor(h));j=int(math.ceil(h));return means[i]+(h-i)*(means[j]-means[i])
        maxboot=max(maxboot,abs(quant(.025)-r.p025),abs(quant(.975)-r.p975),abs(sum(x)/len(x)-r.mean_share))
    for r in loo.itertuples():
        z=policy[(policy.source_scope==r.source_scope)&(policy.scenario==r.scenario)&(policy.group==r.group)&(policy.label==r.label)&(policy.stage==r.stage)&(policy.policy_id!=r.removed_policy_id)]
        vals=z.share.tolist()
        if vals and all(math.isfinite(v) for v in vals):maxloo=max(maxloo,abs(sum(vals)/len(vals)-r.leave_one_out_mean))
    require(maxboot<1e-12 and maxloo<1e-12,'Bootstrap/LOO independent replay failed')
    # Check co-coding from independent record loops for every policy, source scope and G/T pair.
    cq=defaultdict(int);cu=defaultdict(int);cl=defaultdict(int)
    for r in matrix.to_dict('records'):
        if r['C2_eligibility']!='1':continue
        for scope in SCOPES:
            if scope=='EXCLUDE_SOURCE_UNRESOLVED' and r['source_scope_verified'].lower()!='true':continue
            for g in G:
                if r['C2_'+g]!='1':continue
                cu[(scope,r['policy_id'],g)]+=int(r['C2_T2']=='')
                cl[(scope,r['policy_id'],g)]+=int(r['T2_LEGACY_DIAGNOSTIC'])
                for t in T:
                    if r['C2_'+t]=='1':cq[(scope,r['policy_id'],g,t)]+=1
    require(all(int(r.known_positive_joint_count)==cq[(r.source_scope,r.policy_id,r.G,r.T)] for r in coc.itertuples()),'Independent co-coding count failed')
    maxco=0
    for r in coc.itertuples():
        key=(r.source_scope,r.policy_id,r.G);counts=[cq[(*key,t)] for t in T]
        if r.scenario=='A_LEGACY':counts[1]=cl[key]
        elif r.scenario=='D_UNKNOWN_ONE_ASSUMPTION':counts[1]+=cu[key]
        elif r.scenario=='B_UNKNOWN_PRIMARY' and cu[key]:
            require(not math.isfinite(r.conditional_T_share_given_G),'Unknown T2 row became complete composition');continue
        expected=counts[T.index(r.T)]/sum(counts) if sum(counts) else float('nan')
        require(math.isfinite(expected)==math.isfinite(r.conditional_T_share_given_G),'Co-coding definedness failed')
        if math.isfinite(expected):maxco=max(maxco,abs(expected-r.conditional_T_share_given_G))
    require(maxco<1e-12,'Independent co-coding normalization failed')
    return dict(policy_ratio_max_absolute_error=maxerr,bootstrap_interval_max_error=maxboot,leave_one_out_max_error=maxloo,
                co_coding_known_counts_match=True,co_coding_normalization_max_error=maxco,
                method='separate plain record counters and manual linear percentile; saved actual policy draws')

def independent_check_proposal(loo,g0,out):
    """Proposal only: no audit is drawn, no human judgment or approval is created."""
    z=loo[(loo.source_scope=='INCLUDE_ALL')&(loo.scenario=='B_UNKNOWN_PRIMARY')&(loo.label=='G3')].copy()
    z['absolute_influence']=z.delta_from_full.abs();rows=[]
    for stage in STAGES:
        r=z[z.stage.eq(stage)].sort_values(['absolute_influence','removed_policy_id'],ascending=[False,True]).iloc[0]
        p=g0[g0.policy_id.eq(r.removed_policy_id)].iloc[0]
        rows.append(dict(purpose='G3_EVOLUTION_AND_GATE_OMISSIONS',stage=stage,policy_id=r.removed_policy_id,
          selection='largest absolute G3 leave-one-policy influence within fixed stage; diagnostic scope only',
          leave_one_out_G3_delta=r.delta_from_full,model_gate_negative_units=int(p.model_negative_gate_units),
          source_unresolved_units=int(p.source_unresolved_units),
          proposed_scope='verify target policy body/version first; then a new registered independent check of gate-negative and gate-positive source clauses; recover complete source sentence for each',
          suggested_first_diagnostic_budget='at most 10 gate-negative + 10 gate-positive source clauses per selected policy; no sufficiency/precision guarantee',
          judgment_fields='actual target-and-action eligibility; G3 present/absent; source-unit truncation/duplication; full-clause location',
          statistical_identity='targeted policy diagnostic; not corpus accuracy estimate; random within-stratum only after protocol registration',
          decision_use='determine whether current G3 evolution is materially distorted; do not automatically overwrite frozen labels or extrapolate to all 68 policies',
          status='PROPOSAL_ONLY_NOT_SAMPLED_NOT_APPROVED'))
    rows.append(dict(purpose='T2_CONFIGURATION_IF_MAIN_CLAIM_RETAINED',stage='ALL',policy_id='NOT_YET_SELECTED',
      proposed_scope='a separately registered independent T2 validation design across the intended use pool, preserving positive and negative/unknown identities',
      suggested_first_diagnostic_budget='not fixed from observed performance; otherwise retain unknown and report conditional ranges only',
      decision_use='needed for a complete six-tool main point composition; not required for this conditional supplement',status='PROPOSAL_ONLY_NO_NEW_LABEL_REQUEST'))
    write(out/'minimal_independent_check_proposal.csv',rows)

def targeted_tests():
    tests=[]
    def check(n,b):require(b,n);tests.append(dict(test=n,passed=True,data_identity='SYNTHETIC_TEST_ONLY'))
    check('equal_policy_not_clause_weight',abs(np.mean([1.,0.])-.5)<1e-15 and abs((100+0)/(100+1)-.5)>.4)
    check('unknown_T2_not_zero',not np.isfinite(ratio(0,0)))
    check('multilabel_outer_product_counts_four_pairs',int(np.outer([1,1,0],[1,0,1,0,0,0]).sum())==4)
    check('policy_without_G_denominator_is_NA',np.isnan(ratio(0,0)))
    check('compound_clause_does_not_require_atomic_ID',contract()['counting'].find('no universal independent-action-ID gate')>=0)
    # Statistical invariants in toy data: seed repeat, fixed stage size, duplicate sampling allowed.
    a=np.random.default_rng(123).integers(0,3,(B,3));b=np.random.default_rng(123).integers(0,3,(B,3))
    check('bootstrap_seed_replay',np.array_equal(a,b));check('with_replacement_and_stage_n',a.shape==(B,3) and any(len(set(z))<3 for z in a))
    check('coding_error_not_bootstrap_interval',contract()['RESEARCH_USE_QUALITY_SUPPORTED'] is False)
    return tests

def figures(boot,change,out):
    import matplotlib;matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8,'svg.fonttype':'none','pdf.fonttype':42,
      'axes.spines.top':False,'axes.spines.right':False,'axes.labelsize':9})
    colors=['#477A99','#B67E50','#7E739C']
    fig,(ax,bx)=plt.subplots(1,2,figsize=(10.4,4.0),gridspec_kw={'width_ratios':[1.45,1]},layout='constrained')
    z=boot[(boot.source_scope=='INCLUDE_ALL')&(boot.scenario=='B_UNKNOWN_PRIMARY')&boot.label.isin(G)]
    x=np.arange(4)
    for j,g in enumerate(G):
        q=z[z.label==g].set_index('stage').reindex(STAGES);xx=x+(j-1)*.16
        ax.errorbar(xx,q.mean_share*100,yerr=[(q.mean_share-q.p025)*100,(q.p975-q.mean_share)*100],fmt='o-',capsize=3,color=colors[j],label=g,ms=4,lw=1)
    ax.set(xticks=x,xticklabels=[f'{s}\n(n={n})' for s,n in zip(STAGES,[11,13,16,28])],ylabel='Equal-policy G assignment share (%)',ylim=(0,100),title='a  Governance functions: conditional coding')
    ax.legend(ncol=3,loc='upper center');ax.grid(axis='y',alpha=.15)
    z=change[(change.source_scope=='INCLUDE_ALL')&(change.scenario=='B_UNKNOWN_PRIMARY')&change.label.isin(G)]
    for j,g in enumerate(G):
        q=z[z.label==g].set_index('later_stage').reindex(STAGES[1:]);yy=np.arange(3)+(j-1)*.18
        bx.errorbar(q.later_minus_earlier*100,yy,xerr=[(q.later_minus_earlier-q.p025)*100,(q.p975-q.later_minus_earlier)*100],fmt='o',capsize=3,color=colors[j],ms=4)
    bx.axvline(0,lw=.8,color='gray',ls='--');bx.set(yticks=np.arange(3),yticklabels=['Stage 1 → 2','Stage 2 → 3','Stage 3 → 4'],xlabel='Later − earlier share (percentage points)',title='b  Adjacent-stage differences')
    for ext in ['svg','pdf','png']:fig.savefig(longpath(out/f'Figure_S8_policy_composition.{ext}'),dpi=600)
    # Small preview is the exact same figure layout, only lower raster resolution for inspection.
    fig.savefig(longpath(out/'Figure_S8_preview.png'),dpi=130);plt.close(fig)

def docs(out,boot,g0,units,qa,consistency):
    z=boot[(boot.source_scope=='INCLUDE_ALL')&(boot.scenario=='B_UNKNOWN_PRIMARY')&boot.label.isin(G)]
    lines=['# B1 V1.2 政策统计补充：执行报告','',
      '本轮仅从当前冻结的条件性编码补充Methods 3.2.1统计，不改标签、模型、阈值或C2批准状态。未运行SD及年度治理。',
      '', '## 统计口径与不确定性',
      '每篇政策先以G赋值总数/T赋值总数归一，再在四阶段政策等权平均。多标签不互斥；同一单元可同时贡献多个赋值。每阶段有放回抽取本阶段n篇政策，2,000次；种子20261028，2.5%–97.5%线性分位数。相邻阶段先分别抽样，再逐重复取后减前。',
      '这些95%区间描述固定语料的政策样本组成敏感性，不包含编码误差、来源错误、阶段划分不确定性，不是总体政策抽样的严格概率推断。68项是准入清单，不是从完整政策总体中随机抽样；按篇Bootstrap也未把修订家族的相关性另行建模。',
      'Bootstrap和逐篇留一均对冻结标签有条件；编码质量不足不能因数值复算通过而变为可靠。T2的C/D范围是未知标签假设的条件性范围，与Bootstrap区间分别列示；不与其合并为一种95%区间。',
      '', '## 本轮G结果（条件性）','', '|阶段|G1 [政策组成区间]|G2 [政策组成区间]|G3 [政策组成区间]|','|---|---|---|---|']
    for s in STAGES:
        parts=[]
        for g in G:
            r=z[(z.stage==s)&(z.label==g)].iloc[0];parts.append(f'{r.mean_share*100:.2f}% [{r.p025*100:.2f}, {r.p975*100:.2f}]')
        lines.append('|'+s+'|'+'|'.join(parts)+'|')
    lines += ['', '## 67/68与G0',
      '准入68项与当前编码68项按policy_id逐一匹配。原稿67项只恢复了阶段总数：11/13/16/27；未找到能证明原稿唯一G0政策身份的原始条款表。较早B1重建表反而有两项G0（66项可编码），该表不是原投稿67清单，单列对照，不作本轮筛选依据。当前所有68项都有条件性阳性；不强行改G0。',
      f'当前合格但G全零{int(g0.eligible_G_allzero.sum())}单元；机器负门控{int(g0.model_negative_gate_units.sum())}单元，不等于经人工证实不合格。G0_policy_consistency逐政策分开这些来源身份。',
      '', '## 共编码与工具组成',
      'function_tool_cocoding.csv按政策输出3×6所有组合、A/B/C/D及两种来源范围。raw_joint_count为同单元G与T同时为1的次数，允许一单元贡献多个组合。known_positive_joint_count只计已知的当前值，机器T2未知不置0。归一化为每个G行内的T共现赋值比例（行分母为六类T共现总赋值）。T2未知导致有关行的完整组成比例NA；同时保留已识别次数与C/D条件上下界。',
      'function_tool_stage_summary另列政策等权与汇总赋值次数加权，两者不是同一估计量。政策中无该G的行定义为NA并明确支持范围，不当0。原稿未唯一说明功能—工具全局百分比的跨政策分母，因此两口径都提供，不以接近原稿决定口径。',
      'B为主要证据状态；A仅旧点值对照，C/D是假定所有未识别T2为0/1。非T2的完整组成也受T2分母影响；不得把五类重新归一后当六类完整工具配置。',
      '', '## 原文单元与最小修复',
      f'{len(units)}个原ID保留，源位置和清洁正文哈希逐条通过；同一物理区间重复数为0。本轮恢复{int(units.reading_repair_applied.sum())}个单元的实际句段阅读上下文，不把相同parent、相同标签或阅读块直接合并为行动。',
      '原稿允许句/条款、复合句与多标签，本轮统计不加“先取得独立行动ID”门槛。原计数批准仍保留。可证明的阅读截断作展示层恢复，保留旧单位到实际字符范围及正文哈希；邻近行动标签不传播。',
      '部分网页切分/标题与正文混合的真实编码单位仍未获语义核验；为避免重新编码冒充冻结结果，本轮未做无证据的标签合并或清除。coding_unit_consistency标明原位置、恢复范围、跨编号候选、纯元数据阳性候选与现有来源未决。候选不等于自动删除决定，也不等于逐条必审队列。',
      '', '## 与原稿、旧结果及状态',
      'manuscript_result_consistency逐项保留原Table2点值/区间、当前点值/区间和差值，原文Results功能排序与六个G–T百分比。原网络计数及后续SD结果不在本轮范围，未声称复算。',
      'A/B/C/D、排序审计、旧三池失败及不利分类头结果均按原哈希保留并随preserved_context给出。新bootstrap不选择原稿接近的模型；原600及49条标签没有读取。',
      'COMPUTATION_REPRODUCIBLE=true；RESEARCH_USE_QUALITY_SUPPORTED=false；PART1_COMPLETED=false。作者采用机器补全的批准不等于逐条人审，也不代替质量证据。',
      '', '## 真实执行与检查',
      '本轮已执行：冻结输入哈希、68政策对应、2,000次分阶段政策Bootstrap、每政策留一、相邻阶段差、全部政策G–T共编码、逐单元字符位置核验、独立计数/算术/分位数复核、相关合成边界测试、表图导出。QA.json区分真实数据检查与合成测试。未重新训练、未抽取新人审、未运行年度库存/G、SD或Shapley。',
      '输入/代码/配置/产物哈希在input_hashes、manifest；source_hashes绑定68份清洁正文。bootstrap_policy_indices.npz和bootstrap_policy_index_map保存真实抽样；bootstrap_share_replicates保存逐次计算值。',
      '', '## 停止点及必要证据提案（未自动执行）',
      '若要把功能演变写成正式主结论，优先针对影响G3、负门控与单位/来源身份的固定政策范围做一次目的明确的独立核查；不重审原600/49或全库，不改原判断。minimal_independent_check_proposal.csv已按各阶段G3留一绝对影响最大者列出4项具体政策，建议先登记至多每篇20个源句段的诊断范围；它是针对性核查而非全库质量验收，也不保证80个单元足够。未抽样、未发起新审核。不能以选择性便利审核外推全库。',
      '若正式报告六类工具配置，需要新的、独立于已查看评价的经济工具T2核查或明确缩小论文论断为已识别共现次数/条件性范围；当前材料不足以给出可信T2主点估计。原稿67项G0身份如继续保留需原始证据；无法恢复时应按本轮68项条件性重建如实改写。',
      '本轮统计到此停止，不自动启动上述核查、模型改进或第二部分。',
      '', '## 可执行命令',
      '在项目根目录执行：',
      '```powershell',
      "$env:PYTHONIOENCODING='utf-8'",
      ".\\OCMA_empirical_revision_workspace_B1_20261026\\.venv\\Scripts\\python.exe .\\policy_statistics_20261028.py",
      '.\\OCMA_empirical_revision_workspace_B1_20261026\\.venv\\Scripts\\python.exe .\\policy_statistics_20261028.py --verify-only',
      '```']
    longpath(out/'README.md').write_text('\n'.join(lines),'utf-8')
    caption='Figure S8 | Governance-function composition under frozen conditional coding. a, Policy-equal means; error bars show the 2.5th–97.5th percentiles of 2,000 within-stage policy bootstrap replicates (n = 11, 13, 16, 28 policies). b, Later-minus-earlier differences from independently resampled stages. These intervals quantify policy-sample composition sensitivity, not coding error. Machine G3, eligibility gating and source-unit limitations remain; no T2 point estimate is shown. Labels, model and thresholds were unchanged.'
    longpath(out/'Figure_S8_caption.txt').write_text(caption,'utf-8')
    # Searchable/printable supplement, underlying full CSVs always retained.
    h=['<!doctype html><meta charset="utf-8"><style>body{font:14px Arial;margin:32px;max-width:1400px}table{border-collapse:collapse;font-size:12px}td,th{border:1px solid #bbb;padding:5px}th{background:#eee}</style>',
       '<h1>Table S9. Policy sample-composition sensitivity and manuscript consistency</h1>',
       '<p>Conditional coding only. Intervals describe policy composition, not coding errors. T2 primary state remains unknown. Main-paper Table2 and Fig4b/FigS1 correspondences are identified in CSV.</p>',z.to_html(index=False),
       '<h2>Adjacent-stage changes and manuscript checks</h2>',consistency.to_html(index=False),
       '<p>Complete tool A/B/C/D and both source scopes: stage_policy_bootstrap.csv; complete leave-one-out: leave_one_policy_out.csv.</p>']
    longpath(out/'Table_S9_policy_statistics.html').write_text('\n'.join(h),'utf-8')
    write(out/'Table_S9_G_bootstrap.csv',z)
    write(out/'Figure_S8_source_data.csv',boot[(boot.scenario=='B_UNKNOWN_PRIMARY')&boot.label.isin(G)])

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--verify-only',action='store_true');args=ap.parse_args()
    ctx=Context(str(WS),ACTIVE['run_id']);current=ctx.root/'C2_CURRENT.json';cur=json.loads(current.read_text('utf-8-sig'))
    snap=WS/cur['snapshot_directory'];rec=WS/cur['source_structure_supplement']['workspace_relative_directory']
    paths=dict(current=current,matrix=snap/'C2_conditional_evidence.csv',corpus=ctx.artifact('prepare')/'corpus.csv',
      recovery=rec/'source_structure_reading_recovery.csv',mapping=snap/'source_unit_to_action_mapping.csv',
      admission=WS/'b1/01_sources/policy/admission_68.csv',original_admission=ROOT/'data/processed/莱州湾蓝碳政策全文摘要库_2000-2023语义分析准备版_20260723/00_清单/语义分析准入全文清单_68条.csv',
      historical=WS/'b1/02_policy/reconstructed/policy_function_shares_B1.csv',
      manuscript=WS/'00_reference/Manuscript.docx',supplement=WS/'00_reference/supplementary material.docx',
      model=ctx.artifact('train')/'diagnostic_model.joblib',old_policy_G=snap/'source_scope_conditional_shares.csv',
      old_policy_T=snap/'policy_scenario_tool_composition.csv',old_quality=snap/'coding_quality_and_limitations.csv',
      old_rank=snap/'stage_comparison_sensitivity.csv',old_status=snap/'PART1_EXECUTION_STATUS.json',code=Path(__file__))
    before={k:sha(p) for k,p in paths.items()};key=hashlib.sha256(json.dumps(before,sort_keys=True).encode()).hexdigest()[:16]
    out=ctx.root/'policy_statistics_supplement_20261028'/key
    out.mkdir(parents=True,exist_ok=True)
    if args.verify_only:
        manifest=json.loads(longpath(out/'manifest.json').read_text('utf-8'))
        require(all(sha(out/f)==h for f,h in manifest['files'].items()),'Published statistics hash changed')
        require(all(sha(paths[k])==v for k,v in before.items()),'Input changed')
        print(json.dumps(dict(output=str(out),published_hashes_verified=len(manifest['files']),RESEARCH_USE_QUALITY_SUPPORTED=False),ensure_ascii=False));return
    if (out/'manifest.json').exists():
        print(json.dumps(dict(output=str(out),already_completed=True),ensure_ascii=False));return
    start=time.time()
    jout(out/'statistical_protocol.json',contract()) # before results
    jout(out/'figure_contract.json',dict(conclusion='Frozen function composition and stage differences are conditional on coding, policy-composition uncertainty separate from errors',
      archetype='quantitative grid',backend='Python matplotlib',panels={'a':'stage G means and policy bootstrap intervals','b':'adjacent stage G differences'},
      export='10.4 x 4 inch; editable SVG/PDF; PNG600; source data; no T2 validated point'))
    matrix=read(paths['matrix']);corpus=read(paths['corpus']);ad=read(paths['admission'])
    require(matrix.unit_id.is_unique and corpus.unit_id.is_unique and set(matrix.unit_id)==set(corpus.unit_id),'Unit alignment failed')
    require(set(ad.policy_id)==set(matrix.policy_id),'68 admission alignment failed')
    original_ad=read(paths['original_admission'])
    require(set(original_ad.policy_id)==set(ad.policy_id),'Original admission IDs changed')
    # Current snapshot registry hashes must match, including T2 unknown evidence.
    require(sha(paths['matrix'])==cur['file_hashes']['C2_conditional_evidence.csv'],'Frozen current matrix hash mismatch')
    oldman=Path('C:/Users/Mario/Desktop/OCMA投稿/Manuscript.docx');oldsup=oldman.parent/'supplementary material.docx'
    require(sha(oldman)==sha(paths['manuscript']) and sha(oldsup)==sha(paths['supplement']),'Submission reference copy drift')
    paragraphs,tables=extract_docx(paths['manuscript']);sp,st=extract_docx(paths['supplement'])
    jout(out/'manuscript_extracted_evidence.json',dict(paragraphs={str(i):p for i,p in enumerate(paragraphs) if i in [79,80,81,82,110,147]},table2=tables[1],supplement_G0={str(i):p for i,p in enumerate(sp) if 52<=i<=55}))
    policy=build_policy(matrix);write(out/'policy_statistical_input.csv',policy)
    boot,loo,change=bootstrap_and_loo(policy,out)
    write(out/'stage_policy_bootstrap.csv',boot);write(out/'leave_one_policy_out.csv',loo);write(out/'stage_function_change.csv',change)
    coc=cocoding(matrix);co=aggregate_cocoding(coc)
    write(out/'function_tool_cocoding.csv',coc);write(out/'function_tool_stage_summary.csv',co)
    g0=g0_audit(matrix,corpus,ad,read(paths['historical']));write(out/'G0_policy_consistency.csv',g0)
    units=audit_units(matrix,corpus,read(paths['recovery']),read(paths['mapping']),out);write(out/'coding_unit_consistency.csv',units)
    consistency=manuscript_consistency(boot,co,units,g0,paragraphs,tables);write(out/'manuscript_result_consistency.csv',consistency)
    independent_check_proposal(loo,g0,out)
    numeric=independent_numeric_check(matrix,policy,boot,loo,coc,out/'bootstrap_policy_indices.npz')
    # Reconcile recomputed policy shares with frozen A/B/C/D aggregates, not used as calculation input.
    oldg=read(paths['old_policy_G']);oldg=oldg[oldg.group.eq('G')]
    compare=policy[policy.group.eq('G')&policy.scenario.eq('A_LEGACY')].merge(oldg,on=['policy_id','stage','source_scope','group','label'],suffixes=('_new','_old'),validate='one_to_one')
    maxg=float(np.abs(compare.share_new-pd.to_numeric(compare.share_old,errors='coerce')).max())
    oldt=read(paths['old_policy_T']);cmp=policy[policy.group.eq('T')].merge(oldt,on=['policy_id','stage','source_scope','scenario','label'],suffixes=('_new','_old'),validate='one_to_one')
    nt=pd.to_numeric(cmp.share_old,errors='coerce');maxt=float(np.nanmax(np.abs(cmp.share_new-nt)))
    require(maxg<1e-9 and maxt<1e-9 and cmp.share_new.isna().equals(nt.isna()),'Frozen aggregate reconciliation failed')
    tests=targeted_tests()
    # Actual adjacent difference intervals independently checked from saved replicates.
    rr=np.load(longpath(out/'bootstrap_share_replicates.npz'));maxdiff=0
    for r in change.itertuples():
        if not np.isfinite(r.later_minus_earlier):continue
        k='|'.join([r.source_scope,r.scenario,r.group,r.label])
        v=rr[k+'|'+r.later_stage]-rr[k+'|'+r.earlier_stage]
        a,b=np.quantile(v,[.025,.975]);maxdiff=max(maxdiff,abs(a-r.p025),abs(b-r.p975))
    require(maxdiff<1e-12,'Adjacent interval mismatch')
    figures(boot,change,out)
    qa=dict(version=VERSION,actual_data_checks=dict(units=len(matrix),policies=len(ad),stage_policy_counts={s:int(matrix.loc[matrix.stage.eq(s),'policy_id'].nunique()) for s in STAGES},
      source_intervals_verified=int(units.source_interval_verified.sum()),reading_intervals_verified=int(units.source_sentence_reading_verified.sum()),
      duplicate_physical_spans=int((units.physical_span_duplicates>1).sum()),reading_repairs=int(units.reading_repair_applied.sum()),
      metadata_pattern_positive_candidates=int(units.pure_metadata_pattern_positive.sum()),multi_article_candidates=int(units.crosses_multiple_numbered_articles.sum()),
      eligible_G_allzero=int(g0.eligible_G_allzero.sum()),model_negative_gate=int(g0.model_negative_gate_units.sum()),
      stage_bootstrap_rows=len(boot),defined_stage_bootstrap_rows=int(boot.bootstrap_replicates.eq(B).sum()),leave_one_out_rows=len(loo),
      cocoding_rows=len(coc),original_admission_all_match=True,original_manuscript_copy_hash_matches=True,
      frozen_G_max_rounding_difference=maxg,frozen_T_max_rounding_difference=maxt,adjacent_interval_max_difference=maxdiff,**numeric),
      synthetic_tests=tests,not_executed=['new semantic coding validation','new audit sampling','retraining','threshold selection','SD','annual governance'],
      RESEARCH_USE_QUALITY_SUPPORTED=False,PART1_COMPLETED=False)
    jout(out/'QA.json',qa);docs(out,boot,g0,units,qa,consistency)
    write(out/'Table_S10_function_tool_summary.csv',co)
    longpath(out/'Table_S10_function_tool_summary.html').write_text('<!doctype html><meta charset="utf-8"><style>body{font:14px Arial;margin:30px}table{border-collapse:collapse;font-size:11px}td,th{border:1px solid #bbb;padding:4px}</style><h1>Table S10. Function–instrument co-coding: policy-equal and pooled summaries</h1><p>B is the primary evidence state; eligible unknown machine T2 remains unknown. A is legacy diagnostic; C/D are conditional assumptions, not confidence limits. All scenarios and both source treatments are retained. Undefined G rows are never set to zero. Full policy-level raw pair counts and within-G normalized proportions: function_tool_cocoding.csv.</p>'+co.to_html(index=False),'utf-8')
    # Keep all adverse context together without altering or recreating its conclusions.
    import shutil
    preserved=out/'preserved_context';preserved.mkdir(exist_ok=True)
    for name in ['T2_conditional_sensitivity.csv','stage_comparison_sensitivity.csv','stage_tool_composition_ranges.csv','policy_tool_composition_ranges.csv','label_machine_quality_diagnostics.csv','Table_S7C_old_failed_pools.csv','coding_quality_and_limitations.csv','PART1_EXECUTION_STATUS.json']:
        p=snap/name
        require(longpath(p).exists(),'Frozen adverse context missing: '+name)
        shutil.copyfile(longpath(p),longpath(preserved/name))
    shutil.copyfile(Path(__file__),longpath(out/Path(__file__).name))
    write(out/'input_hashes.csv',[dict(role=k,path=str(p.relative_to(WS)) if p.is_relative_to(WS) else str(p),sha256=before[k]) for k,p in paths.items()])
    require(all(sha(p)==before[k] for k,p in paths.items()),'Frozen inputs/code changed during run')
    jout(out/'run_log.json',dict(started_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime(start)),elapsed_seconds=time.time()-start,
      scope='frozen policy statistics only',model_sha256=before['model'],model_fits=0,threshold_searches=0,new_audit_samples=0,labels_changed=0,
      bootstrap_replicates_per_defined_stage_spec=B,seed=SEED,inputs_unchanged=True,completed_calculations=True,
      actual_command=f'{sys.executable} {Path(__file__)}',python=sys.version,numpy=np.__version__,pandas=pd.__version__))
    files={str(p.relative_to(out)).replace('\\','/'):sha(p) for p in out.rglob('*') if p.is_file() and p.name!='manifest.json'}
    jout(out/'manifest.json',dict(version=VERSION,input_hashes=before,files=files,all_requested_statistics_executed=True,RESEARCH_USE_QUALITY_SUPPORTED=False,PART1_COMPLETED=False))
    # Does not change C2_CURRENT or pipeline stage state.
    jout(ctx.root/'POLICY_STATISTICS_CURRENT.json',dict(version=VERSION,workspace_relative_path=str(out.relative_to(longpath(WS))),manifest_sha256=sha(out/'manifest.json')))
    print(json.dumps(dict(output=str(out),qa=qa['actual_data_checks'],completed=True,RESEARCH_USE_QUALITY_SUPPORTED=False),ensure_ascii=False))

if __name__=='__main__':main()
