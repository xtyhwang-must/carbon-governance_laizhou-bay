"""Read-only spreadsheet input extraction; no model or statistical execution."""
from pathlib import Path
import csv,json,hashlib,re,argparse
ROOT=Path(__file__).resolve().parent
CHILD=ROOT/'OCMA_empirical_revision_workspace_B1_20261026/05_revision_work/R1_20261026/01_coding/coding_pipeline_completion/runs/part1_completion_20261027/history_quality_repair_20261028/sample_528'
SCOPE_HASH='b834784e5cc336396acceb1657446c5583978ddde58974b7bd4aa7a8b6708653'
PROTOCOL_HASH='ac6da323683e56091abab2795afed782c7e1f5d54dcdbeddc069ab46991fce2f'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def display(text):return re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f]',lambda m:f'⟦U+{ord(m.group()):04X}⟧',text)

def chunks(text,width=50,max_lines=10):
 parts=[];part='';line=1;col=0
 for char in text:
  part+=char
  if char=='\n':line+=1;col=0
  else:
   col+=1
   if col>=width:line+=1;col=0
  if line>=max_lines:parts.append(part);part='';line=1;col=0
 if part:parts.append(part)
 return parts or ['']

def run(role='PRIMARY',binary=False):
 assert role in ['PRIMARY','SECONDARY']
 child=CHILD;assert sha(child/'G_ONLY_SCOPE_REVISION.json')==SCOPE_HASH
 manifest=json.loads((child/'sample/sample_manifest.json').read_text('utf-8'))
 assert all(sha(child/'sample'/name)==value for name,value in manifest['files'].items())
 with (child/f'sample/registered_{role}_TEMPLATE.csv').open(encoding='utf-8-sig',newline='') as file:template=list(csv.DictReader(file))
 readings={};rows=[]
 for r in template:
  readings.setdefault(r['reading_id'],r)
  rows.append([r['unit_id'],display(r['exact_evidence_text']),None,None,None,None,None,None,r['reading_id'],r['clean_start']+':'+r['clean_end']] if binary else [r['unit_id'],display(r['exact_evidence_text']),None,None,None,None,None,None,r['reading_id'],None,None,None,r['clean_start']+':'+r['clean_end']])
 source=[];links={}
 for rid,r in readings.items():
  links[rid]=len(source)+2
  for n,text in enumerate(chunks(display(r['reading_text'])),1):source.append([rid,n,r['policy_id'],text,r['source_location']])
 batch=[['reviewer',None,'请填真实审核者姓名'],['completed_at',None,'请填本批实际完成时间，如2026-10-28 18:30；不要预填或推测'],
    ['confirmation',None,'填写完成后选择：确认本人实际审核'],['coder_role',role,'主审528目标；第二编码106目标，须由另一真实人员独立完成'],
    ['review_scope','G_ONLY','只审核合格性和G1—G3，T保持未知'],['presentation_schema','JOINT528_G_ONLY_XLSX_V1','固定表格结构，请保留'],
    ['scope_revision_sha256',SCOPE_HASH,'已批准的范围修订，勿改'],['protocol_sha256',PROTOCOL_HASH,'原528抽样协议，勿改']]
 notes=[['项目','填写规则'],['本表范围','528个固定目标，264个抽样层，502个阅读块；不需重新审核旧600/49或已完成材料。'],
    ['填写顺序','先在审核填写页阅读目标，点击“阅读原文”链接看完整上下文。填写C—G列；仅有异常时填写H、J—L列。'],
    ['合格性','1/合格：目标同时具有相关治理对象与行动；0/不合格：标题、背景、愿景、网页信息或没有相应行动。无法判断可选“无法判断”。'],
    ['G1','源头压力控制：污染、排污、养殖/工业/农业生产压力或入海污染负荷控制。'],
    ['G2','生境保护修复：湿地、潮滩、盐沼、岸线等生境的保护、维护、恢复或修复。'],
    ['G3','监测协调：环境监测、预警、反馈、跨部门/跨辖区协调及相应治理组织行动。'],
    ['G字段','属于的类别填1；可填多个1。不属于可填0，或留空后明确确认三类均已检查。未确认的空白始终为未知。'],
    ['完成确认','无异常请选择“G已检查，来源句条无异常”，同时明确确认G三类、来源正文和句条有效性。有异常选择“G已检查，有异常”，并填写实际来源/句条情况。'],
    ['不合格','合格性填0后，G由该真实父证据依法派生0，不必逐个填零；T不填写。'],
    ['原文单位','仅判断目标单元；上下文不能把邻句行动传播过来。允许复合句和多标签。不得仅凭parent、相似文字或相同标签合并。'],
    ['原文页','每个阅读块原文只存一次。长块分为连续片段，按片段序号阅读，拼接后原文完全不变。'],
    ['保留内容','不要修改或删除unit_id、目标原文、reading_id、原文位置和阅读原文页；不要修改固定协议字段。'],
    ['保存回传','BATCH_INFO页填姓名、实际完成时间和本人确认，直接保存.xlsx并告知已填写。可分批回传；未填写行不视为接受。'],
    ['后续计算','每项政策的预定样本全部有效后计算该政策；每阶段完整后计算阶段。第二编码未返回不阻止主审计算。'],
    ['盲审身份','本表不含机器建议、分数或旧参考答案。当前表仅主审；第二编码者不得查看此已填写工作簿。']]
 if role=='SECONDARY':
  notes[1]=['本表范围',f'原定{len(rows)}个第二编码目标，{len(readings)}个阅读块；原名单和概率身份不变。']
  notes[-2]=['后续计算','按作者本轮安排，第二编码表返回后再启动主审G估计与独立一致性计算。当前不运行研究计算。']
  notes[-1]=['独立盲审','须由不同于主审的真实人员独立填写。不得查看主审答案或复制主审判断；本表不含机器建议、分数或旧参考答案。']
 if binary:
  batch[2]=['confirmation',None,'本批实际独立审核完成填1；0或空白不表示确认']
  batch[5][1]='JOINT528_G_ONLY_BINARY_XLSX_V1'
  notes=[['项目','0/1填写规则'],['本表范围',f'{len(rows)}个原定第二编码目标，名单、原文与概率身份不变。'],
   ['只填C—H','审核区全部用0/1，不填写文字结论。空白=未判断/无法判断，不能用0代替不知道。'],
   ['C 合格性','1=有明确相关治理对象和行动；0=不合格。标题、愿景、背景、网页信息不因相邻行动而合格。'],
   ['D—F G1/G2/G3','合格时三个字段分别填0或1，可多个1。1=属于，0=明确不属于。不合格时G可留空，由资格父证据依法派生0。'],
   ['G 属于目标正文','1=确认是目标政策正文；0=明确不是目标政策正文。不能确认请留空。'],
   ['H 句条无异常','1=句/条款有效（复合句允许），无截断、重复或跨条混合问题；0=存在此类问题。H=0仅标记问题，不把合格性或G改成0。'],
   ['G1','源头压力控制：污染/排污、生产压力及入海污染负荷控制。'],
   ['G2','生境保护修复：湿地、潮滩、盐沼、岸线等生境保护、维护或修复。'],
   ['G3','监测协调：环境监测、预警、反馈、跨部门/辖区协调及治理组织行动。'],
   ['原文与批次','I列保留阅读块ID，J列保留原文位置，K列链接完整原文。BATCH_INFO仅填写一次真实姓名、实际完成时间，确认格填1。'],
   ['独立性','由另一真实编码者独立填写，不查看主审答案。不填写T。保存xlsx回传，第二表返回后再运行研究计算。']]
 folder=ROOT/'outputs/JOINT_528_ac6da323683e5609/xlsx_authoring'
 input_name='workbook_input_SECONDARY_BINARY.json' if binary else 'workbook_input.json' if role=='PRIMARY' else 'workbook_input_SECONDARY.json'
 (folder/input_name).write_text(json.dumps(dict(rows=rows,source=source,links=links,batch=batch,notes=notes,
    metadata=dict(sample_n=len(rows),reading_n=len(readings),sample_manifest_sha256=sha(child/'sample/sample_manifest.json'),member_sha256=sha(child/'sample/actual_sample_BACKEND.csv'))),ensure_ascii=False),'utf-8')
 print(dict(rows=len(rows),reading_blocks=len(readings),reading_fragments=len(source)))

if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--role',choices=['PRIMARY','SECONDARY'],default='PRIMARY');parser.add_argument('--binary',action='store_true');args=parser.parse_args();assert not args.binary or args.role=='SECONDARY';run(args.role,args.binary)
