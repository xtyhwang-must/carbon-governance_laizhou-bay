"""Scoped G continuation regression. Synthetic fixtures never enter real returns."""
import json,shutil,tempfile,traceback
from pathlib import Path
from unittest.mock import patch
import numpy as np
import pandas as pd
import joint_history_audit_20261028 as j
import joint528_compact_20261028 as c
import joint528_G_ONLY_execution_20261028 as run

RESULTS=[]
def check(name,kind,fn):
 try:fn();RESULTS.append(dict(test=name,identity=kind,status='PASS'))
 except Exception:RESULTS.append(dict(test=name,identity=kind,status='FAIL',trace=traceback.format_exc()))

def fixture(root):
 (root/'sample').mkdir();rows=[];sample=[];alloc=[];templates=[]
 for pn in range(4):
  pid='TEST_P'+str(pn);stage=j.STAGES[0] if pn<2 else j.STAGES[pn-1]
  for n in range(2):
   uid=pid+'_'+str(n)
   rows.append(dict(unit_id=uid,policy_id=pid,stage=stage,policy_family_id=pid,existing_fields_to_reuse='',source_scope_verified=False,
       C2_eligibility=1,C2_G1=1,C2_G2=0,C2_G3=0,C2_T2=''))
   base=dict(unit_id=uid,policy_id=pid,policy_version_id=pid,stage=stage,reading_id=uid,exact_evidence_text='SYNTHETIC_TARGET',reading_text='SYNTHETIC_CONTEXT',
       source_location='TEST_ONLY',clean_start='0',clean_end='10',source_hash='TEST_SOURCE',source_clean_sha256='TEST_SOURCE',requested_fields=';'.join(j.LABELS),
       unit_validity='',source_membership='',canonical_unit_id='',G_selected='',T_selected='',G_group_checked='',T_group_checked='')
   base.update({'human_'+k:'' for k in j.LABELS});templates.append(base)
   if pn<3:sample.append(dict(unit_id=uid,policy_id=pid,stratum_id=pid,inclusion_probability=1,design_weight=1,statistical_identity='JOINT_STRATIFIED_SRSWOR'))
  if pn<3:alloc.append(dict(policy_id=pid,stratum_id=pid,N=2,sample_n=2))
 j.csvout(root/'sampling_frame_BACKEND.csv',rows);j.csvout(root/'sample/actual_sample_BACKEND.csv',sample);j.csvout(root/'allocation_SYNTHETIC.csv',alloc)
 for role in ['PRIMARY','SECONDARY']:j.csvout(root/f'sample/registered_{role}_TEMPLATE.csv',templates[:6])
 j.jsonout(root/'joint_audit_protocol.json',dict(identity='SYNTHETIC_NOT_REAL_APPROVAL'))
 files={n:j.sha(root/'sample'/n) for n in ['actual_sample_BACKEND.csv','registered_PRIMARY_TEMPLATE.csv','registered_SECONDARY_TEMPLATE.csv']}
 j.jsonout(root/'sample/sample_manifest.json',dict(option='SYNTHETIC',files=files,n=6,second_coder_n=2))
 return pd.DataFrame(templates)

def audit_rows(template,pids):
 z=template[template.policy_id.isin(pids)].copy();z['human_eligibility']='1';z['G_selected']='G2';z['G_group_checked']='1'
 z['source_membership']='IN_TARGET';z['unit_validity']='VALID_SENTENCE_OR_CLAUSE'
 return z

def fake_ingest(root,rows,batch):
 path=root/(batch+'.csv');signature=root/(batch+'.json');j.csvout(path,rows)
 j.jsonout(signature,dict(identity='SYNTHETIC_TEST_ONLY',reviewer='TEST_CODER',signed_at='2026-10-28T00:00:00+00:00',coder_role='PRIMARY',review_scope='G_ONLY',
   review_sha256=j.sha(path),protocol_sha256=j.sha(root/'joint_audit_protocol.json')))
 # Mock signature validation only in disposable fixtures, never a real approval.
 with patch.object(j,'signed'),patch.object(j,'verify_review_scope'):
  return j.ingest(None,root,path,signature)

def partial_policy_and_stage():
 with tempfile.TemporaryDirectory(prefix='SYNTHETIC_G_PARTIAL_') as tmp:
  root=Path(tmp);t=fixture(root);fake_ingest(root,audit_rows(t,['TEST_P0']),'ONE_POLICY')
  r=j.evaluate(None,root,'G_ONLY');p=j.read(root/'G_POLICY_AUDIT_CORRECTION.csv');s=j.read(root/'G_STAGE_AUDIT_CORRECTION.csv')
  assert p[p.policy_id.eq('TEST_P0')].design_corrected_share.ne('').all()
  assert p[p.policy_id.eq('TEST_P1')].design_corrected_share.eq('').all()
  assert s[s.stage.eq(j.STAGES[0])].design_corrected_share.eq('').all()
  assert r['second_coder_status']=='SECOND_CODER_PENDING' and not r['states']['G_AUDIT_COMPUTATION_COMPLETED']
  assert r['policy_computed_n']==2 # one audited + one fixed evidence component
  fake_ingest(root,audit_rows(t,['TEST_P1']),'SECOND_POLICY')
  r=j.evaluate(None,root,'G_ONLY');s=j.read(root/'G_STAGE_AUDIT_CORRECTION.csv')
  assert s[s.stage.eq(j.STAGES[0])].design_corrected_share.ne('').all()
  assert s[s.stage.eq(j.STAGES[1])].design_corrected_share.eq('').all()
  assert r['policies_reused']==3 and r['policies_recomputed']==1
  # No unrelated source_scope_verified=False or second-coder gate blocks this.
  assert j.read(root/'ACTUAL_AUDIT_ERROR_METRICS.csv').HT_TP.eq('').all()

def idempotency_and_isolated_conflict():
 with tempfile.TemporaryDirectory(prefix='SYNTHETIC_G_REENTRY_') as tmp:
  root=Path(tmp);t=fixture(root);rows=audit_rows(t,['TEST_P0']);a=fake_ingest(root,rows,'FIRST')
  assert a['accepted_rows']==2
  before=len(list((root/'returns').glob('*/ingest_receipt.json')))
  b=fake_ingest(root,rows,'REPEATED_DIFFERENT_WRAPPER')
  assert b['state']=='ALREADY_IMPORTED' and b['reused_rows']==2
  assert len(list((root/'returns').glob('*/ingest_receipt.json')))==before
  mixed=audit_rows(t,['TEST_P0','TEST_P1']);mixed.loc[mixed.unit_id.eq('TEST_P0_0'),'G_selected']='G1'
  b=fake_ingest(root,mixed,'ONE_CONFLICT_PLUS_VALID')
  assert b['accepted_rows']==2 and b['unresolved_rows']==1 and b['reused_rows']==1
  assert sum(j.load(p)['accepted_rows'] for p in (root/'returns').glob('*/ingest_receipt.json'))==4

def no_missing_or_derived_fake_independence():
 rows=pd.DataFrame([dict(unit_id='X',human_eligibility='1',G_selected='G1',G_group_checked='',source_membership='IN_TARGET',unit_validity='VALID_SENTENCE_OR_CLAUSE')])
 a,e=j.normalize_truth(rows,review_scope='G_ONLY');assert a.empty and len(e)==1
 rows.loc[0,'G_group_checked']='1';a,e=j.normalize_truth(rows,review_scope='G_ONLY');assert e.empty and a.iloc[0].G2==0
 assert all(a[k].isna().all() for k in j.T)
 primary=a.copy();secondary=a.copy();primary['reviewer']='SAME_PERSON';secondary['reviewer']='same_person'
 ag,_=j.independent_coding_agreement(primary,secondary,'G_ONLY');assert ag.paired_actual_n.sum()==0 and ag.excluded_same_reviewer_n.eq(1).all()
 rows.loc[0,'human_eligibility']='UNRESOLVED';rows.loc[0,'G_group_checked']=''
 a,e=j.normalize_truth(rows,review_scope='G_ONLY');assert a.empty and len(e)==1

def full_completion_not_full_C2():
 with tempfile.TemporaryDirectory(prefix='SYNTHETIC_G_COMPLETE_') as tmp:
  root=Path(tmp);t=fixture(root);fake_ingest(root,audit_rows(t,['TEST_P0','TEST_P1','TEST_P2']),'FULL_PRIMARY')
  r=j.evaluate(None,root,'G_ONLY')
  assert r['states']['G_AUDIT_COMPUTATION_COMPLETED']
  assert not r['states']['PART1_COMPLETED'] and not r['states']['C2_FORMAL_RELEASE_READY']
  assert r['states']['T_CONFIGURATION_SUPPORTED']=='INDETERMINATE'
  assert r['second_coder_status']=='SECOND_CODER_PENDING'
  assert j.read(root/'G_STAGE_CHANGE_AUDIT_CORRECTION.csv').design_corrected_difference.ne('').all()

def scoped_JSON_adapter_roundtrip():
 with tempfile.TemporaryDirectory(prefix='SYNTHETIC_G_JSON_') as tmp:
  root=Path(tmp);t=fixture(root)
  class View:
   def __init__(self):self.root=root
   def __truediv__(self,key):return root/key
  view=View();r=t.iloc[0].to_dict();uid=r['unit_id'];payload=dict(format='JOINT528_G_ONLY_RETURN_V1',review_scope='G_ONLY',scope_revision_sha256='TEST_SCOPE',protocol_sha256=c.APPROVED_HASH,
    coder_role='PRIMARY',reviewer='TEST_CODER',completed_at='2026-10-28T00:00:00+00:00',confirmation='CONFIRM_ACTUAL_JOINT_INDEPENDENT_AUDIT',
    records=[dict(unit_id=uid,template_row_sha256=j.digest(r),human_eligibility='0',G_selected='',G_group_checked='',source_membership='',unit_validity='',canonical_unit_id='')])
  path=root/'SYNTHETIC_RETURN.json';j.jsonout(path,payload)
  # Production adapter and importer run; scope/actual signature checks are mocked
  # solely for this disposable synthetic data. No real directory is used.
  with patch.object(c,'g_only_view',return_value=(None,view)),patch.object(j,'verify_review_scope'),patch.object(j,'signed'),patch.object(c,'APPROVED_HASH',j.sha(root/'joint_audit_protocol.json')):
   payload['protocol_sha256']=c.APPROVED_HASH;j.jsonout(path,payload)
   a=c.ingest_g_only_json(path,evaluate=False);assert a['accepted_rows']==1
   b=c.ingest_g_only_json(path,evaluate=False);assert b['state']=='ALREADY_IMPORTED'
  event=next((root/'returns').glob('*/actual_normalized.csv'));a=j.read(event)
  assert a.iloc[0].G1=='0' and all(a.iloc[0][k]=='' for k in j.T)
  ev=j.read(event.parent/'adjudication_compatible_events_STAGED_ONLY.csv')
  assert len(ev)==4 and ev[ev.field.isin(j.G)].parent_audit_unit_id.eq(uid).all()

def real_scope_sample_and_ui():
 ctx,parent,child=c.location();view=c.GOnlyView(child,parent)
 before=j.load(parent/'G_history_priority_patch_20261028/frozen_input_hashes.json')
 assert all(j.sha(v['path'])==v['sha256'] for v in before.values())
 j.verify_review_scope(view,'G_ONLY',run.SCOPE_HASH)
 s=j.read(child/'sample/actual_sample_BACKEND.csv');assert len(s)==528 and s.unit_id.is_unique and s.stratum_id.nunique()==264
 assert s.reading_id.nunique()==502 and j.truth(s.second_coder_selected).sum()==106
 html=run.ENTRY.read_text('utf-8');payload=json.loads(html.split('<script id="audit-data" type="application/json">')[1].split('</script>')[0])
 assert {r['unit_id'] for r in payload['records']}==set(s.unit_id) and len(payload['readings'])==502
 assert sum(r['secondary'] for r in payload['records'])==106
 for r in payload['records']:assert not any(k.startswith('C2_') or k.startswith('score_') or k.startswith('human_') for k in r)
 a=j.read(view/'G_POLICY_FUNCTION_STATUS_204.csv');assert len(a)==204 and a[['policy_id','G']].drop_duplicates().shape[0]==204
 assert a.function_presence_status.eq('SUPPORTED_WITHIN_BOUND_UNIT_SCOPE').sum()==183
 assert len(j.read(view/'G_POLICY_INPUT_APPLICABILITY_68.csv'))==68
 auth=j.load(child/'G_ONLY_SCOPE_APPROVAL.json');assert not auth.get('signed_at') and not auth['quality_approval']

def real_idempotent_scope_and_cache():
 ctx,parent,child=c.location();view=c.GOnlyView(child,parent);old=j.sha(child/'G_ONLY_SCOPE_APPROVAL.json')
 assert run.apply_scope()['status']=='ALREADY_APPLIED' and j.sha(child/'G_ONLY_SCOPE_APPROVAL.json')==old
 r=j.evaluate(ctx,view,'G_ONLY');r2=j.evaluate(ctx,view,'G_ONLY')
 assert r2['policies_recomputed']==0 and r2['policies_reused']==68
 assert r2['primary_actual_n']==0 and r2['stage_computed_n']==0

def main():
 for fn in [partial_policy_and_stage,idempotency_and_isolated_conflict,no_missing_or_derived_fake_independence,full_completion_not_full_C2,scoped_JSON_adapter_roundtrip]:check(fn.__name__,'SYNTHETIC_DISPOSABLE_FIXTURE_NOT_RESEARCH_DATA',fn)
 for fn in [real_scope_sample_and_ui,real_idempotent_scope_and_cache]:check(fn.__name__,'REAL_AUTHORIZATION_AND_FILE_CHECK',fn)
 _,p,d=c.location();out=d/'G_ONLY_execution';report=dict(results=RESULTS,passed=sum(r['status']=='PASS' for r in RESULTS),failed=sum(r['status']=='FAIL' for r in RESULTS),
   actual_new_G_audit_n=0,model_fits=0,code_sha256={Path(m.__file__).name:j.sha(m.__file__) for m in [j,c,run]},time=j.now())
 j.jsonout(out/'G_ONLY_regression_QA.json',report);print(json.dumps(report,ensure_ascii=False,indent=2))
 if report['failed']:raise SystemExit(1)

if __name__=='__main__':main()
