"""Approved nested audit leaf; frozen JOINT_600 and all its labels stay intact.
Reuses the existing joint-audit importer and estimators through a directory view.
"""
from pathlib import Path
import argparse,json,math,re,shutil
from datetime import datetime
import numpy as np
import pandas as pd
from openpyxl import load_workbook
import joint_history_audit_20261028 as j

APPROVED_HASH='ac6da323683e56091abab2795afed782c7e1f5d54dcdbeddc069ab46991fce2f'
BAD=re.compile(r'[\x00-\x08\x0b\x0c\x0e-\x1f]')
def display(v):return BAD.sub(lambda m:f'⟦U+{ord(m.group()):04X}⟧',v) if isinstance(v,str) else v
def location():
 ctx,parent=j.ctx_and_dir();return ctx,parent,parent/'sample_528'

class AuditView:
 """Reads the original population frame without copying or rebuilding it."""
 def __init__(self,root,parent):self.root=root;self.parent=parent
 def __truediv__(self,name):
  if str(name)=='sampling_frame_BACKEND.csv':return self.parent/'sampling_frame_BACKEND.csv'
  return self.root/name

class GOnlyView:
 """One active G scope; all frozen probability/legacy FULL_10 files stay in place."""
 def __init__(self,child,parent):
  self.child=child;self.parent=parent;self.root=child/'G_ONLY_execution'
 def __truediv__(self,name):
  name=str(name)
  if name=='sampling_frame_BACKEND.csv':return self.parent/name
  if name=='sample' or name.startswith('sample/') or name.startswith('allocation_') or name in ['joint_audit_protocol.json','G_ONLY_SCOPE_APPROVAL.json','G_ONLY_SCOPE_REVISION.json']:
   return self.child/name
  return self.root/name

def g_only_view():
 ctx,parent,child=location();return ctx,GOnlyView(child,parent)

def ingest_g_only_json(file,evaluate=True,verify_only=False):
 """Recover immutable source/IDs from registered templates, never from predictions."""
 ctx,view=g_only_view();payload=j.load(file)
 j.require(payload.get('format')=='JOINT528_G_ONLY_RETURN_V1' and payload.get('review_scope')=='G_ONLY','Wrong scoped return format')
 j.verify_review_scope(view,'G_ONLY',payload.get('scope_revision_sha256',''))
 j.require(payload.get('protocol_sha256')==APPROVED_HASH,'Wrong frozen protocol')
 role=payload.get('coder_role');j.require(role in ['PRIMARY','SECONDARY'],'Actual role required')
 template=j.read(view/f'sample/registered_{role}_TEMPLATE.csv').set_index('unit_id');rows=[]
 allowed=['human_eligibility','human_G1','human_G2','human_G3','G_selected','G_group_checked','source_membership','unit_validity','canonical_unit_id','exception_detail']
 for r in payload.get('records',[]):
  uid=r['unit_id'];j.require(uid in template.index,'Outside fixed sampled unit')
  original=template.loc[uid].to_dict();original['unit_id']=uid
  j.require(r.get('template_row_sha256')==j.digest(original),'Registered source/template row changed')
  original.update({k:str(r.get(k,'')).strip() for k in allowed});original.update(review_scope='G_ONLY',T_group_checked='',T_selected='')
  for k in j.T:original['human_'+k]=''
  rows.append(original)
 j.require(rows and len({r['unit_id'] for r in rows})==len(rows),'No actual rows or repeated IDs')
 if verify_only:return dict(verified=True,rows=len(rows),review_scope='G_ONLY',actual_judgments_ingested=0)
 j.require(payload.get('confirmation')=='CONFIRM_ACTUAL_JOINT_INDEPENDENT_AUDIT' and payload.get('reviewer') and payload.get('completed_at'),'Actual reviewer, submission time and confirmation required')
 if role=='SECONDARY':
  primary_reviewers={j.load(p.parent/'actual_signature.json')['reviewer'].strip().casefold() for p in (view.root/'returns').glob('*/ingest_receipt.json') if j.load(p).get('coder_role')=='PRIMARY'} if (view.root/'returns').exists() else set()
  j.require(payload['reviewer'].strip().casefold() not in primary_reviewers,'Same author cannot be registered as independent second coder')
 h=j.sha(file);archive=view.root/'json_returns'/h;archive.mkdir(parents=True,exist_ok=True)
 canonical=archive/'actual_return_registered_text.csv';sig=archive/'actual_signature.json';j.csvout(canonical,rows)
 signature=dict(statement=payload['confirmation'],identity='REAL',reviewer=payload['reviewer'],signed_at=payload['completed_at'],coder_role=role,
  review_sha256=j.sha(canonical),source_return_sha256=h,protocol_sha256=APPROVED_HASH,review_scope='G_ONLY',scope_revision_sha256=payload['scope_revision_sha256'])
 if payload.get('source_workbook_sha256'):signature['source_workbook_sha256']=payload['source_workbook_sha256']
 if payload.get('supplement_event_path'):
  event_path=Path(payload['supplement_event_path'])
  j.require(j.sha(event_path)==payload['supplement_event_sha256'],'Supplement event binding changed')
  signature.update(supplement_event_path=str(event_path),supplement_event_sha256=payload['supplement_event_sha256'])
 j.jsonout(sig,signature);shutil.copyfile(file,archive/'original_return.json')
 result=j.ingest(ctx,view,canonical,sig)
 if evaluate:result['evaluation']=j.evaluate(ctx,view,'G_ONLY')
 return result

def g_only_xlsx_payload(file):
 """Read a saved author workbook without changing it or adopting any fields."""
 ctx,view=g_only_view();book=load_workbook(j.longpath(file),read_only=True,data_only=False)
 try:
  j.require({'审核填写','阅读原文','BATCH_INFO'}<=set(book.sheetnames),'Required G-only workbook sheets missing')
  batch={str(r[0]):'' if len(r)<2 or r[1] is None else str(r[1]).strip() for r in list(book['BATCH_INFO'].values)[1:] if r and r[0]}
  binary=batch.get('presentation_schema')=='JOINT528_G_ONLY_BINARY_XLSX_V1'
  j.require(batch.get('presentation_schema') in ['JOINT528_G_ONLY_XLSX_V1','JOINT528_G_ONLY_BINARY_XLSX_V1'] and batch.get('coder_role') in ['PRIMARY','SECONDARY'],'Wrong G-only workbook schema/role')
  j.require(batch.get('protocol_sha256')==APPROVED_HASH,'Frozen protocol mismatch')
  j.verify_review_scope(view,'G_ONLY',batch.get('scope_revision_sha256',''))
  template=j.read(view/f'sample/registered_{batch["coder_role"]}_TEMPLATE.csv').set_index('unit_id')
  values=list(book['审核填写'].values);header=[str(x) for x in values[0]];records=[];seen=set()
  expected_readings={}
  for row in template.reset_index().to_dict('records'):expected_readings.setdefault(row['reading_id'],display(row['reading_text']))
  source_rows=list(book['阅读原文'].values);sources={};parts={}
  for row in source_rows[1:]:
   if not row or not row[0]:continue
   k=str(row[0]);part=int(row[1]);j.require((k,part) not in parts,'Duplicate reading fragment');parts[(k,part)]='' if row[3] is None else str(row[3])
  for k in expected_readings:
   nums=sorted(n for rid,n in parts if rid==k);j.require(nums==list(range(1,len(nums)+1)) and nums,'Missing/reordered reading fragments')
   sources[k]=''.join(parts[(k,n)] for n in nums)
  j.require(set(k for k,n in parts)==set(expected_readings),'Reading source changed or missing')
  presentation_changes=[]
  for k,expected in expected_readings.items():
   actual=sources[k]
   if actual!=expected:
    j.require(re.sub(r'\s+','',actual)==re.sub(r'\s+','',expected),'Reading source substantive text changed: '+k)
    presentation_changes.append(dict(reading_id=k,change='WHITESPACE_ONLY',registered_sha256=j.digest(expected),returned_sha256=j.digest(actual)))
  for values in values[1:]:
   if not values or not values[0]:continue
   r={k:'' if v is None else str(v).strip() if k!='目标单元原文' else str(v) for k,v in zip(header,values)};uid=r['unit_id']
   j.require(uid in template.index and uid not in seen,'Repeated/outside sampled ID');seen.add(uid);original=template.loc[uid].to_dict();original['unit_id']=uid
   j.require(r['目标单元原文']==display(original['exact_evidence_text']) and r['reading_id']==original['reading_id'] and r['原文位置']==original['clean_start']+':'+original['clean_end'],'Protected target text/position changed')
   editable=['合格性','G1','G2','G3','属于目标正文','句条无异常'] if binary else ['合格性','G1','G2','G3','完成确认','异常说明','来源适用（仅异常）','句条有效性（仅异常）','重复时规范单元ID']
   if not any(r.get(k,'') for k in editable):continue
   bits={k:r.get(k,'') for k in j.G};j.require(all(v in ['','0','1'] for v in bits.values()),'G cells allow 0, 1 or blank only')
   if binary:
    j.require(all(r.get(k,'') in ['','0','1'] for k in editable),'Binary review cells allow only 0, 1 or blank')
    raw=dict(unit_id=uid,human_eligibility=r['合格性'],G_selected=';'.join(k for k,v in bits.items() if v=='1'),G_group_checked='',T_group_checked='',
      source_membership={'1':'IN_TARGET','0':'OUTSIDE_TARGET','':''}[r['属于目标正文']],
      unit_validity={'1':'VALID_SENTENCE_OR_CLAUSE','0':'UNABLE_TO_JUDGE','':''}[r['句条无异常']],canonical_unit_id='',
      exception_detail='BINARY_UNIT_ISSUE_FLAG;SPECIFIC_TYPE_UNRESOLVED' if r['句条无异常']=='0' else '',**{'human_'+k:v for k,v in bits.items()})
    raw.update(template_row_sha256=j.digest(original));records.append(raw);continue
   eligibility={'合格':'1','不合格':'0','无法判断':'UNRESOLVED'}.get(r['合格性'],r['合格性'])
   done={'G已检查，来源句条无异常':'G_GROUP_CHECKED_NO_EXCEPTION','G已检查，有异常':'G_GROUP_CHECKED','无法判断':'UNRESOLVED','':''}.get(r['完成确认'])
   j.require(done is not None,'Unknown G completion choice')
   scope={'目标政策正文':'IN_TARGET','明确非目标正文':'OUTSIDE_TARGET','来源无法确认':'UNRESOLVED','':''}.get(r['来源适用（仅异常）'],r['来源适用（仅异常）'])
   unit={'有效句子/条款':'VALID_SENTENCE_OR_CLAUSE','有效复合句/条款':'VALID_COMPOUND_CLAUSE','截断，暂未解决':'TRUNCATED_UNRESOLVED','跨条款混合，暂未解决':'MULTI_CLAUSE_UNRESOLVED','已核实重复':'DUPLICATE_CONFIRMED','非目标正文':'SOURCE_NOT_TARGET','无法判断':'UNABLE_TO_JUDGE','':''}.get(r['句条有效性（仅异常）'],r['句条有效性（仅异常）'])
   raw=dict(unit_id=uid,human_eligibility=eligibility,G_selected=';'.join(k for k,v in bits.items() if v=='1'),review_complete=done,
       source_membership=scope,unit_validity=unit,canonical_unit_id=r['重复时规范单元ID'],exception_detail=r['异常说明'],**{'human_'+k:v for k,v in bits.items()})
   expanded=expand_completion(pd.DataFrame([raw]),'G_ONLY').iloc[0].to_dict()
   expanded.update(template_row_sha256=j.digest(original));records.append(expanded)
  j.require(seen==set(template.index),'Workbook sample roster changed; retain all registered rows')
  confirmation='CONFIRM_ACTUAL_JOINT_INDEPENDENT_AUDIT' if batch.get('confirmation') in ['确认本人实际审核','CONFIRM_ACTUAL_JOINT_INDEPENDENT_AUDIT'] or (binary and batch.get('confirmation')=='1') else ''
  completed_at=batch.get('completed_at','')
  if re.fullmatch(r'\d{8}',completed_at):completed_at=datetime.strptime(completed_at,'%Y%m%d').date().isoformat()
  return dict(format='JOINT528_G_ONLY_RETURN_V1',review_scope='G_ONLY',scope_revision_sha256=batch['scope_revision_sha256'],protocol_sha256=APPROVED_HASH,
      coder_role=batch['coder_role'],reviewer=batch.get('reviewer',''),completed_at=completed_at,completed_at_original=batch.get('completed_at',''),confirmation=confirmation,
      source_workbook_sha256=j.sha(file),records=records),dict(roster_n=len(seen),reading_blocks=len(sources),touched_n=len(records),blank_n=len(seen)-len(records),presentation_changes=presentation_changes)
 finally:book.close()

def ingest_g_only_xlsx(file,evaluate=True,verify_only=False):
 payload,qa=g_only_xlsx_payload(file)
 if verify_only:return dict(verified=True,actual_judgments_ingested=0,**qa)
 j.require(payload['records'],'No actual workbook judgments; blank cells are not accepted')
 _,view=g_only_view();folder=view.root/'xlsx_returns'/j.sha(file);folder.mkdir(parents=True,exist_ok=True)
 target=folder/'actual_return.json';j.jsonout(target,payload);shutil.copyfile(j.longpath(file),folder/'original_workbook.xlsx')
 result=ingest_g_only_json(target,evaluate=evaluate);result['workbook_QA']=qa;return result

def draw(approval_path):
 ctx,parent,root=location();proposal=parent/'reduction_proposal_JOINT_528/nested_reduction_protocol_PROPOSED.json'
 j.require(j.sha(proposal)==APPROVED_HASH,'Approved child protocol changed')
 p=j.load(proposal);a=j.load(approval_path);j.signed(a,'APPROVE_NESTED_AUDIT_REDUCTION','REAL')
 j.require(a.get('protocol_sha256')==APPROVED_HASH and a.get('option')==p['option'],'Wrong child approval')
 j.require(j.sha(parent/'joint_audit_protocol.json')==p['parent_protocol_sha256'],'Parent protocol changed')
 j.require(j.sha(parent/'sample/actual_sample_BACKEND.csv')==p['parent_actual_sample_sha256'],'Parent roster changed')
 allocpath=parent/'reduction_proposal_JOINT_528/planned_nested_allocation.csv'
 j.require(j.sha(allocpath)==p['allocation_sha256'],'Child allocation changed')
 if (root/'sample/sample_manifest.json').exists():
  m=j.load(root/'sample/sample_manifest.json');j.require(m['approval_sha256']==j.sha(approval_path),'Different approval on existing child draw')
  j.require(all(j.sha(root/'sample'/n)==h for n,h in m['files'].items()),'Frozen child files changed')
  return dict(reused=True,**{k:m[k] for k in ['n','actual_primary_reading_blocks','second_coder_n']})
 root.mkdir(exist_ok=True);sampledir=root/'sample';sampledir.mkdir(exist_ok=True)
 original=j.read(parent/'sample/actual_sample_BACKEND.csv');alloc=j.read(allocpath);rng=np.random.default_rng(p['seed']);ids=[]
 for r in alloc.sort_values('stratum_id').itertuples():
  z=original[original.stratum_id.eq(r.stratum_id)].sort_values('unit_id');n=int(r.sample_n)
  j.require(len(z)==int(r.parent_sample_n),'Parent stratum differs');ids.extend(z.iloc[rng.choice(len(z),n,replace=False)].unit_id.tolist())
 actual=original[original.unit_id.isin(ids)].copy();idx=alloc.set_index('stratum_id')
 actual['parent_inclusion_probability']=actual.inclusion_probability
 actual['conditional_keep_probability']=actual.stratum_id.map(idx.conditional_keep_probability)
 actual['inclusion_probability']=actual.stratum_id.map(idx.final_inclusion_probability)
 actual['design_weight']=1/j.numeric(actual.inclusion_probability)
 actual['parent_second_coder_selected']=actual.second_coder_selected
 second=set(rng.choice(sorted(ids),int(p['second_coder_target_n']),replace=False))
 actual['second_coder_selected']=actual.unit_id.isin(second)
 actual['second_phase_inclusion_probability']=j.numeric(actual.inclusion_probability)*len(second)/len(actual)
 j.require(len(actual)==p['target_n'] and actual.unit_id.is_unique,'Wrong child size')
 j.csvout(sampledir/'actual_sample_BACKEND.csv',actual)
 registered=j.read(parent/'sample/registered_PRIMARY_TEMPLATE.csv')
 template=registered[registered.unit_id.isin(ids)].copy();template['review_complete']='';template['exception_detail']=''
 j.csvout(sampledir/'registered_PRIMARY_TEMPLATE.csv',template)
 j.csvout(sampledir/'registered_SECONDARY_TEMPLATE.csv',template[template.unit_id.isin(second)])
 # Approved document bytes are retained; approval/execution are distinct events.
 shutil.copyfile(proposal,root/'joint_audit_protocol.json')
 alloc['planned_pi']=j.numeric(alloc.final_inclusion_probability);alloc['planned_weight']=1/alloc.planned_pi
 j.csvout(root/f'allocation_{p["option"]}.csv',alloc)
 j.jsonout(root/'approval_applied.json',dict(approval=a,approval_file_sha256=j.sha(approval_path),recorded_at=j.now(),scope='nested draw and compact UI only; not quality or C2 adoption'))
 frozen=['actual_sample_BACKEND.csv','registered_PRIMARY_TEMPLATE.csv','registered_SECONDARY_TEMPLATE.csv']
 j.jsonout(sampledir/'sample_manifest.json',dict(option=p['option'],protocol_sha256=APPROVED_HASH,approval_sha256=j.sha(approval_path),
   parent_sample_sha256=p['parent_actual_sample_sha256'],n=len(actual),actual_primary_reading_blocks=int(actual.reading_id.nunique()),
   second_coder_n=len(second),actual_second_reading_blocks=int(actual.loc[actual.second_coder_selected,'reading_id'].nunique()),
   files={n:j.sha(sampledir/n) for n in frozen}))
 j.jsonout(root/'PART1_RESEARCH_USE_DECISION.json',dict(status='WAITING_FOR_AUDIT_RETURN',active_option=p['option'],
   states=dict(COMPUTATION_REPRODUCIBLE=True,G_HISTORY_QUALITY_SUPPORTED=False,T_CONFIGURATION_QUALITY_SUPPORTED=False,C2_FORMAL_RELEASE_READY=False,PART1_COMPLETED=False),
   derivation=dict(protocol_approval_present=True,actual_new_audit_return_events=0,design_corrected_evidence_present=False),part2_started=False))
 j.jsonout(parent/'ACTIVE_INDEPENDENT_AUDIT.json',dict(active_option=p['option'],workspace_relative_directory=str(root.relative_to(j.longpath(j.WS))),
   protocol_sha256=APPROVED_HASH,parent_600_preserved=True,status='WAITING_FOR_AUDIT_RETURN'))
 return dict(reused=False,**j.load(sampledir/'sample_manifest.json'))

PROTECTED=['unit_id','policy_id','policy_version_id','stage','reading_id','exact_evidence_text','reading_text','source_location','clean_start','clean_end','source_hash','source_clean_sha256','requested_fields']

def expand_completion(rows,review_scope='FULL_10'):
 """Only an actual, explicit combined confirmation can derive these fields."""
 result=rows.copy()
 j.require(review_scope in ['G_ONLY','FULL_10'],'Explicit supported review scope required')
 for i,r in rows.iterrows():
  done=str(r.get('review_complete','')).strip()
  done={'完成（无异常）':'COMPLETE_NO_EXCEPTION','标签检查完成（有异常）':'EXCEPTION_LABELS_CHECKED','暂无法判断':'UNRESOLVED'}.get(done,done)
  if review_scope=='G_ONLY':
   done={'G检查完成（无异常）':'G_GROUP_CHECKED_NO_EXCEPTION','G检查完成（有异常）':'G_GROUP_CHECKED'}.get(done,done)
   j.require(done in ['','UNRESOLVED','G_GROUP_CHECKED','G_GROUP_CHECKED_NO_EXCEPTION'],'G_ONLY needs explicit G-only confirmation, not legacy full/T confirmation')
   result.loc[i,'review_scope']='G_ONLY'
   result.loc[i,'T_group_checked']=''
   if done not in ['G_GROUP_CHECKED','G_GROUP_CHECKED_NO_EXCEPTION']:continue
   j.require(str(r.get('human_eligibility','')).strip() in ['0','1'],'Explicit eligibility required')
   result.loc[i,'G_group_checked']='1'
   if done=='G_GROUP_CHECKED_NO_EXCEPTION':
    j.require(not str(r.get('source_membership','')).strip() or r['source_membership']=='IN_TARGET','G source confirmation conflict')
    result.loc[i,'source_membership']='IN_TARGET'
    result.loc[i,'unit_validity']=r.get('unit_validity') or 'VALID_SENTENCE_OR_CLAUSE'
   result.loc[i,'compact_confirmation_identity']='ACTUAL_HUMAN_G_GROUP_CHECKED;T_NOT_REVIEWED'
   continue
  j.require(done in ['','COMPLETE_NO_EXCEPTION','EXCEPTION_LABELS_CHECKED','UNRESOLVED'],'Unknown combined confirmation')
  if done not in ['COMPLETE_NO_EXCEPTION','EXCEPTION_LABELS_CHECKED']:continue
  j.require(str(r.get('human_eligibility','')).strip() in ['0','1'],'Explicit eligibility required before completion')
  expected={'G_group_checked':'1','T_group_checked':'1'}
  if done=='COMPLETE_NO_EXCEPTION':expected.update(source_membership='IN_TARGET',unit_validity='VALID_SENTENCE_OR_CLAUSE')
  # Valid compound clauses are not an exception and remain explicitly recorded.
  if done=='COMPLETE_NO_EXCEPTION' and r.get('unit_validity')=='VALID_COMPOUND_CLAUSE':expected['unit_validity']='VALID_COMPOUND_CLAUSE'
  for k,v in expected.items():
   old=str(r.get(k,'')).strip();j.require(not old or old==v,'Combined confirmation conflicts with '+k);result.loc[i,k]=v
  if done=='COMPLETE_NO_EXCEPTION':j.require(not str(r.get('canonical_unit_id','')).strip(),'Duplicate/canonical issue requires exception review')
  result.loc[i,'compact_confirmation_identity']='ACTUAL_HUMAN_'+done+';NO_DEFAULTS_FROM_BLANK'
 return result

def recover(file):
 ctx,parent,root=location();view=AuditView(root,parent)
 wb=load_workbook(file,read_only=True,data_only=False);batch={str(r[0]):r[1] for r in list(wb['BATCH_INFO'].values)[1:] if r and r[0]};wb.close()
 role=str(batch.get('coder_role',''));j.require(role in ['PRIMARY','SECONDARY'],'Missing registered coder role')
 j.require(str(batch.get('protocol_sha256',''))==APPROVED_HASH,'Wrong child protocol')
 manifest=j.load(root/'sample/sample_manifest.json');j.require(all(j.sha(root/'sample'/n)==h for n,h in manifest['files'].items()),'Child roster or template changed')
 template=j.read(root/'sample'/f'registered_{role}_TEMPLATE.csv');ti=template.set_index('unit_id');raw=j.read_review(file)
 j.require(raw.unit_id.is_unique and set(raw.unit_id)<=set(template.unit_id),'Wrong/repeated sampled unit')
 restored=raw.copy();encoded=0
 for i,row in raw.iterrows():
  for k in PROTECTED:
   expected=row.unit_id if k=='unit_id' else ti.loc[row.unit_id,k]
   j.require(str(row[k])==str(display(expected)),'Protected source changed: '+row.unit_id+' '+k)
   restored.loc[i,k]=expected;encoded+=int(str(expected)!=str(display(expected)))
 review_scope=str(batch.get('review_scope') or 'FULL_10')
 expanded=expand_completion(restored,review_scope)
 batch['review_scope']=review_scope
 return ctx,view,expanded,batch,dict(role=role,returned_rows=len(raw),registered_rows=len(template),display_fields_restored=encoded)

def ingest(file,evaluate=False,verify_only=False):
 ctx,view,rows,batch,qa=recover(file)
 if verify_only:return dict(verification_only=True,actual_judgments_ingested=0,**qa)
 j.require(batch.get('confirmation')=='CONFIRM_ACTUAL_JOINT_INDEPENDENT_AUDIT','Actual batch confirmation required')
 j.require(str(batch.get('reviewer') or '').strip() and str(batch.get('completed_at') or '').strip(),'Actual reviewer/time required')
 j.verify_review_scope(view,batch['review_scope'],batch.get('scope_revision_sha256',''))
 h=j.sha(file);archive=view.root/'workbook_returns'/h;archive.mkdir(parents=True,exist_ok=True)
 canonical=archive/'actual_return_registered_text.csv';sig=archive/'actual_signature.json';j.csvout(canonical,rows)
 signature=dict(statement=batch['confirmation'],identity='REAL',reviewer=str(batch['reviewer']),signed_at=str(batch['completed_at']),coder_role=qa['role'],
   batch_id='JOINT528_'+qa['role']+'_'+h[:12],review_sha256=j.sha(canonical),source_workbook_sha256=h,protocol_sha256=APPROVED_HASH,
   review_scope=batch['review_scope'],scope_revision_sha256=batch.get('scope_revision_sha256',''),
   presentation_adapter='COMPACT_ACTUAL_CONFIRMATION_V2_SCOPED;independent_field_provenance_preserved',processing_code_sha256=j.sha(Path(__file__)))
 j.jsonout(sig,signature);shutil.copyfile(file,archive/'actual_workbook.xlsx');j.jsonout(archive/'presentation_QA.json',qa)
 outcome=dict(import_result=j.ingest(ctx,view,canonical,sig),source_workbook_sha256=h)
 if evaluate:outcome['evaluation']=j.evaluate(ctx,view,review_scope=batch['review_scope'])
 return outcome

def main():
 p=argparse.ArgumentParser();p.add_argument('command',choices=['draw','ingest','verify']);p.add_argument('--approval');p.add_argument('--workbook');p.add_argument('--evaluate',action='store_true');a=p.parse_args()
 if a.command=='draw':j.require(a.approval,'Actual approval file required');r=draw(Path(a.approval))
 else:j.require(a.workbook,'Actual workbook path required');r=ingest(Path(a.workbook),a.evaluate,a.command=='verify')
 print(json.dumps(j.clean_json(r),ensure_ascii=False))
if __name__=='__main__':main()
