"""Read-only review document; no research computation or label changes."""
import ast,json,re
from pathlib import Path
import joint_history_audit_20261028 as j
import joint528_compact_20261028 as c

ctx,parent,root=c.location();current=j.load(ctx.root/'C2_CURRENT.json');snapshot=j.longpath(j.WS/current['snapshot_directory'])
states=j.load(root/'PART1_RESEARCH_USE_DECISION.json');roster=j.load(root/'sample/sample_manifest.json');qa=j.load(root/'DRAW_AND_COMPACT_QA.json')
report=j.ROOT/'B1_V1.2_当前代码与528审核必要性_GPT审阅材料_20261028.md'
parts=[]
def add(s):parts.append(s+'\n')
def block(s,lang='text'):
 f='`'*max(3,max([len(x) for x in re.findall(r'`{3,}',s)] or [0])+1)
 return '\n'+f+lang+'\n'+s.rstrip()+'\n'+f+'\n'

add('''# B1 V1.2：当前代码、两份528盲审表与人工审核必要性

核查日期：2026-10-28。本次仅整理材料、读取当前文件，没有重训、调阈值、重新抽样或改变研究结果。

## 1. 请GPT独立判断

请作为方法与代码审阅者，判断现有条件性基准能支持什么，是否确需新增人工，以及最小修复路线。请区分科学证据、统计设计和工程门槛，不预设必须人审，也不预设可以免审。

重点回答：

1. 条件性计算基准、真实历史G构成、正式每政策G经验输入、六类工具配置，分别需要哪些证据？
2. 能否复用已有真实判断或可信外部参照？原600/49不得用于训练、阈值、概率校准、候选择优或新审核答案检索。旧固定参考评价若复用，应保留原设计范围和已被查看的事实，不能说全新盲验。
3. 528主审及106第二编码有无通用的科学必需性？若可减量，需说明新的估计对象、抽样概率、权重、方差及损失的信息，不能只给更小数字。
4. 能否优先完成G历史和经验输入，把T配置保持条件性？需要最小拆分哪些导入和发布逻辑？
5. 哪些阻断真正影响结论，哪些来自硬编码或完整案例要求？不能简单改true，也不能用程序false作为必须不断追加审核的唯一理由。
6. 给出最小调整、实际人工工作、质量依据和停止条件。不追平原稿，不运行SD。

## 2. 当前真实起点

固定68政策、32,858源单元，四阶段政策数11/13/16/28。已完成冻结机器编码、政策等权份额、2,000次阶段政策Bootstrap、逐篇留一、相邻阶段差、G–T共编码及T2条件性分析。代码早已能运行，不是必须先填528表才能有任何计算结果。

旧二值层306,140/328,580字段来自机器（93.1706%），这是来源比例而非验证率。后续30,614个机器T2字段保持未知，不应继续当作正式二值点估计。2,244个已有完整证据单元复用，包含真实人工、批准的严格组传播和合法派生字段，不都等于新的独立金标准。它们的潜在语义错误不在新抽样方差内。

当前G2四阶段点份额均最大、G3约9%—18%，不同于原稿早期G3占优。结果不同本身不是错误，也不能反向改标签追平；但是弱分类头、负门控和单元问题仍需范围匹配的质量依据。

政策Bootstrap只衡量政策样本组成敏感性，不涵盖编码错误。数值复算、字节哈希、作者总体采用、开发性指标、正式研究可靠性是不同事项。

## 3. 现有分类质量：开发诊断，非本次独立验收
''')
q=j.read(snapshot/'label_machine_quality_diagnostics.csv')
add(block(q[['label','development_precision','development_recall','quality_identity']].to_csv(index=False),'csv'))
add('''G3、T1、T2、T3、T4、T6六头未满足原开发使用要求。T2 precision约2.01%、recall约66.67%；G3约50%/48%。合格性、G1/G2/T5开发可用也不等于全库独立验证。弱头不自动意味着必须全库逐条人工，但高分或多个同源模型一致也不能代替质量证据。

## 4. 三套样本身份不能混淆

- 原600随机参考与49留出：旧固定评价身份保留，主要参考覆盖13项留出政策，不能未经论证代表全部68政策。
- JOINT_600：新联合审核父样本，覆盖机器正负门控及风险维度，不是原600参考。
- JOINT_528：作者批准后，从JOINT_600各层固定随机保留2个目标。旧600名单与文件不覆盖，没有按答案挑容易项。

全框含68政策/49修订家族；新概率域为30,614个未复用单元。两个已有完整证据的小政策不重审，不是删除政策。现有264层按政策×正负门控×平衡风险划分；排序考虑来源/结构、G3分数及预测、T2未知等，家族元数据保留。

528=264×2，是本特定分层下估计层内方差的计算下限，不是通用科研最低样本量。可另设更少的设计，但需要论证精度和覆盖，不自动等价。

子样本条件保留概率2/n_h(父600)，完整设计一阶概率2/N_h，权重N_h/2。第二编码者在子样本再SRS抽106个，边际概率为(2/N_h)×106/528；106来自ceil(20%×528)，20%不是普适必需比例。

## 5. 两份当前工作簿
''')
books=[]
for role,name,n,r in [('PRIMARY','JOINT_528_主审核_COMPACT_BLIND.xlsx',528,502),('SECONDARY','JOINT_528_第二编码者_COMPACT_BLIND.xlsx',106,106)]:
 p=j.ROOT/'outputs/JOINT_528_ac6da323683e5609'/name
 _,_,rows,batch,info=c.recover(p)
 books.append(dict(role=role,path=str(p),sha256=j.sha(p),target_n=n,reading_blocks=r,local_filled_eligibility_n=int(rows.human_eligibility.ne('').sum()),local_filled_confirmation_n=int(rows.review_complete.ne('').sum())))
add(block(j.pd.DataFrame(books).to_csv(index=False),'csv'))
add('''每份有“审核”“完整句段”“填写说明”“BATCH_INFO”。普通记录只填：合格性、G阳性多选、T阳性多选、检查确认。

- “完成（无异常）”：明确确认全部适用G/T已检查、来源为目标正文、单元为有效句/条款（含复合句），才派生组检查及来源/边界确认。
- “标签检查完成（有异常）”：只确认G/T检查，来源与边界需额外明细。
- 空白/暂无法判断不填0、不默认来源正确。
- 真实不合格才依法派生九个零；合格时整组检查明确完成后，未选项才作为人工零。

不显示机器分数、建议或旧答案。少数PDF控制字符采用可逆显示，导入逐ID核对后还原，不删除原文。第二编码者需另一真实人员独立完成，不能查看主审答案。

截至本轮核查，系统无新审核回传，两份本地交付表的人工列仍为空；不代表作者其他副本没有开始。旧表有效判断应按ID保存复用，不重填。

## 6. 当前代码链

joint_history_audit_20261028.py建立框、登记概率、导入实际审核，计算错误及组成影响。joint528_compact_20261028.py处理子样本、精简界面和可逆字符，通过目录视图复用原估计器，不重建机器学习流程。

audit_composition_impact()使用模型辅助差分总量：冻结辅助总量＋样本(真实值−辅助值)/pi。T2未知在辅助项中取0只是估计代数，未写回正式T2；真实审核残差提供设计加权总量。随后按政策内赋值分母形成G/T份额，阶段政策等权，以联合残差协方差作Taylor线性化。

G–T按同单元多标签外积共编码，不等于精确的独立行动—工具关系，更不是因果机制。负总量、非正分母和未识别问题不靠clip制造合法比例。编码审核方差与原政策Bootstrap区间分列。

## 7. 需要GPT特别审查的程序限制

**质量状态尚无完整结果驱动闭环。** 初始化写false是合理等待状态，但evaluate()在计算真实审核结果后仍直接写G_HISTORY_QUALITY_SUPPORTED=False和T_CONFIGURATION_QUALITY_SUPPORTED=False；尚无绑定实际误差、用途与批准的完整正式采用逻辑。因此不能说“填完528即可完成”，也不能因为布尔值false就继续无限追加人工。需要实际证据驱动的判定，而非直接改true。

**G/T仍有完整案例连带。** normalize_truth()对合格记录要求全部9个G/T齐全，否则该记录不能成为完整概率审核记录。若科学目标允许先做G、T保持条件性，当前导入/估计器需最小分组修改；不能把代码要求全填视为科学上全部必需。

**局部未决可能连带整政策。** feature_vector()对部分来源/结构未决先返回None，随后该政策全部特征估计置NA。共同分母确实未知时可能必要；对已经确认不合格、零贡献或与某组无关的问题是否过度阻断，应具体核对，不能一概放行或一概重审。

**来源与单元问题需按根因处理。** 旧source_scope复合标志已拆出来源版本未决0、提取范围2,017单元、语义规则1单元。不能要求26篇来源全部重新批准。另有1,470个未覆盖含文字区间，可能是元数据也可能有正文遗漏，不能自动当遗漏治理行动。源单元概率样本不能自动覆盖完全漏提取的目标条款。

**阅读恢复不是计数修复。** 21,341处上下文恢复保留旧ID和计数，不代表所有碎片已正确合并、有效，也不允许邻句标签传播。复合句允许多标签，不应统一要求独立行动ID。

**小样本近似有限。** 多数层仅2个，稀有类别、政策小分母和Taylor正态近似可能不稳。零观察错误不是零风险；代码对非全查且经验方差0时不报零宽区间，但也不因此成为可靠覆盖保证。

**双编码比例不是技术依赖。** 当前Cohen kappa和一致率仅在真实同单元、不同人员返回后计算，属于未加权子样本描述。106和20%是设计安排，不能冒称通用要求；没有第二人不能伪造一致性，但不意味着既有统计不能运行。

## 8. 对人工必要性的分层判断，请GPT评估

1. 仅保留“条件性计算基准”：不必先填新表即可运行和交付已有结果，但不得称正式真实历史。
2. 要声称真实G历史或每政策经验输入：当前需要与声称对应的可靠参照证据。可恰当复用真实记录、重新设计少量独立审核或可信外部标注，不自动等于必须恰好528＋106。阶段结果可靠不自动证明每篇政策份额精确。
3. 要声称真实六类工具配置：须处理T2与其他弱头质量，或缩小为已识别次数/条件性范围。只修G不等于T可靠，只修T2也不等于其他工具可靠。
4. 不能把设计支持的总体/阶段纠偏估计混同每条机器标签都已验证，也不要求32,858条全量逐条人审才允许任何输出。

请比较：A不新增判断、保留条件性结果；B优先G相关最小审核与源码闭环，T另保留条件性；C执行现有完整528＋106。分别列出能报告的结论、最少工作及风险，不按原稿接近度择优。

## 9. 实际状态与QA
''')
add(block(json.dumps(states,ensure_ascii=False,indent=2),'json'))
add('当前28项检查中21项为真实抽样/工作簿/冻结检查，7项为合成测试，不是28个分类准确性验证。尚无新真实混淆矩阵、设计纠偏结果或独立编码一致性；未重训、未调阈值、未运行年度治理/SD。')
add('## 10. 实际关键代码全文与行号')
for name in ['joint_history_audit_20261028.py','joint528_compact_20261028.py']:
 p=j.ROOT/name;raw=p.read_text('utf-8');tree=ast.parse(raw)
 add('### '+name);add('路径：`'+str(p)+'`；SHA256：`'+j.sha(p)+'`。代码块从实际文件第1行开始，不是伪代码；其中旧“等待批准”字符串是生成逻辑，当前状态以本材料实际指针与回收状态为准。')
 add(block(j.pd.DataFrame([dict(function=n.name,start_line=n.lineno,end_line=n.end_lineno) for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))]).to_csv(index=False),'csv'))
 add(block(raw,'python'))
add('## 11. 精确样本登记和实际QA原文')
add(block(json.dumps(roster,ensure_ascii=False,indent=2),'json'));add(block(json.dumps(qa,ensure_ascii=False,indent=2),'json'))
body='\n'.join(parts).replace('\r\n','\n').replace('\r','\n')
report.write_text(body,'utf-8')
assert report.read_text('utf-8')==body
print(json.dumps(dict(report=str(report),bytes=report.stat().st_size,sha256=j.sha(report),research_code_and_data_unchanged=True),ensure_ascii=False))
