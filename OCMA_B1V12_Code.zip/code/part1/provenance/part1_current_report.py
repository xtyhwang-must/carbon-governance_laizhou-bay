"""Single current Part 1 reporting entry. Reads frozen HT; never trains or codes.

Run with the project venv. DOCX edits use the bundled document runtime separately.
Legacy network excluded; frozen HT results reused without re-estimation.
"""
from pathlib import Path
import argparse, hashlib, json, shutil, subprocess, sys, time
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from PIL import Image
from zipfile import ZipFile
import xml.etree.ElementTree as ET
from io import BytesIO

ROOT=Path(__file__).resolve().parent
if sys.platform=='win32' and not str(ROOT).startswith('\\\\?\\'):ROOT=Path('\\\\?\\'+str(ROOT))
WS=ROOT/'OCMA_empirical_revision_workspace_B1_20261026'
RUN=WS/'05_revision_work/R1_20261026/01_coding/coding_pipeline_completion/runs/part1_completion_20261027'
AUDIT=RUN/'history_quality_repair_20261028/sample_528/G_ONLY_execution'
HT=AUDIT/'estimator_stability_patch_20261028'
OUT=ROOT/'outputs/B1_V1.2_PART1_CURRENT_REPORT'
STAGES=['2000-2010','2011-2016','2017-2020','2021-2023']; G=['G1','G2','G3']
COLORS=['#1B4F72','#278A7A','#C9755E']
DEPS={}
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dep(p):
 p=Path(p);DEPS[str(p)]=sha(p);return p
def read(p):return pd.read_csv(dep(p))
def load(p):return json.loads(dep(p).read_text('utf-8-sig'))
def write(name,x):pd.DataFrame(x).to_csv(OUT/name,index=False,encoding='utf-8-sig',float_format='%.15g')
def jout(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False),'utf8')
def save(fig,name):
 for ext in ['pdf','svg','png']:fig.savefig(OUT/f'{name}.{ext}',dpi=450,facecolor='white',bbox_inches='tight')
 plt.close(fig)

def statistics():
 h=read(HT/'G_POLICY_HT_SHARES.csv');stage=read(HT/'G_STAGE_HT_ESTIMATES.csv')
 old=load(RUN/'POLICY_STATISTICS_CURRENT.json');oldpath=WS/old['workspace_relative_path']
 ids=load(oldpath/'bootstrap_policy_index_map.json');draw=np.load(dep(oldpath/'bootstrap_policy_indices.npz'))
 rows=[];rep=[];loo=[];means={}
 for i,s in enumerate(STAGES):
  z=h[h.stage.eq(s)].pivot(index='policy_id',columns='label',values='design_corrected_share').reindex(ids[s])[G]
  assert len(z)==[11,13,16,28][i] and np.isfinite(z).all().all()
  assert ((z>=0)&(z<=1)).all().all() and np.allclose(z.sum(axis=1),1,atol=1e-12)
  idx=draw[f'stage_{i}'];assert idx.shape==(2000,len(z))
  val=z.to_numpy()[idx].mean(axis=1);means[s]=z.mean().to_numpy()
  for k,g in enumerate(G):
   point=float(z[g].mean());source=float(stage[(stage.stage==s)&(stage.label==g)].design_corrected_share.iloc[0]);assert abs(point-source)<1e-12
   lo,hi=np.quantile(val[:,k],[.025,.975],method='linear')
   rows.append(dict(stage=s,policies_included_in_HT_estimation=len(z),label=g,HT_policy_equal_share=point,policy_bootstrap_p025=lo,policy_bootstrap_p975=hi,replicates=2000,interval_identity='POLICY_SAMPLE_COMPOSITION_SENSITIVITY_NOT_CODING_ERROR'))
   rep.extend(dict(stage=s,label=g,replicate=b+1,mean_share=v) for b,v in enumerate(val[:,k]))
   for pid in z.index:loo.append(dict(stage=s,label=g,removed_policy_id=pid,full_mean=point,leave_one_out_mean=z.drop(pid)[g].mean(),delta=z.drop(pid)[g].mean()-point))
 t=pd.DataFrame(rows);write('Table2_updated.csv',t);write('CURRENT_TABLE2.csv',t);write('Table2_bootstrap_source_data.csv',rep);write('HT_leave_one_policy_out.csv',loo)
 shutil.copy2(oldpath/'bootstrap_policy_indices.npz',OUT/'bootstrap_policy_indices.npz');shutil.copy2(oldpath/'bootstrap_policy_index_map.json',OUT/'bootstrap_policy_index_map.json')
 # Paired contrasts use the full within-policy total covariance and the ratio Jacobian.
 totals=read(HT/'G_POLICY_HT_TOTALS.csv');cov=read(HT/'G_POLICY_HT_COVARIANCE.csv');contrasts=[]
 for s in STAGES:
  vs=[]
  for pid in ids[s]:
   tt=totals[(totals.policy_id==pid)&totals.feature.isin(G)].set_index('feature').estimated_total.reindex(G).to_numpy()
   cc=cov[(cov.policy_id==pid)&cov.feature_1.isin(G)&cov.feature_2.isin(G)].pivot(index='feature_1',columns='feature_2',values='covariance').reindex(index=G,columns=G).to_numpy()
   den=tt.sum();jac=np.eye(3)/den-tt[:,None]/den**2;vs.append(jac@cc@jac.T)
  V=sum(vs)/len(ids[s])**2
  for a,b in [(0,1),(0,2),(1,2)]:
   delta=means[s][a]-means[s][b];se=np.sqrt(max(0,V[a,a]+V[b,b]-2*V[a,b]))
   contrasts.append(dict(stage=s,contrast=G[a]+'-'+G[b],difference=delta,standard_error=se,p025=delta-1.96*se,p975=delta+1.96*se,identity='UNADJUSTED_TAYLOR_DESIGN_APPROX;NOT_MULTIPLE_TEST_CONFIRMED'))
 write('G_WITHIN_STAGE_PAIRED_CONTRASTS.csv',contrasts)
 for name in ['G_STAGE_HT_ESTIMATES.csv','G_STAGE_HT_CHANGES.csv','G_ESTIMATOR_COMPARISON.csv','G_POLICY_DESCRIPTIVE_68.csv','G_POLICY_FUNCTION_STATUS_204.csv','G_CODER_DISAGREEMENT_SENSITIVITY.csv','SOURCE_PROVENANCE_AND_COVERAGE.csv','SOURCE_SCOPE_IMPACT_ON_G.csv','G_ERROR_SOURCE_DECOMPOSITION.csv']:
  shutil.copy2(dep(HT/name),OUT/name)
 for name in ['ACTUAL_AUDIT_ERROR_METRICS.csv','INDEPENDENT_CODING_AGREEMENT.csv']:
  shutil.copy2(dep(AUDIT/name),OUT/name)
 write('CURRENT_FIGURE4_SOURCE.csv',stage);write('Figure4b_source.csv',stage)
 return h,stage,t

def build_policy_ternary_data():
 d=read(OUT/'G_POLICY_DESCRIPTIVE_68.csv');h=read(HT/'G_POLICY_HT_SHARES.csv')
 cols=['policy_id','stage']+[g+'_HT_share' for g in G]+['result_identity','source_category','statistical_population','descriptive_status']
 d=d[cols].copy();v=d[[g+'_HT_share' for g in G]].to_numpy()
 assert len(d)==68 and d.policy_id.is_unique and np.isfinite(v).all() and (v>=0).all() and np.allclose(v.sum(1),1,atol=1e-12)
 for g in G:
  expected=h[h.label.eq(g)].set_index('policy_id').design_corrected_share.reindex(d.policy_id).to_numpy()
  assert np.allclose(d[g+'_HT_share'],expected,atol=1e-12)
 d['x']=v[:,1]+.5*v[:,2];d['y']=np.sqrt(3)/2*v[:,2]
 d['coordinate_overlap_n']=d.groupby(['x','y']).policy_id.transform('size')
 write('Figure4a_ternary_source.csv',d);return d

def plot_policy_ternary(ax,d):
 H=np.sqrt(3)/2
 for q in [.25,.5,.75]:
  ax.plot([.5*q,1-.5*q],[H*q,H*q],color='.87',lw=.55)
  ax.plot([q,(1+q)/2],[0,H*(1-q)],color='.87',lw=.55)
  ax.plot([1-q,(1-q)/2],[0,H*(1-q)],color='.87',lw=.55)
  ax.text(q,-.025,f'{int(q*100)}',ha='center',va='top',fontsize=10,color='.4')
 ax.plot([0,1,.5,0],[0,0,H,0],color='.3',lw=.8)
 colors=['#244A73','#258A83','#DA8A45','#80718E'];markers=['o','s','^','D']
 for i,stage in enumerate(STAGES):
  z=d[d.stage.eq(stage)];assert len(z)==[11,13,16,28][i]
  ax.scatter(z.x,z.y,s=28+8*(z.coordinate_overlap_n-1),marker=markers[i],c=colors[i],alpha=.72,edgecolors='white',linewidths=.45,label=stage+' (n='+str(len(z))+')',zorder=3)
 ax.text(0,-.085,'G1\nSource pressure control',ha='center',va='top',fontsize=11)
 ax.text(1,-.085,'G2\nHabitat protection\nand restoration',ha='center',va='top',fontsize=11)
 ax.text(.5,H+.035,'G3 — Monitoring and coordination',ha='center',fontsize=11)
 ax.set(xlim=(-.14,1.14),ylim=(-.21,H+.1));ax.set_aspect('equal');ax.axis('off')
 ax.legend(loc='upper center',bbox_to_anchor=(.5,-.07),ncol=2,frameon=False,fontsize=11,title='Policy stage',title_fontsize=11)

def plot_stage_g_composition(ax,stage):
 for k,g in enumerate(G):
  z=stage[stage.label.eq(g)].set_index('stage').loc[STAGES]
  ax.errorbar(np.arange(4)+(k-1)*.16,z.design_corrected_share*100,yerr=z.standard_error*196,fmt='o',lw=1.2,capsize=3,color=COLORS[k],label=g,ms=4)
 ax.set_xticks(range(4),[s+'\nn = '+str(n) for s,n in zip(STAGES,[11,13,16,28])],fontsize=11)
 ax.set_ylim(0,70);ax.set_ylabel('Policy-equal G assignment share (%)');ax.grid(axis='y',color='.91')
 ax.legend(ncol=3,loc='upper left',frameon=False,title='Governance function',title_fontsize=11)

def build_policy_share_distribution_table(d):
 rows=[]
 for stage in STAGES:
  for g in G:
   x=d.loc[d.stage.eq(stage),g+'_HT_share']
   rows.append(dict(stage=stage,label=g,policy_n=len(x),median=x.median(),p25=x.quantile(.25),p75=x.quantile(.75),minimum=x.min(),maximum=x.max(),identity='CROSS_POLICY_HT_ESTIMATE_DISTRIBUTION_NOT_CONFIDENCE_INTERVAL'))
 write('Table_S11_policy_share_distribution.csv',rows)

def plot_within_stage_g_contrasts():
 z=read(OUT/'G_WITHIN_STAGE_PAIRED_CONTRASTS.csv');shutil.copy2(OUT/'G_WITHIN_STAGE_PAIRED_CONTRASTS.csv',OUT/'Figure_S1_source.csv')
 fig,axes=plt.subplots(1,4,figsize=(10,3.4),sharey=True,sharex=True)
 for ax,stage in zip(axes,STAGES):
  q=z[z.stage.eq(stage)].set_index('contrast').loc[['G1-G2','G1-G3','G2-G3']]
  ax.axvline(0,color='.5',lw=.8,ls='--');ax.errorbar(q.difference*100,np.arange(3),xerr=np.vstack([(q.difference-q.p025)*100,(q.p975-q.difference)*100]),fmt='o',color='#244A73',capsize=3)
  ax.set_yticks(range(3),q.index);ax.set_title(stage,fontsize=10);ax.grid(axis='x',color='.93');ax.set_xlabel('Difference (pp)')
 axes[0].invert_yaxis();fig.tight_layout();save(fig,'Figure_S1_updated')

def figures(stage):
 plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Arial','DejaVu Sans'],'font.size':12,'svg.fonttype':'none','pdf.fonttype':42,'axes.spines.top':False,'axes.spines.right':False})
 d=build_policy_ternary_data();build_policy_share_distribution_table(d)
 fig,ax=plt.subplots(figsize=(6,5.8));plot_policy_ternary(ax,d);ax.set_title('Policy-level governance-function composition',fontsize=11,pad=20);save(fig,'Figure4a_ternary')
 fig=plt.figure(figsize=(11.8,5.8));ax=fig.add_axes([.035,.22,.47,.65]);plot_policy_ternary(ax,d)
 fig.text(.03,.96,'a  Policy-level governance-function\n    composition',fontsize=13,weight='bold')
 ax=fig.add_axes([.59,.26,.39,.60]);plot_stage_g_composition(ax,stage)
 fig.text(.56,.96,'b  Governance-function composition',fontsize=13,weight='bold');fig.text(.585,.92,'across policy stages',fontsize=13,weight='bold')
 fig.text(.59,.10,'Bars: 95% Taylor audit-design approximation\nFixed extracted-unit frame; post-audit HT estimates',fontsize=10)
 save(fig,'Figure4_updated')
 for ext in ['png','svg','pdf']:shutil.copy2(OUT/('Figure4_updated.'+ext),OUT/('Figure4.'+ext))
 plot_within_stage_g_contrasts()
 jout(OUT/'Figure4_source_data_manifest.json',dict(identity='FIXED_FRAME_POST_AUDIT_DESCRIPTIVE_RESULT',sources={n:sha(OUT/n) for n in ['G_POLICY_DESCRIPTIVE_68.csv','Figure4a_ternary_source.csv','Figure4b_source.csv','G_STAGE_HT_ESTIMATES.csv','Table2_updated.csv','G_WITHIN_STAGE_PAIRED_CONTRASTS.csv']},HT_reestimated=False,network_used=False))

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--skip-docx',action='store_true');args=ap.parse_args();OUT.mkdir(parents=True,exist_ok=True);start=time.time()
 for p in [ROOT/'part1_current_report.py',ROOT/'part1_report_documents.py',ROOT/'policy_statistics_20261028.py',ROOT/'g_descriptive_delivery_20261028.py',ROOT/'g_estimator_stability_20261028.py',ROOT/'joint_history_audit_20261028.py']:dep(p)
 manifest=load(HT/'PART1_G_DELIVERY_MANIFEST.json')
 for item in manifest['input_hashes']:
  assert sha(item['path'])==item['sha256'],item['path']
 for p in [Path('C:/Users/Mario/Desktop/OCMA投稿/Manuscript.docx'),Path('C:/Users/Mario/Desktop/OCMA投稿/supplementary material.docx')]:
  dep(p);(OUT/'historical_archive').mkdir(exist_ok=True);shutil.copy2(p,OUT/'historical_archive'/p.name)
 h=read(HT/'G_POLICY_HT_SHARES.csv');stage=read(OUT/'G_STAGE_HT_ESTIMATES.csv');t=read(OUT/'Table2_updated.csv')
 dep(OUT/'NETWORK_REPRODUCIBILITY_DECISION.json');figures(stage)
 (OUT/'CODE_AUDIT.md').write_text('Current entry reuses frozen HT, Table 2, saved Bootstrap and covariance contrasts. No estimator rerun, training, sampling or SD. Figure 4a is the 68-policy ternary plot; Figure S1 uses frozen paired contrasts; Table S11 is a cross-policy distribution. Legacy network inputs were not found in one scoped search and remain NOT_REVALIDATED; network excluded from current empirical results. Historical data remain archived.','utf8')
 jout(OUT/'REPORT_INPUTS.json',DEPS)
 if not args.skip_docx:
  runtime=Path('C:/Users/Mario/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe')
  subprocess.run([str(runtime),str(ROOT/'part1_report_documents.py')],check=True)
 assert all(sha(p)==v for p,v in DEPS.items())
 for item in manifest['input_hashes']:assert sha(item['path'])==item['sha256']
 jout(OUT/'REPORT_COMPUTATION_LOG.json',dict(elapsed_seconds=time.time()-start,input_count=len(DEPS),frozen_dependency_checks=len(manifest['input_hashes']),training=False,sampling=False,SD=False,bootstrap_replay=0,bootstrap_saved_replicates_reused=2000,HT_reestimated=False,network_events_revalidated=False))
 if not args.skip_docx:subprocess.run([sys.executable,str(ROOT/'test_part1_current_report.py')],check=True)
 print(str(OUT))
if __name__=='__main__':main()
