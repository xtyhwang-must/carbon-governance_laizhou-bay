"""Targeted synthetic tests and read-only real-frame checks; no human events."""
import itertools,json,math
from pathlib import Path
import numpy as np
import pandas as pd
import joint_history_audit_20261028 as j

checks=[]
def ok(name,value,identity='SYNTHETIC_TEST_ONLY'):
    assert value,name;checks.append(dict(test=name,passed=True,identity=identity))
def must_fail(name,fn):
    try:fn()
    except ValueError:ok(name,True);return
    raise AssertionError(name)

ok('read-group probability matches independent exact integer combinations',abs(j.no_hit_prob(10,3,2)-math.comb(8,3)/math.comb(10,3))<1e-12)
ok('whole-census missed-group probability is zero',j.no_hit_prob(10,10,1)==0)
must_fail('blank protocol template cannot authorize sample',lambda:j.authorize_draw({},dict(statement='APPROVE_JOINT_HISTORY_AUDIT_DESIGN',reviewer='',signed_at=''),Path('.')))

rows=[];truth=[]
for i in range(9):
    real=dict(unit_id=f'P__B1U{i:05}',policy_id='P',stage='2000-2010',eligibility=1,
       G1=int(i in [0,2,6]),G2=int(i in [3,7]),G3=int(i in [1,4,8]),
       T1=int(i in [0,3]),T2=int(i in [1,4,8]),T3=int(i==2),T4=int(i in [4,6]),T5=0,T6=int(i==7),
       unit_validity='VALID_SENTENCE_OR_CLAUSE',source_membership='IN_TARGET',reused_fields='')
    truth.append(real)
    row=dict(unit_id=real['unit_id'],policy_id='P',stage='2000-2010',policy_family_id='F',
      stratum_id='FIXED' if i==0 else 'H1' if i<5 else 'H2',new_probability_domain=i>0)
    for k in j.LABELS:row['C2_'+k]=str(real[k]) if i==0 else '0'
    if i>0:row['C2_T2']=''
    rows.append(row)
frame=pd.DataFrame(rows);truth=pd.DataFrame(truth)
allocation=pd.DataFrame([dict(stratum_id='H1',policy_id='P',N='4',sample_n='2'),dict(stratum_id='H2',policy_id='P',N='4',sample_n='2')])
all_est=[];all_var=[];positive_sample=None;positive_actual=None
for a,b in itertools.product(itertools.combinations(range(1,5),2),itertools.combinations(range(5,9),2)):
    ids=[f'P__B1U{i:05}' for i in a+b]
    sample=frame[frame.unit_id.isin(ids)].copy();sample['statistical_identity']='JOINT_STRATIFIED_SRSWOR';sample['inclusion_probability']='0.5';sample['design_weight']='2'
    actual=truth[truth.unit_id.isin(ids)].copy()
    moment,total=j.audit_composition_impact(frame,sample,actual,allocation)
    all_est.append(moment['P'][0]);all_var.append(moment['P'][1])
    if 1 in a:positive_sample=sample;positive_actual=actual
expected=sum((j.feature_vector(r,'truth') for r in truth.to_dict('records')),np.zeros(len(j.FEATURES)))
ok('all 36 possible stratified samples have unbiased difference totals',np.allclose(np.mean(all_est,axis=0),expected,atol=1e-12))
ix=j.FEATURES.index('G3')
ok('estimated stratum variance unbiased over exact finite randomization',abs(np.mean(np.asarray(all_var)[:,ix,ix])-np.var(np.asarray(all_est)[:,ix],ddof=0))<1e-12)
ok('T2 zero auxiliary leaves frozen T2 unknown',frame.loc[frame.new_probability_domain,'C2_T2'].eq('').all() and expected[j.FEATURES.index('T2')]==3)
metrics=j.error_metrics(frame,positive_sample,positive_actual)
ok('machine-negative actual eligibility and G3 positives become FN',int(metrics[(metrics.dimension=='ALL')&metrics.label.eq('eligibility')].FN.iloc[0])>0 and int(metrics[(metrics.dimension=='ALL')&metrics.label.eq('G3')].FN.iloc[0])>0)
ok('unknown T2 reported as abstention rather than observed zero',int(metrics[(metrics.dimension=='ALL')&metrics.label.eq('T2')].prediction_abstention_n.iloc[0])==len(positive_sample))
directed=positive_sample.copy();directed['statistical_identity']='DIRECTED_ADJUDICATION'
must_fail('directed cases cannot become probability correction',lambda:j.audit_composition_impact(frame,directed,positive_actual,allocation))
wrong=positive_sample.copy();wrong['inclusion_probability']='0.2'
must_fail('incorrect inclusion probability rejected',lambda:j.audit_composition_impact(frame,wrong,positive_actual,allocation))
partial=positive_actual.iloc[:-1]
must_fail('partial actual return cannot extrapolate whole population',lambda:j.audit_composition_impact(frame,positive_sample,partial,allocation))

base=dict(unit_id='TEST',human_eligibility='',unit_validity='VALID_SENTENCE_OR_CLAUSE',source_membership='IN_TARGET')
norm,err=j.normalize_truth(pd.DataFrame([base]));ok('blank eligibility remains unresolved',norm.empty and len(err)==1)
negative=dict(base,human_eligibility='0')
norm,err=j.normalize_truth(pd.DataFrame([negative]));ok('explicit human ineligible derives GT zeros with parent identity',len(norm)==1 and norm[j.G+j.T].sum().sum()==0 and norm.zero_origin.iloc[0]=='DERIVED_FROM_ACTUAL_HUMAN_INELIGIBLE')
bad=dict(negative,human_G3='1');norm,err=j.normalize_truth(pd.DataFrame([bad]));ok('ineligible plus G3 positive conflict not silently erased',norm.empty and len(err)==1)
known={'TEST':{k:str(v) for k,v in {'eligibility':1,'G1':0,'G2':0,'G3':1,**{t:0 for t in j.T}}.items()}}
norm,err=j.normalize_truth(pd.DataFrame([base]),known);ok('valid existing fields reused without retyping',len(norm)==1 and norm.G3.iloc[0]==1)
bad=dict(base,human_G3='0');norm,err=j.normalize_truth(pd.DataFrame([bad]),known);ok('machine or new blank form cannot overwrite existing true field',norm.empty and len(err)==1)
multi=dict(base,human_eligibility='1',G_group_checked='1',T_group_checked='1',G_selected='G2;G3',T_selected='T2;T4')
norm,err=j.normalize_truth(pd.DataFrame([multi]));ok('explicit complete multiselect derives only actual checked unselected zeros',len(norm)==1 and norm.G3.iloc[0]==1 and norm.T2.iloc[0]==1 and norm.T6.iloc[0]==0 and norm.zero_origin_T.iloc[0]=='HUMAN_COMPLETE_GROUP_UNSELECTED')
unchecked=dict(multi,T_group_checked='');norm,err=j.normalize_truth(pd.DataFrame([unchecked]));ok('unconfirmed multiselect is not a completed group',norm.empty and len(err)==1)

# Equal-policy means remain independent of policy length/field-group count.
m={};ff=[]
for pid,n,totalg in [('SMALL',2,[2,0,0]),('LARGE',20,[0,20,0])]:
    v=np.zeros(len(j.FEATURES));v[0]=n;v[1:4]=totalg;m[pid]=(v,np.zeros((len(v),len(v))),[])
    ff.extend([dict(unit_id=pid+str(i),policy_id=pid,stage='2000-2010') for i in range(n)])
_,stage=j.evaluate_function_history(pd.DataFrame(ff),m)
ok('policy-equivalent shares not unit-length weighted',stage.set_index('label').loc['G1','design_corrected_share']==.5)
unresolved=positive_actual.copy();unresolved.loc[unresolved.index[0],'unit_validity']='MULTI_CLAUSE_UNRESOLVED'
_,tot=j.audit_composition_impact(frame,positive_sample,unresolved,allocation)
ok('unresolved unit mapping keeps estimates unidentified',tot.estimated_total.isna().all())
constant_frame=frame.copy()
constant_actual=positive_actual.copy()
for k in j.LABELS:
    constant_actual[k]=0
    constant_frame['C2_'+k]='0'
constant_actual['eligibility']=1;constant_actual['G1']=1
constant_frame['C2_eligibility']='1';constant_frame['C2_G1']='1'
cm,_=j.audit_composition_impact(constant_frame,positive_sample,constant_actual,allocation)
_,cs=j.evaluate_function_history(constant_frame,cm)
ok('zero observed residual variance not published as zero-risk interval',cs.p025_normal_approx.isna().all() and cs.zero_empirical_variance_not_zero_risk.all())

ctx,d=j.ctx_and_dir();protocol=j.load(d/'joint_audit_protocol.json');real=j.read(d/'sampling_frame_BACKEND.csv');probs=j.read(d/'AUDIT_DESIGN_AND_INCLUSION_PROBABILITIES.csv')
ok('real frame retains all original IDs and 68 policies',real.unit_id.is_unique and len(real)==32858 and real.policy_id.nunique()==68,'ACTUAL_FRAME_CHECK')
ok('original 600 and 49 are not re-requested',not (j.truth(real.new_probability_domain)&real.protected_reference_identity.ne('')).any(),'ACTUAL_FRAME_CHECK')
for option in protocol['options']:
    opt=option['option'];a=j.read(d/f'allocation_{opt}.csv');pi=j.numeric(probs['planned_pi_'+opt]);new=j.truth(real.new_probability_domain)
    ok(f'{opt} allocation, positive probabilities and inverse weights',int(j.numeric(a.sample_n).sum())==option['new_target_units'] and pi[new].between(0,1,inclusive='right').all() and np.allclose(j.numeric(probs['planned_weight_'+opt]),1/pi),'ACTUAL_FRAME_CHECK')
    ok(f'{opt} expected reading blocks do not exceed sampled units',option['expected_primary_distinct_reading_blocks']<=option['new_target_units']+1e-6,'ACTUAL_FRAME_CHECK')
ok('no real probability draw or new agreement report before approval',not (d/'sample').exists() and not (d/'INDEPENDENT_CODING_AGREEMENT.csv').exists(),'ACTUAL_FRAME_CHECK')
frozen=j.load(d/'frozen_start/manifest.json')
ok('frozen model bytes and training signature unchanged',j.sha(ctx.artifact('train')/'diagnostic_model.joblib')==frozen['model_sha256'] and j.sha(ctx.artifact('build-registry')/'training_signature.json')==frozen['training_signature_sha256'],'ACTUAL_FRAME_CHECK')
ok('old active numerical pipeline source not modified',all(j.sha(d/'frozen_start'/name)==j.sha(ctx.code/Path(name).name) for name in frozen['files'] if name.startswith('code')),'ACTUAL_FRAME_CHECK')
decision=j.load(d/'PART1_RESEARCH_USE_DECISION.json')
ok('research quality and completion remain false without actual evidence',not any(decision['states'][k] for k in ['G_HISTORY_QUALITY_SUPPORTED','T_CONFIGURATION_QUALITY_SUPPORTED','C2_FORMAL_RELEASE_READY','PART1_COMPLETED']),'ACTUAL_FRAME_CHECK')
ok('G0 identity and 68-policy status unchanged',j.read(d/'G0_POLICY_STATUS.csv').equals(j.read(j.paths_for(ctx)['g0'])),'ACTUAL_FRAME_CHECK')
causes=j.read(d/'scope_root_cause_reconciliation.csv').set_index('issue_type')
ok('old source flag is decomposed and accepted versions not reopened',int(causes.loc['SOURCE_VERSION','units'])==0 and int(causes.loc['EXTRACTION_SCOPE','units'])==2017 and int(causes.loc['SEMANTIC_RULE','units'])==1,'ACTUAL_FRAME_CHECK')
j.jsonout(d/'QA.json',dict(scope='joint audit extension only; old Bootstrap not rerun',actual_frame_checks=[r for r in checks if r['identity']=='ACTUAL_FRAME_CHECK'],synthetic_tests=[r for r in checks if r['identity']=='SYNTHETIC_TEST_ONLY'],all_passed=True,research_results_from_synthetic_data=False,new_actual_human_judgments=0))
print(json.dumps(dict(passed=len(checks),actual=sum(r['identity']=='ACTUAL_FRAME_CHECK' for r in checks),synthetic=sum(r['identity']=='SYNTHETIC_TEST_ONLY' for r in checks)),ensure_ascii=False))
