"""Workbook identity/readback and in-memory synthetic judgment adapter checks."""
from pathlib import Path
from unittest.mock import patch
import json,zipfile
from openpyxl import load_workbook
import pandas as pd
import joint_history_audit_20261028 as j
import joint528_compact_20261028 as c

FILE=j.ROOT/'outputs/JOINT_528_ac6da323683e5609/JOINT_528_G_ONLY_主审填写.xlsx'
_,parent,child=c.location();view=c.GOnlyView(child,parent)
book=load_workbook(FILE,read_only=True,data_only=False)
original={s.title:list(s.values) for s in book.worksheets};book.close()
results=[]
def check(name,identity,func):
 func();results.append(dict(test=name,identity=identity,status='PASS'))

def real_readback():
 p,qa=c.g_only_xlsx_payload(FILE)
 assert qa==dict(roster_n=528,reading_blocks=502,touched_n=0,blank_n=528)
 assert not p['records'] and not p['reviewer'] and not p['completed_at'] and not p['confirmation']
 template=j.read(child/'sample/registered_PRIMARY_TEMPLATE.csv')
 rows=original['审核填写'];headers=list(rows[0]);units=[r[headers.index('unit_id')] for r in rows[1:]]
 assert len(units)==len(set(units))==528 and set(units)==set(template.unit_id)
 assert all(k not in headers for k in j.T)

def blank_not_acceptance():
 try:c.ingest_g_only_xlsx(FILE,evaluate=False)
 except ValueError as e:assert 'No actual workbook judgments' in str(e)
 else:raise AssertionError('Blank workbook was adopted')

def preserved_sampling_and_model():
 frozen=j.load(parent/'G_history_priority_patch_20261028/frozen_input_hashes.json')
 assert all(j.sha(v['path'])==v['sha256'] for v in frozen.values())
 sample=j.read(child/'sample/actual_sample_BACKEND.csv')
 assert sample.stratum_id.nunique()==264 and sample.reading_id.nunique()==502
 assert not (view.root/'xlsx_returns').exists()

class Sheet:
 def __init__(self,values):self.values=values
class FakeBook:
 def __init__(self,data):self.data=data;self.sheetnames=list(data)
 def __getitem__(self,key):return Sheet(self.data[key])
 def close(self):pass

def synthetic_rows(changes):
 data={k:[list(r) for r in rows] for k,rows in original.items()}
 header=data['审核填写'][0]
 for i,values in changes.items():
  for key,value in values.items():data['审核填写'][i][header.index(key)]=value
 with patch.object(c,'load_workbook',return_value=FakeBook(data)):
  payload,qa=c.g_only_xlsx_payload(FILE)
 return payload,qa

def synthetic_positive_and_negative():
 payload,qa=synthetic_rows({1:{'合格性':0},2:{'合格性':1,'G1':1,'G2':1,'完成确认':'G已检查，来源句条无异常'}})
 a,e=j.normalize_truth(pd.DataFrame(payload['records']),review_scope='G_ONLY')
 assert e.empty and len(a)==2
 z=a.iloc[0];assert z.eligibility==0 and z.G1==z.G2==z.G3==0
 assert z.field_origin_G1=='DERIVED_FROM_CURRENT_INELIGIBLE'
 z=a.iloc[1];assert z.eligibility==1 and z.G1==1 and z.G2==1 and z.G3==0
 assert a[j.T].isna().all().all()

def synthetic_incomplete_not_zero():
 payload,qa=synthetic_rows({1:{'合格性':1,'G1':1,'来源适用（仅异常）':'目标政策正文','句条有效性（仅异常）':'有效句子/条款'}})
 a,e=j.normalize_truth(pd.DataFrame(payload['records']),review_scope='G_ONLY')
 assert a.empty and len(e)==1

def changed_source_rejected():
 try:synthetic_rows({1:{'目标单元原文':'SYNTHETIC_CHANGED_SOURCE'}})
 except ValueError as e:assert 'Protected target' in str(e)
 else:raise AssertionError('Source change silently accepted')

def native_features():
 with zipfile.ZipFile(FILE) as z:
  assert z.testzip() is None
  review=z.read('xl/worksheets/sheet1.xml').decode('utf-8')
  assert 'dataValidation' in review and 'pane' in review and 'HYPERLINK' in review
  assert '<mergeCells' not in review

check('528_sample_and_502_readings_exact_readback','REAL_SAVED_WORKBOOK',real_readback)
check('blank_workbook_cannot_be_accepted','REAL_SAVED_WORKBOOK',blank_not_acceptance)
check('fixed_sample_probabilities_and_model_unchanged','REAL_FROZEN_INPUT_HASHES',preserved_sampling_and_model)
check('positive_multilabel_negative_parent_and_T_unknown','SYNTHETIC_IN_MEMORY_ONLY',synthetic_positive_and_negative)
check('unchecked_G_blank_not_zero','SYNTHETIC_IN_MEMORY_ONLY',synthetic_incomplete_not_zero)
check('edited_original_text_rejected','SYNTHETIC_IN_MEMORY_ONLY',changed_source_rejected)
check('valid_xlsx_dropdowns_freeze_and_source_navigation','REAL_OPENXML_PACKAGE',native_features)
out=FILE.parent/'xlsx_authoring';report=dict(generated_at=j.now(),workbook_sha256=j.sha(FILE),results=results,passed=len(results),failed=0,
  actual_human_judgments=0,model_runs=0,scope='WORKBOOK_EXPORT_ADAPTER_ONLY;NO_RESEARCH_ESTIMATION',
  importer_code_sha256=j.sha(Path(c.__file__)),entry_code_sha256=j.sha(j.ROOT/'joint528_G_ONLY_execution_20261028.py'))
j.jsonout(out/'xlsx_identity_and_importer_QA.json',report)
print(json.dumps(report,ensure_ascii=False,indent=2))
