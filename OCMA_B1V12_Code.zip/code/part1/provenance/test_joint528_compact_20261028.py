"""Approved draw and UI checks only. Synthetic judgments are never imported."""
import tempfile,json
from pathlib import Path
import numpy as np
import pandas as pd
from openpyxl import load_workbook
import joint_history_audit_20261028 as j
import joint528_compact_20261028 as c

checks=[]
def ok(name,value,identity='ACTUAL_DRAW_OR_WORKBOOK_CHECK'):
 assert value,name;checks.append(dict(test=name,passed=True,identity=identity))
def fails(name,fn):
 try:fn()
 except ValueError:ok(name,True,'SYNTHETIC_NEGATIVE_TEST');return
 raise AssertionError(name)
ctx,parent,root=c.location();sm=j.load(root/'sample/sample_manifest.json');p=j.load(root/'joint_audit_protocol.json')
parent_roster=j.read(parent/'sample/actual_sample_BACKEND.csv');actual=j.read(root/'sample/actual_sample_BACKEND.csv');allocation=j.read(root/f'allocation_{p["option"]}.csv')
ok('all 528 IDs are a strict subset of frozen 600',len(actual)==528 and actual.unit_id.is_unique and set(actual.unit_id)<set(parent_roster.unit_id))
ok('all 264 strata retained at locked allocation',len(allocation)==264 and all(len(actual[actual.stratum_id.eq(r.stratum_id)])==int(r.sample_n) for r in allocation.itertuples()))
rng=np.random.default_rng(p['seed']);selected=[]
for r in allocation.sort_values('stratum_id').itertuples():
 z=parent_roster[parent_roster.stratum_id.eq(r.stratum_id)].sort_values('unit_id');selected.extend(z.iloc[rng.choice(len(z),int(r.sample_n),replace=False)].unit_id.tolist())
second=set(rng.choice(sorted(selected),106,replace=False))
ok('fixed seed reproduces both nested rosters',set(selected)==set(actual.unit_id) and second==set(actual.loc[actual.second_coder_selected.eq('True'),'unit_id']))
ok('final and conditional inclusion probabilities match nested design',all(np.allclose(j.numeric(actual[actual.stratum_id.eq(r.stratum_id)].inclusion_probability),int(r.sample_n)/int(r.N)) and np.allclose(j.numeric(actual[actual.stratum_id.eq(r.stratum_id)].conditional_keep_probability),int(r.sample_n)/int(r.parent_sample_n)) for r in allocation.itertuples()))
ok('weights and second-phase marginal probability',np.allclose(j.numeric(actual.design_weight),1/j.numeric(actual.inclusion_probability)) and np.allclose(j.numeric(actual.second_phase_inclusion_probability),j.numeric(actual.inclusion_probability)*106/528))
ok('both machine gates and no protected reference re-review',set(actual.machine_gate)=={'0','1'} and actual.protected_reference_identity.eq('').all())
ok('parent actual roster preserved',j.sha(parent/'sample/actual_sample_BACKEND.csv')==p['parent_actual_sample_sha256'])
approval=next((parent/'approvals').glob('chat_JOINT_528_*.json'))
before={n:j.sha(root/'sample'/n) for n in sm['files']};again=c.draw(approval)
ok('child draw re-entry idempotent',again['reused'] and before=={n:j.sha(root/'sample'/n) for n in sm['files']})

base=dict(unit_id='SYNTHETIC_UNIT_ONLY',human_eligibility='1',G_selected='G3',T_selected='T2',G_group_checked='',T_group_checked='',source_membership='',unit_validity='',canonical_unit_id='',review_complete='')
blank=c.expand_completion(pd.DataFrame([base])).iloc[0]
ok('blank confirmation derives no GT check or source acceptance',blank.G_group_checked=='' and blank.source_membership=='','SYNTHETIC_TEST_ONLY')
normal=c.expand_completion(pd.DataFrame([dict(base,review_complete='完成（无异常）')]))
truth,error=j.normalize_truth(normal)
ok('actual combined confirmation yields grouped labels and source check',len(truth)==1 and truth.G3.iloc[0]==1 and truth.T2.iloc[0]==1 and truth.T6.iloc[0]==0 and truth.source_membership.iloc[0]=='IN_TARGET','SYNTHETIC_TEST_ONLY')
exception=c.expand_completion(pd.DataFrame([dict(base,review_complete='标签检查完成（有异常）')])).iloc[0]
ok('exception confirmation never grants source or boundary acceptance',exception.G_group_checked=='1' and exception.source_membership=='' and exception.unit_validity=='','SYNTHETIC_TEST_ONLY')
negative=c.expand_completion(pd.DataFrame([dict(base,human_eligibility='0',G_selected='',T_selected='',review_complete='完成（无异常）')]))
nt,ne=j.normalize_truth(negative)
ok('explicit ineligible uses parent-derived zeros',len(nt)==1 and nt[j.G+j.T].sum().sum()==0 and nt.zero_origin.iloc[0]=='DERIVED_FROM_ACTUAL_HUMAN_INELIGIBLE','SYNTHETIC_TEST_ONLY')
fails('a source exception cannot be silently replaced by no-exception confirmation',lambda:c.expand_completion(pd.DataFrame([dict(base,review_complete='完成（无异常）',source_membership='OUTSIDE_TARGET')])))
unknown=c.expand_completion(pd.DataFrame([dict(base,review_complete='暂无法判断')])).iloc[0]
ok('unable-to-judge does not produce zero fields',unknown.G_group_checked=='' and unknown.source_membership=='','SYNTHETIC_TEST_ONLY')

out=j.ROOT/'outputs/JOINT_528_ac6da323683e5609';reports=[]
for role,name in [('PRIMARY','JOINT_528_主审核_COMPACT_BLIND.xlsx'),('SECONDARY','JOINT_528_第二编码者_COMPACT_BLIND.xlsx')]:
 file=out/name;_,view,rows,batch,meta=c.recover(file)
 template=j.read(root/'sample'/f'registered_{role}_TEMPLATE.csv');ok(role+' sample set and all protected text recovered exactly',set(rows.unit_id)==set(template.unit_id) and len(rows)==len(template))
 fields=['human_'+k for k in j.LABELS]+['G_selected','T_selected','review_complete','G_group_checked','T_group_checked','source_membership','unit_validity']
 ok(role+' no actual human values prefilled',all(rows[k].eq('').all() for k in fields))
 ok(role+' batch has no fabricated reviewer/time/signature',not batch.get('reviewer') and not batch.get('completed_at') and not batch.get('confirmation'))
 wb=load_workbook(file,data_only=False);main=wb['审核'];headers=[v.value for v in main[1]]
 ok(role+' blind file has no scores or old predictions',not any(str(v).startswith(('score_','C2_','origin_','diagnostic_','usable_')) for v in headers))
 ok(role+' native links pane and validations exported',sum(cell.hyperlink is not None for row in main for cell in row)==len(template) and main.freeze_panes=='D2' and len(main.data_validations.dataValidation)==4)
 wb.close();reports.append(dict(file=str(file),sha256=j.sha(file),**meta))
with tempfile.TemporaryDirectory(prefix='SYNTHETIC_CORRUPTION_ONLY_',dir=out/'build') as tmp:
 wrong=Path(tmp)/'SYNTHETIC_CHANGED_SOURCE.xlsx';book=load_workbook(out/'JOINT_528_主审核_COMPACT_BLIND.xlsx');book['审核']['B2']='SYNTHETIC_CORRUPTION_ONLY';book.save(wrong);book.close()
 fails('modified source text rejected before import',lambda:c.recover(wrong))
old=j.load(parent/'JOINT_600_DRAW_DELIVERY_MANIFEST.json')
oldout=j.ROOT/'outputs/JOINT_600_7e471637738bc8f5'
ok('old public 600 workbooks untouched',all(j.sha(oldout/r['filename'])==r['sha256'] for r in old['workbooks']))
start=j.load(parent/'frozen_start/manifest.json')
ok('model training and frozen coding/statistics pointers untouched',j.sha(ctx.artifact('train')/'diagnostic_model.joblib')==start['model_sha256'] and j.sha(ctx.artifact('build-registry')/'training_signature.json')==start['training_signature_sha256'] and j.sha(ctx.root/'C2_CURRENT.json')==j.sha(parent/'frozen_start/C2_CURRENT.json') and j.sha(ctx.root/'POLICY_STATISTICS_CURRENT.json')==j.sha(parent/'frozen_start/POLICY_STATISTICS_CURRENT.json'))
ok('no fake review or research-quality promotion',not (root/'returns').exists() and not any(j.load(root/'PART1_RESEARCH_USE_DECISION.json')['states'][k] for k in ['G_HISTORY_QUALITY_SUPPORTED','T_CONFIGURATION_QUALITY_SUPPORTED','C2_FORMAL_RELEASE_READY','PART1_COMPLETED']))
j.jsonout(root/'DRAW_AND_COMPACT_QA.json',dict(checks=checks,workbooks=reports,actual_new_human_judgments=0,old600_preserved=True,
 actual_primary_n=528,actual_primary_reading_n=502,actual_secondary_n=106,actual_secondary_reading_n=106,
 test_scope='approved nested draw and compact presentation only; synthetic examples never imported',all_passed=True))
print(json.dumps(dict(checks=len(checks),actual=sum(r['identity']=='ACTUAL_DRAW_OR_WORKBOOK_CHECK' for r in checks),synthetic=sum(r['identity']!='ACTUAL_DRAW_OR_WORKBOOK_CHECK' for r in checks)),ensure_ascii=False))
