"""Joint historical-composition audit extension to the existing B1 coding run.

Prepare is read-only with respect to frozen research artifacts. A probability
draw requires a real, hash-bound approval. Review data never train a model.
"""
import argparse, json, math, re, sys, time
from pathlib import Path
from collections import defaultdict
import numpy as np
import pandas as pd
from scipy.special import gammaln

ROOT=Path(__file__).resolve().parent
WS=ROOT/'OCMA_empirical_revision_workspace_B1_20261026'
BASE=WS/'05_revision_work/R1_20261026/01_coding/coding_pipeline_completion'
ACTIVE=json.loads((BASE/'CURRENT_ACTIVE_PIPELINE.json').read_text('utf-8-sig'))
sys.path.insert(0,ACTIVE['active_code'])
from common import Context,read,read_review,load,sha,digest,csvout,jsonout,longpath,require,signed,atomic_json,now,LABELS

G=['G1','G2','G3'];T=['T1','T2','T3','T4','T5','T6']
STAGES=['2000-2010','2011-2016','2017-2020','2021-2023']
VERSION='B1_V1.2_JOINT_HISTORY_AUDIT_20261028_v1'
VALID_UNITS={'VALID_SENTENCE_OR_CLAUSE','VALID_COMPOUND_CLAUSE'}
UNIT_CHOICES=VALID_UNITS|{'TRUNCATED_UNRESOLVED','DUPLICATE_CONFIRMED','MULTI_CLAUSE_UNRESOLVED','SOURCE_NOT_TARGET','UNABLE_TO_JUDGE'}

def ctx_and_dir():
    ctx=Context(str(WS),ACTIVE['run_id'])
    directory=ctx.root/'history_quality_repair_20261028'
    directory.mkdir(exist_ok=True)
    return ctx,directory

def truth(s):return s.astype(str).str.lower().isin(['true','1'])
def numeric(s):return pd.to_numeric(s,errors='raise')
def optional_ratio(n,d):return n/d if d else np.nan
def observed_bit(value):
    if value is None or str(value).strip()=='':return None
    try:v=float(value)
    except (ValueError,TypeError):return None
    return int(v) if np.isfinite(v) and v in [0.,1.] else None
def clean_json(x):
    if isinstance(x,dict):return {str(k):clean_json(v) for k,v in x.items()}
    if isinstance(x,list):return [clean_json(v) for v in x]
    if isinstance(x,(np.integer,)):return int(x)
    if isinstance(x,(np.floating,float)):return float(x) if math.isfinite(x) else None
    if isinstance(x,np.bool_):return bool(x)
    return x

def refresh_actual_progress(directory):
    """Administrative progress derives from real files; never promotes quality."""
    path=directory/'PART1_RESEARCH_USE_DECISION.json'
    if not path.exists():return
    decision=load(path);sample=directory/'sample/sample_manifest.json'
    receipts=list((directory/'returns').glob('*/ingest_receipt.json')) if (directory/'returns').exists() else []
    primary_n=sum(int(load(p)['accepted_rows']) for p in receipts if load(p)['coder_role']=='PRIMARY')
    evaluation=load(directory/'evaluation_status.json') if (directory/'evaluation_status.json').exists() else {}
    decision['derivation'].update(protocol_approval_present=sample.exists(),actual_new_audit_return_events=len(receipts),actual_primary_returned_rows=primary_n,
      design_corrected_evidence_present=evaluation.get('status')=='COMPUTED_AUDIT_EFFECTS_QUALITY_SCOPE_REVIEW_REQUIRED')
    decision['status']=evaluation.get('status') or ('WAITING_FOR_COMPLETE_RETURN' if primary_n else 'WAITING_FOR_AUDIT_RETURN') if sample.exists() else 'WAITING_FOR_DESIGN_APPROVAL'
    decision['quality_status_reason']='No actual use-specific research-quality acceptance of error/uncertainty and source/unit evidence; no flag is promoted by execution or protocol approval'
    atomic_json(path,decision)

def paths_for(ctx):
    current=load(ctx.root/'C2_CURRENT.json');stats=load(ctx.root/'POLICY_STATISTICS_CURRENT.json')
    snapshot=longpath(WS/current['snapshot_directory']);statdir=longpath(WS/stats['workspace_relative_path'])
    require(sha(statdir/'manifest.json')==stats['manifest_sha256'],'Statistics pointer mismatch')
    manifest=load(statdir/'manifest.json')
    require(all(sha(statdir/n)==h for n,h in manifest['files'].items()),'Frozen statistics altered')
    return dict(current=ctx.root/'C2_CURRENT.json',statistics_pointer=ctx.root/'POLICY_STATISTICS_CURRENT.json',
      matrix=snapshot/'C2_conditional_evidence.csv',unit_audit=statdir/'coding_unit_consistency.csv',
      policy_input=statdir/'policy_statistical_input.csv',g0=statdir/'G0_policy_consistency.csv',
      stats_manifest=statdir/'manifest.json',original_proposal=statdir/'minimal_independent_check_proposal.csv',
      corpus=ctx.artifact('prepare')/'corpus.csv',codebook=ctx.artifact('prepare')/'codebook.md',
      predictions=ctx.artifact('predict')/'corpus_predictions.csv',model=ctx.artifact('train')/'diagnostic_model.joblib',
      training_signature=ctx.artifact('build-registry')/'training_signature.json',
      field_registry=ctx.artifact('build-registry')/'human_field_evidence.csv',
      decisions=ctx.artifact('build-registry')/'decision_registry.csv',issues=ctx.artifact('prepare')/'issue_scope_audit.csv',code=Path(__file__))

def build_frame(ctx,paths):
    """Keep all 68 policies; no holdout truth or old answers enter the risk rank."""
    from group_readiness import effective_field_evidence
    matrix=read(paths['matrix']);cat=read(paths['corpus']);pr=read(paths['predictions']);ua=read(paths['unit_audit'])
    ev=effective_field_evidence(ctx)
    require(not ev.duplicated(['unit_id','field']).any(),'Duplicate effective fields')
    valid=ev[ev.value.isin(['0','1'])&ev.evidence_id.ne('')]
    fixed_fields=valid.groupby('unit_id').field.agg(set)
    reuse=set(fixed_fields[fixed_fields.map(lambda s:set(LABELS)<=s)].index)
    # A stored field must agree with the frozen adopted matrix; conflicts are not guessed away.
    mi=matrix.set_index('unit_id')
    for r in valid.itertuples():require(mi.loc[r.unit_id,'C2_'+r.field]==r.value,'Live/frozen evidence conflict: '+r.unit_id+' '+r.field)
    cols=['unit_id','diagnostic_raw_eligibility','diagnostic_raw_G3','score_eligibility','score_G3','score_T2']
    frame=cat[['unit_id','policy_id','policy_family_id','policy_version_id','stage','source_hash','source_clean_sha256','source_location','source_clean_path','clean_start','clean_end','exact_evidence_text']].merge(matrix,on=['unit_id','policy_id','stage','source_hash'],validate='one_to_one')
    frame=frame.merge(pr[cols],on='unit_id',validate='one_to_one').merge(ua[['unit_id','source_sentence_reading_start','source_sentence_reading_end','reading_text','reading_repair_applied','possible_multiple_source_items','exact_text_repetitions_distinct_locations']],on='unit_id',validate='one_to_one')
    frame['reused_complete_evidence']=frame.unit_id.isin(reuse)
    frame['new_probability_domain']=~frame.reused_complete_evidence
    frame['machine_gate']=numeric(frame.diagnostic_raw_eligibility).astype(int)
    require(frame.machine_gate.isin([0,1]).all(),'Missing machine gate')
    score=numeric(frame.score_G3);cuts=score.quantile([1/3,2/3]).to_numpy(float)
    frame['G3_score_band']=np.select([score<=cuts[0],score<=cuts[1]],['LOW','MID'],default='HIGH')
    frame['G3_diagnostic_positive']=numeric(frame.diagnostic_raw_G3).astype(int)
    frame['T2_unknown_in_frozen_matrix']=frame.C2_T2.eq('')
    frame['T2_unknown_current_eligible']=frame.T2_unknown_in_frozen_matrix&frame.C2_eligibility.eq('1')
    oldlen=numeric(frame.clean_end)-numeric(frame.clean_start)
    newlen=numeric(frame.source_sentence_reading_end)-numeric(frame.source_sentence_reading_start)
    frame['source_scope_risk']=~truth(frame.source_scope_verified)
    # The inherited source_scope flag conflates versions, extraction and semantics.
    # Resolve its actual current causes; do not re-open approved policy sources.
    causes={k:set() for k in ['SOURCE_VERSION','EXTRACTION_SCOPE','SEMANTIC_RULE']}
    for r in read(paths['issues']).to_dict('records'):
        if str(r['blocks_coding']).lower()!='true':continue
        typ='SEMANTIC_RULE' if r['issue_type']=='CLAUSE_SEMANTIC_RULE' else 'EXTRACTION_SCOPE' if r['issue_type']=='EXTRACTION_FRAGMENT' else 'SOURCE_VERSION'
        causes[typ].update(json.loads(r['affected_ids']))
    for r in read(paths['decisions']).to_dict('records'):
        if r['type'] not in causes:continue
        ids=set(json.loads(r['unit_ids']))
        if r['value']=='CONFIRM':causes[r['type']].difference_update(ids)
        else:causes[r['type']].update(ids)
    require(set(frame.loc[frame.source_scope_risk,'unit_id'])==set.union(*causes.values()),'Scope-cause/current-mask conflict')
    for typ,ids in causes.items():frame['unresolved_'+typ]=frame.unit_id.isin(ids)
    frame['structure_risk']=truth(frame.possible_multiple_source_items)|(newlen>3*oldlen)|(numeric(frame.exact_text_repetitions_distinct_locations)>1)
    frame['reading_id']=['READ_'+digest([r.policy_id,r.source_clean_sha256,int(r.source_sentence_reading_start),int(r.source_sentence_reading_end)])[:22] for r in frame.itertuples()]
    frame['domain']='REUSED_EXISTING_EVIDENCE_FIXED_COMPONENT'
    frame.loc[frame.new_probability_domain,'domain']='NEW_INDEPENDENT_AUDIT_DOMAIN'
    frame['risk_tier']='FIXED';frame['stratum_id']='FIXED_REUSE'
    # Controlled coarsening: balanced risk tiers avoid a 767-cell design requiring
    # ~1,500 reviews before any allocation flexibility. Rank considers every risk axis.
    sorting=['source_scope_risk','structure_risk','G3_score_band','G3_diagnostic_positive','T2_unknown_current_eligible','score_G3','unit_id']
    rankframe=frame.copy();rankframe['G3_score_band']=rankframe.G3_score_band.map({'LOW':0,'MID':1,'HIGH':2});rankframe['score_G3']=numeric(rankframe.score_G3)
    for (pid,gate),z in rankframe[rankframe.new_probability_domain].groupby(['policy_id','machine_gate'],sort=True):
        z=z.sort_values(sorting,kind='mergesort');half=(len(z)+1)//2
        for tier,inds in [('LOWER_RISK_RANK',z.index[:half]),('UPPER_RISK_RANK',z.index[half:])]:
            if not len(inds):continue
            frame.loc[inds,'risk_tier']=tier
            frame.loc[inds,'stratum_id']='H_'+digest([pid,int(gate),tier])[:18]
    # Labels are backend only. Exported blind UI never contains these auxiliary fields.
    frame['existing_fields_to_reuse']=frame.unit_id.map(fixed_fields.map(lambda s:';'.join(k for k in LABELS if k in s))).fillna('')
    # Only ID metadata is read: never retrieve reference answers for the new blind UI.
    prep=ctx.artifact('prepare')
    ref=set(pd.read_csv(prep/'reference_ids.csv',usecols=['unit_id'],encoding='utf-8-sig').unit_id)
    old200=set(pd.read_csv(longpath(ctx.input('sample')),usecols=['unit_id'],encoding='utf-8-sig').unit_id)
    held=set(cat.loc[cat.split.eq('HELD_OUT_POLICY')&cat.unit_id.isin(old200),'unit_id'])
    frame['protected_reference_identity']=frame.unit_id.map(lambda u:'ORIGINAL_600' if u in ref else 'ORIGINAL_49' if u in held else '')
    require(not (frame.new_probability_domain&frame.protected_reference_identity.ne('')).any(),'Protected reference has missing effective fields; isolate original evidence recovery, never re-request it')
    return frame,ev,dict(G3_score_tertiles=cuts.tolist(),score_use='SAMPLING_RISK_RANK_ONLY_NOT_THRESHOLD_SELECTION',
       risk_order=['source_scope_risk','structure_risk','G3_score_tertile','G3_diagnostic_positive','T2_unknown_current_eligible','G3_score','unit_id_tie'],
       scope_cause_counts={k:dict(units=len(v),policies=int(cat.loc[cat.unit_id.isin(v),'policy_id'].nunique())) for k,v in causes.items()},
       probability_domain='all non-reused units including both machine gates; existing judgments are a fixed, explicitly conditional component, not new random validation')

def allocate(strata,budget):
    n=np.minimum(strata.N.to_numpy(int),2);N=strata.N.to_numpy(int)
    require(budget>=int(n.sum()) and budget<=int(N.sum()),'Budget below estimable stratified minimum or above population')
    weights=strata.allocation_weight.to_numpy(float)
    for _ in range(budget-int(n.sum())):
        gains=np.where(n<N,weights**2/(n*(n+1)), -1.)
        n[int(np.argmax(gains))]+=1
    return n

def no_hit_prob(N,n,m):
    if m==0 or n==0:return 1.
    if N-m<n:return 0.
    # Exact hypergeometric zero-hit probability evaluated in log space.
    return float(math.exp(gammaln(N-m+1)-gammaln(n+1)-gammaln(N-m-n+1)-gammaln(N+1)+gammaln(n+1)+gammaln(N-n+1)))

def planned_precision(frame,strata,nvec):
    sh=strata.copy();sh['n']=nvec
    ids=sh.set_index('stratum_id');un=frame[frame.new_probability_domain]
    unique=0.
    for _,z in un.groupby('reading_id'):
        pnone=1.
        for h,m in z.stratum_id.value_counts().items():
            r=ids.loc[h];pnone*=no_hit_prob(int(r.N),int(r.n),int(m))
        unique+=1-pnone
    policy_N=frame.groupby('policy_id').size();by_policy={}
    for pid,z in sh.groupby('policy_id'):
        # Worst-case variance for binary prevalence over fixed extracted units.
        # It is NOT a prospective bound for the nonlinear G/T share ratios.
        val=0.
        for r in z.itertuples():
            finite_s2=r.N/(r.N-1)*.25 if r.N>1 else 0.
            val+=(r.N/policy_N[pid])**2*(1-r.n/r.N)*finite_s2/r.n
        by_policy[pid]=val
    stages=[]
    for stage,z in frame[['stage','policy_id']].drop_duplicates().groupby('stage'):
        v=sum(by_policy.get(p,0) for p in z.policy_id)/len(z)**2
        stages.append(dict(stage=stage,policy_n=len(z),planning_binary_prevalence_95_halfwidth=1.96*math.sqrt(v),
           identity='NORMAL_APPROX_WORST_CASE_PLANNING_ONLY;NOT_G_T_SHARE_PRECISION;EXCLUDES_ERRORS_IN_FIXED_EVIDENCE_AND_SOURCE_COVERAGE'))
    return unique,stages

def source_coverage(frame,corpus):
    cards=[];gaps=[]
    for path,z in corpus.groupby('source_clean_path',sort=False):
        txt=longpath(path).read_text('utf-8-sig');pid=z.iloc[0].policy_id;last=0;meaningful=0
        for a,b in sorted(zip(numeric(z.clean_start).astype(int),numeric(z.clean_end).astype(int)))+[(len(txt),len(txt))]:
            if a>last:
                v=txt[last:a]
                if re.search(r'[\u4e00-\u9fffA-Za-z]',v):
                    meaningful+=1;gaps.append(dict(policy_id=pid,start=last,end=a,text=v,source_clean_sha256=sha(path),
                       status='UNCOVERED_SPAN_NOT_AUTOMATIC_GOVERNANCE_ACTION',
                       technical_pattern='POSSIBLE_SITE_METADATA' if re.search('免责声明|相关阅读|版权所有|您可能|点击|手机版|责任编辑|浏览次数',v) else 'NOT_CLASSIFIED_BY_TECHNICAL_CHECK',
                       sampling_identity='SOURCE_COVERAGE_EXCEPTION_NOT_MAIN_PROBABILITY_UNIT'))
            last=max(last,b)
        q=frame[frame.policy_id.eq(pid)]
        cards.append(dict(policy_id=pid,stage=q.iloc[0].stage,source_clean_sha256=sha(path),source_char_n=len(txt),
          original_unit_n=len(q),source_scope_unresolved_units=int(q.source_scope_risk.sum()),
          source_version_unresolved_units=int(q.unresolved_SOURCE_VERSION.sum()),extraction_scope_unresolved_units=int(q.unresolved_EXTRACTION_SCOPE.sum()),semantic_rule_unresolved_units=int(q.unresolved_SEMANTIC_RULE.sum()),
          uncovered_letter_span_n=meaningful,reading_expanded_units=int(truth(q.reading_repair_applied).sum()),
          repeated_text_units=int((numeric(q.exact_text_repetitions_distinct_locations)>1).sum()),
          existing_counting_ids_not_universal_gate=True,
          required_action='REVIEW_ONLY_EXTRACTION_OR_SEMANTIC_EXCEPTIONS;DO_NOT_REOPEN_APPROVED_VERSIONS' if q.source_scope_risk.any() else 'REUSE_CURRENT_SOURCE_SCOPE;CHECK_UNCOVERED_SPANS_IF_THEY_CONTAIN_TARGET_CLAUSES',
          coverage_quality='NOT_PROVEN_BY_HASH;GAPS_MAY_BE_METADATA_OR_MISSING_CONTENT'))
    return pd.DataFrame(cards),pd.DataFrame(gaps)

def write_current_reports(ctx,directory,paths,frame,cards,proposal):
    pol=read(paths['policy_input']);g0=read(paths['g0']);gr=[];tr=[]
    for stage in STAGES:
        for group,labs,rows in [('G',G,gr),('T',T,tr)]:
            for lab in labs:
                q=pol[(pol.stage==stage)&(pol.source_scope=='INCLUDE_ALL')&(pol.scenario=='B_UNKNOWN_PRIMARY')&(pol.label==lab)]
                vals=pd.to_numeric(q.share,errors='coerce')
                rows.append(dict(stage=stage,label=lab,policy_n=len(q),conditional_mean_share=vals.mean() if vals.notna().all() else np.nan,
                   independent_new_review_n=0,actual_TP=np.nan,actual_FP=np.nan,actual_FN=np.nan,design_corrected_share=np.nan,
                   G3_or_T2_priority=lab in ['G3','T2'],quality_supported=False,
                   status='WAITING_FOR_APPROVED_DESIGN_AND_ACTUAL_REVIEW;CONDITIONAL_RESULT_ONLY'))
    csvout(directory/'G_HISTORY_QUALITY_REPORT.csv',gr);csvout(directory/'T_CONFIGURATION_QUALITY_REPORT.csv',tr)
    csvout(directory/'CODING_UNIT_VALIDITY_REPORT.csv',cards)
    csvout(directory/'G0_POLICY_STATUS.csv',g0)
    shares=pol[pol.scenario.eq('B_UNKNOWN_PRIMARY')].copy();shares['publication_identity']='CONDITIONAL_NOT_FORMAL';shares['quality_supported']=False
    csvout(directory/'G_T_POLICY_SHARES_FINAL_OR_CONDITIONAL.csv',shares)
    # Readiness is derived from absence of actual approved audit evidence, never set by run success.
    actual_returns=list((directory/'returns').glob('*/ingest_receipt.json')) if (directory/'returns').exists() else []
    states=dict(COMPUTATION_REPRODUCIBLE=all(sha(p)==proposal['input_hashes'][k] for k,p in paths.items()),
      G_HISTORY_QUALITY_SUPPORTED=False,T_CONFIGURATION_QUALITY_SUPPORTED=False,C2_FORMAL_RELEASE_READY=False,PART1_COMPLETED=False)
    jsonout(directory/'PART1_RESEARCH_USE_DECISION.json',dict(version=VERSION,states=states,
      derivation=dict(actual_new_audit_return_events=len(actual_returns),protocol_approval_present=False,
        design_corrected_evidence_present=False,source_membership_and_unit_semantics_not_validated=True,
        exact_formal_candidate_approval_present=False),
      status='WAITING_FOR_DESIGN_APPROVAL',no_new_agreement_file='No real second-coder returns; no agreement statistics generated',
      frozen_C2_pointer_sha256=sha(paths['current']),frozen_statistics_manifest_sha256=sha(paths['stats_manifest']),part2_started=False))
    jsonout(directory/'PART2_GOVERNANCE_INPUT_CONTRACT.json',dict(version=VERSION,contract_kind='SCHEMA_AND_BLOCKED_HANDOFF_ONLY',
      empirical_policy_input_authorized=states['G_HISTORY_QUALITY_SUPPORTED'],annual_series_generated=False,SD_started=False,
      required_policy_keys=['policy_id','policy_version_id','source_hash','coding_version','unit_definition_version','G1_share','G2_share','G3_share','G_assignment_denominator','quality_scope','evidence_hash'],
      normalization='policy G assignment share; denominator zero=NA; all admitted policies retain status',
      forbidden_substitution='unknown eligibility/G must not become zero; current conditional shares not formal empirical truth',
      next_phase_gate='supported G history with traceable quality scope and author-approved exact evidence/parameter-free policy data version; separate instruction before annual stock construction',
      T2_unknown_status='T2 NOT REQUIRED AS SUBSTITUTE FOR G; SIX_TOOL_CONFIGURATION_REMAINS_UNIDENTIFIED',
      current_C2_sha256=sha(paths['matrix']),model_sha256=sha(paths['model'])))

def prepare(ctx,directory):
    started=now();clock=time.perf_counter()
    paths=paths_for(ctx);before={k:sha(p) for k,p in paths.items()}
    if (directory/'proposal_manifest.json').exists():
        old=load(directory/'proposal_manifest.json')
        if old['input_hashes']==before and all(sha(directory/n)==h for n,h in old['files'].items()):
            return dict(state='WAITING_FOR_DESIGN_APPROVAL',reused=True,directory=str(directory),protocol_sha256=sha(directory/'joint_audit_protocol.json'))
        require(not (directory/'sample').exists(),'Approved/drawn design cannot be overwritten')
        history=directory/'draft_history';history.mkdir(exist_ok=True)
        jsonout(history/(digest(old)[:16]+'.json'),old)
    frame,ev,definition=build_frame(ctx,paths)
    csvout(directory/'sampling_frame_BACKEND.csv',frame);csvout(directory/'existing_field_reuse.csv',ev)
    csvout(directory/'existing_evidence_profile.csv',ev.groupby(['status','value_origin','role'],dropna=False).size().reset_index(name='field_n'))
    csvout(directory/'scope_root_cause_reconciliation.csv',[dict(issue_type=k,**v) for k,v in definition['scope_cause_counts'].items()])
    un=frame[frame.new_probability_domain]
    rows=[];policyN=frame.groupby('policy_id').size()
    for h,z in un.groupby('stratum_id',sort=True):
        r=z.iloc[0];weight=len(z)/policyN[r.policy_id]*(1.3 if r.risk_tier=='UPPER_RISK_RANK' else 1)*(1.2 if r.machine_gate==0 else 1)
        rows.append(dict(stratum_id=h,policy_id=r.policy_id,policy_family_id=r.policy_family_id,stage=r.stage,machine_gate=int(r.machine_gate),risk_tier=r.risk_tier,N=len(z),allocation_weight=weight))
    strata=pd.DataFrame(rows);floor=int(np.minimum(strata.N.astype(int),2).sum());options=[];precision=[];support=[];probs=frame[['unit_id','policy_id','policy_family_id','stage','domain','stratum_id']].copy()
    for budget in [600,900,1400]:
        if budget<floor:continue
        option=f'JOINT_{budget}';nv=allocate(strata,budget);ss=strata.copy();ss['sample_n']=nv;ss['planned_pi']=nv/ss.N.astype(float);ss['planned_weight']=1/ss.planned_pi
        csvout(directory/f'allocation_{option}.csv',ss)
        mapping=ss.set_index('stratum_id').planned_pi;probs['planned_pi_'+option]=frame.stratum_id.map(mapping).fillna(1.)
        probs['planned_weight_'+option]=1/probs['planned_pi_'+option]
        expected,ps=planned_precision(frame,strata,nv)
        n2=math.ceil(.2*budget)
        options.append(dict(option=option,new_target_units=budget,existing_units_reused=int(frame.reused_complete_evidence.sum()),
          expected_primary_distinct_reading_blocks=expected,second_coder_target_n=n2,
          expected_total_reading_operations_upper=expected+n2,actual_readings_completed=0,
          design_minimum_for_estimable_strata=floor,allocation_sha256=sha(directory/f'allocation_{option}.csv'),
          composition_ratio_precision='NOT_PROMISED;DENOMINATORS_AND_ERRORS_NOT_YET_OBSERVED',
          recommended=(budget==900)))
        precision.extend([dict(option=option,**r) for r in ps])
        w=un[['policy_id','policy_family_id','stage','stratum_id','machine_gate','G3_score_band','G3_diagnostic_positive','T2_unknown_current_eligible','source_scope_risk','structure_risk']].copy();w['pi']=w.stratum_id.map(mapping)
        for dim in ['stage','policy_family_id','machine_gate','G3_score_band','G3_diagnostic_positive','T2_unknown_current_eligible','source_scope_risk','structure_risk']:
            for key,z in w.groupby(dim):support.append(dict(option=option,dimension=dim,level=str(key),population_n=len(z),expected_audited_units=float(z.pi.sum()),identity='EXPECTED_DESIGN_SUPPORT_NOT_TRUE_CLASS_SUPPORT'))
    require(options,'No feasible proposed budget; inspect stratum count')
    csvout(directory/'AUDIT_DESIGN_AND_INCLUSION_PROBABILITIES.csv',probs)
    csvout(directory/'sample_size_options.csv',options);csvout(directory/'planning_precision.csv',precision);csvout(directory/'expected_support_by_design_axis.csv',support)
    cards,gaps=source_coverage(frame,read(paths['corpus']));csvout(directory/'source_unmapped_spans.csv',gaps)
    fine=un.groupby(['policy_id','machine_gate','G3_score_band','source_scope_risk','structure_risk','T2_unknown_current_eligible']).size()
    definition.update(dict(fine_cross_strata_n=len(fine),fine_cross_minimum_two_or_census=int(fine.clip(upper=2).sum()),actual_balanced_risk_strata_n=len(strata),balanced_minimum_two_or_census=floor))
    protocol=dict(version=VERSION,identity='PROPOSED_JOINT_INDEPENDENT_AUDIT_NOT_APPROVED',seed=2026102801,
      target='equal-policy G/T composition of the fixed 68-policy corpus, not all possible policy texts',
      primary_frame='all 32858 original IDs; new SRSWOR within policy/gate/balanced-risk strata; valid existing fields fixed and reused, not new independent evidence',
      sampling_definition=definition,options=options,frame_sha256=sha(directory/'sampling_frame_BACKEND.csv'),
      probabilities_sha256=sha(directory/'AUDIT_DESIGN_AND_INCLUSION_PROBABILITIES.csv'),code_sha256=sha(Path(__file__)),
      reusable_fields_sha256=sha(directory/'existing_field_reuse.csv'),
      frame_counts=dict(units=len(frame),policies=frame.policy_id.nunique(),families=frame.policy_family_id.nunique(),fixed_existing_units=int(frame.reused_complete_evidence.sum()),new_probability_units=int(frame.new_probability_domain.sum()),protected_reference_units=int(frame.protected_reference_identity.ne('').sum())),
      population_source_limit='Source gaps and wrong-body inclusion are separately audited; primary unit sampling cannot identify completely omitted clauses. No unconditional full-text truth claim until relevant scope/mapping resolved.',
      precision='planning values concern binary extracted-unit prevalence only; not guaranteed G/T composition accuracy; no universal ±.05 quality threshold',
      second_coder='nested SRS of ceil(20% of primary new units); secondary inclusion=primary_pi*n_second/n_primary; separate blind returns, no fabricated agreement',
      reuse_assumption='Existing human/group/derived fields are held valid in their accepted scope; their unknown semantic errors are not estimated by this new design. No original 600/49 re-fill or training use.',
      estimation='fixed auxiliary totals + stratified HT residual totals; T2 unknown uses zero AUXILIARY only, never observed zero; ratios and paired configuration via Taylor linearization and joint residual covariance',
      complete_return_required_for_design_estimation=True,
      invalid_unit_handling='unresolved truncation/multi-clause prevents formal composition estimation; confirmed duplicates/source-outside require actual bound decision, not parent merge',
      formal_claim_quality='not determined by sample size or zero observed errors; error/variance and source/unit support must match intended claims; acceptance must bind actual evidence and explicit scope',
      no_training=True,no_threshold_change=True,no_pool_resampling=True,no_SD=True,
      input_hashes=before)
    jsonout(directory/'joint_audit_protocol.json',protocol)
    approval=dict(statement='APPROVE_JOINT_HISTORY_AUDIT_DESIGN',identity='REAL',reviewer='',signed_at='',option='JOINT_900',
      protocol_sha256=sha(directory/'joint_audit_protocol.json'),frame_sha256=protocol['frame_sha256'],
      allocation_sha256=sha(directory/'allocation_JOINT_900.csv'),scope='new audit only; no model training or formal C2 adoption')
    jsonout(directory/'APPROVAL_TEMPLATE_UNSIGNED.json',approval)
    write_current_reports(ctx,directory,paths,frame,cards,protocol)
    write_proposal_doc(directory,protocol,cards,gaps)
    require(all(sha(p)==before[k] for k,p in paths.items()),'Frozen dependency changed')
    jsonout(directory/'run_log.json',dict(started_utc=started,ended_utc=now(),elapsed_seconds=time.perf_counter()-clock,
      actual_command=f'{sys.executable} {Path(__file__)} prepare',identity='REAL_FRAME_PREPARATION_NOT_REAL_AUDIT',
      original_unit_n=len(frame),policy_n=frame.policy_id.nunique(),strata_n=len(strata),
      actual_probability_draws=0,actual_new_human_judgments=0,actual_model_fits=0,actual_threshold_searches=0,
      old_bootstrap_reruns=0,annual_governance_runs=0,SD_runs=0,frozen_inputs_unchanged=True))
    files={p.name:sha(p) for p in directory.iterdir() if p.is_file() and p.name not in ['proposal_manifest.json','QA.json']}
    jsonout(directory/'proposal_manifest.json',dict(version=VERSION,input_hashes=before,files=files,actual_probability_samples_drawn=0,actual_human_judgments_created=0))
    return dict(state='WAITING_FOR_DESIGN_APPROVAL',directory=str(directory),strata=len(strata),minimum_two_or_census=floor,options=options,protocol_sha256=sha(directory/'joint_audit_protocol.json'))

def write_proposal_doc(directory,protocol,cards,gaps):
    lines=['# 联合独立审核：作者精简审阅方案','',
      '本轮已完成抽样框、可行样本量比较、评价实现和当前条件性结果交付；尚未抽样、没有新审核结果。旧600/49评价身份不变，不重填既有材料，不进入训练。',
      '', '## 一次批准覆盖的动作',
      '选择下列一档，批准当前精确协议/框/分层分配哈希后，才生成真实随机名单和盲审入口。批准不等于质量通过或正式C2采用。',
      '', '|方案|新目标单元|预计主审独立阅读块|第二编码者单元|预计两人总阅读操作上限*|','|---|---:|---:|---:|---:|']
    for r in protocol['options']:lines.append(f'|{r["option"]}|{r["new_target_units"]}|{r["expected_primary_distinct_reading_blocks"]:.1f}|{r["second_coder_target_n"]}|{r["expected_total_reading_operations_upper"]:.1f}|')
    lines += ['', '*主审为精确抽样设计下的期望阅读块数；实际抽样后才知道去重阅读数。第二编码者上限按每单元另读一次计算，不是时间/效率保证。一次完整句段可含多个目标片段，每片段保留ID，不能自动合并计数。',
      '', '推荐JOINT_900作为成本与分层信息量的中档起点，不保证稀有G3/T2或每个政策份额足够准确，也不承诺它能使第一部分完成。可选600降低初次负担、或1400增强支持。未规定统一误差硬门槛。',
      '', '## 覆盖与复用',
      f'{protocol["frame_counts"]["policies"]}政策/{protocol["frame_counts"]["families"]}修订家族全部在框中；原{protocol["frame_counts"]["units"]:,}单元完整保留。{protocol["frame_counts"]["fixed_existing_units"]:,}个既有完整证据单元作为固定组件复用，{protocol["frame_counts"]["new_probability_units"]:,}个其他单元可进入新概率域；既有定向裁定没有被当作新随机验证。固定组件的潜在语义错误不在新设计方差中。',
      'existing_evidence_profile.csv分别列出来源身份、零值历史来源未完全恢复等情况；固定复用不是为这些字段新增独立真实性证明。原600与49的ID元数据仅用于防止重复索取，未提取其答案给新审核者。新600档是其他未审域的新协议，绝非重抽或替换原600。',
      '按政策和机器合格性正/负分层，再依据来源、句段结构、G3分数/预测和T2未知形成高/低平衡风险层；保存所有细分轴，输出预期支持。采用有限风险分层，避免全交叉造成约千余条最低审核负担；具体细分最小数见协议。抽样分位数只用于安排审核，不改分类阈值。',
      '每层SRSWOR；每个新概率域单元计划pi=n_h/N_h且大于0，设计权重为其倒数。已有证据pi=1表示固定已知组件，不是声称重新随机审核了一遍。',
      '', '## 能支持什么、不能保证什么',
      'A：审核G1–G3错误、负门控漏纳及阶段构成影响；B：审核六类工具（重点T2）及同单元G–T共现；C：记录截断、重复、跨条款及来源范围问题。主审默认不显示机器答案或旧人工答案。第二编码者独立盲审20%新样本，真实返回前不生成一致性表。',
      'planning_precision.csv只给冻结源单元二值出现率的保守正态近似规划半宽，不是G/T归一化组成的保证。真实类别支持、政策小分母和稀有类精度要在回收后才能评价。',
      f'本轮另发现{len(gaps)}个含字母/汉字的未覆盖源区间；其中可能是网站元数据/推荐信息，也可能有遗漏正文。它们不是新治理行动，未填标签。原框概率抽样不能自动覆盖完全漏提取的条款。',
      f'已按真实issue_scope与决定账本拆开旧source_scope复合标志：来源版本未决{protocol["sampling_definition"]["scope_cause_counts"]["SOURCE_VERSION"]["units"]}单元；提取/断句范围未决{protocol["sampling_definition"]["scope_cause_counts"]["EXTRACTION_SCOPE"]["units"]}单元；语义规则未决{protocol["sampling_definition"]["scope_cause_counts"]["SEMANTIC_RULE"]["units"]}单元。旧26项受影响政策不能称26份来源都未核实；不重发已批准版本或原52项卡片。只核查尚会改变计数/分类的具体例外。',
      'source_unmapped_spans.csv保留全部候选区间，CODING_UNIT_VALIDITY_REPORT.csv逐政策列明问题。没有要求每个原单元批准独立行动ID。',
      '', '## 回收及评价',
      '实际抽样后导出合并盲审HTML/CSV：完整源句段只显示一次，每个目标保留精确原文/位置；判断合格性、G/T多标签、句/条款有效性和来源。明确不合格可依法派生九个零；空白/无法判断不等于负类。',
      '新样本先按锁定协议评价，不自动训练。分别输出未加权样本混淆与设计加权误差、按阶段/家族支持、HT残差纠偏总量与政策等权比例。T2零辅助项仅用于估计代数，不会写成正式T2=0。',
      '现有代码能对完整有效回收作设计型估计；未回齐不把部分便利样本作总体结果。未解决计数/来源/跨条款时保留未识别，不能用一个比率把这些缺口消掉。编码误差方差与旧政策Bootstrap区间分列，不合并。',
      '只有真实两编码者返回才生成INDEPENDENT_CODING_AGREEMENT.csv；不会把多人分批签名当同条独立复编码。旧三池失败不变。',
      '', '## 本轮交付与状态',
      'G_HISTORY_QUALITY_REPORT/T_CONFIGURATION_QUALITY_REPORT目前给既有条件性值与新审核未运行的NA；不是空壳成功。G_T_POLICY_SHARES_FINAL_OR_CONDITIONAL保留实际68政策的G及T2未知状态。PART2_GOVERNANCE_INPUT_CONTRACT是被阻止的接口合同，不是年度序列。',
      'COMPUTATION_REPRODUCIBLE由冻结哈希检查计算；其余研究质量/正式C2/第一部分完成状态仍false。此时不启动第二部分。',
      '', '## 可直接接续的命令',
      '```powershell',"$env:PYTHONIOENCODING='utf-8'",
      '.\\OCMA_empirical_revision_workspace_B1_20261026\\.venv\\Scripts\\python.exe .\\joint_history_audit_20261028.py prepare',
      '# 仅在本方案真实批准后；先把批准的真实信息与精确哈希保存为JSON，不能把空模板当批准：',
      '.\\OCMA_empirical_revision_workspace_B1_20261026\\.venv\\Scripts\\python.exe .\\joint_history_audit_20261028.py draw --approval <实际批准.json>',
      '# 真实审核回收后：',
      '.\\OCMA_empirical_revision_workspace_B1_20261026\\.venv\\Scripts\\python.exe .\\joint_history_audit_20261028.py ingest --review <实际回传.csv或xlsx> --signature <真实批次签署.json>',
      '.\\OCMA_empirical_revision_workspace_B1_20261026\\.venv\\Scripts\\python.exe .\\joint_history_audit_20261028.py evaluate',
      '```', '', '协议SHA256：`'+sha(directory/'joint_audit_protocol.json')+'`。这份精简方案是唯一待作者选择入口，不重发旧52项或已完成审核。']
    (directory/'AUTHOR_AUDIT_DESIGN.md').write_text('\n'.join(lines),'utf-8')

def authorize_draw(protocol,approval,directory):
    signed(approval,'APPROVE_JOINT_HISTORY_AUDIT_DESIGN','REAL')
    require(approval['protocol_sha256']==sha(directory/'joint_audit_protocol.json'),'Protocol approval mismatch')
    require(approval['frame_sha256']==protocol['frame_sha256'],'Frame approval mismatch')
    opts={r['option']:r for r in protocol['options']};require(approval['option'] in opts,'Unknown option')
    path=directory/f'allocation_{approval["option"]}.csv'
    require(approval['allocation_sha256']==sha(path)==opts[approval['option']]['allocation_sha256'],'Allocation approval mismatch')
    return approval['option']

def draw(ctx,directory,approval_path):
    protocol=load(directory/'joint_audit_protocol.json');approval=load(approval_path);option=authorize_draw(protocol,approval,directory)
    frame=read(directory/'sampling_frame_BACKEND.csv');require(sha(directory/'sampling_frame_BACKEND.csv')==protocol['frame_sha256'],'Frame changed')
    target=directory/'sample';target.mkdir(exist_ok=True)
    if (target/'sample_manifest.json').exists():
        old=load(target/'sample_manifest.json');require(old['approval_sha256']==sha(approval_path),'Draw already bound to different approval')
        require(all(sha(target/n)==h for n,h in old['files'].items()),'Draw changed');return dict(state='WAITING_FOR_AUDIT_RETURN',reused=True)
    alloc=read(directory/f'allocation_{option}.csv');rng=np.random.default_rng(protocol['seed']);chosen=[]
    for r in alloc.sort_values('stratum_id').itertuples():
        z=frame[frame.stratum_id.eq(r.stratum_id)].sort_values('unit_id');n=int(r.sample_n)
        chosen.extend(z.iloc[rng.choice(len(z),n,replace=False)].unit_id.tolist())
    sample=frame[frame.unit_id.isin(chosen)].copy();sample['inclusion_probability']=sample.stratum_id.map(alloc.set_index('stratum_id').planned_pi)
    sample['design_weight']=1/numeric(sample.inclusion_probability)
    n2=math.ceil(.2*len(sample));second=set(rng.choice(sorted(chosen),n2,replace=False));sample['second_coder_selected']=sample.unit_id.isin(second)
    sample['second_phase_inclusion_probability']=numeric(sample.inclusion_probability)*n2/len(sample)
    sample['statistical_identity']='JOINT_STRATIFIED_SRSWOR'
    csvout(target/'actual_sample_BACKEND.csv',sample)
    # Full text and exact target remain; answers and scores are excluded from both blind versions.
    visible=['unit_id','policy_id','policy_version_id','stage','reading_id','exact_evidence_text','reading_text','source_location','clean_start','clean_end','source_hash','source_clean_sha256']
    template=sample[visible].copy()
    template['requested_fields']=sample.existing_fields_to_reuse.map(lambda s:';'.join(k for k in LABELS if k not in set(s.split(';')))).to_numpy()
    for k in ['human_'+k for k in LABELS]+['G_selected','T_selected','G_group_checked','T_group_checked','unit_validity','source_membership','canonical_unit_id','notes']:
        template[k]=''
    csvout(target/'JOINT_REVIEW_BLIND.csv',template)
    csvout(target/'SECOND_CODER_BLIND.csv',template[template.unit_id.isin(second)])
    csvout(target/'registered_PRIMARY_TEMPLATE.csv',template)
    csvout(target/'registered_SECONDARY_TEMPLATE.csv',template[template.unit_id.isin(second)])
    # HTML groups reading blocks; CSV remains the import surface, with no answers embedded.
    import html
    blocks=['<!doctype html><meta charset="utf-8"><style>body{font:16px Arial;max-width:1000px;margin:30px auto}article{padding:18px;border-bottom:1px solid #ccc}pre{white-space:pre-wrap}</style><h1>联合盲审：完整句/条款阅读入口</h1><p>在JOINT_REVIEW_BLIND.csv填写；本页仅供阅读，不含机器答案/旧判断。每个目标ID分别判断，不把相邻行动标签传播。</p>']
    for rid,z in template.groupby('reading_id',sort=False):
        blocks.append('<article><h2>'+html.escape(z.iloc[0].policy_id)+' / '+html.escape(rid)+'</h2><pre>'+html.escape(z.iloc[0].reading_text)+'</pre>')
        for r in z.itertuples():blocks.append('<p><b>'+html.escape(r.unit_id)+'</b> ['+r.clean_start+':'+r.clean_end+'] '+html.escape(r.exact_evidence_text)+'</p>')
        blocks.append('</article>')
    (target/'JOINT_READING_BLIND.html').write_text('\n'.join(blocks),'utf-8')
    jsonout(target/'approval_applied.json',dict(approval=approval,source_sha256=sha(approval_path),actual_imported_at=now(),meaning='audit draw permission only, not quality/adoption'))
    # Real batch fields intentionally blank; never fabricate reviewer identity/time.
    jsonout(target/'RETURN_SIGNATURE_TEMPLATE_UNSIGNED.json',dict(statement='CONFIRM_ACTUAL_JOINT_INDEPENDENT_AUDIT',identity='REAL',reviewer='',signed_at='',coder_role='PRIMARY',batch_id='',review_sha256='',protocol_sha256=sha(directory/'joint_audit_protocol.json')))
    frozen=['actual_sample_BACKEND.csv','registered_PRIMARY_TEMPLATE.csv','registered_SECONDARY_TEMPLATE.csv','approval_applied.json']
    files={n:sha(target/n) for n in frozen}
    jsonout(target/'sample_manifest.json',dict(approval_sha256=sha(approval_path),protocol_sha256=sha(directory/'joint_audit_protocol.json'),option=option,n=len(sample),actual_primary_reading_blocks=sample.reading_id.nunique(),second_coder_n=n2,files=files))
    refresh_actual_progress(directory)
    return dict(state='WAITING_FOR_AUDIT_RETURN',sample_n=len(sample),unique_reading_blocks=sample.reading_id.nunique(),second_coder_n=n2)

def normalize_truth(rows,existing=None,review_scope='FULL_10'):
    """Keep current-coder observations distinct from reuse and legal derivation."""
    require(review_scope in ['FULL_10','G_ONLY'],'Explicit supported review scope required')
    records=[];errors=[]
    for raw in rows.to_dict('records'):
        r=dict(raw);uid=r['unit_id'];reused=(existing or {}).get(uid,{})
        requested=set(str(raw.get('requested_fields',';'.join(LABELS))).split(';'))
        for k in LABELS:
            r['independent_'+k]=bool(str(raw.get('human_'+k,'')).strip() in ['0','1'] and k not in reused and k in requested)
            r['field_origin_'+k]='CURRENT_CODER_EXPLICIT' if r['independent_'+k] else 'UNOBSERVED'
        r['review_scope']=review_scope
        conflict=False
        for k,v in reused.items():
            supplied=str(r.get('human_'+k,'')).strip()
            if supplied and supplied!=str(v):conflict=True
            r['human_'+k]=str(v)
            r['independent_'+k]=False;r['field_origin_'+k]='REUSED_EXISTING_EVIDENCE'
        if conflict:errors.append(dict(unit_id=uid,reason='existing true field cannot be overwritten without explicit correction'));continue
        r['reused_fields']=';'.join(k for k in LABELS if k in reused)
        elig=str(r.get('human_eligibility','')).strip()
        source_zero=r.get('source_membership')=='OUTSIDE_TARGET' or r.get('unit_validity')=='SOURCE_NOT_TARGET'
        duplicate_zero=r.get('unit_validity')=='DUPLICATE_CONFIRMED' and bool(str(r.get('canonical_unit_id','')).strip())
        if elig not in ['0','1'] and not (source_zero or duplicate_zero):
            errors.append(dict(unit_id=uid,reason='eligibility blank/unknown'));continue
        vals={k:str(r.get('human_'+k,'')).strip() for k in LABELS}
        group_invalid=False
        for group,labs in [('G',G),('T',T)]:
            if review_scope=='G_ONLY' and group=='T':
                for k in T:
                    vals[k]='';r['independent_'+k]=False;r['field_origin_'+k]='OUT_OF_REVIEW_SCOPE'
                continue
            selected=[v for v in re.split(r'[;,，；\s]+',str(r.get(group+'_selected','')).strip()) if v]
            if set(selected)-set(labs):errors.append(dict(unit_id=uid,reason='unknown selected '+group+' category'));group_invalid=True;break
            if elig=='0' and selected:errors.append(dict(unit_id=uid,reason='ineligible with positive selected category'));group_invalid=True;break
            r['zero_origin_'+group]='EXPLICIT_HUMAN_FIELDS'
            if elig=='1' and str(r.get(group+'_group_checked','')).lower() in ['1','true','yes','确认']:
                for k in labs:
                    if k in reused:continue
                    v=str(int(k in selected))
                    if vals[k] and vals[k]!=v:errors.append(dict(unit_id=uid,reason='selected group contradicts explicit '+k));group_invalid=True;break
                    vals[k]=v
                    r['independent_'+k]=k in requested
                    r['field_origin_'+k]='CURRENT_CODER_GROUP_CHECK'
                r['zero_origin_'+group]='HUMAN_COMPLETE_GROUP_UNSELECTED'
        if group_invalid:continue
        applicable=G if review_scope=='G_ONLY' else G+T
        if elig=='0':
            if any(vals[k]=='1' for k in applicable):errors.append(dict(unit_id=uid,reason='ineligible with positive label'));continue
            for k in applicable:
                vals[k]='0'
                if not r['independent_'+k] and k not in reused:r['field_origin_'+k]='DERIVED_FROM_CURRENT_INELIGIBLE'
            zero_origin='DERIVED_FROM_ACTUAL_HUMAN_INELIGIBLE'
        else:
            if not (source_zero or duplicate_zero) and any(vals[k] not in ['0','1'] for k in applicable):errors.append(dict(unit_id=uid,reason='eligible '+review_scope+' fields incomplete'));continue
            zero_origin='EXPLICIT_HUMAN_FIELDS'
        known_zero=elig=='0' or source_zero or duplicate_zero
        if not known_zero and (r.get('unit_validity','') not in UNIT_CHOICES or r.get('source_membership','') not in ['IN_TARGET','OUTSIDE_TARGET','UNRESOLVED']):
            errors.append(dict(unit_id=uid,reason='unit/source judgment missing'));continue
        if r.get('unit_validity')=='DUPLICATE_CONFIRMED' and not r.get('canonical_unit_id',''):
            errors.append(dict(unit_id=uid,reason='duplicate requires exact canonical unit'));continue
        r.update({k:int(v) if v in ['0','1'] else None for k,v in vals.items()})
        r['zero_origin']=zero_origin;r['duplicate_rule_confirmed']=duplicate_zero
        r['G_contribution_basis']='ACTUAL_INELIGIBLE_ZERO' if elig=='0' else 'ACTUAL_OUTSIDE_TARGET_ZERO' if source_zero else 'ACTUAL_DUPLICATE_ZERO' if duplicate_zero else 'G_FIELDS_WITH_UNIT_SCOPE'
        records.append(r)
    return pd.DataFrame(records),pd.DataFrame(errors,columns=['unit_id','reason'])

def verify_review_scope(directory,review_scope,scope_revision_sha256=''):
    require(review_scope in ['FULL_10','G_ONLY'],'Unknown review scope')
    if review_scope=='G_ONLY':
        revision=load(directory/'G_ONLY_SCOPE_APPROVAL.json')
        if revision.get('event_type')=='EXPLICIT_USER_SCOPE_AUTHORIZATION':
            require(revision.get('identity')=='REAL' and revision.get('statement')=='APPROVE_EXACT_G_ONLY_SCOPE_REVISION' and
                revision.get('authorization_identity')=='DIRECT_USER_INSTRUCTION_IN_CURRENT_CHAT','Explicit user scope event required')
            require(sha(revision['source_instruction_path'])==revision['source_instruction_sha256'] and
                revision['approval_quote'] in longpath(revision['source_instruction_path']).read_text('utf-8-sig'),'Actual scope instruction binding changed')
        else:signed(revision,'APPROVE_EXACT_G_ONLY_SCOPE_REVISION','REAL')
        require(revision['scope_revision_sha256']==scope_revision_sha256==sha(directory/'G_ONLY_SCOPE_REVISION.json') and revision['sample_manifest_sha256']==sha(directory/'sample/sample_manifest.json'),'G_ONLY scope not actually approved/bound')

def ingest(ctx,directory,review,signature):
    require((directory/'sample/sample_manifest.json').exists(),'No approved actual sample')
    sig=load(signature);signed(sig,'CONFIRM_ACTUAL_JOINT_INDEPENDENT_AUDIT','REAL')
    review_scope=sig.get('review_scope','FULL_10')
    verify_review_scope(directory,review_scope,sig.get('scope_revision_sha256',''))
    require(sig['review_sha256']==sha(review) and sig['protocol_sha256']==sha(directory/'joint_audit_protocol.json'),'Return binding mismatch')
    role=sig.get('coder_role');require(role in ['PRIMARY','SECONDARY'],'Actual coder role required')
    sm=load(directory/'sample/sample_manifest.json');require(all(sha(directory/'sample'/n)==h for n,h in sm['files'].items()),'Frozen probability roster or template changed')
    template=read(directory/'sample'/f'registered_{role}_TEMPLATE.csv')
    rows=read_review(review);require(rows.unit_id.is_unique and set(rows.unit_id)<=set(template.unit_id),'Duplicate/outside sampled IDs')
    protected=['unit_id','policy_id','policy_version_id','stage','reading_id','exact_evidence_text','reading_text','source_location','clean_start','clean_end','source_hash','source_clean_sha256','requested_fields']
    ti=template.set_index('unit_id')
    for r in rows.to_dict('records'):
        for k in protected:require(str(r.get(k,''))==str(ti.loc[r['unit_id'],k]) if k!='unit_id' else True,'Protected text/identity changed: '+k)
    frame=read(directory/'sampling_frame_BACKEND.csv')
    existing={r.unit_id:{k:getattr(r,'C2_'+k) for k in r.existing_fields_to_reuse.split(';') if k} for r in frame.itertuples() if r.existing_fields_to_reuse}
    normalized,errors=normalize_truth(rows,existing,review_scope)
    for r in normalized.to_dict('records'):
        if r.get('duplicate_rule_confirmed'):
            other=frame[frame.unit_id.eq(r['canonical_unit_id'])]
            require(len(other)==1 and other.iloc[0].policy_id==r['policy_id'] and r['canonical_unit_id']!=r['unit_id'],'Duplicate requires a distinct same-policy canonical unit')
    reused_ids=[]
    if review_scope=='G_ONLY' and len(normalized):
        root=directory if isinstance(directory,Path) else directory.root;seen={}
        core=['eligibility']+G+['source_membership','unit_validity','canonical_unit_id']+['independent_'+k for k in ['eligibility']+G]
        def observation(r):return {k:(str(observed_bit(r.get(k))) if k in ['eligibility']+G and observed_bit(r.get(k)) is not None else '' if r.get(k) is None else str(r.get(k,'')).lower()) for k in core}
        for p in (root/'returns').glob('*/ingest_receipt.json') if (root/'returns').exists() else []:
            receipt=load(p)
            if receipt.get('review_scope')!='G_ONLY' or receipt['coder_role']!=role:continue
            for r in read(p.parent/'actual_normalized.csv').to_dict('records'):seen[r['unit_id']]=observation(r)
        keep=[];conflicts=[]
        for r in normalized.to_dict('records'):
            if r['unit_id'] not in seen:keep.append(r)
            elif observation(r)==seen[r['unit_id']]:reused_ids.append(r['unit_id'])
            else:conflicts.append(dict(unit_id=r['unit_id'],reason='Conflicting prior G_ONLY observation; explicit correction required only for this ID'))
        normalized=pd.DataFrame(keep,columns=normalized.columns);errors=pd.concat([errors,pd.DataFrame(conflicts)],ignore_index=True)
        if not len(normalized) and errors.empty:return dict(state='ALREADY_IMPORTED',accepted_rows=0,reused_rows=len(reused_ids),coder_role=role,review_scope=review_scope)
    event_id=digest([sha(review),sha(signature),role,review_scope]);event=directory/'returns'/event_id
    if (event/'ingest_receipt.json').exists():return dict(reused=True,**load(event/'ingest_receipt.json'))
    event.mkdir(parents=True,exist_ok=True)
    csvout(event/'actual_normalized.csv',normalized);csvout(event/'unresolved_return_rows.csv',errors)
    import shutil
    shutil.copyfile(longpath(review),event/('actual_review'+Path(review).suffix));jsonout(event/'actual_signature.json',sig)
    receipt=dict(identity='REAL_PROBABILITY_AUDIT',coder_role=role,accepted_rows=len(normalized),unresolved_rows=len(errors),
       full_sample_return=len(normalized)==len(template),review_sha256=sha(review),signature_sha256=sha(signature),
       event_id=event_id,training_role='AUDIT_ONLY_NOT_TRAINING',C2_adoption=False)
    receipt['review_scope']=review_scope;receipt['reused_rows']=len(reused_ids)
    jsonout(event/'ingest_receipt.json',receipt)
    # Adapter staging uses the existing field-event schema, but never commits it as truth/train data.
    events=[]
    for r in normalized.to_dict('records'):
        for k in LABELS:
            if r.get(k) not in [0,1]:continue
            events.append(dict(unit_id=r['unit_id'],field=k,value=r[k],role='AUDIT_ONLY',statistical_identity='JOINT_SRSWOR_PRIMARY' if role=='PRIMARY' else 'NESTED_SECOND_CODER',
              protocol_sha256=sig['protocol_sha256'],reviewer=sig['reviewer'],review_time=sig['signed_at'],source_hash=r['source_hash'],
              zero_origin=r['field_origin_'+k] if r[k]==0 else '',field_origin=r['field_origin_'+k],
              independently_filled_by_current_coder=r['independent_'+k],
              parent_audit_unit_id=r['unit_id'] if r['field_origin_'+k]=='DERIVED_FROM_CURRENT_INELIGIBLE' else '',
              correction_of='',event_id=digest([event_id,r['unit_id'],k]),import_result='STAGED_AUDIT_NOT_AUTOMATIC_C2_ADOPTION'))
    csvout(event/'adjudication_compatible_events_STAGED_ONLY.csv',events)
    refresh_actual_progress(directory)
    return receipt

def feature_names(review_scope='FULL_10'):
    require(review_scope in ['FULL_10','G_ONLY'],'Unsupported review scope')
    return ['eligibility']+G if review_scope=='G_ONLY' else FEATURES

def feature_vector(r,kind='truth',review_scope='FULL_10'):
    features=feature_names(review_scope)
    if kind=='truth':
        # These facts prove zero G contribution even if unrelated source fields are unknown.
        if observed_bit(r.get('eligibility'))==0 or r.get('source_membership')=='OUTSIDE_TARGET' or r.get('unit_validity')=='SOURCE_NOT_TARGET' or (r.get('unit_validity')=='DUPLICATE_CONFIRMED' and str(r.get('duplicate_rule_confirmed','')).lower() in ['true','1']):return np.zeros(len(features))
        if r.get('source_membership')!='IN_TARGET' or r.get('unit_validity') not in VALID_UNITS:return None
        if observed_bit(r.get('eligibility'))!=1 or any(observed_bit(r.get(k)) is None for k in G):return None
        e=1;g=[observed_bit(r[k]) for k in G]
        if review_scope=='G_ONLY':return np.asarray([e]+g,float)
        if any(observed_bit(r.get(k)) is None for k in T):return None
        t=[observed_bit(r[k]) for k in T]
    else:
        e=int(r['C2_eligibility']);g=[e*int(r['C2_'+k]) for k in G]
        if review_scope=='G_ONLY':return np.asarray([e]+g,float)
        # Unknown auxiliary zero is never written to C2; unbiased design residuals supply T2 total.
        t=[e*(int(r['C2_'+k]) if str(r['C2_'+k])!='' else 0) for k in T]
    return np.asarray([e]+g+t+[a*b for a in g for b in t],float)

FEATURES=LABELS+[g+'x'+t for g in G for t in T]

def audit_composition_impact(frame,sample,actual,allocation,review_scope='FULL_10',allow_partial=False,cached_moments=None):
    """Model-assisted finite-population difference totals and joint covariance.

    Complete primary probability return required. Ratios are Taylor estimates;
    policy-bootstrap intervals are not read or combined here.
    """
    require('statistical_identity' in sample and sample.statistical_identity.eq('JOINT_STRATIFIED_SRSWOR').all(),'Directed cases are not a probability audit')
    require(numeric(sample.inclusion_probability).between(0,1,inclusive='right').all(),'Invalid inclusion probability')
    require(actual.unit_id.is_unique and (set(actual.unit_id)<=set(sample.unit_id) if allow_partial else set(actual.unit_id)==set(sample.unit_id)),'Incomplete probability return; no design extrapolation')
    names=feature_names(review_scope)
    af=actual.set_index('unit_id');fi=frame.set_index('unit_id');moments={};rows=[]
    for pid,z in frame.groupby('policy_id',sort=True):
        if cached_moments and pid in cached_moments:
            moments[pid]=cached_moments[pid];continue
        total=sum((feature_vector(r,'aux',review_scope) for r in z.to_dict('records')),np.zeros(len(names)))
        cov=np.zeros((len(names),len(names)));reason=[]
        for h,a in allocation[allocation.policy_id.eq(pid)].set_index('stratum_id').iterrows():
            ss=sample[sample.stratum_id.eq(h)];N=int(a.N);n=int(a.sample_n)
            require(len(ss)==n,'Actual sample differs from allocation')
            require(np.allclose(numeric(ss.inclusion_probability),n/N,rtol=0,atol=1e-12),'Actual sample probability differs from locked stratum')
            residual=[]
            for uid in ss.unit_id:
                if uid not in af.index:reason.append('MISSING:'+uid);continue
                y=feature_vector(af.loc[uid].to_dict(),'truth',review_scope)
                if y is None:reason.append(uid);continue
                residual.append(y-feature_vector(fi.loc[uid].to_dict(),'aux',review_scope))
            if len(residual)!=n:continue
            res=np.asarray(residual);total+=N*res.mean(axis=0)
            if n<N:
                require(n>=2,'Variance unidentifiable for noncensus n1 stratum')
                cov+=N*N*(1-n/N)*np.cov(res,rowvar=False,ddof=1)/n
        a_policy=allocation[allocation.policy_id.eq(pid)]
        moments[pid]=(total,cov,reason,dict(has_noncensus_stratum=bool((numeric(a_policy.sample_n)<numeric(a_policy.N)).any()),feature_names=names,review_scope=review_scope))
    # Cached and newly computed policies have the same output contract.
    for pid,(total,cov,reason,_) in moments.items():
        for k,v in zip(names,total):rows.append(dict(policy_id=pid,feature=k,estimated_total=v if not reason else np.nan,
          standard_error=math.sqrt(max(0,cov[names.index(k),names.index(k)])) if not reason else np.nan,
          status='UNIDENTIFIED_UNIT_OR_SOURCE_MAPPING' if reason else 'DESIGN_ASSISTED_DIFFERENCE_ESTIMATE',
          variance_caveat='zero empirical residual variance is not proof of no unseen errors in noncensus strata',
          unresolved_unit_ids=';'.join(reason),scope='FIXED_EXTRACTED_UNITS;EXISTING_EVIDENCE_ASSUMED_VALID;OMITTED_SOURCE_CLAUSES_NOT_IDENTIFIED'))
    return moments,pd.DataFrame(rows)

def estimate_direct_stratified_HT(frame,sample,actual,allocation):
    """Post-audit sensitivity: fixed verified component + original SRSWOR HT.

    Count totals are design-unbiased conditional on the fixed evidence being
    valid; normalized shares are ratio estimators, not strictly unbiased.
    This function neither clips DIFF nor uses model predictions in sampled HT.
    """
    names=['eligibility']+G
    require(actual.unit_id.is_unique and set(actual.unit_id)==set(sample.unit_id),'HT requires complete original probability sample')
    require(sample.statistical_identity.eq('JOINT_STRATIFIED_SRSWOR').all(),'HT requires registered probability identities')
    fixed=frame.existing_fields_to_reuse.ne('')
    require(not set(frame.loc[fixed,'unit_id'])&set(sample.unit_id),'Fixed evidence counted twice')
    require(frame.loc[fixed,'existing_fields_to_reuse'].map(lambda x:set(LABELS)<=set(x.split(';'))).all(),'Fixed component lacks complete evidence')
    require(set(allocation.stratum_id)==set(sample.stratum_id),'HT stratum mismatch')
    af=actual.set_index('unit_id');moments={};rows=[]
    for pid,z in frame.groupby('policy_id',sort=True):
        fixedz=z[z.existing_fields_to_reuse.ne('')]
        fixed_total=sum((feature_vector(r,'aux','G_ONLY') for r in fixedz.to_dict('records')),np.zeros(4))
        total=fixed_total.copy();cov=np.zeros((4,4));unknown=[]
        alloc=allocation[allocation.policy_id.eq(pid)]
        require(int(pd.to_numeric(alloc.N).sum())==int(z.existing_fields_to_reuse.eq('').sum()),'HT frame partition mismatch')
        for a in alloc.itertuples():
            ss=sample[sample.stratum_id.eq(a.stratum_id)];N=int(a.N);n=int(a.sample_n)
            require(len(ss)==n and np.allclose(numeric(ss.inclusion_probability),n/N,rtol=0,atol=1e-12),'HT locked design mismatch')
            require(np.allclose(numeric(ss.design_weight),N/n,rtol=0,atol=1e-10),'HT weight mismatch')
            values=[]
            for uid in ss.unit_id:
                y=feature_vector(af.loc[uid].to_dict(),'truth','G_ONLY')
                if y is None:unknown.append(uid)
                else:values.append(y)
            if len(values)!=n:continue
            y=np.asarray(values);require(np.all(y>=0),'Negative true HT contribution')
            total+=N/n*y.sum(axis=0)
            if n<N:
                require(n>=2,'Noncensus HT stratum variance unidentified')
                cov+=N*N*(1-n/N)*np.cov(y,rowvar=False,ddof=1)/n
        require(np.all(total>=0),'Negative HT total is an implementation error')
        meta=dict(has_noncensus_stratum=bool((numeric(alloc.sample_n)<numeric(alloc.N)).any()),feature_names=names,
                  review_scope='G_ONLY',estimator='DIRECT_STRATIFIED_HT',identity='POST_AUDIT_ESTIMATOR_SENSITIVITY',
                  fixed_evidence_n=len(fixedz),sample_n=int(numeric(alloc.sample_n).sum()))
        moments[pid]=(total,cov,unknown,meta)
        for k,value,fix in zip(names,total,fixed_total):
            rows.append(dict(policy_id=pid,feature=k,estimated_total=value if not unknown else np.nan,
              fixed_evidence_total=fix,sampled_domain_total=value-fix if not unknown else np.nan,
              standard_error=math.sqrt(max(0,cov[names.index(k),names.index(k)])) if not unknown else np.nan,
              fixed_evidence_n=len(fixedz),sample_n=meta['sample_n'],unresolved_unit_ids=';'.join(unknown),
              status='UNRESOLVED_CONTRIBUTION' if unknown else 'ZERO_ESTIMATED_ASSIGNMENTS_NOT_CONFIRMED_G0' if value==0 and k in G else 'DESIGN_HT_TOTAL',
              identity='POST_AUDIT_ESTIMATOR_SENSITIVITY',scope='FIXED_EXTRACTED_UNIT_FRAME;FIXED_EVIDENCE_ASSUMED_VALID',
              ratio_identity='NORMALIZED_RATIO_NOT_STRICTLY_UNBIASED'))
    return moments,pd.DataFrame(rows)

def evaluate_function_history(frame,moments,group='G'):
    labs=G if group=='G' else T;policy=[];stage=[]
    for pid,z in frame.groupby('policy_id',sort=True):
        total,cov,unresolved=moments[pid][:3];meta=moments[pid][3] if len(moments[pid])>3 else {}
        names=meta.get('feature_names',FEATURES);require(all(k in names for k in labs),'Group not in reviewed scope')
        ix=[names.index(k) for k in labs];den=float(total[ix].sum())
        for j,k in zip(ix,labs):
            defined=not unresolved and den>0 and np.all(total[ix]>=0)
            grad=np.zeros(len(names));grad[ix]=-total[j]/den**2 if den else 0;grad[j]+=1/den if den else 0
            variance=float(grad@cov@grad) if defined else np.nan
            policy.append(dict(policy_id=pid,stage=z.iloc[0].stage,label=k,design_corrected_share=total[j]/den if defined else np.nan,
                standard_error=math.sqrt(max(0,variance)) if defined else np.nan,assignment_denominator=den if not unresolved else np.nan,
                negative_total_not_clipped=bool(np.any(total[ix]<0)),status='UNIDENTIFIED_OR_NONPOSITIVE_RATIO' if not defined else 'DESIGN_LINEARIZED_RATIO',
                sample_scope_complete=not unresolved,has_noncensus_stratum=meta.get('has_noncensus_stratum',False),
                variance_identity='CODING_AUDIT_DESIGN_ONLY_NOT_POLICY_BOOTSTRAP'))
    result=pd.DataFrame(policy)
    for (s,k),z in result.groupby(['stage','label']):
        full=z.design_corrected_share.notna().all();v=float(np.sum(z.standard_error**2)/len(z)**2) if full else np.nan
        value=float(z.design_corrected_share.mean()) if full else np.nan;se=math.sqrt(v) if full else np.nan
        interval_ok=full and (v>0 or not z.has_noncensus_stratum.any())
        stage.append(dict(stage=s,label=k,policy_n=len(z),design_corrected_share=value,standard_error=se,
          p025_normal_approx=value-1.96*se if interval_ok else np.nan,p975_normal_approx=value+1.96*se if interval_ok else np.nan,
          normal_interval_reportable=interval_ok,zero_empirical_variance_not_zero_risk=bool(full and v==0 and z.has_noncensus_stratum.any()),
          interval_identity='TAYLOR_NORMAL_AUDIT_DESIGN_APPROX_NOT_POLICY_COMPOSITION_BOOTSTRAP',
          limitation='small strata/rare labels may make normal approximation weak; no coverage guarantee; zero observed errors or zero residual variance do not prove zero population risk; source gaps excluded'))
    return result,pd.DataFrame(stage)

def evaluate_tool_configuration(frame,moments):
    p,stage=evaluate_function_history(frame,moments,'T');pairs=[]
    for pid,moment in moments.items():
        total,cov,unresolved=moment[:3]
        for g in G:
            ix=[FEATURES.index(g+'x'+t) for t in T];den=total[ix].sum()
            for t,j in zip(T,ix):
                ok=not unresolved and den>0 and np.all(total[ix]>=0)
                grad=np.zeros(len(FEATURES));grad[ix]=-total[j]/den**2 if den else 0;grad[j]+=1/den if den else 0
                pairs.append(dict(policy_id=pid,G=g,T=t,estimated_joint_count=total[j] if not unresolved else np.nan,
                  T_share_within_G=total[j]/den if ok else np.nan,standard_error=math.sqrt(max(0,float(grad@cov@grad))) if ok else np.nan,
                  identity='DESIGN_ASSISTED_WITHIN_UNIT_COCODING_NOT_CAUSAL;NO_C2_T2_IMPUTATION'))
    return p,stage,pd.DataFrame(pairs)

def audit_diagnostics(frame,sample,actual,moments,review_scope='FULL_10'):
    """Persist observed design residuals and joint total covariance."""
    names=feature_names(review_scope);fi=frame.set_index('unit_id');af=actual.set_index('unit_id');residuals=[];covariance=[]
    for r in sample.to_dict('records'):
        uid=r['unit_id']
        if uid not in af.index:continue
        y=feature_vector(af.loc[uid].to_dict(),'truth',review_scope);x=feature_vector(fi.loc[uid].to_dict(),'aux',review_scope)
        for i,k in enumerate(names):
            residuals.append(dict(unit_id=uid,policy_id=fi.loc[uid,'policy_id'],stratum_id=r['stratum_id'],feature=k,
              auxiliary_value=x[i],audit_value=y[i] if y is not None else np.nan,
              residual=y[i]-x[i] if y is not None else np.nan,design_weight=r.get('design_weight',1/float(r['inclusion_probability'])),
              status='OBSERVED_DESIGN_RESIDUAL' if y is not None else 'UNRESOLVED_G_AFFECTING_UNIT'))
    for pid,(_,cov,unresolved,*_) in moments.items():
        for i,k in enumerate(names):
            for ii,kk in enumerate(names):covariance.append(dict(policy_id=pid,feature_1=k,feature_2=kk,covariance=cov[i,ii] if not unresolved else np.nan,
                identity='JOINT_AUDIT_DESIGN_TOTAL_COVARIANCE_NOT_POLICY_BOOTSTRAP'))
    return pd.DataFrame(residuals),pd.DataFrame(covariance)

def stage_changes(stage):
    """Adjacent-stage contrasts under independently drawn policy strata."""
    rows=[]
    for earlier,later in zip(STAGES,STAGES[1:]):
        for k in sorted(stage.label.unique()):
            a=stage[stage.stage.eq(earlier)&stage.label.eq(k)];b=stage[stage.stage.eq(later)&stage.label.eq(k)]
            if len(a)!=1 or len(b)!=1:continue
            a=a.iloc[0];b=b.iloc[0]
            value=b.design_corrected_share-a.design_corrected_share;se=math.sqrt(a.standard_error**2+b.standard_error**2)
            ok=bool(a.normal_interval_reportable and b.normal_interval_reportable and np.isfinite(value) and np.isfinite(se))
            rows.append(dict(earlier_stage=earlier,later_stage=later,label=k,design_corrected_difference=value,standard_error=se,
                p025_normal_approx=value-1.96*se if ok else np.nan,p975_normal_approx=value+1.96*se if ok else np.nan,
                normal_interval_reportable=ok,identity='ADJACENT_STAGE_CODING_DESIGN_TAYLOR_APPROX;NOT_POLICY_BOOTSTRAP;NOT_QUALITY_PASS'))
    return pd.DataFrame(rows)

def error_metrics(frame,sample,actual,review_scope='FULL_10'):
    labs=['eligibility']+G if review_scope=='G_ONLY' else LABELS
    z=actual.merge(sample[['unit_id','design_weight']],on='unit_id',validate='one_to_one').merge(frame[['unit_id','policy_family_id']+['C2_'+k for k in labs]],on='unit_id',validate='one_to_one')
    rows=[]
    for dimension in ['ALL','stage','policy_family_id']:
        groups=[('ALL',z)] if dimension=='ALL' else list(z.groupby(dimension))
        for scope,q in groups:
            w=numeric(q.design_weight).to_numpy(float)
            for k in labs:
                # Reused fields support the fixed component but are not newly independent error observations.
                keep=~q.get('reused_fields',pd.Series('',index=q.index)).map(lambda v:k in str(v).split(';'))
                keep &= pd.to_numeric(q[k],errors='coerce').isin([0,1])
                qq=q[keep];ww=w[keep.to_numpy()]
                y=numeric(qq[k]).to_numpy(int);pred=pd.to_numeric(qq['C2_'+k],errors='coerce').to_numpy(float);known=np.isfinite(pred)
                masks=dict(TP=(y==1)&(pred==1),FP=(y==0)&(pred==1),FN=(y==1)&(pred==0),TN=(y==0)&(pred==0))
                row=dict(dimension=dimension,scope=scope,label=k,sample_n=len(qq),actual_positive_n=int(y.sum()),prediction_abstention_n=int((~known).sum()),
                  weighted_abstained_positives=float(ww[(~known)&(y==1)].sum()),identity='NEW_PROBABILITY_DOMAIN_ONLY;NOT_DIRECTED_CASES;FIXED_REUSE_COMPONENT_NOT_NEW_VALIDATION')
                for name,mask in masks.items():row[name]=int(mask.sum());row['HT_'+name]=float(ww[mask].sum())
                rows.append(row)
    return pd.DataFrame(rows)

def independent_coding_agreement(primary,secondary,review_scope='FULL_10'):
    """Only two genuinely current-coder observations enter field agreement."""
    paired=primary.merge(secondary,on='unit_id',suffixes=('_primary','_secondary'),validate='one_to_one');rows=[];differences=[]
    distinct=paired.reviewer_primary.str.strip().str.casefold().ne(paired.reviewer_secondary.str.strip().str.casefold()) if len(paired) else pd.Series([],dtype=bool)
    if len(paired) and review_scope!='G_ONLY':require(distinct.all(),'Second coder must be a distinct real reviewer')
    for k in (['eligibility']+G if review_scope=='G_ONLY' else LABELS):
        flag=lambda side: paired.get('independent_'+k+'_'+side,pd.Series(False,index=paired.index)).astype(str).str.lower().isin(['true','1'])
        valid=flag('primary')&flag('secondary')&distinct
        valid &= pd.to_numeric(paired[k+'_primary'],errors='coerce').isin([0,1])&pd.to_numeric(paired[k+'_secondary'],errors='coerce').isin([0,1])
        q=paired[valid];a=numeric(q[k+'_primary']).to_numpy(int);b=numeric(q[k+'_secondary']).to_numpy(int)
        pa=float((a==b).mean()) if len(q) else np.nan;pe=float(a.mean()*b.mean()+(1-a.mean())*(1-b.mean())) if len(q) else np.nan
        rows.append(dict(label=k,paired_actual_n=len(q),excluded_reused_or_unobserved_n=len(paired)-len(q),excluded_same_reviewer_n=int((~distinct).sum()),raw_agreement=pa,cohen_kappa=(pa-pe)/(1-pe) if len(q) and pe<1 else np.nan,identity='ACTUAL_INDEPENDENT_FIELDS_ONLY;UNWEIGHTED_NESTED_SAMPLE_DESCRIPTION'))
        for r in q.to_dict('records'):differences.append(dict(unit_id=r['unit_id'],field=k,primary_value=r[k+'_primary'],secondary_value=r[k+'_secondary'],agree=str(r[k+'_primary'])==str(r[k+'_secondary']),primary_reviewer=r['reviewer_primary'],secondary_reviewer=r['reviewer_secondary']))
    return pd.DataFrame(rows),pd.DataFrame(differences)

def assess_research_use(evidence,claims=None):
    """Three-valued, claim-specific assessment; no implicit tolerance or blanket pass.

    Numeric criteria must be explicitly registered before seeing audit truth and
    bound to that audit. Absence is INDETERMINATE, never automatically supported.
    """
    if evidence.get('assessment_identity')=='FIXED_FRAME_DESCRIPTIVE_SCOPE_ASSESSMENT':
        # The current author protocol permits internal descriptive reporting
        # without re-approval, T completion or full-body coverage certification.
        ok=bool(evidence['sample_identity_verified'] and evidence['HT_numerically_verified'] and
                evidence['policy_stage_definitions_consistent'] and evidence['limitations_disclosed'] and
                evidence['statistical_population']=='FIXED_EXTRACTED_UNIT_FRAME')
        states=dict(G_HT_COMPUTATION_COMPLETED=evidence['HT_computation_complete'],
          G_FIXED_FRAME_DESCRIPTIVE_REPORTABLE=ok,
          G_STAGE_HISTORICAL_DESCRIPTION_AVAILABLE=bool(ok and evidence['stage_estimates_defined']),
          G_POLICY_ESTIMATE_AVAILABLE=bool(ok and evidence['policy_estimates_defined']),
          G_FULL_POLICY_BODY_VALIDATED=evidence['full_body_validated'],
          G_POLICY_INTENSITY_FORMALLY_SUPPORTED=evidence['formal_intensity_supported'],
          FULL_C2_FORMAL_RELEASE_READY=evidence['full_C2_formal_release_ready'],
          PART1_COMPLETED=evidence['full_C2_formal_release_ready'],
          PART1_G_DESCRIPTIVE_DELIVERY_COMPLETED=bool(ok and evidence['descriptive_files_complete'] and evidence['delivery_QA_passed']))
        # Legacy fields remain explicit and scope-labeled for old clients.
        states.update(C2_FORMAL_RELEASE_READY=states['FULL_C2_FORMAL_RELEASE_READY'],
          G_AUDIT_COMPUTATION_COMPLETED=states['G_HT_COMPUTATION_COMPLETED'],
          G_STAGE_HISTORY_SUPPORTED='FIXED_FRAME_DESCRIPTIVE_RESULT_AVAILABLE' if states['G_STAGE_HISTORICAL_DESCRIPTION_AVAILABLE'] else 'INDETERMINATE',
          G_POLICY_INPUT_SUPPORTED='DESCRIPTIVE_ESTIMATES_AVAILABLE;NOT_PRECISE_ACTION_STOCK' if states['G_POLICY_ESTIMATE_AVAILABLE'] else 'INDETERMINATE',
          T_CONFIGURATION_SUPPORTED='OUT_OF_SCOPE_CONDITIONAL')
        return dict(assessment_identity='FIXED_FRAME_DESCRIPTIVE_SCOPE_ASSESSMENT',
          result_identity='FIXED_FRAME_POST_AUDIT_DESCRIPTIVE_RESULT',states=states,
          descriptive_G_statistics_available=ok,scope=evidence['statistical_population'],
          research_use_adoption=evidence['formal_manuscript_adoption'],
          limitations=evidence['limitations'],evidence_files=evidence['evidence_files'],
          full_body_and_T_are_not_descriptive_prerequisites=True,part2_started=False)
    if evidence.get('assessment_identity')=='POSTHOC_USE_SCOPE_ASSESSMENT':
        # Actual evidence files, not a missing preregistration tolerance, control
        # descriptive availability. Acceptance is a separate bound real event.
        states={k:evidence[k] for k in ['AUDIT_SAMPLE_COMPLETE','ESTIMATOR_NUMERICALLY_VERIFIED',
          'G_POLICY_ESTIMATE_DEFINED','G_STAGE_ESTIMATE_DEFINED','SOURCE_FIXED_FRAME_COVERED',
          'FULL_SOURCE_BODY_COVERAGE_SUPPORTED','POLICY_FUNCTION_PRESENCE_SUPPORTED',
          'POLICY_G_INTENSITY_SUPPORTED','RESEARCH_USE_SCOPE_ACCEPTED']}
        descriptive_ok=bool(states['AUDIT_SAMPLE_COMPLETE'] and states['ESTIMATOR_NUMERICALLY_VERIFIED'] and states['G_STAGE_ESTIMATE_DEFINED'] and states['SOURCE_FIXED_FRAME_COVERED'])
        states.update(G_AUDIT_COMPUTATION_COMPLETED=states['AUDIT_SAMPLE_COMPLETE'],
          G_STAGE_HISTORY_SUPPORTED='SUPPORTED_WITHIN_ACCEPTED_SCOPE' if states['RESEARCH_USE_SCOPE_ACCEPTED'] and descriptive_ok else 'INDETERMINATE',
          G_POLICY_INPUT_SUPPORTED='INDETERMINATE',T_CONFIGURATION_SUPPORTED='INDETERMINATE',
          C2_FORMAL_RELEASE_READY=False,PART1_COMPLETED=False)
        return dict(assessment_identity='POSTHOC_USE_SCOPE_ASSESSMENT',states=states,
          descriptive_G_statistics_available=descriptive_ok,
          descriptive_scope='FIXED_EXTRACTED_UNIT_FRAME;POST_AUDIT_ESTIMATOR_SENSITIVITY',
          defined_policy_n=evidence['defined_policy_n'],policy_n=68,
          reasons=evidence['limitations'],evidence_files=evidence['evidence_files'],
          numeric_threshold_predeclared=False,part2_started=False)
    claims=claims or {};out={};reasons={}
    for state,group in [('G_STAGE_HISTORY_SUPPORTED','stage'),('G_POLICY_INPUT_SUPPORTED','policy'),('T_CONFIGURATION_SUPPORTED','tools')]:
        spec=claims.get(group,{})
        why=[]
        if not evidence.get('actual_probability_audit_complete'):why.append('NO_COMPLETE_ACTUAL_PROBABILITY_AUDIT')
        if group=='tools' and evidence.get('review_scope')=='G_ONLY':why.append('T_OUT_OF_REVIEW_SCOPE')
        if not spec.get('predeclared_and_bound'):why.append('NO_ACTUAL_BOUND_USE_SPECIFIC_ACCEPTANCE_CONDITIONS')
        if not evidence.get('source_population_scope_resolved'):why.append('SOURCE_POPULATION_COVERAGE_NOT_ESTABLISHED')
        if evidence.get('G_unidentified_policy_n',0) and group in ['stage','policy']:why.append('G_RATIO_OR_COUNT_UNIDENTIFIED')
        if group=='policy' and not evidence.get('policy_presence_and_strength_assessed'):why.append('POLICY_PRESENCE_AND_INTENSITY_NOT_ESTABLISHED')
        # caller supplies computed metrics with identifiers, not an author boolean.
        checks=spec.get('numeric_checks',[])
        if not checks:why.append('NO_DECLARED_COMPUTABLE_CLAIM_CHECKS')
        passed=[]
        for check in checks:
            key=check.get('metric');v=evidence.get('claim_metrics',{}).get(key)
            require(check.get('operator') in ['<=','>='],'Unsupported acceptance operator')
            if v is None or not np.isfinite(v):why.append('UNAVAILABLE_CLAIM_METRIC:'+str(key));continue
            passed.append(v<=check['limit'] if check['operator']=='<=' else v>=check['limit'])
        out[state]='INDETERMINATE' if why else 'SUPPORTED' if all(passed) else 'NOT_SUPPORTED'
        reasons[state]=why or ([] if all(passed) else ['ACTUAL_METRIC_FAILS_PREDECLARED_CLAIM'])
    out['C2_FORMAL_RELEASE_READY']=bool(evidence.get('full_ten_field_record_evidence_complete') and evidence.get('exact_formal_C2_approval') and all(out[k]=='SUPPORTED' for k in ['G_STAGE_HISTORY_SUPPORTED','G_POLICY_INPUT_SUPPORTED','T_CONFIGURATION_SUPPORTED']))
    out['PART1_COMPLETED']=bool(out['C2_FORMAL_RELEASE_READY'] and evidence.get('reproducible_release_verified'))
    return dict(states=out,reasons=reasons,conditional_G_delivery_allowed=True,part2_started=False)

def g_audit_progress(frame,sample,actual):
    """Scheduled sample completeness, distinct from ratio/quality sufficiency."""
    ai=actual.set_index('unit_id');rows=[]
    for pid,z in frame.groupby('policy_id',sort=True):
        planned=sample[sample.unit_id.isin(z.unit_id)];returned=[u for u in planned.unit_id if u in ai.index]
        valid=[u for u in returned if feature_vector(ai.loc[u].to_dict(),'truth','G_ONLY') is not None]
        complete=len(valid)==len(planned)
        rows.append(dict(policy_id=pid,stage=z.iloc[0].stage,planned_sample_n=len(planned),returned_n=len(returned),valid_G_n=len(valid),
            missing_n=len(planned)-len(returned),unresolved_return_n=len(returned)-len(valid),design_sample_complete=complete,
            status='FIXED_EXISTING_EVIDENCE_COMPONENT' if not len(planned) else 'COMPLETE_FOR_FIXED_FRAME_ESTIMATION' if complete else 'PARTIAL_RETURN' if len(returned)<len(planned) else 'G_JUDGMENT_UNRESOLVED',
            scope='FIXED_EXTRACTED_UNIT_FRAME;OMITTED_SOURCE_TEXT_NOT_IDENTIFIED'))
    policy=pd.DataFrame(rows);stages=[]
    for stage,z in policy.groupby('stage'):
        complete=bool(z.design_sample_complete.all())
        stages.append(dict(stage=stage,policy_n=len(z),complete_policy_n=int(z.design_sample_complete.sum()),planned_sample_n=int(z.planned_sample_n.sum()),
            returned_n=int(z.returned_n.sum()),valid_G_n=int(z.valid_G_n.sum()),design_sample_complete=complete,status='COMPLETE_FOR_FIXED_FRAME_ESTIMATION' if complete else 'PARTIAL_RETURN'))
    return policy,pd.DataFrame(stages)

def evaluate_g_only(ctx,directory,claims=None,research_evidence=None):
    """Incremental, policy-complete estimation; no T or second-coder prerequisite."""
    active=directory/'G_ESTIMATOR_SENSITIVITY_ACTIVE.json'
    if active.exists():
        import g_estimator_stability_20261028 as stability
        return stability.execute(refresh_source=False)
    sm=load(directory/'sample/sample_manifest.json')
    binding=directory/'G_ONLY_INPUT_BINDING.json'
    if binding.exists():require(all(sha(r['path'])==r['sha256'] for r in load(binding)['dependencies']),'Bound fixed G audit inputs changed')
    require(all(sha(directory/'sample'/n)==h for n,h in sm['files'].items()),'Probability roster/template changed')
    sample=read(directory/'sample/actual_sample_BACKEND.csv');frame=read(directory/'sampling_frame_BACKEND.csv')
    allocation=read(directory/f'allocation_{sm["option"]}.csv');primary=[];secondary=[]
    root=directory if isinstance(directory,Path) else directory.root
    for p in sorted((root/'returns').glob('*/ingest_receipt.json')) if (root/'returns').exists() else []:
        receipt=load(p)
        if receipt.get('review_scope')!='G_ONLY' or not receipt.get('accepted_rows',0):continue
        sig=load(p.parent/'actual_signature.json');d=read(p.parent/'actual_normalized.csv');d['reviewer']=sig['reviewer'];d['batch_time']=sig['signed_at']
        (primary if receipt['coder_role']=='PRIMARY' else secondary).append(d)
    columns=['unit_id','stage','eligibility']+G+['source_membership','unit_validity','reused_fields','reviewer']
    actual=pd.concat(primary,ignore_index=True) if primary else pd.DataFrame(columns=columns)
    require(actual.unit_id.is_unique and set(actual.unit_id)<=set(sample.unit_id),'Repeated/outside primary audit IDs require explicit correction')
    progress,stage_progress=g_audit_progress(frame,sample,actual)
    csvout(directory/'G_POLICY_AUDIT_PROGRESS.csv',progress);csvout(directory/'G_STAGE_AUDIT_PROGRESS.csv',stage_progress)
    # Cache is per policy and includes actual observations, frame inputs, design
    # and estimator bytes. Other policy returns do not invalidate its key.
    cachepath=directory/'G_POLICY_MOMENTS_CACHE.json';old=load(cachepath) if cachepath.exists() else {};keys={};cached={};new={}
    modelcols=['unit_id','policy_id','stage']+['C2_'+k for k in ['eligibility']+G]+[k for k in ['source_hash','source_clean_sha256'] if k in frame]
    for pid,z in frame.groupby('policy_id',sort=True):
        ss=sample[sample.unit_id.isin(z.unit_id)]
        key=digest(dict(frame=z[modelcols].to_dict('records'),sample=ss.to_dict('records'),
            allocation=allocation[allocation.policy_id.eq(pid)].to_dict('records'),actual=actual[actual.unit_id.isin(z.unit_id)].to_dict('records'),
            numerical_code_sha256=sha(Path(__file__)),review_scope='G_ONLY'))
        keys[pid]=key
        if old.get(pid,{}).get('key')==key:
            v=old[pid];cached[pid]=(np.asarray(v['total'],float),np.asarray(v['covariance'],float),v['unresolved'],v['metadata'])
    moments,totals=audit_composition_impact(frame,sample,actual,allocation,'G_ONLY',allow_partial=True,cached_moments=cached)
    for pid,(total,cov,unknown,meta) in moments.items():new[pid]=dict(key=keys[pid],total=total.tolist(),covariance=cov.tolist(),unresolved=unknown,metadata=meta)
    atomic_json(cachepath,new)
    gp,gs=evaluate_function_history(frame,moments);gp=gp.merge(progress[['policy_id','status']],on='policy_id',suffixes=('','_progress'))
    gs=gs.merge(stage_progress[['stage','status','design_sample_complete']],on='stage',validate='many_to_one')
    changes=stage_changes(gs);residuals,covariance=audit_diagnostics(frame,sample,actual,moments,'G_ONLY')
    for name,d in [('DESIGN_ASSISTED_TOTALS.csv',totals),('G_POLICY_AUDIT_CORRECTION.csv',gp),('G_STAGE_AUDIT_CORRECTION.csv',gs),
       ('G_STAGE_CHANGE_AUDIT_CORRECTION.csv',changes),('AUDIT_RESIDUALS.csv',residuals),('AUDIT_TOTAL_COVARIANCE.csv',covariance)]:csvout(directory/name,d)
    if len(actual):
        metrics=error_metrics(frame,sample,actual,'G_ONLY')
        if len(actual)!=len(sample):
            for col in [c for c in metrics if c.startswith('HT_')]:metrics[col]=np.nan
            metrics['identity']='PARTIAL_RESPONSE_DESCRIPTIVE_ONLY;NO_ORIGINAL_WEIGHT_EXTRAPOLATION'
        csvout(directory/'ACTUAL_AUDIT_ERROR_METRICS.csv',metrics)
    evidence=dict(research_evidence or {});all_valid=bool(progress.design_sample_complete.all())
    evidence.update(actual_probability_audit_complete=all_valid,review_scope='G_ONLY',G_unidentified_policy_n=int(gp.loc[gp.design_corrected_share.isna(),'policy_id'].nunique()))
    decision=assess_research_use(evidence,claims);decision['states']['G_AUDIT_COMPUTATION_COMPLETED']=all_valid
    decision.update(computation_scope='FIXED_EXTRACTED_UNITS;NOT_FULL_SOURCE_COVERAGE',completed_stages=stage_progress.loc[stage_progress.design_sample_complete,'stage'].tolist(),
        completed_policy_n=int(progress.design_sample_complete.sum()),primary_actual_n=len(actual),expected_primary_n=len(sample))
    second_n=0;independent_field_pairs=0
    if secondary:
        other=pd.concat(secondary,ignore_index=True);require(other.unit_id.is_unique,'Repeated secondary audit IDs')
        agreement,diffs=independent_coding_agreement(actual,other,'G_ONLY');second_n=len(other)
        independent_field_pairs=int(agreement.paired_actual_n.sum())
        csvout(directory/'INDEPENDENT_CODING_AGREEMENT.csv',agreement);csvout(directory/'INDEPENDENT_CODING_DISAGREEMENTS.csv',diffs)
    secondary_state='SECOND_CODER_PENDING' if second_n<int(sm.get('second_coder_n',0)) else 'SECOND_CODER_RETURNED'
    decision['second_coder_status']=secondary_state
    jsonout(directory/'SECOND_CODER_STATUS.json',dict(status=secondary_state,actual_secondary_n=second_n,expected_secondary_n=sm.get('second_coder_n',0),independent_observed_field_pairs=independent_field_pairs,blocks_primary_computation=False))
    jsonout(directory/'G_RESEARCH_USE_ASSESSMENT.json',decision)
    state='G_AUDIT_COMPUTATION_COMPLETED' if all_valid else 'WAITING_FOR_G_AUDIT_RETURN'
    result=dict(status=state,primary_actual_n=len(actual),expected_primary_n=len(sample),policy_computed_n=int(progress.design_sample_complete.sum()),
       stage_computed_n=int(stage_progress.design_sample_complete.sum()),policies_recomputed=len(moments)-len(cached),policies_reused=len(cached),
       second_coder_status=secondary_state,new_training_labels=0,frozen_T2_overwritten=False,part2_started=False,states=decision['states'])
    jsonout(directory/'evaluation_status.json',result);return result

def evaluate(ctx,directory,review_scope='FULL_10',claims=None,research_evidence=None):
    if review_scope=='G_ONLY':return evaluate_g_only(ctx,directory,claims,research_evidence)
    require((directory/'sample/sample_manifest.json').exists(),'No approved sample exists')
    sm=load(directory/'sample/sample_manifest.json');require(all(sha(directory/'sample'/n)==h for n,h in sm['files'].items()),'Probability roster/template changed')
    primary=[];secondary=[]
    for p in sorted((directory/'returns').glob('*/ingest_receipt.json')) if (directory/'returns').exists() else []:
        receipt=load(p);sig=load(p.parent/'actual_signature.json')
        if receipt.get('review_scope','FULL_10')!=review_scope:continue
        d=read(p.parent/'actual_normalized.csv');d['reviewer']=sig['reviewer'];d['batch_time']=sig['signed_at']
        (primary if receipt['coder_role']=='PRIMARY' else secondary).append(d)
    require(primary,'No actual primary audit returns')
    actual=pd.concat(primary,ignore_index=True);require(actual.unit_id.is_unique,'Conflicting/repeated primary returns require explicit correction ledger')
    sample=read(directory/'sample/actual_sample_BACKEND.csv');frame=read(directory/'sampling_frame_BACKEND.csv');protocol=load(directory/'joint_audit_protocol.json')
    sm=load(directory/'sample/sample_manifest.json');allocation=read(directory/f'allocation_{sm["option"]}.csv')
    metrics=error_metrics(frame,sample,actual,review_scope);csvout(directory/'ACTUAL_AUDIT_ERROR_METRICS.csv',metrics)
    if set(actual.unit_id)!=set(sample.unit_id):
        jsonout(directory/'evaluation_status.json',dict(status='PARTIAL_RETURN_NO_DESIGN_EXTRAPOLATION',returned=len(actual),expected=len(sample),G_HISTORY_QUALITY_SUPPORTED=False,T_CONFIGURATION_QUALITY_SUPPORTED=False));refresh_actual_progress(directory);return dict(state='WAITING_FOR_COMPLETE_RETURN',returned=len(actual))
    moments,totals=audit_composition_impact(frame,sample,actual,allocation,review_scope);gp,gs=evaluate_function_history(frame,moments)
    residuals,covariance=audit_diagnostics(frame,sample,actual,moments,review_scope)
    products=[('DESIGN_ASSISTED_TOTALS.csv',totals),('G_POLICY_AUDIT_CORRECTION.csv',gp),('G_HISTORY_QUALITY_REPORT.csv',gs),
        ('G_STAGE_DIFFERENCE_AUDIT_CORRECTION.csv',stage_changes(gs)),('AUDIT_RESIDUALS.csv',residuals),('AUDIT_TOTAL_COVARIANCE.csv',covariance)]
    if review_scope=='FULL_10':
        tp,ts,coc=evaluate_tool_configuration(frame,moments);products += [('T_POLICY_AUDIT_CORRECTION.csv',tp),('T_CONFIGURATION_QUALITY_REPORT.csv',ts),('G_T_COCODING_AUDIT_CORRECTION.csv',coc)]
    for name,d in products:csvout(directory/name,d)
    evidence=dict(research_evidence or {})
    evidence.update(actual_probability_audit_complete=True,review_scope=review_scope,G_unidentified_policy_n=int(gp.loc[gp.design_corrected_share.isna(),'policy_id'].nunique()))
    decision=assess_research_use(evidence,claims)
    jsonout(directory/'G_RESEARCH_USE_ASSESSMENT.json',decision)
    # No claim-quality thresholds are invented after viewing results. Signed use-scope
    # review of actual errors, uncertainty and source coverage remains a real dependency.
    jsonout(directory/'evaluation_status.json',dict(status='COMPUTED_AUDIT_EFFECTS_QUALITY_SCOPE_REVIEW_REQUIRED',
      primary_actual_n=len(actual),new_training_labels=0,frozen_T2_overwritten=False,
      research_use_assessment=decision,
      reason='Actual claim-specific assessment is recorded separately; absent conditions are INDETERMINATE, not an invented pass'))
    if secondary:
        other=pd.concat(secondary,ignore_index=True);require(other.unit_id.is_unique,'Repeated secondary returns')
        agreement,differences=independent_coding_agreement(actual,other,review_scope)
        csvout(directory/'INDEPENDENT_CODING_AGREEMENT.csv',agreement)
        csvout(directory/'INDEPENDENT_CODING_DISAGREEMENTS.csv',differences)
    refresh_actual_progress(directory)
    return dict(state='AUDIT_EFFECTS_COMPUTED_QUALITY_NOT_AUTOMATIC',actual_n=len(actual))

def main():
    p=argparse.ArgumentParser();p.add_argument('command',choices=['prepare','draw','ingest','evaluate']);p.add_argument('--approval');p.add_argument('--review');p.add_argument('--signature')
    a=p.parse_args();ctx,d=ctx_and_dir()
    if a.command=='prepare':r=prepare(ctx,d)
    elif a.command=='draw':require(a.approval,'Actual design approval required');r=draw(ctx,d,Path(a.approval))
    elif a.command=='ingest':require(a.review and a.signature,'Actual return and signature required');r=ingest(ctx,d,Path(a.review),Path(a.signature))
    else:r=evaluate(ctx,d)
    print(json.dumps(clean_json(r),ensure_ascii=False))

if __name__=='__main__':main()
