"""Finalize the single existing delivery folder; verify real manifest contents."""
from pathlib import Path
import difflib,json,shutil
import g_descriptive_delivery_20261028 as d
s=d.s;j=d.j;ctx,parent,v,out=s.locations();short=j.ROOT/'outputs/JOINT_528_ac6da323683e5609';dest=short/'G估计器稳定性修复结果'
result=j.load(out/'PART1_EXECUTION_STATUS.json');qa=j.load(out/'G_DELIVERY_QA.json')
j.require(qa['all_passed'] and result['assessment']['states']['PART1_G_DESCRIPTIVE_DELIVERY_COMPLETED'],'Real descriptive delivery not complete')
for n in ['joint_history_audit_20261028.py','g_estimator_stability_20261028.py','joint528_G_ONLY_execution_20261028.py']:
 before=(out/'before_G_descriptive_delivery'/n).read_text('utf-8');after=(j.ROOT/n).read_text('utf-8')
 (out/(n+'.descriptive.patch')).write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='before/'+n,tofile='after/'+n)),'utf-8')
patch='''# G描述性交付：本轮最小修复

1. assess_research_use新增FIXED_FRAME_DESCRIPTIVE_SCOPE_ASSESSMENT分支；报告性由真实样本/权重、冻结输入、HT结果合法性与一致性、已列明局限及固定框范围判定。完整正文、T、旧池、独立窄区间和再次采用签署不是内部输出前置条件。
2. research_evidence/applicability通过当前描述性协议接入实际数据，68政策逐项生成总量、份额、SE、固定/抽样支持、编码者敏感性、来源与限制。wide或zero SE均不拒绝出表；zero SE明确不表示零风险。
3. 来源规则接受PDF、HTML、可追溯正文和条款摘录；网页解读/导航仅作上下文。原source_coverage并无PDF强制门槛，此次补齐来源清单和适用范围，不伪称修复不存在的格式限制。
4. 68份本地捕获正文和clean_text哈希核对，保留URL和capture_batch；未新增联网核验。515段按共同根因归并并筛查语境，不填0、不更改原ID或528入样概率。
5. 现有status/refresh/package接续新描述性状态及数据。PART1_G_DESCRIPTIVE_DELIVERY_COMPLETED与完整十字段PART1_COMPLETED分开。
6. 本轮author protocol amendment只授权流程与范围，未冒充具体历史份额真实性确认或正式稿件采用。若将来用于稿件，可一次绑定最终manifest、政策/阶段数据和METHOD_AND_LIMITATIONS，不需要作者手抄哈希。
7. 最终manifest在实际日志写入后生成；两个manifest互相排除以避免循环依赖。原模型、HT、DIFF与人工事件没有修改。
'''
(out/'G_DESCRIPTIVE_PATCHLOG.md').write_text(patch,'utf-8')
prov=j.read(out/'SOURCE_PROVENANCE_AND_COVERAGE.csv');groups=j.read(out/'UNRESOLVED_SOURCE_GROUPS.csv')
rows=j.read(out/'G_POLICY_DESCRIPTIVE_68.csv');stage=j.read(out/'G_STAGE_DESCRIPTIVE.csv')
lines=[]
for period in j.STAGES:
 z=stage[stage.stage.eq(period)].set_index('label');lines.append('|'+period+'|'+ '|'.join(f'{float(z.loc[g,"design_corrected_share"])*100:.2f}%' for g in j.G)+'|')
report=f'''# B1 V1.2：固定提取框G描述性结果——本轮完成交付

## 当前完成范围
本轮G固定框描述性计算、数据和附录交付已完成：PART1_G_DESCRIPTIVE_DELIVERY_COMPLETED=true。
68政策G估计可复算，G_HT_COMPUTATION_COMPLETED、G_FIXED_FRAME_DESCRIPTIVE_REPORTABLE、G_STAGE_HISTORICAL_DESCRIPTION_AVAILABLE、G_POLICY_ESTIMATE_AVAILABLE均为true。

这套内部研究输出不等待新的用途签署，不要求再审核528/106，不因完整正文或T仍有限制而暂停。当前不是WAITING_FOR_APPROVAL或WAITING_FOR_AUDIT_RETURN。

## 四阶段政策等权G份额
|阶段|G1|G2|G3|
|---|---:|---:|---:|
{chr(10).join(lines)}

HT政策份额、阶段均值、标准误和阶段差与前次冻结结果逐字节/数值核对一致。原DIFF24篇负估计和阶段NA完整保留，没有改标签、调阈值或按原稿择优。G赋值次数分母和68政策等权口径不变。

## 来源如何纳入
68项本地捕获文件均经哈希核验。来源分类：{prov.source_category.value_counts().to_dict()}。
来源清单逐政策列URL、本地载体、发文信息（仅能从正文明确恢复者）、文号、字符引用位置、获取批次日期和哈希。HTML与PDF均可作为条款证据；摘录可支持局部存在，不能证明整篇覆盖。1项网页上下文记录不会伪装成全文验证，本框内原统计仍以对应冻结单元为对象。

955段元数据保留具体原规则；515段未知已归并为{len(groups)}个政策×来源×提取根因组，而非新增人工任务。语境筛查只定位实质例外，不赋G、不填0、不扩展原概率。2017个框内提取风险和1个语义风险与框外区间单列。

## 政策级用途和剩余限制
全部68政策可标DESCRIPTIVE_ESTIMATE_AVAILABLE_WITH_LIMITATIONS，可作固定框的描述性比较。194个政策×功能有正例支持，10个未知，未将缺正例改成不存在。
较宽或为0的设计SE不阻止出表；0经验SE不证明无误差。26个单元/45字段的双编码敏感性、原机器G2误纳/G3漏检全部保留。Taylor区间仅为小样本审核设计近似，不包含编码者语义误差及框外遗漏。
完整政策正文覆盖、政策级精确供给强度仍未获得充分证据，不能把当前G份额直接当第二部分精确行动库存。

## 完成状态
- PART1_G_DESCRIPTIVE_DELIVERY_COMPLETED=true。
- G_FULL_POLICY_BODY_VALIDATED=false。
- G_POLICY_INTENSITY_FORMALLY_SUPPORTED=false。
- FULL_C2_FORMAL_RELEASE_READY=false；PART1_COMPLETED=false（保留完整十字段C2的既有定义）。
- T及机器T2保持原条件性/未知；第二部分继续关闭。

本轮到此结束G描述性交付，不因PART1_COMPLETED=false追加研究流程。正式采用为稿件表图时，可一次明确采用范围绑定最终manifest和方法局限；该事件不追溯证明全文、标签和T可靠。

## 实际QA与文件
本轮12项检查通过，包含真实输入/输出核对及少量隔离的来源分类示例；合成来源例子没有进入研究数据。前轮9项HT数值QA与本轮12项分开记录，不合计冒充本轮新增测试。没有重新训练、新抽样、原判断更改或SD运算。

主要文件：G_POLICY_DESCRIPTIVE_68.csv、G_STAGE_DESCRIPTIVE.csv、G_STAGE_CHANGES_DESCRIPTIVE.csv、G_ESTIMATOR_COMPARISON.csv、G_POLICY_FUNCTION_STATUS_204.csv、G_CODER_DISAGREEMENT_SENSITIVITY.csv、SOURCE_PROVENANCE_AND_COVERAGE.csv、G_RESEARCH_USE_SCOPE_DECISION.json、PART1_G_DELIVERY_MANIFEST.json。
已有PNG/SVG/PDF附录图及图数据沿用同版统计。代码副本、输入/输出哈希、实际日志和METHOD_AND_LIMITATIONS.md随交付保留。

## 已实际执行的命令
在项目根目录：
```powershell
.\\OCMA_empirical_revision_workspace_B1_20261026\\.venv\\Scripts\\python.exe .\\g_descriptive_delivery_20261028.py
.\\OCMA_empirical_revision_workspace_B1_20261026\\.venv\\Scripts\\python.exe .\\test_G_descriptive_delivery_20261028.py
.\\OCMA_empirical_revision_workspace_B1_20261026\\.venv\\Scripts\\python.exe .\\joint528_G_ONLY_execution_20261028.py status
```
第一条重建来源清单；第二条轻量核验；第三条同版刷新当前描述性结果。均不运行SD或训练。短目录为审阅交付，复算仍使用原工作区的固定输入。
'''
(out/'G固定框描述性成果_交付说明.md').write_text(report,'utf-8')
shutil.copyfile(j.ROOT/'finalize_G_descriptive_delivery_20261028.py',out/'code/finalize_G_descriptive_delivery_20261028.py')
j.jsonout(out/'G_DESCRIPTIVE_RUN_LOG.json',dict(completed_at=j.now(),actual_executed=['g_descriptive_delivery_20261028.py','g_estimator_stability_20261028.py','test_G_descriptive_delivery_20261028.py','joint528_G_ONLY_execution_20261028.py status'],QA_passed=12,states=result['assessment']['states'],model_fits=0,new_samples=0,part2_started=False))
d.finalize_manifest(v,out,result)
manifest=j.load(out/'PART1_G_DELIVERY_MANIFEST.json')
j.require(all(j.sha(out/n)==h for n,h in manifest['output_hashes'].items()),'Final output hash mismatch')
j.require(all(j.sha(x['path'])==x['sha256'] for x in manifest['input_hashes']),'Final input hash mismatch')
dest.mkdir(exist_ok=True)
for p in out.rglob('*'):
 if p.is_file():
  t=dest/p.relative_to(out);t.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,t)
j.require(all(j.sha(dest/n)==h for n,h in manifest['output_hashes'].items()),'Copied release hash mismatch')
j.jsonout(short/'G_AUDIT_CURRENT_RESULTS.json',dict(path=str(dest),actual_root=str(out),identity=d.IDENTITY,status=result,
 authoritative_manifest='PART1_G_DELIVERY_MANIFEST.json',manifest_sha256=j.sha(dest/'PART1_G_DELIVERY_MANIFEST.json')))
# Refresh the small handoff pointer after finalizing the exact G release.
import joint528_G_ONLY_execution_20261028 as entry
entry.package()
print(json.dumps(dict(output=str(dest),policy_n=len(rows),states=result['assessment']['states'],input_hashes=len(manifest['input_hashes']),output_hashes=len(manifest['output_hashes'])),ensure_ascii=False))
