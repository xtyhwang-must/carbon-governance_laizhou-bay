"""Final fixed-frame G delivery on the existing run; no new estimates or labels."""
from pathlib import Path
from urllib.parse import urlparse
import ast,hashlib,json,re,shutil,sys
import numpy as np
import pandas as pd
import g_estimator_stability_20261028 as s
j=s.j
IDENTITY='FIXED_FRAME_POST_AUDIT_DESCRIPTIVE_RESULT'
SOURCE_KINDS=['OFFICIAL_DOCUMENT','OFFICIAL_WEB_FULL_TEXT','TRACEABLE_WEB_POLICY_TEXT',
              'VERIFIED_POLICY_EXCERPT','WEB_CONTEXT_ONLY','UNRESOLVED_SOURCE']
REQUIRED=['G_POLICY_DESCRIPTIVE_68.csv','G_STAGE_DESCRIPTIVE.csv','G_STAGE_CHANGES_DESCRIPTIVE.csv',
          'G_ESTIMATOR_COMPARISON.csv','G_POLICY_FUNCTION_STATUS_204.csv','G_CODER_DISAGREEMENT_SENSITIVITY.csv',
          'SOURCE_PROVENANCE_AND_COVERAGE.csv','G_RESEARCH_USE_SCOPE_DECISION.json','METHOD_AND_LIMITATIONS.md']

def classify_source(media,official,role,local_verified,traceable):
 """A verified excerpt supports a bound clause, never whole-document coverage."""
 if role in ['NEWS_INTERPRETATION','NAVIGATION','CONTEXT_ONLY']:return 'WEB_CONTEXT_ONLY'
 if not local_verified:return 'UNRESOLVED_SOURCE'
 if role=='EXCERPT':return 'VERIFIED_POLICY_EXCERPT' if traceable else 'UNRESOLVED_SOURCE'
 if role!='POLICY_TEXT':return 'UNRESOLVED_SOURCE'
 if official and media in ['pdf','doc','docx','scan']:return 'OFFICIAL_DOCUMENT'
 if official and media in ['html','htm']:return 'OFFICIAL_WEB_FULL_TEXT'
 return 'TRACEABLE_WEB_POLICY_TEXT' if traceable else 'UNRESOLVED_SOURCE'

def header_value(text,name):
 x=re.search(r'【'+re.escape(name)+r'】\s*([^【\n]+)',text)
 return x.group(1).strip() if x else ''

def provenance(v,out):
 """Reuse archived local records. No fresh network claim or format-based rejection."""
 registry_path=j.WS/'b1/02_policy/policy_registry.csv';audit_path=j.WS/'b1/02_policy/reconstructed/text_source_audit.csv'
 reg=j.read(registry_path).set_index('policy_id');audit=j.read(audit_path).set_index('policy_id')
 frame=j.read(v/'sampling_frame_BACKEND.csv');impact=j.read(out/'SOURCE_SCOPE_IMPACT_ON_G.csv').set_index('policy_id')
 rows=[];deps=[dict(path=str(p),sha256=j.sha(p)) for p in [registry_path,audit_path]]
 for pid,z in frame.groupby('policy_id',sort=True):
  r=reg.loc[pid];a=audit.loc[pid];clean=j.longpath(z.iloc[0].source_clean_path);text=clean.read_text('utf-8-sig')
  j.require(j.sha(clean)==z.iloc[0].source_clean_sha256==a.clean_text_sha256,'Local source text binding changed')
  raw=j.WS/'b1'/a.body_source_relative_path;exists=raw.exists()
  verified=bool(exists and j.sha(raw)==a.body_source_sha256)
  j.require(not exists or verified,'Captured body source hash conflict')
  url=a.body_source_url or r['原始来源URL'];host=(urlparse(url).hostname or '').lower();official=host=='gov.cn' or host.endswith('.gov.cn')
  media=raw.suffix.lower().lstrip('.')
  # Existing title variants are recorded; they are not silently rejected.
  role='POLICY_TEXT'
  title=a.expected_title
  if re.search(r'政策解读|图解|答记者问|新闻发布',title):role='NEWS_INTERPRETATION'
  if media=='json':role='CONTEXT_ONLY'
  kind=classify_source(media,official,role,verified,bool(url and a.body_source_relation))
  ss=impact.loc[pid];body_complete=False
  uncertainty='SOURCE_BODY_EXTRACTION_NOT_EXHAUSTIVELY_VALIDATED'
  if kind=='WEB_CONTEXT_ONLY':uncertainty='ARCHIVE_IS_CONTEXT;FROZEN_EXTRACTED_TEXT_STILL_REPORTABLE_WITH_LIMITATION'
  issuer=header_value(text,'发布部门');number=header_value(text,'发布文号')
  if not number:
   m=re.search(r'(?m)^([^\n]{0,24}[〔\[]\d{4}[〕\]][^\n]{0,12}号)\s*$',text[:1800]);number=m.group(1) if m else ''
  row=dict(policy_id=pid,stage=z.iloc[0].stage,policy_title=title,issuing_authority=issuer,document_number=number,
   issuing_authority_status='EXPLICIT_IN_SOURCE_HEADER' if issuer else 'NOT_EXPLICITLY_RECOVERED',
   source_category=kind,source_role=role,official_domain_from_record=official,URL=url,
   local_body_path=str(raw),captured_body_sha256=a.body_source_sha256,local_capture_hash_verified=verified,
   clean_text_path=str(clean),clean_text_sha256=j.sha(clean),capture_date=a.capture_batch,
   capture_date_identity='EXISTING_CAPTURE_LEDGER_NOT_NEW_RETRIEVAL',body_source_relation=a.body_source_relation,
   title_head_match_recorded=a.title_head_present,title_variant_is_not_automatic_error=True,
   reference_position='clean character offsets: see existing policy/unit IDs and clean_start:clean_end',
   unit_character_extent=';'.join(str(x) for x in [int(pd.to_numeric(z.clean_start).min()),int(pd.to_numeric(z.clean_end).max())]),
   extracted_unit_n=len(z),statistical_scope='FIXED_EXTRACTED_UNIT_FRAME',
   source_evidence_scope='LOCAL_CAPTURE_POLICY_TEXT' if role=='POLICY_TEXT' else 'CONTEXT_ARCHIVE_PLUS_BOUND_EXTRACTED_UNITS',
   eligible_for_policy_clause_evidence=kind in ['OFFICIAL_DOCUMENT','OFFICIAL_WEB_FULL_TEXT','TRACEABLE_WEB_POLICY_TEXT','VERIFIED_POLICY_EXCERPT'],
   full_body_validated=body_complete,full_body_validation_reason=uncertainty,
   unmapped_span_n=int(ss.unmapped_span_n),metadata_span_n=int(ss.confirmed_metadata_n),
   unresolved_span_n=int(ss.unresolved_span_n),potential_missing_span_n=int(ss.potential_missing_n),
   inframe_source_risk_n=int(ss.inframe_risk_union_n),network_verification='NOT_RECHECKED_THIS_RUN;LOCAL_ARCHIVE_USED',
   descriptive_output_blocked_by_source_format=False,unknown_span_G_value='UNKNOWN_NOT_ZERO')
  rows.append(row);deps.append(dict(path=str(clean),sha256=j.sha(clean)))
  if verified:deps.append(dict(path=str(raw),sha256=j.sha(raw)))
 j.csvout(out/'SOURCE_PROVENANCE_AND_COVERAGE.csv',rows);j.jsonout(out/'source_provenance_inputs.json',deps)
 # Group the 515 unresolved spans by source and common extraction root; no tasks.
 spans=j.read(out/'SOURCE_COVERAGE_ROOT_CAUSE.csv');u=spans[spans.classification.eq('UNRESOLVED_SOURCE_SPAN')].copy()
 def root(text):
  t=re.sub(r'\s','',text)
  if len(t)<=2:return 'ISOLATED_CHARACTER_OR_SYMBOL_CONTEXT_REQUIRED'
  if re.fullmatch(r'[A-Za-z0-9/.,:;=()\[\]_%+\-]+',t):return 'TABLE_FORMULA_OR_EXTRACTION_FRAGMENT'
  return 'MULTICHARACTER_SOURCE_GAP_CONTEXT_REQUIRED'
 u['extraction_root']=u.text.map(root)
 grouped=u.groupby(['policy_id','source_clean_sha256','extraction_root']).agg(span_n=('text','size'),
  examples=('text',lambda x:' | '.join(str(a).strip() for a in x.head(4))),character_n=('text',lambda x:sum(len(str(a)) for a in x))).reset_index()
 grouped['original_sampling_probability']='';grouped['automatic_human_review_required']=False
 j.csvout(out/'UNRESOLVED_SOURCE_GROUPS.csv',grouped)
 # Recover the actual sentence context already captured by prior source repair.
 exc=j.read(out/'POTENTIAL_MISSING_CLAUSE_EXCEPTIONS.csv');flags=[]
 for x in exc.to_dict('records'):
  context=x['recovered_text'];match=bool(re.search(r'保护|修复|污染|排放|监测|预警|湿地|海域|流域|岸线',context) and re.search(r'应当|不得|禁止|实施|开展|建立|负责|治理|控制|防治',context))
  flags.append(dict(policy_id=x['policy_id'],start=x['start'],end=x['end'],source_clean_sha256=x['source_clean_sha256'],
    recovered_start=x['recovered_start'],recovered_end=x['recovered_end'],recovered_text=context,
    review_priority='POSSIBLE_ACTION_CONTEXT;MISSING_ACTION_NOT_PROVEN' if match else 'NO_ACTION_IDENTIFIED_BY_CONTEXT_SCREEN;STILL_UNKNOWN',
    within_existing_sentence_context=True,new_governance_clause_confirmed=False,new_original_528_probability=None,new_G_label=None))
 j.csvout(out/'SOURCE_SUBSTANTIVE_EXCEPTION_SCREEN.csv',flags)
 return pd.DataFrame(rows)

def frozen_numerics_ok(out):
 names=['G_POLICY_HT_TOTALS.csv','G_POLICY_HT_SHARES.csv','G_STAGE_HT_ESTIMATES.csv','G_STAGE_HT_CHANGES.csv']
 return all(j.sha(out/n)==j.sha(out/'before_G_descriptive_delivery'/n) for n in names)

def research_evidence(v,out,hs,hg,impact):
 frame=j.read(v/'sampling_frame_BACKEND.csv');sample=j.read(v/'sample/actual_sample_BACKEND.csv');a,b=s.actual_returns(v)
 sm=j.load(v/'sample/sample_manifest.json')
 identity=bool(set(a.unit_id)==set(sample.unit_id) and len(b)==int(sm['second_coder_n']) and all(j.sha(v/'sample'/n)==h for n,h in sm['files'].items()))
 binding=all(j.sha(d['path'])==d['sha256'] for d in j.load(v/'G_ONLY_INPUT_BINDING.json')['dependencies'])
 # The estimator bytes/formula have not changed; use actual previous numeric QA
 # only together with byte-identical count/share outputs and original input hashes.
 oldqa=j.load(out/'before_G_descriptive_delivery/QA.json')
 numeric=bool(oldqa['all_passed'] and frozen_numerics_ok(out) and binding)
 legal=bool(hs.design_corrected_share.notna().all() and hs.groupby('policy_id').design_corrected_share.sum().sub(1).abs().lt(1e-10).all())
 consistent=bool(hs.policy_id.nunique()==frame.policy_id.nunique()==68 and hg.stage.nunique()==4)
 for (stage,label),z in hs.groupby(['stage','label']):
  val=hg[hg.stage.eq(stage)&hg.label.eq(label)].iloc[0].design_corrected_share
  consistent=bool(consistent and np.isclose(z.design_corrected_share.mean(),val,atol=1e-12,rtol=0))
 prov=j.read(out/'SOURCE_PROVENANCE_AND_COVERAGE.csv')
 deliveryqa=j.load(out/'G_DELIVERY_QA.json') if (out/'G_DELIVERY_QA.json').exists() else {}
 qa_ok=bool(deliveryqa.get('all_passed',False) and all(j.sha(j.ROOT/n)==h for n,h in deliveryqa.get('code_sha256',{}).items()))
 files=[out/n for n in ['G_POLICY_HT_SHARES.csv','G_STAGE_HT_ESTIMATES.csv','SOURCE_PROVENANCE_AND_COVERAGE.csv','G_ERROR_SOURCE_DECOMPOSITION.csv','G_CODER_DISAGREEMENT_SENSITIVITY.csv']]
 e=dict(assessment_identity='FIXED_FRAME_DESCRIPTIVE_SCOPE_ASSESSMENT',statistical_population='FIXED_EXTRACTED_UNIT_FRAME',
  sample_identity_verified=bool(identity and binding),HT_numerically_verified=numeric,policy_stage_definitions_consistent=consistent,
  limitations_disclosed=(out/'G_ERROR_SOURCE_DECOMPOSITION.csv').exists() and (out/'G_CODER_DISAGREEMENT_SENSITIVITY.csv').exists(),
  HT_computation_complete=bool(legal and consistent),policy_estimates_defined=legal,stage_estimates_defined=bool(hg.design_corrected_share.notna().all()),
  full_body_validated=bool(prov.full_body_validated.eq('True').all()),formal_intensity_supported=False,
  full_C2_formal_release_ready=False,formal_manuscript_adoption=False,
  descriptive_files_complete=all((out/n).exists() for n in REQUIRED),delivery_QA_passed=qa_ok,
  limitations=['POST_AUDIT_HT_RATIO_NOT_STRICTLY_UNBIASED','TAYLOR_AUDIT_DESIGN_APPROX;N2_STRATA',
   'SEMANTIC_CODER_DIFFERENCE_AND_OUT_OF_FRAME_OMISSIONS_NOT_IN_TAYLOR_INTERVAL',
   'FIXED_PRIOR_EVIDENCE_ASSUMED_VALID','ZERO_EMPIRICAL_SE_NOT_ZERO_ERROR','NOT_PRECISE_POLICY_ACTION_STOCK',
   'T2_MACHINE_UNKNOWN;FULL_T_CONFIGURATION_CONDITIONAL'],
  evidence_files=[dict(path=str(p),sha256=j.sha(p)) for p in files],defined_policy_n=int(hs.design_corrected_share.notna().groupby(hs.policy_id).all().sum()))
 # A single optional adoption event covers the exact release; never a gate to
 # internal descriptive output. No human-entered SHA values are necessary.
 event=v.root/'G_FORMAL_DESCRIPTIVE_ADOPTION.json'
 if event.exists():
  x=j.load(event);j.signed(x,'ADOPT_EXACT_G_FIXED_FRAME_DESCRIPTIVE_RELEASE','REAL')
  manifest=out/'PART1_G_DELIVERY_MANIFEST.json'
  e['formal_manuscript_adoption']=bool(manifest.exists() and x.get('manifest_sha256')==j.sha(manifest) and x.get('scope')=='FIXED_EXTRACTED_UNIT_FRAME')
 j.jsonout(out/'research_evidence.json',e);return e

def applicability(v,out,hs,ht,impact,e):
 presence=j.read(out/'frozen_before_patch/G_POLICY_FUNCTION_STATUS_204.csv');prov=j.read(out/'SOURCE_PROVENANCE_AND_COVERAGE.csv').set_index('policy_id')
 swap=j.read(out/'G_POLICY_HT_SECONDARY_SWAP.csv');fields=j.read(out/'G_CODER_DISAGREEMENT_FIELD_LOG.csv');a,b=s.actual_returns(v)
 rows=[]
 for pid,z in hs.groupby('policy_id',sort=True):
  tt=ht[ht.policy_id.eq(pid)].set_index('feature');ss=prov.loc[pid]
  valid=bool(z.design_corrected_share.notna().all() and np.isclose(z.design_corrected_share.sum(),1))
  known=presence[presence.policy_id.eq(pid)];changes=fields[fields.unit_id.str.startswith(pid+'__')]
  frozen_only=int(tt.iloc[0].sample_n)==0
  # Formal support requires verified complete scope and census-quality true
  # evidence, rather than an invented SE cutoff. Most policies are descriptive.
  formal=bool(ss.full_body_validated=='True' and frozen_only and known.function_presence_status.eq('SUPPORTED_WITHIN_BOUND_UNIT_SCOPE').all())
  flags=['POST_AUDIT_HT_RATIO','TAYLOR_DESIGN_APPROX_NOT_SEMANTIC_OR_SOURCE_ERROR']
  if z.standard_error.eq(0).any():flags.append('ZERO_EMPIRICAL_SE_NOT_PROOF_OF_ZERO_RISK')
  if int(tt.iloc[0].sample_n)>0:flags.append('N2_STRATA;FINITE_SAMPLE_RATIO')
  if int(ss.unresolved_span_n)>0:flags.append('UNRESOLVED_OUT_OF_FRAME_SOURCE_SPANS')
  if len(changes):flags.append('ACTUAL_CODER_DISAGREEMENT')
  r=dict(policy_id=pid,stage=z.iloc[0].stage,result_identity=IDENTITY,statistical_population='FIXED_EXTRACTED_UNIT_FRAME',
   HT_estimate_defined=valid,descriptive_result_reportable=bool(valid and e['sample_identity_verified'] and e['HT_numerically_verified']),
   descriptive_status='DESCRIPTIVE_ESTIMATE_AVAILABLE_WITH_LIMITATIONS' if valid else 'UNDEFINED_ESTIMATE',
   assignment_denominator=z.iloc[0].assignment_denominator,eligibility_HT_total=tt.loc['eligibility','estimated_total'],
   eligibility_HT_SE=tt.loc['eligibility','standard_error'],fixed_evidence_n=int(tt.iloc[0].fixed_evidence_n),sample_n=int(tt.iloc[0].sample_n),
   independent_second_coder_n=int(b.unit_id.str.startswith(pid+'__').sum()),disagreement_fields=len(changes),disagreement_units=changes.unit_id.nunique(),
   source_category=ss.source_category,source_text_hash=ss.clean_text_sha256,full_policy_body_validated=ss.full_body_validated,
   source_unresolved_spans=int(ss.unresolved_span_n),source_inframe_risk_units=int(ss.inframe_source_risk_n),
   full_policy_intensity_formally_supported=formal,policy_intensity_status='FORMALLY_SUPPORTED_WITHIN_BOUND_SCOPE' if formal else 'DESCRIPTIVE_NOT_PRECISE_FULL_POLICY_ACTION_STOCK',
   formal_manuscript_adoption=e['formal_manuscript_adoption'],known_absence=False,full_C2_release=False,limitations=';'.join(flags))
  for g in j.G:
   q=z[z.label.eq(g)].iloc[0];other=swap[swap.policy_id.eq(pid)&swap.label.eq(g)].iloc[0]
   pr=known[known.G.eq(g)].iloc[0]
   r.update({g+'_HT_total':tt.loc[g,'estimated_total'],g+'_HT_total_SE':tt.loc[g,'standard_error'],
    g+'_HT_share':q.design_corrected_share,g+'_HT_share_SE':q.standard_error,
    g+'_presence':pr.function_presence_status,g+'_confirmed_absent':False,
    g+'_second_coder_swap_share':other.design_corrected_share,
    g+'_coder_sensitivity_difference':pd.to_numeric(other.design_corrected_share,errors='coerce')-q.design_corrected_share})
  rows.append(r)
 df=pd.DataFrame(rows);j.csvout(out/'G_POLICY_DESCRIPTIVE_68.csv',df);j.csvout(out/'G_POLICY_INPUT_APPLICABILITY_68.csv',df);j.csvout(v/'G_POLICY_INPUT_APPLICABILITY_68.csv',df)
 return df

def publish_existing_results(v,out,result):
 """One current-run descriptive release. HT/DIFF inputs remain byte-identical."""
 stage=j.read(out/'G_STAGE_HT_ESTIMATES.csv');changes=j.read(out/'G_STAGE_HT_CHANGES.csv')
 for name,df in [('G_STAGE_DESCRIPTIVE.csv',stage),('G_STAGE_CHANGES_DESCRIPTIVE.csv',changes)]:
  df['result_identity']=IDENTITY;df['statistical_population']='FIXED_EXTRACTED_UNIT_FRAME'
  df['uncertainty_identity']='TAYLOR_AUDIT_DESIGN_APPROX;EXCLUDES_SEMANTIC_CODER_AND_SOURCE_OMISSIONS';j.csvout(out/name,df)
 shutil.copyfile(out/'frozen_before_patch/G_POLICY_FUNCTION_STATUS_204.csv',out/'G_POLICY_FUNCTION_STATUS_204.csv')
 j.jsonout(out/'G_RESEARCH_USE_SCOPE_DECISION.json',result['assessment'])
 text='''# 固定提取框G描述性结果：方法与局限

本交付为FIXED_FRAME_POST_AUDIT_DESCRIPTIVE_RESULT。估计对象是已冻结32,858个原分析单元中的资格/G赋值；2,244条既有完整证据视为固定有效，30,614条概率域按原264层、528主审计算HT。106第二编码用于一致性及分歧替换敏感性。原人工、原C2与模型未改。

政策份额以G1—G3赋值次数总量归一；复合句、多标签保留。阶段先政策内再政策等权，68政策及四阶段不变。HT是看到原DIFF失败后引入的事后估计器敏感性；原DIFF24篇负估计、44篇可定义比例与阶段NA保留。HT比率不是严格无偏。

Taylor区间仅为编码审核设计的正态近似，每层n=2；不包含编码者语义差异、固定旧证据潜在错误或框外遗漏。标准误较宽或为0不阻止描述性输出，0经验SE不证明真实零风险。点排序不是显著排序；原政策Bootstrap不混入本轮区间。

官方PDF、政府政策HTML、官方附件、可追溯转载和有条款定位的可信摘录均可成为来源证据；网页解读/导航仅是上下文。局部摘录支持条款存在，不证明政策正文全部进入抽样框。来源清单标记实际本地捕获、URL、来源位置与哈希；本轮未声称重新联网核实。完整PDF不是输出前置条件。

未映射区间955段已按具体规则识别为元数据，515段仍未知；按来源和共同提取根因归并，不填0、不自动要求逐条人审。框内2017个提取风险单元与1个语义规则单元单列，不能和框外区间相加成行动数。框外恢复内容没有继承原528概率，也未增加或覆盖原ID。

194个政策×功能有绑定正例，10个仍未知，不得将未观察到正例改成不存在。四阶段及逐政策HT估计可作有上述限制的描述性比较，不能直接称第二部分的精确政策行动供给库存。45字段/26单元的实际编码者替换敏感性完整保留。

本轮协议授权自动内部描述性报告；正式将其作为稿件研究表图时可通过一次明确范围的真实采用事件绑定最终manifest、政策/阶段份额和本说明。内部输出不等待这一采用事件。采用本交付不证明逐条机器正确、全文无遗漏、政策强度精确或完整T配置可靠。

T及机器T2保持原条件性/未知身份。PART1_G_DESCRIPTIVE_DELIVERY_COMPLETED与完整十字段C2定义的PART1_COMPLETED分开；第二部分继续关闭。
'''
 (out/'METHOD_AND_LIMITATIONS.md').write_text(text,'utf-8')
 # Recompute delivery completeness after all descriptive files exist.
 e=research_evidence(v,out,j.read(out/'G_POLICY_HT_SHARES.csv').assign(design_corrected_share=lambda x:pd.to_numeric(x.design_corrected_share)),
   j.read(out/'G_STAGE_HT_ESTIMATES.csv').assign(design_corrected_share=lambda x:pd.to_numeric(x.design_corrected_share)),j.read(out/'SOURCE_SCOPE_IMPACT_ON_G.csv'))
 # The typed path avoids interpreting strings/empty cells as booleans.
 e['policy_stage_definitions_consistent']=bool(e['policy_stage_definitions_consistent'])
 decision=j.assess_research_use(e);j.jsonout(out/'G_RESEARCH_USE_SCOPE_DECISION.json',decision)
 j.jsonout(out/'G_RESEARCH_USE_ASSESSMENT_UPDATED.json',decision)
 result['assessment']=decision;result.update(status='FIXED_FRAME_G_DESCRIPTIVE_RESULTS_DELIVERED' if decision['states']['PART1_G_DESCRIPTIVE_DELIVERY_COMPLETED'] else 'FIXED_FRAME_G_DESCRIPTIVE_OUTPUTS_CREATED_QA_PENDING')
 j.jsonout(out/'PART1_EXECUTION_STATUS.json',result)
 code=out/'code';code.mkdir(exist_ok=True)
 for name in ['joint_history_audit_20261028.py','joint528_G_ONLY_execution_20261028.py','joint528_compact_20261028.py','g_estimator_stability_20261028.py','g_descriptive_delivery_20261028.py','test_G_descriptive_delivery_20261028.py']:
  shutil.copyfile(j.ROOT/name,code/name)
 finalize_manifest(v,out,result)

def finalize_manifest(v,out,result):
 """Commit the authoritative G manifest after execution logs have been saved."""
 files={str(p.relative_to(out)):j.sha(p) for p in out.rglob('*') if p.is_file() and 'before_G_descriptive_delivery' not in p.parts and 'frozen_before_patch' not in p.parts and p.name not in ['PART1_G_DELIVERY_MANIFEST.json','delivery_manifest.json']}
 inputs=j.load(v/'G_ONLY_INPUT_BINDING.json')['dependencies']+j.load(out/'source_provenance_inputs.json')
 # Preserve every actual review event and batch signature as an input dependency.
 inputs += [dict(path=str(p),sha256=j.sha(p)) for p in (v.root/'returns').rglob('*') if p.is_file()]
 j.jsonout(out/'PART1_G_DELIVERY_MANIFEST.json',dict(identity=IDENTITY,statistical_population='FIXED_EXTRACTED_UNIT_FRAME',
  input_hashes=inputs,output_hashes=files,code_sha256={n:j.sha(j.ROOT/n) for n in ['joint_history_audit_20261028.py','g_estimator_stability_20261028.py','g_descriptive_delivery_20261028.py']},
  states=result['assessment']['states'],model_fits=0,new_samples=0,part2_started=False))

def prepare_sources():
 ctx,parent,v,out=s.locations();prov=provenance(v,out)
 print(json.dumps(dict(source_categories=prov.source_category.value_counts().to_dict(),policies=len(prov),local_captures_verified=int(prov.local_capture_hash_verified.sum())),ensure_ascii=False))

if __name__=='__main__':prepare_sources()
