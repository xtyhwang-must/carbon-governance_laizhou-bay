"""Read blind XLSX returns, restore only reversible display characters, then use
the approved joint-audit importer. No prediction, training or C2 adoption.
"""
from pathlib import Path
import argparse,re,shutil,json
from openpyxl import load_workbook
import joint_history_audit_20261028 as j

BAD=re.compile(r'[\x00-\x08\x0b\x0c\x0e-\x1f]')
def display(v):return BAD.sub(lambda m:f'⟦U+{ord(m.group()):04X}⟧',v)
PROTECTED=['unit_id','policy_id','policy_version_id','stage','reading_id','exact_evidence_text','reading_text','source_location','clean_start','clean_end','source_hash','source_clean_sha256','requested_fields']

def recover(file):
 ctx,d=j.ctx_and_dir();book=load_workbook(file,read_only=True,data_only=False)
 batch={str(r[0]):r[1] for r in list(book['BATCH_INFO'].values)[1:] if r and r[0]}
 book.close();role=str(batch.get('coder_role',''));j.require(role in ['PRIMARY','SECONDARY'],'Registered coder role missing')
 sm=j.load(d/'sample/sample_manifest.json');j.require(all(j.sha(d/'sample'/n)==h for n,h in sm['files'].items()),'Frozen sample/template changed')
 j.require(str(batch.get('protocol_sha256',''))==j.sha(d/'joint_audit_protocol.json'),'Workbook protocol changed')
 raw=j.read_review(file);j.require(raw.unit_id.is_unique,'Duplicate review IDs')
 template=j.read(d/'sample'/f'registered_{role}_TEMPLATE.csv');ti=template.set_index('unit_id')
 j.require(set(raw.unit_id)<=set(template.unit_id),'Outside approved sample')
 restored=raw.copy();encoded=0
 for i,row in raw.iterrows():
  for k in PROTECTED:
   expected=row.unit_id if k=='unit_id' else ti.loc[row.unit_id,k]
   j.require(str(row[k])==display(str(expected)),'Protected text/location changed: '+row.unit_id+' '+k)
   if str(expected)!=display(str(expected)):encoded+=1
   restored.loc[i,k]=expected
 return ctx,d,restored,batch,dict(role=role,returned_rows=len(raw),registered_rows=len(template),encoded_source_fields_restored=encoded,protected_fields_verified=True)

def main():
 p=argparse.ArgumentParser();p.add_argument('workbook');p.add_argument('--verify-only',action='store_true');p.add_argument('--evaluate',action='store_true');a=p.parse_args()
 file=Path(a.workbook);ctx,d,rows,batch,qa=recover(file)
 if a.verify_only:print(json.dumps(dict(verification_only=True,actual_judgments_ingested=0,**qa),ensure_ascii=False));return
 j.require(batch.get('confirmation')=='CONFIRM_ACTUAL_JOINT_INDEPENDENT_AUDIT','Actual batch confirmation required')
 j.require(str(batch.get('reviewer') or '').strip() and str(batch.get('completed_at') or '').strip(),'Actual reviewer/completion time required')
 rawsha=j.sha(file);archive=d/'workbook_returns'/rawsha
 archive.mkdir(parents=True,exist_ok=True)
 canonical=archive/'actual_return_registered_text.csv';sigpath=archive/'actual_signature.json'
 j.csvout(canonical,rows)
 signature=dict(statement=batch['confirmation'],identity='REAL',reviewer=str(batch['reviewer']),signed_at=str(batch['completed_at']),
  coder_role=qa['role'],batch_id='JOINT600_'+qa['role']+'_'+rawsha[:12],review_sha256=j.sha(canonical),
  source_workbook_sha256=rawsha,protocol_sha256=j.sha(d/'joint_audit_protocol.json'),
  time_semantics='Author-supplied actual batch completion time, not synthetic row times',
  presentation_adapter='REVERSIBLE_XML_CONTROL_DISPLAY_V1;protected_text_verified_then_restored_from_registered_template;human_fields_unchanged')
 j.jsonout(sigpath,signature);shutil.copyfile(file,archive/'actual_workbook.xlsx')
 j.jsonout(archive/'display_restoration_QA.json',qa)
 receipt=j.ingest(ctx,d,canonical,sigpath)
 result=dict(import_result=receipt,source_workbook_sha256=rawsha)
 if a.evaluate:result['evaluation']=j.evaluate(ctx,d)
 print(json.dumps(j.clean_json(result),ensure_ascii=False))

if __name__=='__main__':main()
