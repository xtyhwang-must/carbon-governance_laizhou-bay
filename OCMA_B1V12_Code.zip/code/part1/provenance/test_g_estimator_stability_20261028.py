"""Independent enumerations and real-data arithmetic; no synthetic review import."""
from itertools import combinations
import json,math
import numpy as np
import pandas as pd
import g_estimator_stability_20261028 as s
j=s.j;ctx,parent,v,out=s.locations();results=[]
def check(name,identity,fn):
 try:fn();results.append(dict(name=name,identity=identity,status='PASS'))
 except (AssertionError,ValueError,KeyError,TypeError) as e:results.append(dict(name=name,identity=identity,status='FAIL',error=repr(e)))
frame=j.read(v/'sampling_frame_BACKEND.csv');sample=j.read(v/'sample/actual_sample_BACKEND.csv');actual,second=s.actual_returns(v)
alloc=j.read(v/('allocation_'+j.load(v/'sample/sample_manifest.json')['option']+'.csv'))
ht=j.read(out/'G_POLICY_HT_TOTALS.csv');cov=j.read(out/'G_POLICY_HT_COVARIANCE.csv')
def frozen():
 assert len(actual)==528 and len(second)==106 and actual.unit_id.is_unique and second.unit_id.is_unique
 assert all(j.sha(r['path'])==r['sha256'] for r in j.load(v/'G_ONLY_INPUT_BINDING.json')['dependencies'])
 assert all(j.sha(out/'frozen_before_patch'/n)==h for n,h in j.load(out/'frozen_manifest.json').items())
 for n in ['DESIGN_ASSISTED_TOTALS.csv','G_POLICY_AUDIT_CORRECTION.csv','G_STAGE_AUDIT_CORRECTION.csv','G_STAGE_CHANGE_AUDIT_CORRECTION.csv']:
  assert j.sha(v/n)==j.sha(out/'frozen_before_patch'/n)
def independent_HT():
 fixed=frame[frame.existing_fields_to_reuse.ne('')];assert len(fixed)==2244
 assert not set(fixed.unit_id)&set(sample.unit_id)
 f=frame.set_index('unit_id');a=actual.set_index('unit_id');w=sample.set_index('unit_id').design_weight.astype(float)
 comparisons=[]
 for pid,z in frame.groupby('policy_id'):
  uu=z[z.existing_fields_to_reuse.eq('')].unit_id;ids=sample.loc[sample.unit_id.isin(uu),'unit_id']
  ff=fixed[fixed.policy_id.eq(pid)]
  for k in ['eligibility']+j.G:
   known=pd.to_numeric(ff['C2_'+k])*(1 if k=='eligibility' else pd.to_numeric(ff.C2_eligibility))
   observed=pd.to_numeric(a.loc[ids,k])*(1 if k=='eligibility' else pd.to_numeric(a.loc[ids,'eligibility']))
   independent=known.sum()+np.dot(w.loc[ids],observed)
   production=float(ht[ht.policy_id.eq(pid)&ht.feature.eq(k)].iloc[0].estimated_total)
   assert abs(independent-production)<1e-8 and production>=0
   comparisons.append(dict(policy_id=pid,feature=k,independent_total=independent,production_total=production,absolute_difference=abs(independent-production)))
 j.csvout(out/'QA_independent_HT_totals.csv',comparisons)
def enumerate_known_population():
 pop=np.array([[1,1,0,0],[1,0,1,0],[1,0,0,1],[0,0,0,0]],float)
 fixed=np.array([1,0,1,0.]);N=4;n=2;est=[];vars=[]
 for ids in combinations(range(N),n):
  y=pop[list(ids)]
  frows=[dict(unit_id='fixed',policy_id='P',stage='test',existing_fields_to_reuse=';'.join(j.LABELS),**{'C2_'+k:int(fixed[ii]) if ii<4 else 0 for ii,k in enumerate(j.LABELS)})]
  frows += [dict(unit_id=str(i),policy_id='P',stage='test',existing_fields_to_reuse='') for i in range(N)]
  sam=pd.DataFrame([dict(unit_id=str(i),policy_id='P',stratum_id='H',statistical_identity='JOINT_STRATIFIED_SRSWOR',inclusion_probability=n/N,design_weight=N/n) for i in ids])
  aud=pd.DataFrame([dict(unit_id=str(i),source_membership='IN_TARGET',unit_validity='VALID_SENTENCE_OR_CLAUSE',**{k:int(pop[i,ii]) for ii,k in enumerate(['eligibility']+j.G)}) for i in ids])
  al=pd.DataFrame([dict(policy_id='P',stratum_id='H',N=N,sample_n=n)])
  m,_=j.estimate_direct_stratified_HT(pd.DataFrame(frows),sam,aud,al)
  production_total,production_cov=m['P'][:2]
  assert np.allclose(production_total,fixed+N/n*y.sum(axis=0))
  assert np.allclose(production_cov,N*N*(1-n/N)*np.cov(y,rowvar=False,ddof=1)/n)
  est.append(production_total);vars.append(production_cov)
 truth=fixed+pop.sum(axis=0);est=np.array(est)
 assert np.allclose(est.mean(axis=0),truth)
 actualcov=np.cov(est,rowvar=False,ddof=0)
 assert np.allclose(np.mean(vars,axis=0),actualcov)
 # Ratio of unbiased totals is not generally unbiased; document actual example.
 ratios=est[:,1:]/est[:,1:].sum(axis=1)[:,None];true_ratio=truth[1:]/truth[1:].sum()
 assert not np.allclose(ratios.mean(axis=0),true_ratio)
 j.jsonout(out/'QA_finite_population_enumeration.json',dict(identity='SYNTHETIC_ENUMERATION_NOT_RESEARCH_DATA',all_six_samples=True,
  count_totals_unbiased=True,covariance_estimator_unbiased=True,ratio_mean=ratios.mean(axis=0).tolist(),population_ratio=true_ratio.tolist(),ratio_not_unbiased=True))
def independent_covariance():
 a=actual.set_index('unit_id');f=frame.set_index('unit_id')
 for pid,z in frame.groupby('policy_id'):
  matrix=np.zeros((4,4))
  for r in alloc[alloc.policy_id.eq(pid)].itertuples():
   ids=sample[sample.stratum_id.eq(r.stratum_id)].unit_id;N=int(r.N);n=int(r.sample_n)
   ys=[]
   for uid in ids:
    elig=int(a.loc[uid,'eligibility']);ys.append([elig]+[elig*int(a.loc[uid,g]) for g in j.G])
   ys=np.array(ys,float);center=ys-ys.mean(axis=0)
   if n<N:matrix+=N*N*(1-n/N)*(center.T@center)/(n*(n-1))
  for i,k in enumerate(['eligibility']+j.G):
   for ii,kk in enumerate(['eligibility']+j.G):
    val=float(cov[cov.policy_id.eq(pid)&cov.feature_1.eq(k)&cov.feature_2.eq(kk)].iloc[0].covariance)
    assert math.isclose(val,matrix[i,ii],abs_tol=1e-7,rel_tol=1e-11)
def no_false_absence():
 x=j.read(out/'G_POLICY_INPUT_APPLICABILITY_68.csv');assert x.known_absence.eq('False').all()
 p=j.read(out/'frozen_before_patch/G_POLICY_FUNCTION_STATUS_204.csv')
 assert p.function_presence_status.eq('SUPPORTED_WITHIN_BOUND_UNIT_SCOPE').sum()==194
 assert p.function_presence_status.ne('SUPPORTED_WITHIN_BOUND_UNIT_SCOPE').sum()==10
def different_coders():
 x=j.read(out/'G_CODER_DISAGREEMENT_FIELD_LOG.csv');assert len(x)==45 and x.unit_id.nunique()==26
 assert set(x.unit_id)<=set(second.unit_id)
 z=j.read(out/'G_CODER_DISAGREEMENT_SENSITIVITY.csv');assert z.identity.eq('CODER_DISAGREEMENT_SENSITIVITY_NOT_CONSENSUS').all()
 assert not z[z.level.eq('POLICY_TOTAL')&z.estimator.eq('HT')].secondary_disagreement_swap.eq('').any()
def source_rules():
 x=j.read(out/'SOURCE_COVERAGE_ROOT_CAUSE.csv');assert len(x)==1470 and x.policy_id.nunique()==53
 assert set(x.classification)<=set(['CONFIRMED_NON_TARGET_METADATA','ALREADY_COVERED_BY_VALID_SOURCE_UNIT','POTENTIAL_MISSING_GOVERNANCE_CLAUSE','UNRESOLVED_SOURCE_SPAN'])
 assert x.original_probability.eq('').all()
 assert x[x.classification.eq('UNRESOLVED_SOURCE_SPAN')].not_automatic_G_label.eq('True').all()
 assert x[x.classification.eq('CONFIRMED_NON_TARGET_METADATA')].evidence_rule.ne('').all()
 y=j.read(out/'SOURCE_SCOPE_IMPACT_ON_G.csv');assert pd.to_numeric(y.extraction_scope_unresolved_units).sum()==2017
 assert pd.to_numeric(y.semantic_rule_unresolved_units).sum()==1
def no_T_or_full_release():
 assert all(actual[t].eq('').all() and second[t].eq('').all() for t in j.T)
 result=j.load(out/'G_RESEARCH_USE_ASSESSMENT_UPDATED.json');assert result['descriptive_G_statistics_available']
 assert not result['states']['RESEARCH_USE_SCOPE_ACCEPTED'] and not result['states']['C2_FORMAL_RELEASE_READY'] and not result['states']['PART1_COMPLETED']
 assert result['states']['POLICY_G_INTENSITY_SUPPORTED']!='SUPPORTED'
def ratios_stages():
 x=j.read(out/'G_POLICY_HT_SHARES.csv');assert len(x)==204 and x.design_corrected_share.ne('').all()
 assert np.allclose(x.assign(value=pd.to_numeric(x.design_corrected_share)).groupby('policy_id').value.sum(),1)
 for stage,z in x.groupby('stage'):
  for label,zz in z.groupby('label'):
   stagefile=j.read(out/'G_STAGE_HT_ESTIMATES.csv');r=stagefile[stagefile.stage.eq(stage)&stagefile.label.eq(label)].iloc[0]
   assert math.isclose(float(r.design_corrected_share),pd.to_numeric(zz.design_corrected_share).mean(),abs_tol=1e-12)
 checkdiff=j.read(out/'frozen_before_patch/G_POLICY_AUDIT_CORRECTION.csv');assert checkdiff[checkdiff.negative_total_not_clipped.eq('True')].policy_id.nunique()==24
for name,kind,fn in [('frozen_roster_inputs_and_DIFF','REAL_READ_ONLY',frozen),('independent_count_HT_272','REAL_INDEPENDENT_RECALCULATION',independent_HT),
 ('known_population_HT_covariance_and_ratio','SYNTHETIC_EXHAUSTIVE_ENUMERATION',enumerate_known_population),('n2_covariance_1088_cells','REAL_INDEPENDENT_RECALCULATION',independent_covariance),
 ('zero_not_confirmed_G0','REAL_RESULT_CHECK',no_false_absence),('45_fields_26_units_no_consensus','REAL_SENSITIVITY_CHECK',different_coders),
 ('source_span_rules_and_disjoint_identities','REAL_SOURCE_CHECK',source_rules),('T_unknown_and_no_automatic_release','REAL_SCOPE_CHECK',no_T_or_full_release),
 ('policy_normalization_and_equal_weight_stages','REAL_INDEPENDENT_RECALCULATION',ratios_stages)]:check(name,kind,fn)
report=dict(results=results,all_passed=all(r['status']=='PASS' for r in results),passed=sum(r['status']=='PASS' for r in results),failed=sum(r['status']=='FAIL' for r in results),
 synthetic_data_imported=0,model_fits=0,new_samples=0,code_sha256={n:j.sha(j.ROOT/n) for n in ['joint_history_audit_20261028.py','g_estimator_stability_20261028.py','test_g_estimator_stability_20261028.py']})
j.jsonout(out/'QA.json',report);print(json.dumps(report,ensure_ascii=False))
if not report['all_passed']:raise SystemExit(1)
