"""Read-only real-return QA and isolated importer negative tests; no invented labels committed."""
from pathlib import Path
from unittest.mock import patch
import copy,json
import joint528_compact_20261028 as c

ROOT=Path(__file__).parent/'outputs/JOINT_528_ac6da323683e5609'
FILES=[ROOT/'JOINT_528_G_ONLY_主审填写.xlsx',ROOT/'JOINT_528_G_ONLY_第二编码_01简表.xlsx']
results=[]
def check(name,identity,fn):
 try:fn();results.append(dict(test=name,identity=identity,status='PASS'))
 except Exception as e:results.append(dict(test=name,identity=identity,status='FAIL',error=repr(e)))
def real():
 for f,n in zip(FILES,[528,106]):
  p,q=c.g_only_xlsx_payload(f)
  assert q['roster_n']==q['touched_n']==n and q['blank_n']==0
  assert all(all(r['human_'+k] in ['0','1'] for k in ['eligibility']+c.j.G) for r in p['records'])
  assert len(p['completed_at'])==10 and p['completed_at_original']
def modified(case):
 b=c.load_workbook(FILES[1],read_only=True);sheets={s:list(b[s].values) for s in b.sheetnames};b.close()
 sheets=copy.deepcopy(sheets)
 if case=='substantive':
  r=list(sheets['阅读原文'][1]);r[3]+='新增实体文字';sheets['阅读原文'][1]=tuple(r)
 elif case=='target':
  r=list(sheets['审核填写'][1]);r[1]+='改变目标';sheets['审核填写'][1]=tuple(r)
 elif case=='duplicate':sheets['审核填写'][2]=sheets['审核填写'][1]
 elif case=='whitespace':
  r=list(sheets['阅读原文'][1]);r[3]='\n'+r[3]+'\n';sheets['阅读原文'][1]=tuple(r)
 class Sheet:
  def __init__(self,v):self.values=v
 class Book:
  sheetnames=list(sheets)
  def __getitem__(self,k):return Sheet(sheets[k])
  def close(self):pass
 with patch.object(c,'load_workbook',return_value=Book()):
  if case=='whitespace':
   p,q=c.g_only_xlsx_payload(FILES[1]);assert q['roster_n']==106 and q['presentation_changes'];return
  try:c.g_only_xlsx_payload(FILES[1])
  except ValueError:return
  raise AssertionError('Changed protected content accepted')
def blanks():
 p,q=c.g_only_xlsx_payload(FILES[1]);r=next(x for x in p['records'] if x['human_eligibility']=='1')
 n,e=c.j.normalize_truth(c.pd.DataFrame([r]),review_scope='G_ONLY')
 assert n.empty and len(e)==1 and e.iloc[0].reason=='unit/source judgment missing'
 assert all(r['human_'+k] in ['0','1'] for k in c.j.G)
check('real_rosters_fields_and_date_format','REAL_RETURN_READ_ONLY',real)
for case in ['substantive','target','duplicate','whitespace']:check(case,'SYNTHETIC_IN_MEMORY_NOT_RESEARCH_DATA',lambda case=case:modified(case))
check('blank_scope_does_not_become_approval','REAL_RETURN_READ_ONLY',blanks)
_,v=c.g_only_view();out=v.root/'actual_two_coder_return_20261028';report=dict(results=results,passed=sum(r['status']=='PASS' for r in results),failed=sum(r['status']=='FAIL' for r in results),synthetic_judgments_imported=0)
c.j.jsonout(out/'actual_return_QA.json',report);print(json.dumps(report,ensure_ascii=False))
if report['failed']:raise SystemExit(1)
