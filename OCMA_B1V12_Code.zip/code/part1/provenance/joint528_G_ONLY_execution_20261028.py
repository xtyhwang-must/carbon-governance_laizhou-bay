"""Authorized A continuation. One blind HTML, fixed IDs, incremental G estimates."""
import argparse,difflib,json,shutil,sys
from pathlib import Path
import pandas as pd
import joint_history_audit_20261028 as j
import joint528_compact_20261028 as c

SCOPE_HASH='b834784e5cc336396acceb1657446c5583978ddde58974b7bd4aa7a8b6708653'
INSTRUCTION=Path('C:/Users/Mario/.codex/attachments/27c2b36a-de4c-431f-aaf6-19eb69966d16/已粘贴的文本.txt')
ENTRY=j.ROOT/'outputs/JOINT_528_ac6da323683e5609/JOINT_528_G_ONLY_审核入口.html'

def apply_scope():
 ctx,parent,child=c.location();view=c.GOnlyView(child,parent);view.root.mkdir(exist_ok=True)
 prior=parent/'G_history_priority_patch_20261028'
 proposal=prior/'A_G_ONLY_SCOPE_REVISION_PROPOSED.json';j.require(j.sha(proposal)==SCOPE_HASH,'Approved A scope proposal mismatch')
 frozen=j.load(prior/'frozen_input_hashes.json');j.require(all(j.sha(v['path'])==v['sha256'] for v in frozen.values()),'Frozen research input changed')
 approval=child/'G_ONLY_SCOPE_APPROVAL.json';revision=child/'G_ONLY_SCOPE_REVISION.json'
 if approval.exists():
  j.verify_review_scope(view,'G_ONLY',SCOPE_HASH);state='ALREADY_APPLIED'
 else:
  text=INSTRUCTION.read_text('utf-8-sig');quote='作者现已明确选择方案A：JOINT_528_G_ONLY。'
  j.require(quote in text and SCOPE_HASH in text,'Actual current user authorization not found')
  archive=view.root/'actual_scope_instruction.txt';shutil.copyfile(INSTRUCTION,archive);shutil.copyfile(proposal,revision)
  j.jsonout(approval,dict(event_type='EXPLICIT_USER_SCOPE_AUTHORIZATION',identity='REAL',statement='APPROVE_EXACT_G_ONLY_SCOPE_REVISION',
    authorization_identity='DIRECT_USER_INSTRUCTION_IN_CURRENT_CHAT',approval_quote=quote,selected_option='JOINT_528_G_ONLY',
    source_instruction_path=str(archive),source_instruction_sha256=j.sha(archive),scope_revision_sha256=SCOPE_HASH,
    sample_manifest_sha256=j.sha(child/'sample/sample_manifest.json'),original_protocol_sha256=c.APPROVED_HASH,
    recorded_at=j.now(),time_meaning='SYSTEM_RECORDING_TIME;NOT_AN_INVENTED_AUTHOR_SIGNATURE_OR_REVIEW_TIME',
    allows='G_ONLY review and scoped design computation',quality_approval=False,C2_adoption=False))
  state='APPLIED_FROM_EXPLICIT_USER_INSTRUCTION'
 receipt=dict(status=state,scope_revision_sha256=SCOPE_HASH,approval_event_sha256=j.sha(approval),sample_manifest_sha256=j.sha(child/'sample/sample_manifest.json'),
    member_sha256=j.sha(child/'sample/actual_sample_BACKEND.csv'),sample_n=528,strata_n=264,primary_reading_blocks=502,secondary_target_n=106,
    probability_or_weight_changed=False,author_signing_time_invented=False,quality_approval=False)
 j.jsonout(view.root/'scope_import_receipt.json',receipt)
 binding=view.root/'G_ONLY_INPUT_BINDING.json'
 dependencies=j.load(prior/'input_dependency_hashes.json')
 dependencies += [dict(path=v['path'],sha256=v['sha256'],identity='FROZEN_RESEARCH_INPUT') for v in frozen.values()]
 j.require(all(j.sha(v['path'])==v['sha256'] for v in dependencies),'Original A inputs differ from their recorded content')
 if not binding.exists():j.jsonout(binding,dict(scope_revision_sha256=SCOPE_HASH,dependencies=dependencies))
 active=parent/'ACTIVE_INDEPENDENT_AUDIT.json';old=view.root/'before_patch/ACTIVE_INDEPENDENT_AUDIT.json'
 if active.exists() and not old.exists():shutil.copyfile(active,old)
 j.jsonout(active,dict(active_option='JOINT_528_G_ONLY',review_scope='G_ONLY',workspace_relative_directory=str(view.root.relative_to(j.longpath(j.WS))),
   protocol_sha256=c.APPROVED_HASH,scope_revision_sha256=SCOPE_HASH,parent_600_preserved=True,original_FULL_10_528_preserved=True,
   status='WAITING_FOR_G_AUDIT_RETURN',review_entry=str(ENTRY),author_scope_approval_applied=True))
 protocol=view.root/'G_RESEARCH_USE_PROTOCOL.json'
 if not protocol.exists():
  j.jsonout(protocol,dict(scope='JOINT_528_G_ONLY',fixed_before_new_G_truth=True,source_instruction_sha256=j.sha(view.root/'actual_scope_instruction.txt'),
    uses=[dict(id='A',target='Four-stage G1/G2/G3 policy-equal composition'),dict(id='B',target='Adjacent-stage differences and directions'),
          dict(id='C',target='Policy-specific function presence'),dict(id='D',target='Policy G assignment counts and shares as empirical inputs')],
    estimation_population='FIXED_EXTRACTED_UNITS;EXISTING_EVIDENCE_FIXED_COMPONENT;SOURCE_OMISSIONS_NOT_IDENTIFIED',
    directions='Taylor intervals crossing zero imply INDETERMINATE; finite-sample/rare-category restrictions retained',
    numeric_acceptance_tolerance=None,adoption='One use-specific decision on actual results if no quantitative conditions exist; not repeated scope signatures',
    second_coder_blocks_primary=False,T_or_full_C2_required_for_G_computation=False,old_pool_or_model_quality_required_for_G_computation=False,
    C2_adoption=False,training_role='AUDIT_ONLY_NOT_TRAINING'))
 return receipt

def export_entry():
 ctx,parent,child=c.location();view=c.GOnlyView(child,parent);j.verify_review_scope(view,'G_ONLY',SCOPE_HASH)
 members=j.read(child/'sample/actual_sample_BACKEND.csv');secondary=set(members.loc[j.truth(members.second_coder_selected),'unit_id'])
 template=j.read(child/'sample/registered_PRIMARY_TEMPLATE.csv');records=[];readings={}
 for r in template.to_dict('records'):
  readings.setdefault(r['reading_id'],dict(reading_id=r['reading_id'],policy_id=r['policy_id'],stage=r['stage'],text=r['reading_text'],source=r['source_location']))
  records.append(dict(unit_id=r['unit_id'],policy_id=r['policy_id'],stage=r['stage'],reading_id=r['reading_id'],text=r['exact_evidence_text'],
    location=r['source_location'],clean_start=r['clean_start'],clean_end=r['clean_end'],template_row_sha256=j.digest(r),secondary=r['unit_id'] in secondary))
 data=dict(scope_revision_sha256=SCOPE_HASH,protocol_sha256=c.APPROVED_HASH,records=records,readings=list(readings.values()))
 html=(j.ROOT/'joint528_G_ONLY_review_template_20261028.html').read_text('utf-8')
 html=html.replace('__AUDIT_DATA__',json.dumps(data,ensure_ascii=False).replace('</','<'+chr(92)+'/'))
 ENTRY.parent.mkdir(exist_ok=True,parents=True)
 # Never overwrite a file with embedded human values. This entry contains no judgments;
 # actual local browser drafts and exported JSON remain separate.
 ENTRY.write_text(html,'utf-8')
 j.jsonout(view.root/'review_entry_manifest.json',dict(path=str(ENTRY),sha256=j.sha(ENTRY),target_n=len(records),reading_n=len(readings),
   secondary_n=len(secondary),scope_revision_sha256=SCOPE_HASH,contains_machine_answers=False,contains_old_reference_answers=False,
   model_fits=0,interface='ONE_OFFLINE_HTML;ROLE_SEPARATE_BROWSER_DRAFTS;JSON_BATCH_RETURN'))
 return dict(entry=str(ENTRY),primary_targets=len(records),readings=len(readings),secondary_targets=len(secondary))

def refresh_reports():
 ctx,parent,child=c.location();view=c.GOnlyView(child,parent)
 if (view/'G_ESTIMATOR_SENSITIVITY_ACTIVE.json').exists():
  import g_estimator_stability_20261028 as stability
  return stability.execute(refresh_source=False)
 result=j.evaluate(ctx,view,'G_ONLY')
 prior=parent/'G_history_priority_patch_20261028';presence=j.read(prior/'G_REFERENCE_PRESENCE_SUPPORT.csv')
 gp=j.read(view/'G_POLICY_AUDIT_CORRECTION.csv');progress=j.read(view/'G_POLICY_AUDIT_PROGRESS.csv');actual=[]
 for p in (view.root/'returns').glob('*/ingest_receipt.json') if (view.root/'returns').exists() else []:
  receipt=j.load(p)
  if receipt.get('coder_role')=='PRIMARY' and receipt.get('review_scope')=='G_ONLY' and receipt.get('accepted_rows',0):actual.extend(j.read(p.parent/'actual_normalized.csv').to_dict('records'))
 additions={}
 for r in actual:
  v=j.feature_vector(r,'truth','G_ONLY')
  if v is None or v[0]!=1:continue
  for n,g in enumerate(j.G,1):
   if v[n]==1:additions.setdefault((r['policy_id'],g),[]).append(r['unit_id'])
 totals=j.read(view/'DESIGN_ASSISTED_TOTALS.csv').set_index(['policy_id','feature'])
 for i,r in presence.iterrows():
  ids=additions.get((r.policy_id,r.G),[]);n=int(r.real_reference_positive_unit_n)
  presence.loc[i,'new_actual_audit_positive_unit_n']=len(ids);presence.loc[i,'new_actual_audit_positive_ids']=';'.join(ids)
  presence.loc[i,'function_presence_status']='SUPPORTED_WITHIN_BOUND_UNIT_SCOPE' if n or ids else 'UNKNOWN_NO_CREDIBLE_POSITIVE_NOT_PROOF_OF_ABSENCE'
  z=gp[gp.policy_id.eq(r.policy_id)&gp.label.eq(r.G)].iloc[0]
  presence.loc[i,'design_assignment_total']=totals.loc[(r.policy_id,r.G),'estimated_total']
  presence.loc[i,'design_policy_share']=z.design_corrected_share;presence.loc[i,'design_assignment_denominator']=z.assignment_denominator
 j.csvout(view/'G_POLICY_FUNCTION_STATUS_204.csv',presence)
 frozen=j.read(prior/'G_POLICY_INPUT_APPLICABILITY.csv');released=set(j.read(prior/'EXISTING_SCOPED_POLICY_G_RELEASE.csv').policy_id)
 inputs=[]
 for r in progress.to_dict('records'):
  pid=r['policy_id'];z=gp[gp.policy_id.eq(pid)].set_index('label');conditional=frozen[frozen.policy_id.eq(pid)].set_index('G')
  r.update(function_presence_supported_n=int(presence[presence.policy_id.eq(pid)].function_presence_status.eq('SUPPORTED_WITHIN_BOUND_UNIT_SCOPE').sum()),
    G_input_use_status='EXISTING_SCOPED_CONDITIONAL_G_RELEASE_PRESERVED' if pid in released else 'FIXED_FRAME_ESTIMATE_USE_REVIEW_PENDING' if str(r['design_sample_complete']).lower()=='true' else 'PARTIAL_RETURN',
    estimated_G_assignment_denominator=z.iloc[0].assignment_denominator,
    limitation='Presence, assignment count and policy share are distinct; full source coverage and empirical-use support not implied')
  for g in j.G:r['conditional_'+g]=conditional.loc[g,'conditional_policy_share'];r['design_'+g]=z.loc[g,'design_corrected_share']
  inputs.append(r)
 j.csvout(view/'G_POLICY_INPUT_APPLICABILITY_68.csv',inputs)
 impacts=j.read(prior/'G_source_and_unit_impact.csv');gaps=j.read(parent/'source_unmapped_spans.csv');exceptions=[]
 for pid in set(impacts.policy_id)|set(gaps.policy_id):
  z=impacts[impacts.policy_id.eq(pid)];q=gaps[gaps.policy_id.eq(pid)]
  exceptions.append(dict(policy_id=pid,limited_frame_units=len(z),known_G_zero_units=int(z.G_contribution_status.eq('KNOWN_ZERO_FROM_EXISTING_ACCEPTED_INELIGIBILITY').sum()),
    frame_units_to_be_estimated_not_census_tasks=int(z.blocks_this_units_G_contribution.eq('True').sum()),unmapped_source_spans=len(q),
    treatment='Frame uncertainty handled by scheduled probability truth; unextracted text separate; no reissue of approved source cards',
    detail_file='../source_unmapped_spans.csv',automatic_zero_from_unknown=False))
 j.csvout(view/'G_SOURCE_UNIT_EXCEPTION_SUMMARY.csv',exceptions)
 changes=j.read(view/'G_STAGE_CHANGE_AUDIT_CORRECTION.csv');directions=[]
 for r in changes.to_dict('records'):
  low=pd.to_numeric(r['p025_normal_approx'],errors='coerce');high=pd.to_numeric(r['p975_normal_approx'],errors='coerce')
  r['direction_assessment']='INCREASE_WITHIN_FIXED_FRAME_TAYLOR_APPROX' if low>0 else 'DECREASE_WITHIN_FIXED_FRAME_TAYLOR_APPROX' if high<0 else 'INDETERMINATE'
  r['quality_scope']='DESCRIPTIVE_DIRECTION_EVIDENCE;NOT_AUTOMATIC_RESEARCH_ADOPTION';directions.append(r)
 j.csvout(view/'G_DIRECTION_ASSESSMENT.csv',directions)
 return result

def package():
 ctx,parent,child=c.location();view=c.GOnlyView(child,parent)
 if (view.root/'G_DESCRIPTIVE_SCOPE_PROTOCOL.json').exists():
  out=view.root/'estimator_stability_patch_20261028';manifest=out/'PART1_G_DELIVERY_MANIFEST.json'
  if manifest.exists():
   result=j.load(out/'PART1_EXECUTION_STATUS.json')
   text='# G固定提取框描述性交付\n\n'+(out/'METHOD_AND_LIMITATIONS.md').read_text('utf-8')+'\n\n## 当前状态\n```json\n'+json.dumps(result,ensure_ascii=False,indent=2)+'\n```\n\n当前表：G_POLICY_DESCRIPTIVE_68.csv、G_STAGE_DESCRIPTIVE.csv、G_STAGE_CHANGES_DESCRIPTIVE.csv。原DIFF保持冻结历史身份。复算命令：现有joint528_G_ONLY_execution_20261028.py status。\n'
   (view.root/'G_ONLY_HANDOFF.md').write_text(text,'utf-8')
   j.jsonout(view.root/'G_ONLY_DELIVERY_MANIFEST.json',dict(version='B1_V1.2_G_FIXED_FRAME_DESCRIPTIVE_DELIVERY',
    authoritative_manifest=str(manifest),manifest_sha256=j.sha(manifest),states=result['assessment']['states'],model_fits=0,part2_started=False))
   return
 ctx,parent,child=c.location();view=c.GOnlyView(child,parent);status=j.load(view/'evaluation_status.json')
 for name in ['joint_history_audit_20261028.py','joint528_compact_20261028.py','g_history_priority_delivery_20261028.py']:
  old=view.root/'before_patch'/name
  if old.exists():(view.root/(name+'.patch')).write_text(''.join(difflib.unified_diff(old.read_text('utf-8').splitlines(True),(j.ROOT/name).read_text('utf-8').splitlines(True),fromfile='before/'+name,tofile='after/'+name)),'utf-8')
 lines=['# 方案A G_ONLY执行与回收','',
  '本次明确用户指令已作为真实范围授权导入。原528样本、264层、pi/权重、502主审阅读块和106第二编码目标保持不变。无新增范围签署项；未把范围授权当作审核、质量或C2批准。',
  '',f'唯一审核入口：{ENTRY}',
  '浏览器离线打开，选择主审或第二编码，填写真实姓名。每阅读块展示一次完整句段；每个目标保留独立资格和G判断。可按政策或ID筛选、暂存，导出已填写判断JSON。',
  '不合格：填0；G由资格父证据派生0。合格：填1，勾选实际G类别，并确认三类均已检查。未选且未确认不会变成0。T不填写。来源/句条逐项确认；同一块无异常时可以一次明确确认该块正文及句条范围。',
  'G1为源头压力控制；G2为生境保护修复；G3为监测、预警、反馈或跨部门/辖区协调。对象与行动必须来自目标单元，前后文仅辅助解释，不传播邻句标签。',
  '第二编码者用另一真实人员的独立浏览器/设备打开同一空入口，不查看主审草稿或回传。入口文件不含判断；草稿只在当前浏览器保存。106条未回收不阻止主审数值计算。',
  '', '## 实际进度','```json',json.dumps(status,ensure_ascii=False,indent=2),'```',
  f'当前有效主审回收{status.get("primary_actual_n",0)}/{status.get("expected_primary_n",528)}；第二编码状态{status.get("second_coder_status") }。政策计算完整不等于比例有定义或质量通过。负赋值估计、未定义份额和来源覆盖限制均保留，不裁剪或静默剔除。',
  '204行功能状态按实际绑定正例更新；未见正例不代表不存在。68行政策用途表将存在性、赋值和份额分开。',
  '研究用途A—D已冻结于G_RESEARCH_USE_PROTOCOL.json。无新增统一误差阈值；真实结果形成后按误差、分层支持、区间、来源和用途提交一次具体采用判断。宽区间不等于计算失败。',
  '', '## 接续命令','```powershell',
  '.\\OCMA_empirical_revision_workspace_B1_20261026\\.venv\\Scripts\\python.exe .\\joint528_G_ONLY_execution_20261028.py status',
  '.\\OCMA_empirical_revision_workspace_B1_20261026\\.venv\\Scripts\\python.exe .\\joint528_G_ONLY_execution_20261028.py ingest --return-file "实际回传JSON路径"',
  '```',
  'ingest默认连续估计已完整政策/阶段，按内容幂等复用。重复相同判断不新增事件；不同判断只隔离对应ID，需有出处的更正。模型、阈值、旧Bootstrap和T2均不重算。',
  '', '## 结果与哈希',
  'G_POLICY_AUDIT_PROGRESS、G_STAGE_AUDIT_PROGRESS、G_POLICY_AUDIT_CORRECTION、G_STAGE_AUDIT_CORRECTION、G_STAGE_CHANGE_AUDIT_CORRECTION为唯一当前G审核结果。',
  '原条件性阶段点值、Bootstrap和T分析保留在原冻结目录；本目录只存G审核的新范围结果。PART1_COMPLETED不会因G计算完成自动通过。',
  'scope_import_receipt.json记录授权绑定；G_ONLY_DELIVERY_MANIFEST.json记录实际文件和代码哈希；真实回传在json_returns/returns分开存原文和规范事件；QA中合成记录不进入研究。']
 (view.root/'G_ONLY_HANDOFF.md').write_text('\n'.join(lines),'utf-8')
 j.jsonout(view.root/'G_ONLY_DELIVERY_MANIFEST.json',dict(version='B1_V1.2_JOINT_528_G_ONLY_EXECUTION_20261028',created_at=j.now(),entry=str(ENTRY),entry_sha256=j.sha(ENTRY),
    scope_revision_sha256=SCOPE_HASH,original_sample_manifest_sha256=j.sha(child/'sample/sample_manifest.json'),
    code_sha256={n:j.sha(j.ROOT/n) for n in ['joint_history_audit_20261028.py','joint528_compact_20261028.py','joint528_G_ONLY_execution_20261028.py','joint528_G_ONLY_review_template_20261028.html']},
    files={str(p.relative_to(view.root)):j.sha(p) for p in view.root.rglob('*') if p.is_file() and p.name!='G_ONLY_DELIVERY_MANIFEST.json'},
    model_fits=0,threshold_changes=0,SD_runs=0,status=status))

def main():
 started=j.now()
 p=argparse.ArgumentParser();p.add_argument('command',choices=['prepare','status','ingest','package']);p.add_argument('--return-file');args=p.parse_args()
 if args.command=='prepare':result=dict(approval=apply_scope(),review=export_entry(),evaluation=refresh_reports())
 elif args.command=='status':result=refresh_reports()
 elif args.command=='package':result=dict(packaged=True)
 else:
  j.require(args.return_file,'Actual return workbook/JSON required');file=Path(args.return_file)
  result=c.ingest_g_only_xlsx(file) if file.suffix.lower() in ['.xlsx','.xlsm'] else c.ingest_g_only_json(file);refresh_reports()
 _,_,child=c.location();root=child/'G_ONLY_execution'
 log=dict(started_at=started,completed_at=j.now(),command=[sys.executable]+sys.argv,actual_result=j.clean_json(result),model_fits=0,threshold_changes=0,SD_runs=0)
 with (root/'G_ONLY_EXECUTION_LOG.jsonl').open('a',encoding='utf-8') as file:file.write(json.dumps(log,ensure_ascii=False)+'\n')
 package()
 print(json.dumps(j.clean_json(result),ensure_ascii=False))

if __name__=='__main__':main()
