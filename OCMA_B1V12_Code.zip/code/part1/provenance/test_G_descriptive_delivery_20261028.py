"""Targeted real-file checks and isolated source/state examples for G delivery."""
import json
import numpy as np
import pandas as pd
import g_descriptive_delivery_20261028 as d
s=d.s;j=d.j;ctx,parent,v,out=s.locations();checks=[]
def check(name,kind,fn):
 try:fn();checks.append(dict(test=name,identity=kind,status='PASS'))
 except (AssertionError,ValueError,KeyError,TypeError) as e:checks.append(dict(test=name,identity=kind,status='FAIL',error=repr(e)))

def real_identity():
 a,b=s.actual_returns(v);sm=j.load(v/'sample/sample_manifest.json')
 assert len(a)==528 and len(b)==106 and a.unit_id.is_unique and b.unit_id.is_unique
 assert all(j.sha(v/'sample'/n)==h for n,h in sm['files'].items())
 assert all(j.sha(r['path'])==r['sha256'] for r in j.load(v/'G_ONLY_INPUT_BINDING.json')['dependencies'])

def frozen_HT_and_stages():
 assert d.frozen_numerics_ok(out)
 policy=j.read(out/'G_POLICY_DESCRIPTIVE_68.csv');raw=j.read(out/'G_POLICY_HT_SHARES.csv');stage=j.read(out/'G_STAGE_DESCRIPTIVE.csv')
 assert policy.policy_id.is_unique and len(policy)==68 and len(stage)==12
 for r in policy.itertuples():
  total=0
  for g in j.G:
   val=float(getattr(r,g+'_HT_share'));total+=val
   expected=float(raw[raw.policy_id.eq(r.policy_id)&raw.label.eq(g)].iloc[0].design_corrected_share)
   assert abs(val-expected)<1e-12
  assert abs(total-1)<1e-12
 for r in stage.itertuples():
  z=policy[policy.stage.eq(r.stage)];expected=pd.to_numeric(z[r.label+'_HT_share']).mean()
  assert abs(float(r.design_corrected_share)-expected)<1e-12

def frozen_DIFF():
 for name in ['DESIGN_ASSISTED_TOTALS.csv','G_POLICY_AUDIT_CORRECTION.csv','G_STAGE_AUDIT_CORRECTION.csv','G_STAGE_CHANGE_AUDIT_CORRECTION.csv']:
  assert j.sha(v/name)==j.sha(out/'frozen_before_patch'/name)
 p=j.read(v/'G_POLICY_AUDIT_CORRECTION.csv');assert p[p.negative_total_not_clipped.eq('True')].policy_id.nunique()==24

def official_HTML():
 assert d.classify_source('html',True,'POLICY_TEXT',True,True)=='OFFICIAL_WEB_FULL_TEXT'
 x=j.read(out/'SOURCE_PROVENANCE_AND_COVERAGE.csv');assert x.source_category.eq('OFFICIAL_WEB_FULL_TEXT').sum()==28
 y=j.read(out/'G_POLICY_DESCRIPTIVE_68.csv');assert y[y.source_category.eq('OFFICIAL_WEB_FULL_TEXT')].descriptive_result_reportable.eq('True').all()

def news_not_policy():
 assert d.classify_source('html',True,'NEWS_INTERPRETATION',True,True)=='WEB_CONTEXT_ONLY'
 assert d.classify_source('html',True,'NAVIGATION',True,True)=='WEB_CONTEXT_ONLY'

def excerpt_not_full_body():
 assert d.classify_source('html',False,'EXCERPT',True,True)=='VERIFIED_POLICY_EXCERPT'
 assert d.classify_source('html',False,'EXCERPT',False,True)=='UNRESOLVED_SOURCE'
 # The media classifier never promotes whole-body coverage; actual coverage is separate.
 x=j.read(out/'SOURCE_PROVENANCE_AND_COVERAGE.csv');assert x.full_body_validated.eq('False').all()

def unknown_not_zero():
 x=j.read(out/'SOURCE_COVERAGE_ROOT_CAUSE.csv');old=j.read(out/'before_G_descriptive_delivery/SOURCE_COVERAGE_ROOT_CAUSE.csv')
 assert x.equals(old) and x.classification.eq('UNRESOLVED_SOURCE_SPAN').sum()==515
 assert x.original_probability.eq('').all()
 new=j.read(out/'SOURCE_SUBSTANTIVE_EXCEPTION_SCREEN.csv');assert len(new)==515 and new.new_G_label.eq('').all() and new.new_original_528_probability.eq('').all()
 grouped=j.read(out/'UNRESOLVED_SOURCE_GROUPS.csv');assert pd.to_numeric(grouped.span_n).sum()==515 and grouped.automatic_human_review_required.eq('False').all()

def wide_SE_reportable():
 p=j.read(out/'G_POLICY_DESCRIPTIVE_68.csv');mask=np.zeros(len(p),bool)
 for g in j.G:mask|=pd.to_numeric(p[g+'_HT_share_SE']).gt(.3).to_numpy()
 assert mask.any() and p.loc[mask,'descriptive_result_reportable'].eq('True').all()

def zero_SE_not_error_free():
 p=j.read(out/'G_POLICY_DESCRIPTIVE_68.csv');mask=np.zeros(len(p),bool)
 for g in j.G:mask|=pd.to_numeric(p[g+'_HT_share_SE']).eq(0).to_numpy()
 assert mask.any() and p.loc[mask,'descriptive_result_reportable'].eq('True').all()
 assert p.loc[mask,'limitations'].str.contains('ZERO_EMPIRICAL_SE_NOT_PROOF_OF_ZERO_RISK',regex=False).all()

def no_adoption_gate():
 q=j.load(out/'G_RESEARCH_USE_SCOPE_DECISION.json');states=q['states']
 assert states['G_FIXED_FRAME_DESCRIPTIVE_REPORTABLE'] and states['G_STAGE_HISTORICAL_DESCRIPTION_AVAILABLE']
 assert not q['research_use_adoption'] and not states['G_FULL_POLICY_BODY_VALIDATED']
 assert states['G_POLICY_ESTIMATE_AVAILABLE']

def no_full_C2_or_T():
 q=j.load(out/'G_RESEARCH_USE_SCOPE_DECISION.json');states=q['states']
 assert not states['FULL_C2_FORMAL_RELEASE_READY'] and not states['PART1_COMPLETED']
 a,b=s.actual_returns(v);assert all(a[t].eq('').all() and b[t].eq('').all() for t in j.T)
 p=j.read(out/'G_POLICY_FUNCTION_STATUS_204.csv');assert p.function_presence_status.eq('SUPPORTED_WITHIN_BOUND_UNIT_SCOPE').sum()==194
 assert p.function_presence_status.ne('SUPPORTED_WITHIN_BOUND_UNIT_SCOPE').sum()==10

def final_files_and_no_model():
 assert all((out/n).exists() for n in d.REQUIRED)
 r=j.load(out/'PART1_EXECUTION_STATUS.json');assert not r['model_fits'] and not r['new_probability_samples'] and not r['threshold_changes'] and not r['part2_started']
 p=j.read(out/'G_POLICY_DESCRIPTIVE_68.csv');assert p.descriptive_status.eq('DESCRIPTIVE_ESTIMATE_AVAILABLE_WITH_LIMITATIONS').all()
 assert p.full_policy_intensity_formally_supported.eq('False').all()

for name,kind,fn in [
 ('unchanged_528_106_inputs_weights_hashes','REAL_INPUT_QA',real_identity),
 ('unchanged_HT_68_and_equal_weight_stages','REAL_INDEPENDENT_OUTPUT_RECONCILIATION',frozen_HT_and_stages),
 ('DIFF_24_negative_policies_preserved','REAL_FROZEN_RESULT_QA',frozen_DIFF),
 ('official_HTML_accepted','REAL_FILES_PLUS_ISOLATED_CLASSIFIER_EXAMPLE',official_HTML),
 ('news_and_navigation_not_policy','SYNTHETIC_SOURCE_ROLE_EXAMPLES_NOT_RESEARCH_DATA',news_not_policy),
 ('verified_excerpt_not_full_body','SYNTHETIC_SOURCE_ROLE_EXAMPLE_PLUS_REAL_SCOPE_CHECK',excerpt_not_full_body),
 ('515_unknown_spans_no_zero_no_new_probability','REAL_SOURCE_QA',unknown_not_zero),
 ('wide_SE_not_report_gate','REAL_POLICY_QA',wide_SE_reportable),
 ('zero_empirical_SE_not_zero_error','REAL_POLICY_QA',zero_SE_not_error_free),
 ('no_formal_adoption_needed_for_internal_output','REAL_SCOPE_QA',no_adoption_gate),
 ('G_does_not_release_T_or_full_C2','REAL_SCOPE_QA',no_full_C2_or_T),
 ('complete_delivery_no_training_sampling_SD','REAL_OUTPUT_QA',final_files_and_no_model)]:check(name,kind,fn)
report=dict(results=checks,all_passed=all(x['status']=='PASS' for x in checks),passed=sum(x['status']=='PASS' for x in checks),failed=sum(x['status']=='FAIL' for x in checks),
 model_fits=0,new_samples=0,synthetic_source_examples_imported=0,
 code_sha256={n:j.sha(j.ROOT/n) for n in ['joint_history_audit_20261028.py','g_estimator_stability_20261028.py','g_descriptive_delivery_20261028.py','test_G_descriptive_delivery_20261028.py']})
j.jsonout(out/'G_DELIVERY_QA.json',report);print(json.dumps(report,ensure_ascii=False))
if not report['all_passed']:raise SystemExit(1)
