"""Package the executed sensitivity in one reviewable current-run delivery."""
from pathlib import Path
import difflib,shutil,json,importlib.metadata as md
import numpy as np
import pandas as pd
import g_estimator_stability_20261028 as s
j=s.j;ctx,parent,v,out=s.locations();short=j.ROOT/'outputs/JOINT_528_ac6da323683e5609'
dest=short/'G估计器稳定性修复结果';dest.mkdir(exist_ok=True)
status=j.load(out/'PART1_EXECUTION_STATUS.json');qa=j.load(out/'QA.json')
j.require(qa['all_passed'] and status['assessment']['states']['ESTIMATOR_NUMERICALLY_VERIFIED'],'Actual QA not complete')
patch=[]
for n in ['joint_history_audit_20261028.py','joint528_G_ONLY_execution_20261028.py']:
 before=(out/'frozen_before_patch'/n).read_text('utf-8');after=(j.ROOT/n).read_text('utf-8')
 text=''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='before/'+n,tofile='after/'+n))
 (out/(n+'.patch')).write_text(text,'utf-8')
 patch.append(dict(file=n,before_sha256=j.sha(out/'frozen_before_patch'/n),after_sha256=j.sha(j.ROOT/n)))
env={k:md.version(k) for k in ['numpy','pandas','scipy','matplotlib','scikit-learn','openpyxl']};j.jsonout(out/'environment.json',env)
# Optional concrete proposal: policies whose leading G label changes under the
# actual second-coder sensitivity. No new review workbook or sampled truth.
prim=j.read(out/'G_POLICY_HT_SHARES.csv');other=j.read(out/'G_POLICY_HT_SECONDARY_SWAP.csv');log=j.read(out/'G_CODER_DISAGREEMENT_FIELD_LOG.csv');proposals=[]
for pid,z in prim.groupby('policy_id'):
 q=other[other.policy_id.eq(pid)]
 def lead(x):
  vals=pd.to_numeric(x.design_corrected_share,errors='coerce')
  return x.loc[vals.idxmax(),'label'] if vals.notna().all() else 'UNDEFINED'
 a=lead(z);b=lead(q)
 if a!=b:
  for r in log[log.unit_id.str.startswith(pid+'__')].to_dict('records'):
   proposals.append(dict(policy_id=pid,primary_leading_G=a,secondary_swap_leading_G=b,**r,
    reason='POLICY_LEADING_FUNCTION_CHANGES_UNDER_ACTUAL_CODER_SENSITIVITY',
    action='ONLY_IF_THIS_POLICY_INTENSITY_OR_LEADING_FUNCTION_IS_TO_BE_USED;NO_NEW_AUDIT_STARTED'))
j.csvout(out/'TARGETED_CODER_ADJUDICATION_PROPOSAL.csv',proposals)
# Explicit figure contract and inspection outcome for the actual saved figure.
j.jsonout(out/'figure_contract_and_QA.json',dict(archetype='quantitative grid',backend='Python matplotlib',
 core_claim='HT produces fixed-frame estimates where DIFF policy ratios are undefined; methods differ materially',
 panels=['G1','G2','G3'],formats=['png','svg','pdf'],uncertainty='HT Taylor audit-design approximation only; conditional marker has no audit interval',
 actual_PNG_visually_inspected=True,source_csv='Figure_G_estimator_source_data.csv',editable_vector_text=True,
 DIFF_not_drawn_as_zero=True,not_forced_to_submission_rank=True))
patchtext='''# PATCHLOG

## 本轮实际变更
1. joint_history_audit_20261028.py新增estimate_direct_stratified_HT：固定完整证据与概率域分离、原层/权重校验、非负贡献、有限总体方差/协方差。没有修改原DIFF计算式。
2. 新增g_estimator_stability_20261028.py，读取当前真实回传和冻结DIFF，对照HT、分解门控/头部漏检，计算实际第二编码替换敏感性，并集中核查来源区间。
3. assess_research_use新增POSTHOC_USE_SCOPE_ASSESSMENT分支，自动读取实际结果、QA和范围证据；允许受限描述性输出，不再强迫补造审前数值阈值。旧分支和旧质量判定保留。实际用途采用与计算可用性分开。
4. evaluate_g_only及refresh_reports按活动敏感性指针接续本轮结果。原DESIGN_ASSISTED_TOTALS、DIFF政策/阶段/差值文件字节保留。新版政策用途清单按HT/DIFF可定义性、来源范围和真实正例填写，旧清单在frozen_before_patch保留。
5. 来源分类使用载体全文、哈希、字符定位和精确规则；元数据规则不产生G标签。未映射段的回收句子是来源语境，不是新增编码单元；不加入原抽样框。
6. 添加独立计数/协方差验证与生产HT函数的小型有限总体枚举；合成资料不导入研究。

## 实际运行中纠正的实现问题
- 比较表抽样数统计初版重复merge policy_id，已改为直接读取原样本的政策列。
- 敏感性中主审不合格转为第二编码合格时，原负类事件来源列可能为空；现引用作者对全部目标的真实来源/句条确认，不把空白当未知新标签或假造新确认。
- 页码标记和页脚首部换行导致的元数据识别问题已修正为精确来源标记匹配；仍未确定的片段继续未知。

## 真实范围
没有重训、阈值改变、新抽样、C2标签覆盖、旧三池重验、T补零或第二部分运算。新增HT和编码者替换均为事后敏感性，不伪称原预设主方法。
'''
(out/'PATCHLOG.md').write_text(patchtext,'utf-8')
h=j.read(out/'G_STAGE_HT_ESTIMATES.csv');rows=[]
for stage,z in h.groupby('stage',sort=True):
 vals={r.label:float(r.design_corrected_share)*100 for r in z.itertuples()}
 rows.append(f'|{stage}|{vals["G1"]:.2f}%|{vals["G2"]:.2f}%|{vals["G3"]:.2f}%|')
source=j.read(out/'SOURCE_COVERAGE_ROOT_CAUSE.csv');counts=source.classification.value_counts().to_dict()
sens=j.read(out/'G_CODER_DISAGREEMENT_SENSITIVITY.csv');zs=sens[sens.level.eq('STAGE_SHARE')&sens.estimator.eq('HT')]
maxshift=pd.to_numeric(zs.difference).abs().max()*100
text=f'''# B1 V1.2：G估计器稳定性最小修复实际交付

## 实际结果
原528主审、106第二编码及2,244条固定完整证据均保留。原DIFF结果冻结：44篇份额有定义、24篇至少一个G总量为负、四阶段均NA。新增直接分层HT是POST_AUDIT_ESTIMATOR_SENSITIVITY，未宣布取代原主方法。

HT在同一固定抽取总体上得到全部68篇政策的非负资格/G总量，68篇政策份额与四阶段政策等权组成均有定义：

|阶段|G1|G2|G3|
|---|---:|---:|---:|
{chr(10).join(rows)}

表中是点估计，逐项设计标准误与Taylor近似区间见G_STAGE_HT_ESTIMATES.csv。每层n=2，近似区间不保证覆盖，零经验方差不证明无遗漏；没有与旧政策Bootstrap合并。原政策等权及标签赋值次数分母不变。四阶段G排序只作为点排序，不能据此宣布统计可区分。

2017—2020至2021—2023的G1差为+11.65个百分点（近似区间+1.92至+21.37），G2为−12.05个百分点（−20.91至−3.19）；其余相邻阶段差的近似区间跨0。均仅适用于冻结抽取单元、当前主审真值及设计近似，不是完整政策历史的无条件结论。

## 错误与编码者敏感性
资格TP/FP/FN以及G1–G3逐项错误已按总体、阶段及政策输出；权重估计是域内总量，不冒充政策准确率。
G3样本62个漏检分为资格负门控15个和门控通过后G3输出漏检47个；对应加权漏检421.5与1494.5。G2样本100个假阳性对DIFF残差的负贡献为−3810.5个加权赋值。

45个分歧字段准确对应26个不同单元；只在这些字段作实际第二编码替换敏感性，原值不改、不是共识。HT四阶段仍有定义，阶段G份额最大变化约{maxshift:.2f}个百分点；部分政策份额变化更大，政策级强度不能直接视为精确。2011—2016点排序由G1>G2>G3变为G3>G1>G2。具体影响见敏感性全表。

## 来源范围
读取68份本地完整clean_text载体，逐段核对source hash和字符定位。1470段、53篇政策中，按有证据的页码/网页元数据规则确认{counts.get('CONFIRMED_NON_TARGET_METADATA',0)}段非目标元数据；{counts.get('UNRESOLVED_SOURCE_SPAN',0)}段仍未确定。安全规则未确认已被有效单元完整覆盖的段，亦未发现满足本轮双关键词候选规则的完整缺失治理句；这不证明没有遗漏行动，剩余短字符/片段的语境仍在例外表。

原框内2017个提取范围未决单元、1个语义规则未决单元单独保留，与框外文字段不是同一统计对象，不合并成审核任务数。抽样框外文字没有继承原528概率。

固定抽样框有完整计划回收，不代表完整政策正文覆盖已证实。194个政策×功能有真实正例，另10个仍未知，已确认不存在的组合未被虚构。

## 质量与完成状态
AUDIT_SAMPLE_COMPLETE=true；ESTIMATOR_NUMERICALLY_VERIFIED=true；G_POLICY_ESTIMATE_DEFINED=true；G_STAGE_ESTIMATE_DEFINED=true。
SOURCE_FIXED_FRAME_COVERED=true表示原框内固定证据＋原概率设计已完整接入，不是32,858条逐条真值全查。
FULL_SOURCE_BODY_COVERAGE_SUPPORTED=false；POLICY_G_INTENSITY_SUPPORTED=INDETERMINATE；RESEARCH_USE_SCOPE_ACCEPTED=false。

现可提供固定抽取总体下有不确定性和来源限制的描述性G估计；没有缺审前统一误差门槛而禁止输出。真实研究采用仍未发生，不能把数值有定义改称历史真实构成已获验证。
T仍不在本轮审核范围；T2未知、旧600/49评价身份及原失败池保留。C2_FORMAL_RELEASE_READY=false；PART1_COMPLETED=false；第二部分未启动。

## QA和实际执行
9项测试均通过，其中8项基于真实资料检查/独立复算，1项为小型已知有限总体穷举。独立核查272个HT总量、1088个协方差项；穷举调用了生产HT函数并检验总量无偏和协方差公式，同时展示比值并非严格无偏。合成数据未进入研究。
模型、C2、原样本/权重、固定证据和DIFF冻结哈希核验通过。图件保存PNG/SVG/PDF，PNG已实际目检。实际执行命令与环境版本附后。

## 最小接续
本轮不新增人审表、不重新抽样。TARGETED_CODER_ADJUDICATION_PROPOSAL.csv只列实际第二编码替换会改变政策首位功能的既有分歧，只有拟使用这些政策的首位功能或强度时才需要针对性裁定，并非自动必审队列。来源515段也不等于515条人工任务；优先按重复技术根因和真实语境继续定位是否改变目标分母。

将HT描述性结果用于正文前，应明确事后敏感性及固定框范围；如希望正式更换主估计器，须说明方法修订、同一估计对象及质量限制，不能为接近原稿或排名择优。

## 已实际执行的命令
在项目根目录执行，沿用现有虚拟环境：
```powershell
.\\OCMA_empirical_revision_workspace_B1_20261026\\.venv\\Scripts\\python.exe .\\g_estimator_stability_20261028.py --refresh-source
.\\OCMA_empirical_revision_workspace_B1_20261026\\.venv\\Scripts\\python.exe .\\test_g_estimator_stability_20261028.py
.\\OCMA_empirical_revision_workspace_B1_20261026\\.venv\\Scripts\\python.exe .\\joint528_G_ONLY_execution_20261028.py status
```
轻量复核使用第二条；第一条重核来源并计算本轮敏感性，第三条通过现有执行链接续，三者均不训练或运行SD。审阅目录不是脱离原工作区的独立运行包；实际依赖由G_ONLY_INPUT_BINDING及manifest记录。
'''
(out/'G估计器修复_实际结果与限制.md').write_text(text,'utf-8')
j.jsonout(out/'code_change_manifest.json',patch)
# Code and unmodified original DIFF are included for reviewer inspection.
code_dir=out/'code';code_dir.mkdir(exist_ok=True)
for n in ['joint_history_audit_20261028.py','joint528_G_ONLY_execution_20261028.py','joint528_compact_20261028.py','g_estimator_stability_20261028.py','test_g_estimator_stability_20261028.py','deliver_G_estimator_stability_20261028.py']:shutil.copyfile(j.ROOT/n,code_dir/n)
j.jsonout(out/'delivery_manifest.json',dict(identity=s.IDENTITY,created_at=j.now(),files={str(p.relative_to(out)):j.sha(p) for p in out.rglob('*') if p.is_file() and p.name!='delivery_manifest.json'},execution_complete=True,model_fits=0,new_audit_samples=0,part2_started=False))
# Copy the one deliverable, preserving the active run as the computation authority.
for p in out.rglob('*'):
 if p.is_file():
  target=dest/p.relative_to(out);target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target)
j.jsonout(short/'G_AUDIT_CURRENT_RESULTS.json',dict(path=str(dest),actual_root=str(out),identity=s.IDENTITY,status=status,manifest_sha256=j.sha(dest/'delivery_manifest.json')))
print(json.dumps(dict(output=str(dest),files=sum(p.is_file() for p in dest.rglob('*')),HT_policy_n=68,HT_stage_n=4,QA=qa['passed']),ensure_ascii=False))
