"""One bounded post-audit estimator comparison on the existing G-only run."""
from pathlib import Path
import json,re,shutil,sys,time
import numpy as np
import pandas as pd
import joint528_compact_20261028 as c
j=c.j
IDENTITY='POST_AUDIT_ESTIMATOR_SENSITIVITY'

def locations():
 ctx,parent,child=c.location();v=c.GOnlyView(child,parent)
 out=v.root/'estimator_stability_patch_20261028'
 return ctx,parent,v,out

def actual_returns(v):
 primary=[];secondary=[]
 for p in sorted((v.root/'returns').glob('*/ingest_receipt.json')):
  r=j.load(p)
  if r.get('review_scope')!='G_ONLY' or not r.get('accepted_rows'):continue
  z=j.read(p.parent/'actual_normalized.csv');sig=j.load(p.parent/'actual_signature.json');z['reviewer']=sig['reviewer']
  (primary if r['coder_role']=='PRIMARY' else secondary).append(z)
 a=pd.concat(primary,ignore_index=True);b=pd.concat(secondary,ignore_index=True)
 j.require(a.unit_id.is_unique and b.unit_id.is_unique,'Repeated actual audit records')
 return a,b

def source_coverage(frame,parent,out):
 """Local captured text from PDF, HTML, web excerpts or attachments is eligible.

 Media format is not a body-validity gate. Source categories and local-capture
 provenance are recorded by the descriptive delivery layer; this function only
 classifies extraction gaps without assigning G labels or extending probabilities.
 """
 spans=j.read(parent/'source_unmapped_spans.csv');rows=[];exceptions=[];sources={}
 allowed=set(['中国商务法规','北大法宝','信息来源','来源','政策法规司','手机版','电脑版','邮箱','EN','×','首页','打印','字号',
  '大','中','小','返回顶部','关闭','分享','附件','附件下载','政策解读','相关链接','相关阅读','上一篇','下一篇','当前位置',
  '链接','法律话题','产业领域','环境能源','环境保护','公共管理','政府法制','地方政府','省级','部门规章','现行有效','法规标准','点击进入'])
 for pid,z in frame.groupby('policy_id'):
  path=j.longpath(z.iloc[0].source_clean_path);text=path.read_text('utf-8-sig')
  j.require(j.sha(path)==z.iloc[0].source_clean_sha256,'Source text hash changed')
  sources[pid]=(text,z,path)
 for r in spans.to_dict('records'):
  text,z,path=sources[r['policy_id']];start=int(r['start']);end=int(r['end']);part=text[start:end]
  j.require(part==r['text'],'Source span offset/text mismatch')
  norm=lambda s:re.sub(r'[\s\[\]【】<>:：|·,，;；。()（）/\\—_\-]+','',s)
  toks=[norm(x) for x in part.splitlines() if norm(x)]
  body_before=text[:start];reason='';status='UNRESOLVED_SOURCE_SPAN';covered=''
  # Strictly evidenced site blocks: markers must actually occur in this source.
  footer=list(re.finditer(r'(?:免责声明[:：]|相关阅读推荐|网站声明|网站地图|版权所有[:：]|责任编辑[:：]|您可能对以下文章感兴趣)',text))
  mark=next((m for m in footer if m.start()<=start+len(part)-len(part.lstrip()) and m.start()>len(text)*.45),None)
  if mark and not re.search(r'第[一二三四五六七八九十百\d]+条|(?:^|\n)[一二三四五六七八九十]+、',text[mark.end():]):
   status='CONFIRMED_NON_TARGET_METADATA';reason='SOURCE_TRAILING_SITE_BLOCK_AFTER_LITERAL_MARKER:'+mark.group(0)
  elif re.fullmatch(r'\s*(?:\[PAGE:\d+\]\s*)+',part):
   status='CONFIRMED_NON_TARGET_METADATA';reason='EXACT_EXTRACTION_PAGE_MARKER_NOT_POLICY_ACTION'
  elif part.lstrip().startswith('扫一扫在手机打开当前页') and '相关文档:' in part:
   status='CONFIRMED_NON_TARGET_METADATA';reason='TRAILING_SITE_QR_AND_RELATED_DOCUMENTS_BLOCK'
  elif toks and all(t in allowed or re.fullmatch(r'[\d.年月日:：]+',t) or re.fullmatch(r'(?:https?|www).*',t) or re.fullmatch(r'(?:京|鲁|津|沪)?[公ICP备案网安号\d]+',t) for t in toks):
   status='CONFIRMED_NON_TARGET_METADATA';reason='EXACT_LINE_WHITELIST_OR_DATE_URL;NO_ACTION_TEXT'
  else:
   # Coverage only by a separately located, already confirmed complete unit.
   for u in z[z.reused_complete_evidence.astype(str).str.lower().eq('true')].itertuples():
    if len(norm(part))>=20 and norm(part)==norm(u.exact_evidence_text):
     status='ALREADY_COVERED_BY_VALID_SOURCE_UNIT';reason='EXACT_FULL_TEXT_MATCH_TO_FIXED_VALID_EVIDENCE;NO_LABEL_PROPAGATION';covered=u.unit_id;break
  if status=='UNRESOLVED_SOURCE_SPAN' and len(norm(part))>=12 and re.search(r'保护|修复|污染|排放|监测|预警|生态|湿地|海域|流域|渔业|海洋|岸线',part) and re.search(r'应当|不得|禁止|加强|实施|开展|建立|推进|完善|落实|制定|负责|治理|控制|防治',part):
   status='POTENTIAL_MISSING_GOVERNANCE_CLAUSE';reason='ACTION_AND_TARGET_IN_UNMAPPED_TEXT;SEMANTIC_STATUS_UNCONFIRMED'
  r.update(classification=status,evidence_rule=reason or 'NO_SAFE_METADATA_OR_COVERAGE_RULE',covered_unit_id=covered,
    source_path=str(path),frame_membership='OUTSIDE_ORIGINAL_528_TARGET_FRAME',original_probability=None,
    source_verified_by_hash_and_offset=True,not_automatic_G_label=True)
  rows.append(r)
  if status in ['POTENTIAL_MISSING_GOVERNANCE_CLAUSE','UNRESOLVED_SOURCE_SPAN']:
   # Recover paragraph boundaries, never substitute sliding parent windows.
   boundaries=list(re.finditer(r'[。！？]',text[:start]));a=boundaries[-1].end() if boundaries else 0
   closing=re.search(r'[。！？]',text[end:]);b=end+closing.end() if closing else len(text)
   exceptions.append(dict(policy_id=r['policy_id'],start=start,end=end,recovered_start=a,recovered_end=b,
    recovered_text=text[a:b],source_clean_sha256=r['source_clean_sha256'],classification=status,
    G_denominator_impact='UNKNOWN_NOT_ASSUMED_ZERO',original_sampling_probability=None,
    evidence_identity='FRAME_COVERAGE_EXCEPTION_NOT_RANDOM_AUDIT',recovery_status='SOURCE_SENTENCE_CONTEXT_NOT_NEW_CODING_UNIT',source_path=str(path)))
 j.csvout(out/'SOURCE_COVERAGE_ROOT_CAUSE.csv',rows);j.csvout(out/'POTENTIAL_MISSING_CLAUSE_EXCEPTIONS.csv',exceptions)
 rootcause=pd.DataFrame(rows);impact=[]
 for pid,z in frame.groupby('policy_id'):
  ss=rootcause[rootcause.policy_id.eq(pid)]
  mask=lambda k:z[k].astype(str).str.lower().eq('true')
  extraction=mask('unresolved_EXTRACTION_SCOPE');semantic=mask('unresolved_SEMANTIC_RULE');version=mask('unresolved_SOURCE_VERSION')
  impact.append(dict(policy_id=pid,unmapped_span_n=len(ss),confirmed_metadata_n=int(ss.classification.eq('CONFIRMED_NON_TARGET_METADATA').sum()),
    covered_valid_n=int(ss.classification.eq('ALREADY_COVERED_BY_VALID_SOURCE_UNIT').sum()),potential_missing_n=int(ss.classification.eq('POTENTIAL_MISSING_GOVERNANCE_CLAUSE').sum()),
    unresolved_span_n=int(ss.classification.eq('UNRESOLVED_SOURCE_SPAN').sum()),
    extraction_scope_unresolved_units=int(extraction.sum()),semantic_rule_unresolved_units=int(semantic.sum()),
    source_version_unresolved_units=int(version.sum()),inframe_risk_union_n=int((extraction|semantic|version).sum()),
    spans_and_frame_units_are_different_populations=True,
    fixed_frame_design_coverage='COMPLETE_AUDIT_OF_PLANNED_SAMPLE_NOT_CENSUS',
    full_policy_body_coverage='NOT_ESTABLISHED' if len(ss[ss.classification.isin(['POTENTIAL_MISSING_GOVERNANCE_CLAUSE','UNRESOLVED_SOURCE_SPAN'])]) or (extraction|semantic|version).any() else 'NO_REMAINING_FLAG_IN_THIS_CHECK_NOT_EXTERNAL_EXHAUSTIVENESS_PROOF'))
 j.csvout(out/'SOURCE_SCOPE_IMPACT_ON_G.csv',impact)
 return pd.DataFrame(impact)

def error_decomposition(frame,sample,a,out):
 z=a.merge(sample[['unit_id','design_weight']],on='unit_id',validate='one_to_one').merge(frame[['unit_id']+['C2_'+k for k in ['eligibility']+j.G]],on='unit_id',validate='one_to_one')
 w=pd.to_numeric(z.design_weight);rows=[]
 for dim in ['ALL','policy_id','stage']:
  groups=[('ALL',z)] if dim=='ALL' else z.groupby(dim,sort=True)
  for scope,q in groups:
   ww=w.loc[q.index];eligible=pd.to_numeric(q.C2_eligibility)
   for label in ['eligibility']+j.G:
    y=pd.to_numeric(q[label]);pred=pd.to_numeric(q['C2_'+label]);gated=pred if label=='eligibility' else pred*eligible
    masks={'TP':y.eq(1)&gated.eq(1),'FP':y.eq(0)&gated.eq(1),'FN':y.eq(1)&gated.eq(0),'TN':y.eq(0)&gated.eq(0)}
    row=dict(dimension=dim,scope=scope,label=label,sample_n=len(q),identity='ORIGINAL_STRATIFIED_AUDIT;WEIGHTED_TOTALS_NOT_POLICY_ACCURACY')
    for name,mask in masks.items():row[name]=int(mask.sum());row['HT_'+name]=float(ww[mask].sum())
    gate=y.eq(1)&eligible.eq(0) if label=='G3' else pd.Series(False,index=q.index)
    head=y.eq(1)&eligible.eq(1)&pred.eq(0) if label=='G3' else pd.Series(False,index=q.index)
    row.update(G3_gate_FN=int(gate.sum()),G3_head_FN_after_gate=int(head.sum()),HT_G3_gate_FN=float(ww[gate].sum()),HT_G3_head_FN_after_gate=float(ww[head].sum()),
      G2_FP_negative_residual=float(-ww[masks['FP']].sum()) if label=='G2' else 0.,
      HT_total_residual=float(((y-gated)*ww).sum()))
    rows.append(row)
 j.csvout(out/'G_ERROR_SOURCE_DECOMPOSITION.csv',rows);return pd.DataFrame(rows)

def sensitivity(frame,sample,a,b,alloc,out,base_ht,base_hs,base_gs,base_dt,base_ds):
 aa=a.set_index('unit_id').copy();bb=b.set_index('unit_id');changes=[]
 for uid in bb.index:
  for k in ['eligibility']+j.G:
   if aa.loc[uid,k]!=bb.loc[uid,k]:
    changes.append(dict(unit_id=uid,field=k,primary=aa.loc[uid,k],secondary=bb.loc[uid,k]));aa.loc[uid,k]=bb.loc[uid,k]
 j.require(len(changes)==45 and len({r['unit_id'] for r in changes})==26,'Observed disagreement count changed; inspect actual records')
 # All sampled source/unit scopes were expressly confirmed in the author event.
 # A negative primary becoming positive in sensitivity must use that actual scope
 # confirmation, rather than inherit the earlier blank negative-only scope cells.
 for uid in {r['unit_id'] for r in changes}:
  aa.loc[uid,'source_membership']='IN_TARGET';aa.loc[uid,'unit_validity']='VALID_SENTENCE_OR_CLAUSE'
 alt=aa.reset_index();hm,ht=j.estimate_direct_stratified_HT(frame,sample,alt,alloc);hs,hg=j.evaluate_function_history(frame,hm)
 dm,dt=j.audit_composition_impact(frame,sample,alt,alloc,'G_ONLY');ds,dg=j.evaluate_function_history(frame,dm)
 j.csvout(out/'G_CODER_DISAGREEMENT_FIELD_LOG.csv',changes)
 rows=[]
 def compare(level,method,base,new,keys,value):
  for _,r in base.merge(new,on=keys,suffixes=('_primary','_secondary_swap'),validate='one_to_one').iterrows():
   x=pd.to_numeric(pd.Series([r[value+'_primary']]),errors='coerce').iloc[0];y=pd.to_numeric(pd.Series([r[value+'_secondary_swap']]),errors='coerce').iloc[0]
   rows.append(dict(level=level,estimator=method,**{k:r[k] for k in keys},primary_value=x,secondary_disagreement_swap=y,difference=y-x,
    primary_defined=bool(np.isfinite(x)),secondary_swap_defined=bool(np.isfinite(y)),identity='CODER_DISAGREEMENT_SENSITIVITY_NOT_CONSENSUS',changed_fields=45,changed_units=26))
 compare('POLICY_TOTAL','HT',base_ht,ht,['policy_id','feature'],'estimated_total')
 compare('POLICY_SHARE','HT',base_hs,hs,['policy_id','label'],'design_corrected_share')
 compare('STAGE_SHARE','HT',base_gs,hg,['stage','label'],'design_corrected_share')
 compare('POLICY_TOTAL','DIFF',base_dt,dt,['policy_id','feature'],'estimated_total')
 compare('POLICY_SHARE','DIFF',base_ds,ds,['policy_id','label'],'design_corrected_share')
 # Original stage DIFF is all NA; still retain every stage under alternate coder.
 compare('STAGE_SHARE','DIFF',j.read(out/'frozen_before_patch/G_STAGE_AUDIT_CORRECTION.csv'),dg,['stage','label'],'design_corrected_share')
 j.csvout(out/'G_CODER_DISAGREEMENT_SENSITIVITY.csv',rows)
 j.csvout(out/'G_STAGE_HT_SECONDARY_SWAP.csv',hg)
 j.csvout(out/'G_POLICY_HT_SECONDARY_SWAP.csv',hs)
 return pd.DataFrame(rows)

def research_evidence(v,out,hs,hg,impact):
 if (v.root/'G_DESCRIPTIVE_SCOPE_PROTOCOL.json').exists():
  import g_descriptive_delivery_20261028 as delivery
  return delivery.research_evidence(v,out,hs,hg,impact)
 sample=j.read(v/'sample/actual_sample_BACKEND.csv');a,b=actual_returns(v)
 presence=j.read(out/'frozen_before_patch/G_POLICY_FUNCTION_STATUS_204.csv')
 qa=j.load(out/'QA.json') if (out/'QA.json').exists() else {}
 rootcause=j.read(out/'SOURCE_COVERAGE_ROOT_CAUSE.csv')
 evidence_files=[out/'G_POLICY_HT_SHARES.csv',out/'G_STAGE_HT_ESTIMATES.csv',out/'SOURCE_SCOPE_IMPACT_ON_G.csv',out/'G_ERROR_SOURCE_DECOMPOSITION.csv',out/'G_CODER_DISAGREEMENT_SENSITIVITY.csv',out/'frozen_before_patch/G_POLICY_FUNCTION_STATUS_204.csv']
 e=dict(assessment_identity='POSTHOC_USE_SCOPE_ASSESSMENT',AUDIT_SAMPLE_COMPLETE=set(a.unit_id)==set(sample.unit_id),
   ESTIMATOR_NUMERICALLY_VERIFIED=bool(qa.get('all_passed',False) and all(j.sha(j.ROOT/n)==h for n,h in qa.get('code_sha256',{}).items())),
   G_POLICY_ESTIMATE_DEFINED=bool(hs.design_corrected_share.notna().all()),G_STAGE_ESTIMATE_DEFINED=bool(hg.design_corrected_share.notna().all()),
   SOURCE_FIXED_FRAME_COVERED=bool(set(a.unit_id)==set(sample.unit_id)),
   FULL_SOURCE_BODY_COVERAGE_SUPPORTED=False,
   POLICY_FUNCTION_PRESENCE_SUPPORTED=dict(supported=int(presence.function_presence_status.eq('SUPPORTED_WITHIN_BOUND_UNIT_SCOPE').sum()),unknown=int(presence.function_presence_status.ne('SUPPORTED_WITHIN_BOUND_UNIT_SCOPE').sum()),confirmed_absent=0),
   POLICY_G_INTENSITY_SUPPORTED='INDETERMINATE_FINITE_SAMPLE_AND_CODER_SOURCE_LIMITATIONS',
   RESEARCH_USE_SCOPE_ACCEPTED=False,defined_policy_n=int(hs.loc[hs.design_corrected_share.notna(),'policy_id'].nunique()),
   evidence_files=[dict(path=str(p),sha256=j.sha(p)) for p in evidence_files],
   limitations=['HT_IS_POST_AUDIT_SENSITIVITY_NOT_PREDECLARED_PRIMARY',
    'NORMAL_RATIO_INTERVALS_SMALL_N2_STRATA_NOT_COVERAGE_GUARANTEE','NO_REAL_EXACT_RESULT_USE_SCOPE_ACCEPTANCE_EVENT',
    'FULL_SOURCE_BODY_NOT_ESTABLISHED;UNMAPPED_SPANS_DISTINCT_FROM_INFRAME_RISK_UNITS',
    'G2_FALSE_POSITIVES_G3_GATE_AND_HEAD_OMISSIONS','26_DISAGREEMENT_UNITS_NO_AUTOMATIC_CONSENSUS','T_OUT_OF_REVIEW_SCOPE'])
 # Read an actual explicitly signed event only if it binds these exact products.
 approval=v.root/'G_POSTHOC_EXACT_USE_APPROVAL.json'
 if approval.exists():
  x=j.load(approval);j.signed(x,'ACCEPT_EXACT_G_POSTHOC_DESCRIPTIVE_SCOPE','REAL')
  e['RESEARCH_USE_SCOPE_ACCEPTED']=x.get('scope')=='FIXED_EXTRACTED_UNIT_FRAME' and x.get('products')=={p.name:j.sha(p) for p in evidence_files[:2]}
 j.jsonout(out/'research_evidence.json',e);return e

def applicability(v,out,hs,ht,impact,e):
 if e.get('assessment_identity')=='FIXED_FRAME_DESCRIPTIVE_SCOPE_ASSESSMENT':
  import g_descriptive_delivery_20261028 as delivery
  return delivery.applicability(v,out,hs,ht,impact,e)
 old=j.read(out/'frozen_before_patch/G_POLICY_INPUT_APPLICABILITY_68.csv');diff=j.read(out/'frozen_before_patch/G_POLICY_AUDIT_CORRECTION.csv')
 presence=j.read(out/'frozen_before_patch/G_POLICY_FUNCTION_STATUS_204.csv');rows=[]
 for r in old.to_dict('records'):
  pid=r['policy_id'];hh=hs[hs.policy_id.eq(pid)];dd=diff[diff.policy_id.eq(pid)];tt=ht[ht.policy_id.eq(pid)].set_index('feature');ss=impact[impact.policy_id.eq(pid)].iloc[0]
  row=dict(policy_id=pid,stage=r['stage'],fixed_evidence_n=tt.iloc[0].fixed_evidence_n,sample_n=tt.iloc[0].sample_n,
    DIFF_share_defined=bool(pd.to_numeric(dd.design_corrected_share,errors='coerce').notna().all()),HT_share_defined=bool(hh.design_corrected_share.notna().all()),
    HT_eligibility_total=tt.loc['eligibility','estimated_total'],HT_G_assignment_denominator=hh.iloc[0].assignment_denominator,
    full_source_body_coverage=ss.full_policy_body_coverage,
    source_exceptions_n=int(ss.potential_missing_n)+int(ss.unresolved_span_n),
    known_absence=False,policy_intensity_use='INDETERMINATE',
    descriptive_share_use='FIXED_FRAME_POST_AUDIT_ESTIMATE_WITH_LIMITATIONS' if hh.design_corrected_share.notna().all() else 'UNDEFINED_ZERO_ESTIMATED_ASSIGNMENTS_NOT_CONFIRMED_G0',
    exact_research_adoption=False,full_C2_release=False)
  for g in j.G:
   z=hh[hh.label.eq(g)].iloc[0];pr=presence[presence.policy_id.eq(pid)&presence.G.eq(g)].iloc[0]
   row[g+'_presence']=pr.function_presence_status;row[g+'_HT_share']=z.design_corrected_share;row[g+'_HT_share_SE']=z.standard_error
   row[g+'_HT_total']=tt.loc[g,'estimated_total'];row[g+'_HT_total_SE']=tt.loc[g,'standard_error']
  rows.append(row)
 j.csvout(out/'G_POLICY_INPUT_APPLICABILITY_68.csv',rows)
 # Current per-policy interface now uses actual definedness; old file is frozen.
 j.csvout(v/'G_POLICY_INPUT_APPLICABILITY_68.csv',rows)

def figures(out,hs,hg):
 import matplotlib;matplotlib.use('Agg')
 import matplotlib.pyplot as plt
 plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8,'svg.fonttype':'none','pdf.fonttype':42,'axes.spines.top':False,'axes.spines.right':False})
 old=j.read(out/'frozen_before_patch/G_POLICY_INPUT_APPLICABILITY_68.csv');diff=j.read(out/'frozen_before_patch/G_STAGE_AUDIT_CORRECTION.csv');rows=[]
 for stage in j.STAGES:
  for g in j.G:
   cond=pd.to_numeric(old.loc[old.stage.eq(stage),'conditional_'+g]);d=diff[diff.stage.eq(stage)&diff.label.eq(g)].iloc[0];h=hg[hg.stage.eq(stage)&hg.label.eq(g)].iloc[0]
   for method,val,se in [('Frozen conditional',cond.mean(),np.nan),('DIFF',pd.to_numeric(d.design_corrected_share,errors='coerce'),pd.to_numeric(d.standard_error,errors='coerce')),('HT',h.design_corrected_share,h.standard_error)]:
    rows.append(dict(stage=stage,label=g,estimator=method,value=val,SE=se,interval='AUDIT_DESIGN_TAYLOR_NORMAL_APPROX' if method=='HT' else 'NO_INTERVAL_DISPLAYED' if method.startswith('Frozen') else 'UNDEFINED',identity=IDENTITY))
 plot=pd.DataFrame(rows);j.csvout(out/'Figure_G_estimator_source_data.csv',plot)
 fig,axes=plt.subplots(1,3,figsize=(10.5,3.3),sharey=True)
 for ax,g in zip(axes,j.G):
  for method,offset,color,marker in [('Frozen conditional',-.1,'#868b91','s'),('HT',.1,'#357786','o')]:
   z=plot[plot.label.eq(g)&plot.estimator.eq(method)].set_index('stage').loc[j.STAGES]
   if method=='HT':ax.errorbar(np.arange(4)+offset,z.value,yerr=1.96*z.SE,fmt=marker,color=color,ms=4,capsize=2,label='HT: audit-design approx. 95%')
   else:ax.plot(np.arange(4)+offset,z.value,marker,ms=4,color=color,label='Frozen conditional (no audit CI)')
  ax.set_title(g,loc='left',fontweight='bold');ax.set_xticks(range(4),[s.replace('-','–') for s in j.STAGES],rotation=30,ha='right');ax.axhline(0,color='.8',lw=.6)
  ax.text(.02,.97,'DIFF: undefined in all stages',transform=ax.transAxes,va='top',fontsize=7,color='#955a45')
 axes[0].set_ylabel('Policy-equal assignment share');axes[1].legend(loc='lower center',bbox_to_anchor=(.5,-.59),ncol=2,fontsize=7)
 fig.subplots_adjust(left=.07,right=.99,top=.88,bottom=.33,wspace=.15)
 for ext in ['png','svg','pdf']:fig.savefig(j.longpath(out/('Figure_G_estimator_comparison.'+ext)),dpi=320)
 plt.close(fig)
 (out/'Figure_G_legend.md').write_text('Figure | Post-audit comparison of policy-equal G composition. Grey squares: frozen model-conditional shares without audit intervals. Blue points: direct stratified HT ratio estimates; bars are ±1.96 Taylor design SE, not policy Bootstrap intervals or guaranteed probability bounds. DIFF is undefined in all stages because some policy totals are negative; no policies are dropped. HT was introduced after seeing audit truth and is an estimator sensitivity. Fixed extracted-unit frame only; source omissions and semantic coder disagreement are not included in these error bars.\n','utf-8')

def execute(refresh_source=False):
 started=j.now();ctx,parent,v,out=locations();out.mkdir(exist_ok=True)
 frozen=j.load(out/'frozen_manifest.json')
 j.require(all(j.sha(out/'frozen_before_patch'/n)==h for n,h in frozen.items()),'Frozen DIFF history changed')
 j.require(all(j.sha(x['path'])==x['sha256'] for x in j.load(v/'G_ONLY_INPUT_BINDING.json')['dependencies']),'Frozen G input changed')
 frame=j.read(v/'sampling_frame_BACKEND.csv');sample=j.read(v/'sample/actual_sample_BACKEND.csv');a,b=actual_returns(v)
 alloc=j.read(v/('allocation_'+j.load(v/'sample/sample_manifest.json')['option']+'.csv'))
 j.require(len(a)==528 and len(b)==106 and len(frame)==32858,'Actual audit scope changed')
 if refresh_source or not (out/'SOURCE_SCOPE_IMPACT_ON_G.csv').exists():impact=source_coverage(frame,parent,out)
 else:impact=j.read(out/'SOURCE_SCOPE_IMPACT_ON_G.csv')
 hm,ht=j.estimate_direct_stratified_HT(frame,sample,a,alloc);hs,hg=j.evaluate_function_history(frame,hm);changes=j.stage_changes(hg)
 hs['identity']=IDENTITY;hg['identity']=IDENTITY;changes['identity']=IDENTITY
 j.csvout(out/'G_POLICY_HT_TOTALS.csv',ht);j.csvout(out/'G_POLICY_HT_SHARES.csv',hs);j.csvout(out/'G_STAGE_HT_ESTIMATES.csv',hg);j.csvout(out/'G_STAGE_HT_CHANGES.csv',changes)
 cov=[]
 for pid,(_,matrix,_,_) in hm.items():
  for i,k in enumerate(['eligibility']+j.G):
   for q,kk in enumerate(['eligibility']+j.G):cov.append(dict(policy_id=pid,feature_1=k,feature_2=kk,covariance=matrix[i,q],identity='HT_DESIGN_COVARIANCE'))
 j.csvout(out/'G_POLICY_HT_COVARIANCE.csv',cov)
 dt=j.read(out/'frozen_before_patch/DESIGN_ASSISTED_TOTALS.csv');ds=j.read(out/'frozen_before_patch/G_POLICY_AUDIT_CORRECTION.csv')
 cmp=hs.merge(ds,on=['policy_id','stage','label'],suffixes=('_HT','_DIFF'),validate='one_to_one')
 for k in ['design_corrected_share','standard_error','assignment_denominator']:
  cmp[k+'_DIFF']=pd.to_numeric(cmp[k+'_DIFF'],errors='coerce');cmp[k+'_HT_minus_DIFF']=cmp[k+'_HT']-cmp[k+'_DIFF']
 for feature in ['eligibility']+j.G:
  hh=ht[ht.feature.eq(feature)].set_index('policy_id');dd=dt[dt.feature.eq(feature)].set_index('policy_id')
  for method,z in [('HT',hh),('DIFF',dd)]:
   cmp[feature+'_'+method+'_total']=cmp.policy_id.map(pd.to_numeric(z.estimated_total));cmp[feature+'_'+method+'_SE']=cmp.policy_id.map(pd.to_numeric(z.standard_error))
  cmp[feature+'_total_HT_minus_DIFF']=cmp[feature+'_HT_total']-cmp[feature+'_DIFF_total']
 cmp['fixed_evidence_n']=cmp.policy_id.map(frame[frame.existing_fields_to_reuse.ne('')].groupby('policy_id').size()).fillna(0).astype(int)
 cmp['sample_n']=cmp.policy_id.map(sample.groupby('policy_id').size()).fillna(0).astype(int)
 cmp['identity']=IDENTITY;j.csvout(out/'G_ESTIMATOR_COMPARISON.csv',cmp)
 rank=[]
 for stage in j.STAGES:
  z=hg[hg.stage.eq(stage)];valid=z.design_corrected_share.notna().all()
  rank.append(dict(stage=stage,policy_n=int(z.iloc[0].policy_n),HT_defined_policy_n=int(hs[hs.stage.eq(stage)&hs.label.eq('G1')].design_corrected_share.notna().sum()),
   DIFF_defined_policy_n=int(pd.to_numeric(ds.loc[ds.stage.eq(stage)&ds.label.eq('G1'),'design_corrected_share'],errors='coerce').notna().sum()),
   HT_point_order=' > '.join(z.sort_values('design_corrected_share',ascending=False).label) if valid else 'UNDEFINED',
   ordering_identity='POINT_ORDER_ONLY_NOT_STATISTICAL_DISTINGUISHABILITY',DIFF_order='UNDEFINED',identity=IDENTITY))
 j.csvout(out/'G_STAGE_ESTIMATOR_RANKING.csv',rank)
 error_decomposition(frame,sample,a,out);sensitivity(frame,sample,a,b,alloc,out,ht,hs,hg,dt,ds)
 e=research_evidence(v,out,hs,hg,impact);decision=j.assess_research_use(e);j.jsonout(out/'G_RESEARCH_USE_ASSESSMENT_UPDATED.json',decision)
 applicability(v,out,hs,ht,impact,e)
 figures(out,hs,hg)
 result=dict(G_estimation_computation_complete=True,actual_primary_n=len(a),actual_secondary_n=len(b),HT_defined_policy_n=e['defined_policy_n'],
  HT_defined_stage_n=int(hg[hg.design_corrected_share.notna()].stage.nunique()),
  DIFF_defined_policy_n=44,DIFF_negative_policy_n=24,DIFF_unchanged=True,assessment=decision,
  model_fits=0,threshold_changes=0,new_probability_samples=0,part2_started=False,
  status='COMPUTED_POST_AUDIT_HT_SENSITIVITY_WITH_LIMITATIONS')
 j.jsonout(out/'PART1_EXECUTION_STATUS.json',result)
 if (v.root/'G_DESCRIPTIVE_SCOPE_PROTOCOL.json').exists():
  import g_descriptive_delivery_20261028 as delivery
  delivery.publish_existing_results(v,out,result)
 j.jsonout(out/'execution_log.json',dict(started_at=started,completed_at=j.now(),entry='g_estimator_stability_20261028.execute',result=result))
 j.jsonout(out/'delivery_manifest.json',dict(files={str(p.relative_to(out)):j.sha(p) for p in out.rglob('*') if p.is_file() and 'frozen_before_patch' not in p.parts and p.name not in ['delivery_manifest.json','PART1_G_DELIVERY_MANIFEST.json']},
  source_code={p:j.sha(j.ROOT/p) for p in ['joint_history_audit_20261028.py','joint528_G_ONLY_execution_20261028.py','g_estimator_stability_20261028.py']},
  identity=IDENTITY,part2_started=False))
 if (v.root/'G_DESCRIPTIVE_SCOPE_PROTOCOL.json').exists():delivery.finalize_manifest(v,out,result)
 return result

if __name__=='__main__':print(json.dumps(j.clean_json(execute(refresh_source='--refresh-source' in sys.argv)),ensure_ascii=False))
