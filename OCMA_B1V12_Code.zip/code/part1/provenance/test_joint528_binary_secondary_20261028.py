"""Export/readback checks only; synthetic decisions stay in memory."""
from pathlib import Path
from unittest.mock import patch
from openpyxl import load_workbook
import pandas as pd
import joint_history_audit_20261028 as j
import joint528_compact_20261028 as c

FOLDER=j.ROOT/'outputs/JOINT_528_ac6da323683e5609'
FILE=FOLDER/'JOINT_528_G_ONLY_第二编码_01简表.xlsx'
book=load_workbook(FILE,read_only=True,data_only=False);BASE={s.title:list(s.values) for s in book.worksheets};book.close()
class Sheet:
 def __init__(self,values):self.values=values
class FakeBook:
 def __init__(self,data):self.data=data;self.sheetnames=list(data)
 def __getitem__(self,k):return Sheet(self.data[k])
 def close(self):pass
def payload(fields):
 data={k:[list(row) for row in values] for k,values in BASE.items()};header=data['审核填写'][0]
 for key,value in fields.items():data['审核填写'][1][header.index(key)]=value
 with patch.object(c,'load_workbook',return_value=FakeBook(data)):return c.g_only_xlsx_payload(FILE)[0]
results=[]
def check(name,identity,fn):fn();results.append(dict(test=name,identity=identity,status='PASS'))
def real_blank():
 p,qa=c.g_only_xlsx_payload(FILE);assert qa==dict(roster_n=106,reading_blocks=106,touched_n=0,blank_n=106)
 assert not p['records'] and p['coder_role']=='SECONDARY' and not p['confirmation']
 _,parent,child=c.location();fixed=j.read(child/'sample/registered_SECONDARY_TEMPLATE.csv')
 assert {r[0] for r in BASE['审核填写'][1:]}==set(fixed.unit_id)
 before=j.load(parent/'G_history_priority_patch_20261028/frozen_input_hashes.json')
 assert all(j.sha(v['path'])==v['sha256'] for v in before.values())
 assert j.sha(FOLDER/'JOINT_528_G_ONLY_第二编码填写.xlsx')=='c94165ddde643a5f5a957d2c314fc71360ef4ea7295ed2d11d8ff75da8e98953'
def explicit_positive():
 p=payload({'合格性':1,'G1':1,'G2':0,'G3':1,'属于目标正文':1,'句条无异常':1})
 a,e=j.normalize_truth(pd.DataFrame(p['records']),review_scope='G_ONLY');assert e.empty
 r=a.iloc[0];assert [r[k] for k in j.G]==[1,0,1] and r.field_origin_G2=='CURRENT_CODER_EXPLICIT'
 assert a[j.T].isna().all().all() and all(r['independent_'+k] for k in j.G)
def negative_parent():
 p=payload({'合格性':0});a,e=j.normalize_truth(pd.DataFrame(p['records']),review_scope='G_ONLY');assert e.empty
 r=a.iloc[0];assert [r[k] for k in j.G]==[0,0,0] and r.field_origin_G1=='DERIVED_FROM_CURRENT_INELIGIBLE'
def missing_not_zero():
 p=payload({'合格性':1,'G1':1,'属于目标正文':1,'句条无异常':1})
 a,e=j.normalize_truth(pd.DataFrame(p['records']),review_scope='G_ONLY');assert a.empty and len(e)==1
 p=payload({'G1':1,'G2':0,'G3':0,'属于目标正文':1,'句条无异常':1})
 a,e=j.normalize_truth(pd.DataFrame(p['records']),review_scope='G_ONLY');assert a.empty and len(e)==1
def unit_issue_not_G_zero():
 p=payload({'合格性':1,'G1':1,'G2':0,'G3':0,'属于目标正文':1,'句条无异常':0})
 a,e=j.normalize_truth(pd.DataFrame(p['records']),review_scope='G_ONLY');assert e.empty
 assert a.iloc[0].eligibility==1 and a.iloc[0].G1==1 and j.feature_vector(a.iloc[0].to_dict(),review_scope='G_ONLY') is None
def source_exclusion():
 p=payload({'属于目标正文':0});a,e=j.normalize_truth(pd.DataFrame(p['records']),review_scope='G_ONLY');assert e.empty
 assert j.feature_vector(a.iloc[0].to_dict(),review_scope='G_ONLY').sum()==0 and pd.isna(a.iloc[0].eligibility)
def reject_text_choice():
 try:payload({'合格性':'不合格'})
 except ValueError:pass
 else:raise AssertionError('Binary field accepted text')
check('106_IDs_106_readings_blank_secondary_and_frozen_inputs','REAL_SAVED_FILES',real_blank)
for fn in [explicit_positive,negative_parent,missing_not_zero,unit_issue_not_G_zero,source_exclusion,reject_text_choice]:check(fn.__name__,'SYNTHETIC_IN_MEMORY_ONLY',fn)
report=dict(workbook_sha256=j.sha(FILE),results=results,passed=len(results),failed=0,actual_human_judgments_ingested=0,statistical_or_model_runs=0,generated_at=j.now())
j.jsonout(FOLDER/'xlsx_authoring/binary_secondary_QA.json',report)
print(report)
