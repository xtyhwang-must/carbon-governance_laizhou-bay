"""Create unsigned, hash-bound proposals. Never overwrites any filled signature."""
from common import *
def proposal(ctx,kind,input_path=None,output=None,pool_id=None,protocol_sha256=None):
 prep=ctx.artifact('prepare');d=dict(identity=ctx.identity,reviewer='',signed_at='',status='UNSIGNED_PROPOSAL_NOT_APPROVAL')
 if kind.startswith('pool-'):require(pool_id and protocol_sha256,'Explicit pool_id and protocol_sha256 required');d.update(pool_id=pool_id,protocol_sha256=protocol_sha256)
 if kind=='return':
  require(input_path is not None,'Returned file path required')
  d.update(statement='CONFIRM_ACTUAL_HUMAN_RETURN',review_sha256=sha(input_path),sample_sha256=sha(prep/'sample.csv'),model_sha256=load(prep/'v3_lock.json')['model_sha256'],batch_id=Path(input_path).stem)
 elif kind=='decisions':
  require(input_path is not None,'Filled decision table required');d.update(statement='APPROVE_SCOPED_CODING_DECISIONS',decisions_sha256=sha(input_path))
 elif kind=='pool-protocol':
  r=ctx.manifest['stages'].get('plan-audit:'+str(pool_id));require(r and (ctx.root/r['artifact']/'protocol.json').is_file(),'Generate pool proposal first')
  require(protocol_sha256==sha(ctx.root/r['artifact']/'protocol.json'),'Wrong explicit protocol');d.update(statement='APPROVE_EXACT_LOCAL_POOL_PROTOCOL')
 elif kind=='pool-audit':
  require(input_path is not None,'Actual audit return required');plan=ctx.artifact('plan-audit:'+str(pool_id));require(protocol_sha256==sha(plan/'protocol.json'),'Wrong explicit protocol')
  d.update(statement='CONFIRM_ACTUAL_POOL_AUDIT',review_sha256=sha(input_path),protocol_sha256=sha(plan/'protocol.json'))
 elif kind=='pool-acceptance':
  require(input_path is not None,'Actual audit_quality.json path required');q=load(input_path)
  require(q['quality_pass'],'Failed audit cannot be accepted');d.update(statement='ACCEPT_EXACT_VALIDATED_POOL',audit_quality_sha256=sha(input_path),protocol_sha256=q['protocol_sha256'])
 elif kind=='publish':
  ctx.artifact('validate-candidate');ass=ctx.artifact('assemble-candidate');d.update(statement='APPROVE_EXACT_C2_LABELS_AND_EVIDENCE',candidate_sha256=sha(ass/'C2_candidate.csv'),bundle_sha256=sha(ass/'candidate_evidence_bundle.json'))
 else:raise ValueError('Unknown signature kind')
 folder=ctx.root/'unsigned_proposals';folder.mkdir(exist_ok=True);path=longpath(output) if output else folder/(kind+'_'+digest(d)[:16]+'.json')
 require(not path.exists(),'Existing signature/proposal preserved; choose a new output path')
 jsonout(path,d);return dict(state='WAITING_FOR_APPROVAL',unsigned_proposal=str(path),actual_approval=False)

