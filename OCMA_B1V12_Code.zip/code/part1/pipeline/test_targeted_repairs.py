"""Synthetic-only independent expectations for the requested targeted repairs."""
from common import *
from coding_pipeline import execute
from measurement import generate,verify
from export_supplement import export
import tempfile

def main():
 code=Path(__file__).resolve().parent;report=load(code/'end_to_end_test_report.json');ctx=Context(report['workspace'],'full_chain');root=longpath(Path(tempfile.mkdtemp(prefix='SYNTHETIC_TEST_ONLY_patch_',dir=code/'synthetic_tests')));checks={}
 def ck(n,v):checks[n]=bool(v);require(checks[n],n)
 def reject(n,fn):
  try:fn()
  except (ValueError,KeyError):checks[n]=True;return
  raise ValueError('Not rejected: '+n)
 # Independent hand-worked policy composition and different action prevalence.
 cat=[];can=[];dec=[]
 specs=[('multi','m1',1,['G1','G2','T1'],True),('multi','m2',1,['G1','T2'],True),('single','s1',1,['G3','T6'],True),('empty','n1',0,[],True),('zero','z1',1,[],True),('partial','p1',1,['G1','T1'],False)]
 for pol,uid,elig,positive,complete in specs:
  cat.append(dict(unit_id=uid,policy_id=pol,policy_version_id='v1',exact_evidence_text='A full and unique governance action '+uid+'.',parent_member_count=1))
  can.append(dict(unit_id=uid,policy_id=pol,complete=complete,C2_eligibility=str(elig),**{'C2_'+k:str(int(k in positive)) for k in LABELS[1:]}))
  dec.append(dict(decision_event_id='D_'+uid,type='ACTION_COUNTING_BOUNDARY',value='CONFIRM',unit_ids=json.dumps([uid]),action_unit_id='A_'+uid,rule_text='Synthetic exact boundary'))
 ca=pd.DataFrame(cat);cc=pd.DataFrame(can);dd=pd.DataFrame(dec);out=root/'measurement';out.mkdir();res=generate(ctx,out,ca,cc,dd);s=read(out/'policy_level_shares.csv').set_index('policy_id');pr=read(out/'action_prevalence.csv').set_index('policy_id');fr=read(out/'equal_action_weight_sensitivity.csv').set_index('policy_id')
 ck('multilabel_assignment_denominator',np.isclose(float(s.loc['multi','G1']),2/3) and np.isclose(float(s.loc['multi','G2']),1/3) and s.loc['multi','G_assignment_denominator']=='3')
 ck('G_and_T_have_separate_denominators',s.loc['multi','T_assignment_denominator']=='2' and float(s.loc['multi','T1'])==.5)
 ck('action_prevalence_separate',float(pr.loc['multi','G1_action_prevalence'])==1 and float(pr.loc['multi','G2_action_prevalence'])==.5)
 ck('fractional_action_sensitivity_separate',float(fr.loc['multi','G1'])==.75 and float(fr.loc['multi','G2'])==.25)
 ck('single_label_composition',float(s.loc['single','G3'])==1 and float(s.loc['single','T6'])==1)
 ck('zero_eligible_stays_NA',s.loc['empty','G1']=='' and s.loc['empty','eligible_action_n']=='0')
 ck('zero_assignment_denominator_flagged',s.loc['zero','G1']=='' and not res['POLICY_MEASUREMENT_READY'] and 'zero:G:ZERO_GROUP_LABEL' in res['issues'])
 ck('partial_review_not_policy_share',s.loc['partial','G1']=='' and s.loc['partial','measurement_ready']=='False')
 mapping=read(out/'action_unit_mapping.csv').set_index('unit_id');ck('ineligible_needs_no_action_signature',mapping.loc['n1','counting_status']=='NOT_COUNTED_INELIGIBLE' and mapping.loc['n1','action_unit_id']=='')
 altered=read(out/'policy_level_shares.csv');altered.loc[altered.policy_id.eq('multi'),'G1']='0.5';csvout(out/'policy_level_shares.csv',altered);reject('independent_validator_catches_old_mean',lambda:verify(out,cc,ca,dd))
 # Invalid merges block only affected policy measurement, preserving the exception and other policies.
 conflict=root/'merge_conflict';conflict.mkdir();cd=dd.copy();cd.loc[cd.decision_event_id.isin(['D_m1','D_m2']),'action_unit_id']='COLLIDING_ACTION';cm=generate(ctx,conflict,ca,cc,cd);cf=read(conflict/'policy_level_shares.csv').set_index('policy_id');cx=read(conflict/'action_counting_exceptions.csv')
 ck('merge_conflict_is_scoped_exception',cf.loc['multi','measurement_ready']=='False' and cf.loc['single','measurement_ready']=='True' and set(['m1','m2'])<=set(cx.unit_id))
 # General rule covers only explicitly approved, complete, unique boundaries.
 gca=ca.iloc[:2].copy();gca.loc[gca.unit_id.eq('m2'),'parent_member_count']=2;gout=root/'general';gout.mkdir();gd=pd.DataFrame([dict(decision_event_id='GEN',type='ACTION_COUNTING_RULE',value='CONFIRM',unit_ids=json.dumps(['m1','m2']),rule_text='Only complete single-parent distinct units',action_unit_id='')]);generate(ctx,gout,gca,cc.iloc[:2],gd);gm=read(gout/'action_unit_mapping.csv').set_index('unit_id')
 ck('generic_count_rule_excludes_fragments',gm.loc['m1','counting_status']=='COUNTED_ELIGIBLE' and gm.loc['m2','counting_status']=='UNRESOLVED_COUNTING')
 # Source-version confirmation cannot silently resolve a different extraction defect.
 scope=root/'scope';scope.mkdir();csvout(scope/'issue_scope_audit.csv',[dict(issue_type='BODY_IDENTITY_OR_ATTACHMENT_BOUNDARY',affected_ids='["m1"]',blocks_coding=True),dict(issue_type='EXTRACTION_FRAGMENT',affected_ids='["m1"]',blocks_coding=True)])
 sd=pd.DataFrame([dict(type='SOURCE_VERSION',value='CONFIRM',unit_ids='["m1"]')]);sp,rp=pending_scope(scope,ca,sd);ck('version_approval_does_not_clear_extraction',sp=={'m1'})
 sd=pd.concat([sd,pd.DataFrame([dict(type='EXTRACTION_SCOPE',value='CONFIRM',unit_ids='["m1"]')])],ignore_index=True);sp,rp=pending_scope(scope,ca,sd);ck('explicit_extraction_scope_required',not sp)
 # Preserve actual Excel text/context and source positioning including whitespace.
 from openpyxl import Workbook
 w=Workbook();sh=w.active;sh.append(['unit_id','text','context','source_location','eligibility_choice','human_G1']);original=[' id_1 ','  \nOriginal  text\t ',' context\n  ',' page 1:  2 ',' ELIGIBLE ',' 1 '];sh.append(original);xl=root/'roundtrip.xlsx';w.save(xl);rd=read_review(xl).iloc[0]
 ck('Excel_original_characters_preserved',rd.text==original[1] and rd.context==original[2] and rd.source_location==original[3]);ck('Excel_ID_and_options_normalized',rd.unit_id=='id_1' and rd.eligibility_choice=='ELIGIBLE' and rd.human_G1=='1')
 ck('timezones_sort_by_actual_instant',normalized_time('2026-10-27T09:00:00+08:00')<normalized_time('2026-10-27T02:00:00+00:00'))
 reject('synthetic_supplement_rejected',lambda:export(ctx,root))
 # Registry signature excludes counting, metadata and held-out truth while including training truth.
 from issue_scope import signatures
 prep=ctx.artifact('prepare');reg=ctx.artifact('build-registry');h=read(reg/'development_labels.csv');u=read(reg/'development_corpus.csv');dc=read(reg/'decision_registry.csv');sigdir=root/'signatures';sigdir.mkdir();shutil.copyfile(reg/'registry_snapshot.csv',sigdir/'registry_snapshot.csv');shutil.copyfile(reg/'decision_registry.csv',sigdir/'decision_registry.csv')
 signatures(sigdir,prep,h,u,dc,True);before=sha(sigdir/'training_signature.json');extra=dc[dc.type.eq('ACTION_COUNTING_BOUNDARY')].iloc[[0]].copy();extra['rule_text']='Different counting only';d2=pd.concat([dc,extra],ignore_index=True);signatures(sigdir,prep,h,u,d2,True)
 ck('counting_decision_does_not_change_training_signature',sha(sigdir/'training_signature.json')==before)
 h2=h.copy();h2.loc[h2.index[0],'human_G1']='1' if h2.iloc[0].human_G1=='0' else '0';signatures(sigdir,prep,h2,u,dc,True);ck('actual_training_label_invalidates_signature',sha(sigdir/'training_signature.json')!=before)
 original_hash=ctx.code_hash('train');ck('plot_and_measurement_not_numeric_training_dependencies','plot_s6.py' not in original_hash and 'measurement.py' not in original_hash)
 # Two pools with different claims are interleaved; no last-plan implicit selection.
 records={};steps=[]
 def run(cmd,**kw):
  r=execute(ctx,cmd,**kw);steps.append(r);require(r.get('state')!='FAILED',r.get('message',''));return r
 def sign(path,statement,**kwargs):jsonout(path,dict(identity='SYNTHETIC_TEST_ONLY',statement=statement,reviewer='SYNTHETIC_TEST_ONLY',signed_at='2026-10-27T04:00:00+00:00',**kwargs));return path
 for pid,label in [('poolA','G1'),('poolB','G2')]:
  definition=root/(pid+'.json');jsonout(definition,dict(family_id='two_pool_family',label=label,direction='NEGATIVE',score_cut=1.,design='SRSWOR_FINITE_POOL',seed=11,family_alpha=.05,planned_claims=2,risk_limit=.02,sample_n=99999,claim_scope='SYNTHETIC_TEST_ONLY'))
  p=run('plan-audit',pool_id=pid,input=definition);protocol=ctx.root/p['artifact']/'protocol.json';ph=sha(protocol);approval=sign(root/(pid+'_protocol.json'),'APPROVE_EXACT_LOCAL_POOL_PROTOCOL',protocol_sha256=ph)
  records[pid]=dict(input=definition,protocol_sha256=ph,approval=approval,pool_id=pid,batch_id='batch01')
 prior_audit=set()
 for _,apath in ctx.audit_events():
  for r in read(apath/'human_audit_events.csv').itertuples():
   if r.field=='eligibility' and r.value=='0':prior_audit.add(r.unit_id)
 for pid in records:
  pp=ctx.root/ctx.manifest['stages']['plan-audit:'+pid]['artifact'];ck(pid+'_reuses_actual_ineligible_audits',not set(read(pp/'pool_members.csv').unit_id)&prior_audit)
 # A gets approved after B was planned.
 for pid in ['poolA','poolB']:
  d=records[pid];run('plan-audit',**d);pp=ctx.artifact('plan-audit:'+pid);sample=read(pp/'audit_review.csv');sample['truth']='0';review=root/(pid+'_review.csv');csvout(review,sample);sig=sign(root/(pid+'_review_signature.json'),'CONFIRM_ACTUAL_POOL_AUDIT',review_sha256=sha(review),protocol_sha256=d['protocol_sha256']);ss=load(sig);ss['signed_at']='2026-10-27T05:00:00+00:00';jsonout(sig,ss);d.update(review=review,signature=sig)
 bad=execute(ctx,'ingest-audit',pool_id='poolB',batch_id='wrong',review=records['poolA']['review'],signature=records['poolA']['signature'],protocol_sha256=records['poolB']['protocol_sha256']);ck('A_review_cannot_use_B_protocol',bad['state']=='FAILED')
 for pid in ['poolB','poolA']:
  d=records[pid];r=run('ingest-audit',**d);artifact=ctx.root/r['artifact'];approval=sign(root/(pid+'_accept.json'),'ACCEPT_EXACT_VALIDATED_POOL',protocol_sha256=d['protocol_sha256'],audit_quality_sha256=sha(artifact/'audit_quality.json'));d['acceptance']=approval;run('accept-pool',pool_id=pid,batch_id='batch01',protocol_sha256=d['protocol_sha256'],approval=approval)
 ck('two_interleaved_pools_accepted',len([x for x,_ in ctx.accepted_pools() if x.startswith(('accept-pool:poolA:','accept-pool:poolB:'))])==2)
 fam=load(ctx.root/'audit_family_registry.json');ck('family_alpha_budget_preserved',len(fam['families']['two_pool_family']['pools'])==2 and all(fam['pools'][p]['alpha']==.025 for p in ['poolA','poolB']))
 Bhash=ctx.manifest['stages']['plan-audit:poolB']['fingerprint'];A=records['poolA'];changed=root/'A_changed.json';d=load(A['input']);d['score_cut']=.123;jsonout(changed,d);bad=execute(ctx,'plan-audit',pool_id='poolA',input=changed,approval=A['approval'],protocol_sha256=A['protocol_sha256']);ck('changing_A_does_not_overwrite_B',bad['state']=='FAILED' and ctx.valid('plan-audit:poolB') and ctx.manifest['stages']['plan-audit:poolB']['fingerprint']==Bhash)
 run('plan-audit',**A)
 # A pool cannot evade the family ledger simply by changing its name.
 rename=run('plan-audit',pool_id='poolC',input=A['input']);ph=sha(ctx.root/rename['artifact']/'protocol.json');sig=sign(root/'rename_approval.json','APPROVE_EXACT_LOCAL_POOL_PROTOCOL',protocol_sha256=ph);bad=execute(ctx,'plan-audit',pool_id='poolC',input=A['input'],approval=sig,protocol_sha256=ph);ck('renamed_repeated_pool_rejected',bad['state']=='FAILED')
 inbox=ctx.root/'inbox/pools';inbox.mkdir(parents=True,exist_ok=True)
 for pid,d in records.items():jsonout(inbox/(pid+'.json'),{k:str(v) for k,v in d.items()})
 resumed=execute(ctx,'resume');ck('interleaved_pool_resume_reuses_model',next(r for r in resumed if r['stage']=='train')['reused']);ck('both_pool_plans_reused_on_resume',all(next(r for r in resumed if r['stage']=='plan-audit:'+p)['reused'] for p in records))
 # A genuine appended counting decision changes measurement but reuses the exact model.
 from review_registry import scope_binding
 catalog=read(ctx.artifact('prepare')/'corpus.csv');uid=catalog.unit_id.iloc[0];ids=[uid]
 decision=root/'counting_only.csv';csvout(decision,[dict(decision_id='NEW_COUNTING_ONLY',type='ACTION_COUNTING_RULE',value='CONFIRM',unit_ids=json.dumps(ids),rule_text='Synthetic complete single-parent scope only',action_unit_id='',representative_id='',scope_sha256=digest(ids),source_binding=scope_binding(catalog,ids))])
 sig=sign(root/'counting_signature.json','APPROVE_SCOPED_CODING_DECISIONS',decisions_sha256=sha(decision));run('ingest-decisions',decisions=decision,signature=sig);run('build-registry');rr=run('train');ck('actual_counting_append_reuses_existing_fit',rr['reused'])
 saved=ctx.training_dependency;ctx.training_dependency=lambda:'ALTERED_ACTUAL_LABEL_SIGNATURE';ctx._vcache={};ck('training_signature_change_invalidates_model_stage',not ctx.valid('train'));ctx.training_dependency=saved;ctx._vcache={}
 jsonout(code/'targeted_repair_test_report.json',dict(identity='SYNTHETIC_TEST_ONLY',passed=all(checks.values()),checks=checks,steps=steps,actual_fixture=str(root),real_training_run=False));print(json.dumps(dict(passed=True,checks=len(checks))))
if __name__=='__main__':main()
