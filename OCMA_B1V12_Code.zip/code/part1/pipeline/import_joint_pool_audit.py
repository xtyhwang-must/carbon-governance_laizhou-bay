"""Validate a single real return and feed existing pool-audit stages, without fitting."""
import sys,json,argparse,re
from pathlib import Path

def validate_rows(frame,contract):
 from common import require
 expected={r['unit_id']:r for r in contract['review_rows']}
 require(set(contract['review_columns'])<=set(frame.columns),'Missing required columns')
 require(frame.unit_id.is_unique and set(frame.unit_id)==set(expected),'Sample IDs changed: no deletion, substitution or duplicates')
 for row in frame.to_dict('records'):
  old=expected[row['unit_id']]
  for k in contract['protected_columns']:require(row.get(k,'')==old[k],'Protected content changed: '+k)
  for field in ['eligibility','G1','G2']:
   value=row.get('truth_'+field,'')
   require(value in ['','0','1','UNRESOLVED'],'Use 0, 1, UNRESOLVED or blank')
 # Do not derive a second sampled field: each requires its actual answer.
 require(any(row.get('truth_'+f,'') in ['0','1'] for row in frame.to_dict('records') for f in row['required_fields'].split(';')),'No actual sampled judgments: empty review cannot be accepted')
 return frame

def restore_display(frame,contract):
 """Only invert the registered display of the exact expected original string."""
 from common import require
 frame=frame.copy();expected={r['unit_id']:r for r in contract['review_rows']}
 for i,row in frame.iterrows():
  require(row.unit_id in expected,'Unknown sample ID')
  for field in contract['protected_columns']:
   raw=expected[row.unit_id][field]
   shown=re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f]',lambda m:f'⟦U+{ord(m.group()):04X}⟧',raw)
   if row.get(field)==shown:frame.at[i,field]=raw
 return frame

def main():
 p=argparse.ArgumentParser();p.add_argument('--workspace',required=True);p.add_argument('--run-id',required=True);p.add_argument('--review',required=True);p.add_argument('--reviewer');p.add_argument('--signed-at');p.add_argument('--confirmation-record');p.add_argument('--validate-only',action='store_true');a=p.parse_args()
 ws=Path(a.workspace);base=ws/'05_revision_work/R1_20261026/01_coding/coding_pipeline_completion';pointer=json.loads((base/'CURRENT_ACTIVE_PIPELINE.json').read_text(encoding='utf-8-sig'));sys.path.insert(0,pointer['active_code'])
 from common import Context,load,read,read_review,sha,jsonout,csvout,require,longpath,now,LABELS
 from coding_pipeline import execute
 ctx=Context(a.workspace,a.run_id);contract=load(ctx.root/'chat_approval_current_three_pools/joint_audit_contract.json');review=longpath(a.review);x=validate_rows(restore_display(read_review(review),contract),contract)
 reviewer=a.reviewer;signed_at=a.signed_at
 if review.suffix.lower()=='.xlsx':
  from openpyxl import load_workbook
  book=load_workbook(review,read_only=True,data_only=False)
  info={str(k):v for k,v in book['BATCH_INFO'].iter_rows(min_row=2,max_col=2,values_only=True) if k is not None}
  reviewer=reviewer or info.get('reviewer');signed_at=signed_at or info.get('signed_at');book.close()
 require(reviewer and signed_at,'Actual reviewer and timezone-aware completion time required')
 from datetime import datetime
 dt=datetime.fromisoformat(str(signed_at));require(dt.tzinfo is not None,'Use ISO time with timezone, e.g. +08:00')
 for d in contract['plans']:
  plan=ctx.artifact('plan-audit:'+d['pool_id']);require(sha(plan/'protocol.json')==d['protocol_sha256'],'Current pool differs from return contract')
  require(dt>datetime.fromisoformat(load(plan/'protocol_approval.json')['signed_at']),'Review time must follow protocol approval')
 if a.validate_only:print('VALID_REAL_RETURN_NO_IMPORT');return
 # Raw original always archived before pipeline import; no edits to Excel or answers.
 import shutil
 batch='JOINT_'+sha(review)[:20];folder=ctx.root/'actual_joint_audit_returns'/batch;folder.mkdir(parents=True,exist_ok=True)
 raw=folder/('actual_return'+review.suffix.lower())
 if not raw.exists():shutil.copyfile(review,raw)
 # Extra responses remain directed evidence, never counted in the probability audit.
 extras=[]
 for i,row in x.iterrows():
  for field in ['eligibility','G1','G2']:
   if field not in row.required_fields.split(';') and row['truth_'+field]!='':
    extras.append(dict(unit_id=row.unit_id,field=field,value=row['truth_'+field],identity='DIRECTED_RETURN_NOT_PROBABILITY_AUDIT',status='PRESERVED_PENDING_DIRECTED_REGISTRATION',original_return_sha256=sha(raw)))
    x.at[i,'truth_'+field]=''
 if extras:csvout(folder/'extra_directed_judgments.csv',extras)
 normalized=folder/'audit_review.csv'
 if not normalized.exists():csvout(normalized,x)
 signature=folder/'signature.json'
 signature_data=dict(identity='REAL',statement='CONFIRM_ACTUAL_POOL_AUDIT',reviewer=str(reviewer),signed_at=str(signed_at),review_sha256=sha(normalized),original_return_sha256=sha(raw),normalization='REGISTERED_CONTROL_CHARACTER_DISPLAY_ONLY',protocol_sha256s=[d['protocol_sha256'] for d in contract['plans']],timestamp_meaning='Actual human batch completion supplied in returned file/CLI, not invented per-row time')
 if a.confirmation_record:
  confirmation=load(a.confirmation_record);require(confirmation['review_sha256']==sha(raw) and confirmation['recorded_at']==str(signed_at),'Chat confirmation binding mismatch')
  signature_data.update(confirmation_record_sha256=sha(a.confirmation_record),timestamp_meaning='Recording time of explicit current user chat confirmation; original review completion time was not supplied',original_review_time=None)
  shutil.copyfile(a.confirmation_record,folder/'chat_confirmation.json')
 if signature.exists():require(load(signature)==signature_data,'Same return bytes already registered with different signature')
 else:jsonout(signature,signature_data)
 results=[]
 for d in contract['plans']:
  pid=d['pool_id'];inbox=ctx.root/'inbox/pools'/(pid+'.json');queued=load(inbox)
  queued.update(review=str(normalized),signature=str(signature),batch_id=batch);jsonout(inbox,queued)
  result=execute(ctx,'ingest-audit',review=str(normalized),signature=str(signature),pool_id=pid,batch_id=batch,protocol_sha256=d['protocol_sha256']);results.append(result)
  require(result['state']!='FAILED','Audit import failed; actual file preserved')
 for stage in ['assemble-candidate','part1-ledger','finalize-part1']:results.append(execute(ctx,stage))
 # Refresh existing current delivery; no refit and no new research workflow.
 from minimal_repair import build
 sources=[ctx.code/'minimal_repair.py']+([ctx.root/'reading_context_approvals.json'] if (ctx.root/'reading_context_approvals.json').exists() else [])
 results.append(ctx.stage('minimal-repair',['prepare','build-registry','train','predict','assemble-candidate','part1-ledger','plan-audit:*','ingest-audit:*'],sources,lambda target:build(ctx,target)))
 delivery=ctx.root/'part1_delivery'
 for stage,names in [('assemble-candidate',['C2_candidate.csv','field_evidence.csv','action_unit_mapping.csv','policy_level_shares.csv']),('part1-ledger',['policy_share_quality_report.csv','stage_composition_PREVIEW.csv']),('finalize-part1',['PART1_ACCEPTANCE.json']),('minimal-repair',['AUTHOR_REVIEW.html','author_tasks.json','approved_audit_tasks.json'])]:
  artifact=ctx.artifact(stage)
  for name in names:shutil.copyfile(artifact/name,delivery/name)
 qualities=[]
 for d in contract['plans']:
  key='ingest-audit:'+d['pool_id']+':'+batch;artifact=ctx.root/ctx.manifest['stages'][key]['artifact']
  result=load(artifact/'audit_result.json')
  qualities.append(dict(pool_id=d['pool_id'],batch_id=batch,protocol_sha256=d['protocol_sha256'],complete=result.get('complete',False),quality_pass=result.get('quality_pass',False),audit_quality_sha256=sha(artifact/'audit_quality.json') if (artifact/'audit_quality.json').exists() else None,accepted=False))
 jsonout(delivery/'joint_pool_quality_results.json',dict(results=qualities,adoption_approved=False,extra_directed_judgments=len(extras)))
 jsonout(delivery/'combined_pool_adoption_proposal.json',dict(identity='UNAPPROVED_PROPOSAL_NOT_SIGNATURE',pools=[q for q in qualities if q['quality_pass']],statement_required='Author adoption of these exact passed pool result hashes; one combined confirmation is sufficient',reviewer='',signed_at='',approved=False))
 ass=ctx.artifact('assemble-candidate');candidate=read(ass/'C2_candidate.csv');mapping=read(ass/'action_unit_mapping.csv');shares=read(ass/'policy_level_shares.csv');progress=[]
 for row in shares.to_dict('records'):
  pid=row['policy_id'];z=candidate[candidate.policy_id.eq(pid)];m=mapping[mapping.policy_id.eq(pid)]
  progress.append(dict(policy_id=pid,total_units=len(z),unresolved_source_units=int(z.source_rule_resolved.ne('True').sum()),missing_field_cells=sum(int(z['C2_'+k].eq('').sum()) for k in LABELS),unresolved_counting_units=int(m.counting_status.eq('UNRESOLVED_COUNTING').sum()),measurement_ready=row['measurement_ready'],policy_share_quality_accepted=False,status='ARITHMETIC_READY_QUALITY_REVIEW_REQUIRED' if row['measurement_ready']=='True' else 'WAITING_FOR_FIELD_SOURCE_COUNTING_EVIDENCE',formal_stage_composition=False))
 csvout(delivery/'policy_completion_progress.csv',progress)
 workflow='WAITING_FOR_AUDIT_RETURN' if not all(q['complete'] for q in qualities) else 'AUDIT_COMPLETE_ADOPTION_OR_REPAIR_REQUIRED'
 latest=load(ctx.root/'latest_artifacts.json');latest.update(audit_workflow_status=workflow,joint_pool_quality_results=str(delivery/'joint_pool_quality_results.json'));jsonout(ctx.root/'latest_artifacts.json',latest)
 jsonout(delivery/'CURRENT_AUDIT_RETURN_STATUS.json',dict(status=workflow,pools=qualities,automatic_adoption=False,PART1_COMPLETED=False,part2_started=False))
 jsonout(folder/'import_receipt.json',dict(recorded_at=now(),results=results,retrained=False,automatic_adoption=False,part2_started=False,importer_sha256=sha(Path(__file__))))
 jsonout(delivery/'MINIMAL_DELIVERY_MANIFEST.json',dict(recorded_at=now(),status=workflow,files={p.name:sha(p) for p in delivery.iterdir() if p.is_file() and p.name!='MINIMAL_DELIVERY_MANIFEST.json'}))
 print(json.dumps(results,ensure_ascii=False))

if __name__=='__main__':main()
