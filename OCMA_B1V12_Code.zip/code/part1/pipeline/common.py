"""Shared explicit paths, immutable stage artifacts and abstention-aware metrics."""
from pathlib import Path
from datetime import datetime, timezone
import os,json,hashlib,tempfile,shutil,re,traceback
import numpy as np
import pandas as pd
LABELS=['eligibility','G1','G2','G3','T1','T2','T3','T4','T5','T6']
STATES=['NOT_STARTED','READY','RUNNING','COMPLETED','WAITING_FOR_HUMAN','WAITING_FOR_APPROVAL','FAILED']
def now():return datetime.now(timezone.utc).isoformat()
def longpath(p):
 p=Path(p).resolve()
 return Path('\\\\?\\'+str(p)) if os.name=='nt' and not str(p).startswith('\\\\?\\') else p
def read(p):return pd.read_csv(longpath(p),dtype=str,keep_default_na=False,encoding='utf-8-sig')
def read_review(p):
 if Path(p).suffix.lower() not in ['.xlsx','.xlsm']:return read(p)
 from openpyxl import load_workbook
 book=load_workbook(longpath(p),read_only=True,data_only=False);rows=[]
 for sheet in book.worksheets:
  values=sheet.iter_rows(values_only=True);header=next(values,None)
  if not header or not ({'unit_id','decision_id'} & set(header)):continue
  keys=[str(k).strip() if k is not None else '' for k in header]
  require(len([k for k in keys if k])==len(set(k for k in keys if k)),'Duplicate Excel headers')
  for values in values:
   if any(v is not None for v in values):rows.append({k:'' if v is None else (str(v).strip() if k in ['unit_id','policy_id','decision_id','eligibility_choice','value','type','representative_id','action_unit_id','truth'] or k.startswith('human_') or k.startswith('truth_') else str(v)) for k,v in zip(keys,values) if k})
 book.close();require(bool(rows),'No review rows found in workbook')
 return pd.DataFrame(rows).fillna('')
def load(p):return json.loads(longpath(p).read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(longpath(p).read_bytes()).hexdigest()
def digest(x):return hashlib.sha256(json.dumps(x,sort_keys=True,ensure_ascii=False,default=str).encode()).hexdigest()
def jsonout(p,x):longpath(p).write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def csvout(p,x,columns=None):pd.DataFrame(x,columns=columns).to_csv(longpath(p),index=False,encoding='utf-8-sig')
def require(ok,s):
 if not ok:raise ValueError(s)
def boolean(v):
 if isinstance(v,(bool,np.bool_)):return bool(v)
 if isinstance(v,str) and v.lower() in ['true','false']:return v.lower()=='true'
 raise ValueError('Explicit boolean required')
def norm(x):return re.sub(r'\s+','',str(x))
def signed(x,statement,identity):
 require(x.get('statement')==statement and x.get('reviewer') and x.get('signed_at'),'Actual signed statement required')
 datetime.fromisoformat(x['signed_at'])
 require(x.get('identity','REAL')==identity,'Synthetic/real identity mismatch')
def atomic_json(p,x):
 tmp=Path(str(p)+'.tmp');jsonout(tmp,x);os.replace(tmp,p)
def filelist(root):
 return {str(p.relative_to(root)):sha(p) for p in sorted(Path(root).rglob('*')) if p.is_file()}
def answered_metrics(y,p):
 y=np.asarray(y,int);p=np.asarray(p,float);ok=np.isfinite(p)
 tp=int(((y==1)&(p==1)).sum());fp=int(((y==0)&(p==1)).sum());fn=int(((y==1)&(p==0)).sum());tn=int(((y==0)&(p==0)).sum());totalpos=int((y==1).sum())
 return dict(n=len(y),answered_n=int(ok.sum()),coverage=float(ok.mean()) if len(y) else 0.,abstained_n=int((~ok).sum()),abstained_positive_n=int(((~ok)&(y==1)).sum()),positive_n=totalpos,tp=tp,fp=fp,fn=fn,tn=tn,precision=tp/(tp+fp) if tp+fp else 0.,answered_recall=tp/(tp+fn) if tp+fn else 0.,overall_detection=tp/totalpos if totalpos else 0.,specificity=tn/(tn+fp) if tn+fp else 0.,F1=2*tp/(2*tp+fp+fn) if 2*tp+fp+fn else 0.)
def quality(m,label,policies,contract):
 r=contract['usage_requirements']['eligibility' if label=='eligibility' else 'GT']
 return bool(m['coverage']==1 and m['positive_n']>=r['positive_n'] and policies>=r['policies'] and m['precision']>=r['precision'] and m['overall_detection']>=r['recall'] and (label!='eligibility' or m['specificity']>=r['specificity']))
class Waiting(Exception):
 def __init__(self,reason,state='WAITING_FOR_HUMAN'):self.reason=reason;self.state=state

class Context:
 def __init__(self,workspace,run_id,config=None):
  self.workspace=longpath(workspace);require(re.fullmatch(r'[A-Za-z0-9_-]+',run_id),'Invalid run ID')
  self.code=Path(__file__).resolve().parent
  self.root=self.workspace/'05_revision_work/R1_20261026/01_coding/coding_pipeline_completion'/'runs'/run_id
  self.root.mkdir(parents=True,exist_ok=True);self.configpath=self.root/'run_config.json'
  if self.configpath.exists():
   self.cfg=load(self.configpath)
   if config:require(digest(load(config))==digest(self.cfg),'Existing run config immutable: use new run-id')
  else:
   self.cfg=load(config) if config else default_config(self.workspace);jsonout(self.configpath,self.cfg)
  self.identity=self.cfg.get('identity','REAL');require(self.identity in ['REAL','SYNTHETIC_TEST_ONLY'],'Unknown identity')
  self.manifestpath=self.root/'stage_manifest.json'
  self.manifest=load(self.manifestpath) if self.manifestpath.exists() else dict(run_id=run_id,identity=self.identity,stages={},history=[])
 def input(self,k):
  p=Path(self.cfg['inputs'][k]);return p if p.is_absolute() else self.workspace/p
 def code_hash(self,stage):
  if stage in ['train','training-readiness']:
   import ast
   raw=(self.code/'common.py').read_text(encoding='utf-8');tree=ast.parse(raw)
   numeric=[ast.get_source_segment(raw,n) for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ['answered_metrics','quality']]
   current={'train_limited.py':sha(self.code/'train_limited.py'),'common_numeric_contract':digest([LABELS,numeric])}
   binding=self.root/'frozen_training_reuse.json'
   if binding.exists():
    pin=load(binding);old=self.manifest['stages'].get(stage,{})
    if pin.get('current_training_code')==current and pin.get('training_dependency')==self.training_dependency() and pin.get('stages',{}).get(stage,{}).get('fingerprint')==old.get('fingerprint'):
     original=pin['stages'][stage]
     if original.get('artifact')==old.get('artifact') and original.get('outputs')==old.get('outputs'):return original['code']
   return current
  base=stage.split(':')[0];groups={'train':['train_limited.py'],'training-readiness':['train_limited.py'],'predict':['train_limited.py','predict_corpus.py'],'prepare':['review_registry.py','issue_scope.py'],'ingest-return':['review_registry.py'],'build-registry':['review_registry.py','issue_scope.py'],'ingest-decisions':['review_registry.py'],'plan-audit':['pool_audit.py'],'ingest-audit':['pool_audit.py'],'accept-pool':['pool_audit.py'],'export_supplement':['export_supplement.py'],'assemble-candidate':['assemble_candidate.py','pool_audit.py','measurement.py'],'validate-candidate':['assemble_candidate.py','pool_audit.py','candidate_publisher.py','measurement.py'],'publish':['assemble_candidate.py','pool_audit.py','candidate_publisher.py','measurement.py']}
  groups.update({'register-adjudication':['adjudication.py'],'ingest-adjudication':['adjudication.py'],'part1-ledger':['part1_completion.py','pool_audit.py','share_quality.py'],'ingest-share-quality':['share_quality.py'],'finalize-part1':['part1_completion.py'],'reproduce-part1':['part1_completion.py','standalone_replay.py','group_measurement_replay.py'],'publish-part1':['part1_completion.py','standalone_replay.py','part1_release_bundle.py']})
  groups['publish-group']=['share_quality.py','candidate_publisher.py','group_readiness.py']
  extra=['group_readiness.py'] if base in ['prepare','build-registry','assemble-candidate','register-adjudication','validate-candidate','part1-ledger','ingest-share-quality','publish-part1','finalize-part1'] else []
  if base in ['register-adjudication','ingest-adjudication']:extra+=['assemble_candidate.py','group_readiness.py']
  return {n:sha(self.code/n) for n in ['common.py','coding_pipeline.py']+groups.get(base,[])+extra}
 def training_dependency(self):
  reg=self.artifact('build-registry',required=False)
  return sha(reg/'training_signature.json') if reg else None
 def dependencies(self,selectors):
  d={}
  for s in selectors:
   if s=='@training':d[s]=self.training_dependency();continue
   keys=sorted(k for k in self.manifest['stages'] if k.startswith(s[:-1])) if s.endswith('*') else [s]
   for k in keys:
    r=self.manifest['stages'].get(k)
    d[k]=r['fingerprint'] if r and self.valid(k) else None
  return d
 def valid(self,key):
  if not hasattr(self,'_vcache'):self._vcache={}
  if key not in self._vcache:self._vcache[key]=self._valid(key)
  return self._vcache[key]
 def _valid(self,key):
  r=self.manifest['stages'].get(key)
  if not r or r['state'] not in ['COMPLETED','WAITING_FOR_HUMAN','WAITING_FOR_APPROVAL']:return False
  if r.get('immutable_event'):
   return all((self.root/r['artifact']/n).is_file() and sha(self.root/r['artifact']/n)==h for n,h in r['outputs'].items())
  if r['dependencies']!=self.dependencies(r['selectors']):return False
  if r['code']!=self.code_hash(key) or r['config_sha256']!=sha(self.configpath):return False
  if any(not Path(p).is_file() or sha(p)!=h for p,h in r['sources'].items()):return False
  return all((self.root/r['artifact']/n).is_file() and sha(self.root/r['artifact']/n)==h for n,h in r['outputs'].items())
 def artifact(self,key,required=True):
  if self.valid(key) and self.manifest['stages'][key]['state']=='COMPLETED':return self.root/self.manifest['stages'][key]['artifact']
  if required:raise Waiting('Dependency not completed: '+key)
  return None
 def accepted_pools(self):return self.events('accept-pool')
 def audit_events(self):return [(k,self.root/v['artifact']) for k,v in sorted(self.manifest['stages'].items()) if k.startswith('ingest-audit:') and self.valid(k) and (self.root/v['artifact']/'human_audit_events.csv').exists()]
 def events(self,prefix):return [(k,self.root/v['artifact']) for k,v in sorted(self.manifest['stages'].items()) if k.startswith(prefix+':') and self.valid(k) and v['state']=='COMPLETED']
 def stage(self,key,selectors,sources,fn,immutable_event=False):
  sources={str(Path(p).resolve()):sha(p) for p in sources};dep=self.dependencies(selectors);code=self.code_hash(key)
  fp=digest([sources,dep,code,sha(self.configpath),key])
  old=self.manifest['stages'].get(key)
  if old and old['fingerprint']==fp and self.valid(key):
   return dict(stage=key,state=old['state'],reused=True,artifact=old['artifact'])
  start=now();r=dict(fingerprint=fp,selectors=selectors,dependencies=dep,sources=sources,code=code,config_sha256=sha(self.configpath),state='RUNNING',started_at=start,immutable_event=immutable_event)
  self.manifest['stages'][key]=r;atomic_json(self.manifestpath,self.manifest)
  stagebase=self.root/'artifacts'/key.replace(':','_');stagebase.mkdir(parents=True,exist_ok=True)
  temp=Path(tempfile.mkdtemp(prefix='.pending_',dir=stagebase));state='COMPLETED';exitcode=0;message=''
  try:
   fn(temp)
  except Waiting as e:state=e.state;message=e.reason;jsonout(temp/'waiting.json',dict(reason=message,state=state,identity=self.identity))
  except Exception:
   state='FAILED';exitcode=1;message=traceback.format_exc();(temp/'failure.log').write_text(message,encoding='utf-8')
  self._vcache={}
  if code!=self.code_hash(key) or sha(self.configpath)!=r['config_sha256'] or dep!=self.dependencies(selectors) or any(not Path(p).is_file() or sha(p)!=h for p,h in sources.items()):
   state='FAILED';exitcode=1;message='INPUT_CHANGED_DURING_STAGE';jsonout(temp/'input_changed.json',dict(error=message))
  # Unique attempt directory; interrupted pending directories are never reused.
  final=stagebase/(fp[:16]+'_'+digest([start,str(temp)])[:8]);os.replace(temp,final)
  r.update(state=state,ended_at=now(),exit_code=exitcode,message=message,artifact=str(final.relative_to(self.root)),outputs=filelist(final))
  self.manifest['stages'][key]=r;self.manifest['history'].append(dict(stage=key,**r));atomic_json(self.manifestpath,self.manifest)
  return dict(stage=key,state=state,reused=False,artifact=r['artifact'],message=message)
 def status(self):
  result={}
  for name in ['prepare','ingest-return','ingest-decisions','build-registry','train','predict','plan-audit','ingest-audit','accept-pool','training-readiness','export_supplement','assemble-candidate','validate-candidate','publish']:
   if name in self.manifest['stages']:
    r=self.manifest['stages'][name];result[name]=r['state'] if self.valid(name) else ('FAILED' if r['state']=='FAILED' else 'READY')
   else:
    sub=[v['state'] if self.valid(k) else ('FAILED' if v['state']=='FAILED' else 'READY') for k,v in self.manifest['stages'].items() if k.startswith(name+':')]
    result[name]=next((state for state in ['FAILED','WAITING_FOR_HUMAN','WAITING_FOR_APPROVAL','RUNNING','READY','COMPLETED'] if state in sub),'NOT_STARTED')
  registry=self.artifact('build-registry',required=False);assembly=self.artifact('assemble-candidate',required=False);publication=self.artifact('publish',required=False);training=self.artifact('train',required=False)
  detail=dict(registry=load(registry/'registry_manifest.json') if registry else None,candidate=load(assembly/'candidate_status.json') if assembly else None,new_model_trained=bool(training),C2_LABELS_FROZEN=bool(publication),POLICY_MEASUREMENT_READY=bool(assembly and load(assembly/'candidate_status.json')['POLICY_MEASUREMENT_READY']))
  return dict(identity=self.identity,stages=result,stage_details={k:dict(state=v['state'],valid=self.valid(k)) for k,v in self.manifest['stages'].items()},actual=detail,part2_started=False,part2_requires_author_instruction=True)
def default_config(ws):
 part=Path('05_revision_work/R1_20261026/01_coding');v5=part/'review_optimization_v5_minimal';v4=part/'review_optimization_v4';v3=part/'review_optimization_v3';v2=part/'review_optimization_v2'
 names=dict(corpus=v4/'analysis_units.csv',human=v5/'trusted_human_registry.csv',codebook=part/'00_protocol/coding_codebook.md',contract=v5/'development_protocol_locked.json',sample=v3/'next200_review_BLIND.csv',linkage=v3/'next200_audit_linkage_BACKEND.csv',sample_signature=v3/'next200_batch_signature.csv',v3_scores=v3/'C1v3_all_candidate_predictions.csv',v3_lock=v3/'MODEL_LOCK.json',source_cards=v5/'source_version_cards.csv',rule_cards=v5/'semantic_boundary_cards.csv',group_proposals=v5/'exact_group_confirmation_proposals.csv',frozen_manifest=v5/'frozen_inputs.json',reference_ids=part/'05_human_review/reference_evaluation_BLIND.csv',amendments=v2/'author_chat_amendments_20261027.json')
 return dict(project='B1 V1.2',identity='REAL',inputs={k:str(v) for k,v in names.items()},require_complete_existing_sample_before_training=True,development_informed_by_prior_reference_failure=True,derive_ineligible_GT_zero=True,auto_pool_default_score_cuts=[.9,.1],part2_enabled=False)


def pending_scope(prep,cat,dec):
 source=set();rules=set();extraction=set()
 if (prep/'issue_scope_audit.csv').exists():
  issues=read(prep/'issue_scope_audit.csv')
  for r in issues.to_dict('records'):
   if boolean(r['blocks_coding']):
    (rules if r['issue_type']=='CLAUSE_SEMANTIC_RULE' else extraction if r['issue_type']=='EXTRACTION_FRAGMENT' else source).update(json.loads(r['affected_ids']))
 elif (prep/'source_cards.csv').exists():source=set(cat.loc[cat.policy_id.isin(set(read(prep/'source_cards.csv').policy_id)),'unit_id'])
 if (prep/'rule_cards.csv').exists():rules=set(read(prep/'rule_cards.csv').unit_id)
 for row in dec.to_dict('records'):
  target=source if row['type']=='SOURCE_VERSION' else rules if row['type']=='SEMANTIC_RULE' else extraction if row['type']=='EXTRACTION_SCOPE' else None
  if target is not None:
   ids=set(json.loads(row['unit_ids']))
   if row['value']=='CONFIRM':target.difference_update(ids)
   else:target.update(ids)
 return source|extraction,rules


def normalized_time(value):
 if not value:return ""
 ts=pd.Timestamp(value)
 if ts.tzinfo is None:ts=ts.tz_localize("Asia/Macau")
 return ts.tz_convert("UTC").isoformat()
