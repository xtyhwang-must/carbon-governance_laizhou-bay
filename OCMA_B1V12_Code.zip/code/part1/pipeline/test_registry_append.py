"""Partial return union, immutable correction lineage and scope-local decision changes."""
from common import *
from coding_pipeline import execute
import tempfile
def main():
 code=Path(__file__).resolve().parent;r=load(code/'end_to_end_test_report.json');ws=Path(r['workspace']);source=ws/'fixture';ctx=Context(ws,'registry_append_checks',source/'config.json');checks={}
 def run(cmd,**kw):
  result=execute(ctx,cmd,**kw);require(result.get('state')!='FAILED',result.get('message',''));return result
 def ck(k,v):checks[k]=bool(v);require(v,k)
 run('prepare');run('build-registry');prep=ctx.artifact('prepare');initial=ctx.artifact('build-registry');initialhash=sha(initial/'registry_snapshot.csv')
 nbase=len(read(initial/'registry_snapshot.csv'));form=read(source/'returned.csv');sig=load(source/'return_signature.json');work=ctx.root/'fixture_returns';work.mkdir(exist_ok=True)
 halves=[form.iloc[:len(form)//2],form.iloc[len(form)//2:]]
 for i,x in enumerate(halves):
  f=work/('part'+str(i)+'.csv');csvout(f,x);s=dict(sig,batch_id='PART_'+str(i),review_sha256=sha(f));jsonout(work/('sig'+str(i)+'.json'),s)
  run('ingest-return',review=f,signature=work/('sig'+str(i)+'.json'));run('build-registry')
  m=load(ctx.artifact('build-registry')/'registry_manifest.json')
  if i==0:
   ck('partial_union_not_complete_probability_audit',not m['complete_existing_sample_evaluated'])
   ck('partial_valid_labels_added_without_zero_filling',m['actual_unique_human_n']==nbase+len(x))
   ck('production_training_still_waits_after_partial',run('train')['state']=='WAITING_FOR_HUMAN')
  else:
   ck('complete_union_evaluated_before_training_eligibility',m['complete_existing_sample_evaluated'] and (ctx.artifact('build-registry')/'frozen_V3_combined_probability_audit.csv').exists())
 ck('prior_registry_snapshot_immutable',sha(initial/'registry_snapshot.csv')==initialhash)
 reg=ctx.artifact('build-registry');latest=read(reg/'registry_snapshot.csv');fields=read(reg/'human_field_evidence.csv').set_index(['unit_id','field']);cat=read(prep/'corpus.csv').set_index('unit_id');uid='P6_1'
 old=latest.set_index('unit_id').loc[uid];oldvalue=old.human_G1;newvalue='0' if oldvalue=='1' else '1'
 row=dict(unit_id=uid,policy_id=cat.loc[uid,'policy_id'],text=cat.loc[uid,'exact_evidence_text'],context=cat.loc[uid,'context'],source_location=cat.loc[uid,'source_location'],source_hash=cat.loc[uid,'source_hash'],eligibility_choice='ELIGIBLE',**{'human_'+k:old['human_'+k] for k in LABELS[1:]})
 row['human_G1']=newvalue;csvout(work/'correction.csv',[row])
 cs=dict(sig,scope='EXPLICIT_HUMAN_CORRECTION',batch_id='ACTUAL_CORRECTION_FIXTURE',signed_at='2026-10-27T03:00:00+00:00',review_sha256=sha(work/'correction.csv'),registry_sha256=sha(reg/'registry_snapshot.csv'),corrections={uid+'|G1':fields.loc[(uid,'G1'),'evidence_id']})
 jsonout(work/'correction_signature.json',cs)
 run('ingest-return',review=work/'correction.csv',signature=work/'correction_signature.json');run('build-registry')
 updated=ctx.artifact('build-registry');new=read(updated/'registry_snapshot.csv').set_index('unit_id');events=read(updated/'human_registry_events.csv')
 ck('correction_added_not_overwritten',set(events.loc[events.unit_id.eq(uid)&events.field.eq('G1'),'value'])=={oldvalue,newvalue})
 ck('latest_trusted_value_is_author_correction',new.loc[uid,'human_G1']==newvalue)
 ck('corrected_reference_stays_out_of_training',new.loc[uid,'training_allowed']=='False' and uid not in set(read(updated/'development_labels.csv').unit_id))
 ck('original_reference_judgment_preserved',read(prep/'baseline_human.csv').set_index('unit_id').loc[uid,'human_G1']==oldvalue)
 ck('same_unit_not_counted_twice',len(new)==nbase+len(form))
 # Existing undecided source scope excludes only its own units, not unrelated development.
 m=load(updated/'registry_manifest.json');ck('pending_source_scope_does_not_block_all_development',0<m['training_eligible_n'] and m['scope_excluded_n']<len(cat))
 run('ingest-decisions',decisions=source/'decisions.csv',signature=source/'decision_signature.json');run('build-registry')
 m=load(ctx.artifact('build-registry')/'registry_manifest.json');ck('real_scoped_decision_changes_registry_view',m['scope_excluded_n']==0)
 decisions=read(source/'decisions.csv');rev=decisions[decisions.type.eq('SOURCE_VERSION')].copy();rev['value']='REJECT';csvout(work/'source_revoke.csv',rev)
 ds=load(source/'decision_signature.json');ds['decisions_sha256']=sha(work/'source_revoke.csv');ds['signed_at']='2026-10-28T01:00:00+00:00';jsonout(work/'revoke_signature.json',ds)
 run('ingest-decisions',decisions=work/'source_revoke.csv',signature=work/'revoke_signature.json');run('build-registry')
 rm=load(ctx.artifact('build-registry')/'registry_manifest.json')
 ck('later_scope_rejection_invalidates_prior_confirmation',rm['scope_excluded_n']==int((cat.policy_id=='P0').sum()))
 ck('decision_history_preserved',len(read(ctx.artifact('build-registry')/'decision_events_all.csv'))>len(read(ctx.artifact('build-registry')/'decision_registry.csv')))
 result=dict(identity='SYNTHETIC_TEST_ONLY',passed=all(checks.values()),checks=checks,workspace=str(ctx.root),new_models_trained=0,real_reviews_created=0)
 jsonout(code/'registry_append_test_report.json',result);print(json.dumps(dict(passed=result['passed'],checks=len(checks))))
if __name__=='__main__':main()

