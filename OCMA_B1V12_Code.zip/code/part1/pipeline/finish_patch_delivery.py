"""Bind actual repair outputs, unchanged frozen evidence and tested implementation."""
from common import *
from review_registry import scope_binding

def finish(ctx):
 base=ctx.code.parent;out=ctx.root/'delivery';out.mkdir(exist_ok=True);prep=ctx.artifact('prepare');reg=ctx.artifact('build-registry');ass=ctx.artifact('assemble-candidate');sup=ctx.artifact('export_supplement');ready=ctx.artifact('training-readiness')
 frozen=base/'frozen_69qa_20261027';snapshot=load(frozen/'snapshot_manifest.json')
 for n,h in snapshot.items():require(sha(frozen/n)==h,'Frozen 69QA snapshot changed')
 for r in load(ctx.input('frozen_manifest')):require(sha(ctx.workspace/'05_revision_work/R1_20261026/01_coding'/r['path'])==r['sha256'],'Upstream original changed')
 suites=['end_to_end_test_report.json','negative_and_resume_test_report.json','registry_append_test_report.json'];total=0
 for n in suites:
  old=load(frozen/n);new=load(ctx.code/n);require(new['passed'] and set(old['checks'])<=set(new['checks']),'Old regression removed/failed');total+=len(new['checks'])
 extra=load(ctx.code/'targeted_repair_test_report.json');require(extra['passed'] and len(extra['checks'])>=29,'Targeted repair tests incomplete')
 oldpaths=load(frozen/'CURRENT_REAL_ARTIFACTS.json');old=read(Path(oldpaths['registry'])/'development_labels.csv');new=read(reg/'development_labels.csv');counts=[]
 for version,h in [('BEFORE_810_VIEW',old),('AFTER_SCOPED_REPAIR',new)]:
  for k in LABELS:counts.append(dict(version=version,label=k,positive_n=int(h['human_'+k].eq('1').sum()),negative_n=int(h['human_'+k].eq('0').sum()),families=h.cv_group.nunique()))
 csvout(out/'development_composition_before_after.csv',counts)
 allids=sorted(set(old.unit_id)|set(new.unit_id));csvout(out/'development_scope_change.csv',[dict(unit_id=x,before=x in set(old.unit_id),after=x in set(new.unit_id),change='RETAINED' if x in set(old.unit_id)&set(new.unit_id) else 'ADDED' if x in set(new.unit_id) else 'REMOVED') for x in allids])
 cat=read(prep/'corpus.csv');issues=read(prep/'issue_scope_audit.csv');props=read(prep/'decision_proposals.csv');human=read(reg/'registry_snapshot.csv');queue=[]
 bodypol=set(issues.loc[issues.issue_type.eq('BODY_IDENTITY_OR_ATTACHMENT_BOUNDARY'),'issue_id'].str.replace('SRC_','',regex=False))
 for r in props.to_dict('records'):
  if r['type']=='SOURCE_VERSION' and r['decision_id'].replace('SOURCE_','') not in bodypol:continue
  if r['type']=='EXACT_GROUP_SCOPE':
   ids=json.loads(r['unit_ids']);available=human[human.unit_id.isin(ids)&human.complete.eq('True')]
   if not len(available):continue
   r['representative_id']=available.unit_id.iloc[0]
  queue.append(r)
 for r in issues[issues.issue_type.eq('EXTRACTION_FRAGMENT')].to_dict('records'):
  ids=json.loads(r['affected_ids']);queue.append(dict(decision_id=r['issue_id'],type='EXTRACTION_SCOPE',unit_ids=json.dumps(ids),value='',rule_text='',action_unit_id='',representative_id='',scope_sha256=digest(sorted(ids)),source_binding=scope_binding(cat,ids),recommendation='Resolve extraction/context scope explicitly; a source-version confirmation alone is insufficient',basis='extraction_fragment_carrier_check.csv',status='PROPOSAL_ONLY'))
 queue+=read(ass/'counting_rule_scope_proposals.csv').to_dict('records');csvout(out/'central_decision_queue_UNSIGNED.csv',queue)
 jsonout(out/'REAL_EXECUTION_STATUS.json',ctx.status());jsonout(out/'actual_run_history.json',ctx.manifest['history'])
 index=dict(project='B1 V1.2',active_code=str(ctx.code),run_id=ctx.manifest['run_id'],workspace=str(ctx.workspace),stage_manifest=str(ctx.manifestpath),run_config=str(ctx.configpath),prepare=str(prep),registry=str(reg),training_readiness=str(ready),candidate=str(ass),supplement=str(sup),evidence_checks=str(ctx.root/'evidence_checks'),delivery=str(out),audit_family_registry=str(ctx.root/'audit_family_registry.json'),original_200=str(ctx.input('sample')),original_200_signature=str(ctx.input('sample_signature')))
 jsonout(out/'LATEST_ARTIFACTS.json',index);jsonout(base/'CURRENT_ACTIVE_PIPELINE.json',index)
 # Full old scripts remain preserved; this is the only promoted active entry.
 ws=str(ctx.workspace).replace('\\\\?\\','');cli=str(ctx.code/'coding_pipeline.py');python=str(ctx.workspace/'.venv/Scripts/python.exe').replace('\\\\?\\','')
 command=f"& '{python}' '{cli}' resume --workspace '{ws}' --run-id {ctx.manifest['run_id']}"
 (base/'RESUME_CURRENT.ps1').write_text("$ErrorActionPreference = 'Stop'\n"+command+'\nexit $LASTEXITCODE\n',encoding='utf-8-sig')
 actual_counts=read(ass/'action_unit_mapping.csv').groupby('counting_status').size().to_dict();sample_nonblank=int(read(prep/'sample.csv').eligibility_choice.ne('').sum())
 e2e=load(ctx.code/'end_to_end_test_report.json');testctx=Context(e2e['workspace'],'full_chain');lock=load(testctx.artifact('train')/'model_lock.json')
 jsonout(out/'PATCH_QA.json',dict(identity='REAL_REPAIR_WITH_SEPARATE_SYNTHETIC_TESTS',regression_assertions=total,targeted_assertions=len(extra['checks']),all_passed=True,reports={n:sha(ctx.code/n) for n in suites+['targeted_repair_test_report.json']},code_hashes={p.name:sha(p) for p in ctx.code.glob('*.py')},frozen_snapshot_unchanged=True,originals_unchanged=True,real_new_human_returns=sample_nonblank,real_classifier_fit=False,real_vectorizers_preflight=True,synthetic_physical_head_fits=lock['physical_head_fits'],synthetic_logical_trainable_heads=lock['logical_trainable_heads'],synthetic_logical_fold_specifications=18,synthetic_final_refits=1,part2_started=False))
 limitation='The current 200 review remains empty. No new classifier performance or real pool approval has been produced.'
 (out/'PATCHLOG.md').write_text(f'''# B1 V1.2 定点修复交付

本轮在既有执行链受控副本修复，没有重建研究、重训旧1021条或启动SD。旧代码、协议及69项QA对应文件已保存只读快照：`{frozen}`。本轮唯一活动入口由CURRENT_ACTIVE_PIPELINE.json和RESUME_CURRENT.ps1指向；原run与原代码保留供复现。

## 实现改动

1. `measurement.py`：主份额采用G/T各自赋值总数，原出现比例独立输出action_prevalence，等分行动权重作为敏感性。零分母为NA，合格但缺某组标签单列问题；部分政策不估算全篇份额。无合格政策不当0参与政策等权汇总。
2. `pool_audit.py`及CLI：明确pool_id、protocol_sha256和batch_id，阶段为plan-audit:pool_id、ingest-audit:pool_id:batch_id、accept-pool:pool_id:result_hash。登记family、成员、模型/规则、声明数、alpha和look；相同模型标签的已批准重叠池不得靠换名字再次验收。原单池映射保留在evidence_checks，不重写旧批准。
3. `issue_scope.py`：区分标题、正文/附件身份、元数据、提取异常及单条语义。纯标题问题不再直接阻断整篇；元数据只标后续库存风险；EXTRACTION_SCOPE必须单独解决，SOURCE_VERSION确认不自动解除提取异常。
4. 已确认不合格单元标NOT_COUNTED_INELIGIBLE，免逐条行动ID。通用规则需真实范围批准；边界明确单元才生成稳定ID，碎片/重复进入有限例外。标签组传播不等于行动合并。
5. 独立测量验证重新读映射、行动摘要和主份额重算，验证分母与NA，不信candidate_status布尔值。摘要、份额、敏感性、契约、验证报告哈希进入bundle。
6. Excel仅清理ID/选项等约定字段；正文、上下文、定位不strip。导入输出IDENTITY_NO_TRIM_OR_ESCAPE显示映射。原签署时间保留，UTC规范字段排序；历史未带时区时间按Asia/Macau解析，属于明确的时区约定，不是新增人审时间。
7. 状态采用selected_diagnostic_model、eligibility_development_qualified、label_usage_status和automatic_pool_approval，取消把合格性通过称为全模型deployable。formal_C2仍为空。
8. 分离training/measurement/audit签名。训练缓存只绑定实际开发视图、折/规则、配置和数值实现；计数、图件和无关留出变化不触发模型重训。OOF同折六规格复用特征，H-BAL/H-ALLDOMAIN相同合格性头复用；物理拟合数单独记录。词表预检对象可由哈希校验后复用。
9. `export_supplement`从真实不可变产物生成状态草表及后续性能数据出口，拒绝SYNTHETIC_TEST_ONLY。原附录现有S1–S6表、S1–S4图，本轮保留请求的S7A/B/C和S6编号，不覆盖。HTML表继承原三线表Times New Roman 10.5pt、1pt外线与0.5pt表头线；CSV可编辑。尚无真实性能结果，因此未生成正式性能图或虚假的矢量图。

## 真实执行结果及不利结果

真实prepare、build-registry、training-readiness、assemble-candidate和export_supplement已执行；train与predict继续WAITING_FOR_HUMAN。1800条和5条更正完整，原600及留出训练数量均0。原200非空合格性记录为{sample_nonblank}；未发现新真实返回或源/规则/组/池批准。

训练视图810→864，当前802个合格、62个不合格，来自28个开发家族；G3阳性60、T2阳性26、T6阳性35。仍明显不平衡，不能据此预告召回提升。逐折支持、权重、预期UNTRAINABLE和实际词表检查见training_readiness_report.csv；三折词表均非空。只拟合了预检TF-IDF对象，未拟合真实分类器。

受限制语料ID8000→8796：标题范围解除与2052个提取残片新增限制并存，不是为增加训练数统一放行。28份原载体核查无读取错误，2041个片段在载体文本中可匹配，11个未精确匹配；找到字符串不等于完整行动或真实阴性。carrier check保留原文、上下文、定位、哈希与状态。

当前1379/32858条满足编码及范围条件，0字段冲突；未完成31479条不是逐条人审任务清单。已有271条不合格记录免行动ID；52个通用计数范围提案及440条已合格边界例外均尚无真实批准。未决标签本身不会产生一张额外三万条计数必审表。

真实局部池未验收、自动接受0、组传播0、C2_LABELS_FROZEN=false、POLICY_MEASUREMENT_READY=false。没有宣称潜在50次省工已经发生，也没有工时节约估计。

## 检查范围

原69项回归断言保留并通过，新增{len(extra['checks'])}项定点断言通过，包括手算多标签份额、双池交错/错协议拒绝/换名拒绝、Excel原文往返、计数变更实际复用模型、训练签名变化失效、碎片/不合格计数、合成附录拒绝和独立测量重算。

合成执行的物理分类头拟合{lock['physical_head_fits']}次，逻辑可训练头{lock['logical_trainable_heads']}次；18折级规格及1次最终重拟合。它们仅证明覆盖的程序路径，不是真实分类质量或作者批准。测试源码和原报告均保留；正式数据没有运行这套合成模型。

## 附录实际可用范围

Table S7A只有DRAFT_REAL_STATUS草表（CSV、可编辑HTML），用于内部核查。S7B与Figure S6为NOT_RUN；S7C为空模式表，明确尚无实际验收。附录manifest、英文图注、table_figure_mapping.csv、原表头XML及可执行plot_s6.py均已生成。正式结果暂不能用于投稿。绘图入口在没有真实模型时明确拒绝执行，不使用合成F1=1。

## 接续命令与最小作者事项

先填写原200的副本，不重填600或1200：`{ctx.input('sample')}`。

返回后用make-signature --kind return --input实际副本生成哈希绑定提案，作者填写真实reviewer和signed_at，ingest-return导入；随后同一resume依次评价冻结V3、追加注册表和有限训练。只允许开发政策入训，49条留出不训练。当前集中决定表：`{out/'central_decision_queue_UNSIGNED.csv'}`；原字段空白不代表接受，签署前不得导入成批准。C2中的不合格G/T零按父字段合法派生；原始人工事件仍全部保留，这不声称原工作簿相应格子一定未填写。

```powershell
{command}
```

也可运行根目录RESUME_CURRENT.ps1。inbox描述仍支持returns/decisions/pools；池描述必须额外有pool_id、batch_id、protocol_sha256、input、approval（协议批准）、review、signature及acceptance（结果批准）。首次无批准运行plan-audit生成proposal，得到protocol_sha256后填入描述；审核和结果批准按实际发生的顺序提供。生产训练门槛未降低。模型失败则保留诊断输出，不扩大搜索。

原run、旧报告及单池记录均不删除。最新产物以本delivery/LATEST_ARTIFACTS.json为准；第二部分仍需要作者另行启动。
''',encoding='utf-8')
 manifest=dict(identity='REAL_REPAIR_DELIVERY',generated_at=now(),code={p.name:sha(p) for p in ctx.code.glob('*.py')},run_manifest_sha256=sha(ctx.manifestpath),current_artifacts=index,files={k:v for k,v in filelist(out).items() if k!='DELIVERY_MANIFEST.json'},classifier_run=False,SD_run=False)
 jsonout(out/'DELIVERY_MANIFEST.json',manifest)
 print(json.dumps(dict(delivery=str(out),regression=total,targeted=len(extra['checks']),real_train=False),ensure_ascii=False))
if __name__=='__main__':
 import argparse
 p=argparse.ArgumentParser();p.add_argument('--workspace',required=True);p.add_argument('--run-id',required=True);a=p.parse_args();finish(Context(a.workspace,a.run_id))
