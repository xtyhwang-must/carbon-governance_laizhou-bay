"""Update the single current delivery; preserve model and honest completion gates."""
from common import *
from coding_pipeline import execute
from part1_release_bundle import make_bundle
import subprocess,sys

def export(ctx):
 patch=ctx.artifact('minimal-repair');led=ctx.artifact('part1-ledger');ass=ctx.artifact('assemble-candidate');tr=ctx.artifact('train');reg=ctx.artifact('build-registry');delivery=ctx.root/'part1_delivery';delivery.mkdir(exist_ok=True)
 # All original artifacts were snapshotted; these are convenient current copies.
 for p in patch.iterdir():
  if p.is_file():shutil.copyfile(p,delivery/p.name)
 for n in ['C2_candidate.csv','field_evidence.csv','action_unit_mapping.csv','policy_level_shares.csv']:shutil.copyfile(ass/n,delivery/n)
 for n in ['policy_share_quality_report.csv','quality_contract.json','policy_statistical_status.csv']:shutil.copyfile(led/n,delivery/n)
 state=load(ass/'candidate_status.json');registry=load(reg/'registry_manifest.json');ap=ctx.root/'appendix';ap.mkdir(exist_ok=True)
 shutil.copyfile(patch/'development_usable_metrics.csv',ap/'Table_S7B_usable_outputs.csv')
 csvout(ap/'Table_S7C_C2_status.csv',[dict(metric=k,value=v,status='INCOMPLETE_NOT_FORMAL_RELEASE') for k,v in state.items()])
 # Existing S6 plots frozen diagnostic results; no changed predictions or new favorable plot.
 caption=ap/'Figure_S6_caption.md';text=caption.read_text('utf-8')
 marker='Postprocessing clarification:'
 if marker in text:text=text.split(marker)[0]
 caption.write_text(text+'\n'+marker+' All plotted values remain frozen diagnostic outputs. Independently exported usable-output metrics abstain on unsupported heads (Table S7B_usable_outputs.csv). Neither diagnostic performance nor a development-usable threshold approves an automatic pool. The model was not refitted for this patch.\n',encoding='utf-8')
 table=ap/'Table_S7_readable.html';text=table.read_text('utf-8')
 marker='<!-- MINIMAL_PATCH_USABLE -->'
 if marker in text:text=text.split(marker)[0]
 usable=read(patch/'development_usable_metrics.csv');selected=load(tr/'model_lock.json')['selected_diagnostic_model'];u=usable[usable.spec.eq(selected['spec'])&usable.C.astype(float).eq(float(selected['C']))&usable.domain.eq('END_TO_END')]
 table.write_text(text+marker+'<h2>Diagnostic versus usable outputs</h2><p>Postprocessing only. No new training; automatic pool approval remains separate. Unsupported heads abstain.</p>'+u[['label','diagnostic_metric_pass','development_usable_output_status','coverage','overall_detection','automatic_pool_approval']].to_html(index=False,border=0),encoding='utf-8')
 # Replay updated files in the existing independent directory, no new fitting.
 pack=ctx.root/'candidate_replay_package';make_bundle(ctx,pack,formal=False);ind=ctx.root/'independent_replay_directory';shutil.copytree(pack,ind,dirs_exist_ok=True)
 run=subprocess.run([sys.executable,str(ind/'standalone_replay.py'),'--root',str(ind)],capture_output=True,text=True,encoding='utf-8')
 (ctx.root/'independent_replay_stdout.log').write_text(run.stdout,encoding='utf-8');(ctx.root/'independent_replay_stderr.log').write_text(run.stderr,encoding='utf-8');require(run.returncode==0,run.stderr)
 assurance=ctx.root/'assurance';shutil.copyfile(ind/'replay_result.json',assurance/'independent_replay.json')
 tests=load(assurance/'minimal_patch_QA.json');extension=load(ctx.code/'part1_extension_test_report.json')
 jsonout(assurance/'implementation_tests.json',dict(passed=tests['passed'] and extension['passed'],code_sha256={p.name:sha(p) for p in ctx.code.glob('*.py')},current_checks=len(tests['checks'])+len(extension['checks']),current_real_checks=sum(x['identity']=='REAL_DATA_QA' for x in tests['checks']),current_synthetic_checks=sum(x['identity']=='SYNTHETIC_TEST_ONLY' for x in tests['checks'])+len(extension['checks']),historical_checks_not_rerun=101,reference_tuning=False,report_hashes={'minimal_patch_QA.json':sha(assurance/'minimal_patch_QA.json'),'part1_extension_test_report.json':sha(ctx.code/'part1_extension_test_report.json')}))
 result=execute(ctx,'finalize-part1');require(result['state']=='COMPLETED',result)
 for n in ['PART1_ACCEPTANCE.json','PART2_HANDOFF.md']:shutil.copyfile(ctx.artifact('finalize-part1')/n,delivery/n)
 for n in ['minimal_patch_QA.csv','minimal_patch_QA.json']:shutil.copyfile(assurance/n,delivery/n)
 before=load(ctx.root/'minimal_patch_snapshot_20261027/stage_manifest.json');oldtr=ctx.root/before['stages']['train']['artifact'];same=sha(tr/'diagnostic_model.joblib')==sha(oldtr/'diagnostic_model.joblib')
 acceptance=load(delivery/'PART1_ACCEPTANCE.json');status=load(patch/'minimal_status.json');pool=read(patch/'pool_feasibility.csv')
 log=f'''# 最小修复实际执行记录

当前run：{ctx.root.name}。继续使用实际manifest指向的controlled_part1_completion_20261027，未另建竞争性主版本。

## 已执行
- 旧代码、结果、附录和manifest已保存到minimal_patch_snapshot_20261027；原Excel、600、1200、200和52项返回未覆盖。
- 诊断阈值输出冻结；新增usable=True独立汇总。失败头拒判；诊断指标、开发可用性、自动池批准分别保存。
- 人工字段优先，条件G/T建议不证明合格；同一单元的缺字段合为一次阅读路由，已有真实字段不重填。
- 缺类和不收敛按头保留NaN；空词表按折记录，最终拟合失败时保留已完成比较。来源/哈希/泄漏错误仍失败。未增加C或迭代预算。
- 未启用新的阈值加速算法：保留原循环，避免不必要数值变更。开发数据逐切点一致核验{tests['development_threshold_cut_rows_checked']}行。
- 当前模型字节与本轮起点一致：{same}；未重新拟合。模型原训练代码与后处理代码分别绑定，未来真实训练输入改变仍会失效并触发既定有限训练。
- 32项拒绝逐项归因：5项载体/正文身份、25项提取、2项语义。已生成{status['reading_map_rows']}条精确偏移量阅读映射。阅读修复不等于标签/行动边界批准；未擅自撤销拒绝。
- share_quality已移除“预算为0→质量通过”的捷径。实际字段/池证据、计量算术、声明敏感性分开；0.05仍仅为待批准的绝对份额敏感性容差（5个百分点）。没有新增每政策独立置信区间门槛。
- 同版候选、字段证据、行动映射、68政策及4阶段未完成状态已重算并独立核对。已有Table S7新增可用输出；Figure S6诊断数值未变，仅澄清适用范围。

## 实际检查
本轮{len(tests['checks'])}项最小修复检查及{len(extension['checks'])}项合成回归检查通过；真实/合成身份见QA文件。149项人工合格但机器负判的保留核验以实际QA值为准：{tests['human_eligible_machine_negative_cases']}。
独立目录12条固定参数回放通过；未再次全量训练，未声称正式份额复现。历史101项检查未作为本轮重跑。

## 真实研究状态
人工记录{registry['actual_unique_human_n']}；开发{registry['training_eligible_n']}；来源/规则限制{registry['scope_excluded_n']}；C2完整依据{state['complete_rows']}/{state['total_rows']}；自动字段{state['actual_auto_fields']}；组传播字段{state['actual_group_fields']}。
PART1_COMPLETED={acceptance['PART1_COMPLETED']}。正式政策份额不可用的原因是未决标签、作用范围、行动边界及实际质量证据尚未齐备，不是求和代码未执行。未知没有填0，也没有剔除未完成政策。

## 唯一作者入口
打开AUTHOR_REVIEW.html，共{status['author_task_cards']}张修复后任务卡：5项具体载体/正文问题、1项阅读层修复规则（关联25项提取）、2项语义边界、1项计数规则、1项真实代表等价组及3项精确池抽样协议。可部分返回，不重发原52项。
池筛查10候选采用保守的10声明规划；其中3项已有登记协议保留原6声明预算、风险和成员，显示各自实际样本量。两类规划不混用。未批准前不抽样，池通过不代表政策份额质量通过。
阅读层批准本身不会解除碎片语义/计数限制；需具体行动边界或字段判断。全量字段路由仅后台台账，不要求全库逐条填写。

## 接续
真实JSON返回后执行IMPORT_AUTHOR_RETURN.ps1 -ReviewFile <返回文件完整路径>，随后RESUME_PART1.ps1。
来源批准若改变开发输入，先统一导入，再按既定6候选/3折做一次有限训练；计数批准不会触发训练。模型/成员变化使旧池协议失效，不能转移批准。最终C2仍须精确候选与完整证据包批准。
第二部分未启动。未在本轮生成正式第一部分发布。
'''
 (delivery/'minimal_patch_log.md').write_text(log,encoding='utf-8')
 jsonout(delivery/'ACTUAL_ARTIFACTS.json',{k:str(ctx.root/v['artifact']) for k,v in ctx.manifest['stages'].items() if 'artifact' in v})
 jsonout(ctx.root/'latest_artifacts.json',load(delivery/'ACTUAL_ARTIFACTS.json'))
 active=ctx.root.parent.parent/'CURRENT_ACTIVE_PIPELINE.json';pointer=load(active);pointer.update(delivery=str(delivery),minimal_patch_report=str(delivery/'minimal_patch_log.md'),author_task_entry=str(delivery/'AUTHOR_REVIEW.html'),part1_acceptance=str(delivery/'PART1_ACCEPTANCE.json'));jsonout(active,pointer)
 # Old task link is a redirect, not a second editable author sheet.
 (delivery/'AUTHOR_SCOPED_REVIEW.html').write_text('<!doctype html><meta charset="utf-8"><meta http-equiv="refresh" content="0;url=AUTHOR_REVIEW.html"><a href="AUTHOR_REVIEW.html">修复后唯一作者入口</a>',encoding='utf-8')
 jsonout(delivery/'MINIMAL_DELIVERY_MANIFEST.json',dict(identity='INCOMPLETE_REAL_C2_NOT_FORMAL_RELEASE',files={k:v for k,v in filelist(delivery).items() if k!='MINIMAL_DELIVERY_MANIFEST.json'},model_unchanged=same,PART1_COMPLETED=acceptance['PART1_COMPLETED']))
 print(json.dumps(dict(delivery=str(delivery),model_unchanged=same,qa=len(tests['checks'])+len(extension['checks']),PART1_COMPLETED=acceptance['PART1_COMPLETED']),ensure_ascii=False))

if __name__=='__main__':
 import argparse
 p=argparse.ArgumentParser();p.add_argument('--workspace',required=True);p.add_argument('--run-id',required=True);a=p.parse_args();export(Context(a.workspace,a.run_id))
