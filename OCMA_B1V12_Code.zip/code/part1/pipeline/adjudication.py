"""Registered, field-scoped directed HUMAN adjudication, distinct from probability audits."""
from common import *
from review_registry import scope_binding

ROLES={'C2_ONLY','DEVELOPMENT_ADJUDICATION','AUDIT_ONLY'}
PROTECTED=['unit_id','policy_id','field','text','context','source_location','source_hash','role','scope_id']

def register(ctx,out,request,scope_id):
 require(re.fullmatch(r'[A-Za-z0-9_-]+',scope_id or ''),'Explicit safe scope ID required')
 p=ctx.artifact('prepare');cat=read(p/'corpus.csv').set_index('unit_id');q=read(request)
 require({'unit_id','field','role'}<=set(q),'Request requires unit_id,field,role')
 require(not q.duplicated(['unit_id','field']).any(),'Duplicate requested field')
 require(set(q.unit_id)<=set(cat.index) and q.field.isin(LABELS).all() and q.role.isin(ROLES).all(),'Invalid requested scope')
 ref=set(read(p/'reference_ids.csv').unit_id)
 require(not any(r.role=='DEVELOPMENT_ADJUDICATION' and (cat.loc[r.unit_id,'split']!='DEVELOPMENT' or r.unit_id in ref) for r in q.itertuples()),'Reference/heldout cannot become development')
 from group_readiness import effective_field_evidence
 reg=effective_field_evidence(ctx).set_index(['unit_id','field'])
 pred=read(ctx.artifact('predict')/'corpus_predictions.csv').set_index('unit_id');rows=[]
 for r in q.to_dict('records'):
  uid=r['unit_id'];k=r['field'];c=cat.loc[uid];old=reg.loc[(uid,k)] if (uid,k) in reg.index else None
  # Existing real judgments are not re-requested merely because a model disagrees.
  if old is not None:require(bool(r.get('correction_reason','').strip()),'Existing human requires concrete correction reason')
  rows.append(dict(scope_id=scope_id,unit_id=uid,policy_id=c.policy_id,field=k,role=r['role'],text=c.exact_evidence_text,context=c.context,source_location=c.source_location,source_hash=c.source_hash,machine_suggestion=pred.loc[uid,'usable_raw_'+k] if 'usable_raw_'+k in pred.columns else '',score=pred.loc[uid,'score_'+k],score_identity='UNCALIBRATED_DIAGNOSTIC_NOT_TRUTH',previous_event_id=old.evidence_id if old is not None else '',previous_value=old.value if old is not None else '',correction_reason=r.get('correction_reason',''),value='',notes=''))
 csvout(out/'adjudication_review.csv',rows)
 shutil.copyfile(request,out/'registered_request.csv')
 jsonout(out/'scope.json',dict(identity=ctx.identity,scope_id=scope_id,template_sha256=sha(out/'adjudication_review.csv'),request_sha256=sha(request),corpus_sha256=sha(p/'corpus.csv'),rule_sha256=sha(p/'codebook.md'),model_sha256=sha(ctx.artifact('train')/'diagnostic_model.joblib'),source_binding=scope_binding(cat.reset_index(),sorted(set(q.unit_id))),roles=sorted(set(q.role)),purpose='DIRECTED_ADJUDICATION_NOT_RANDOM_ACCURACY_ESTIMATION',actual_human_judgments=0))

def validate_rows(returned,template,signature,corpus,current,identity,rule_hash,review_hash,signature_hash):
 require(not returned.duplicated(['unit_id','field']).any(),'Duplicate returned field')
 t=template.set_index(['unit_id','field']);events=[];errors=[]
 for r in returned.to_dict('records'):
  key=(r.get('unit_id'),r.get('field'))
  try:
   require(key in t.index,'Field outside registered scope');expected=t.loc[key]
   for k in PROTECTED:require(r.get(k,'')==expected[k] if k not in ['unit_id','field'] else r[k]==key[['unit_id','field'].index(k)],'Protected field changed: '+k)
   value=str(r.get('value','')).strip()
   require(value in ['0','1'],'Blank/unknown remains unresolved')
   prior=current.get(key);correction=str(r.get('correction_of','') or r.get('previous_event_id',''))
   if prior and prior['value']!=value:require(correction==prior['evidence_id'],'Correction must bind current exact field evidence')
   uid,k=key;role=expected.role
   require(role in ROLES,'Invalid role')
   require(role!='DEVELOPMENT_ADJUDICATION' or corpus.loc[uid,'split']=='DEVELOPMENT','Heldout leakage')
   e=dict(unit_id=uid,field=k,value=value,batch_id=signature['batch_id'],reviewer=signature['reviewer'],review_time=signature['signed_at'],source_file_sha256=review_hash,signature_sha256=signature_hash,source_hash=corpus.loc[uid,'source_hash'],rule_version=rule_hash,role=role,split=corpus.loc[uid,'split'],import_result='VALID_DIRECTED_ADJUDICATION_NOT_PROBABILITY_SAMPLE',identity=identity,correction_of=correction if prior and prior['value']!=value else '',original_evidence=signature['scope_sha256'])
   if r.get('zero_origin')=='HUMAN_COMPLETE_GROUP_UNSELECTED':e['zero_origin']='HUMAN_COMPLETE_GROUP_UNSELECTED'
   e['event_id']=digest(e);events.append(e)
  except ValueError as e:errors.append(dict(unit_id=key[0],field=key[1],reason=str(e)))
 # An accepted human negative can derive zero, but cannot silently overwrite an old true positive.
 for e in list(events):
  if e['field']!='eligibility' or e['value']!='0':continue
  for k in LABELS[1:]:
   key=(e['unit_id'],k)
   if key in current or any(x['unit_id']==e['unit_id'] and x['field']==k for x in events):continue
   child=dict(e,field=k,correction_of='',import_result='RULE_DERIVABLE_FROM_SIGNED_INELIGIBLE',parent_event_id=e['event_id']);child.pop('event_id');child['event_id']=digest(child);events.append(child)
 return events,errors

def ingest(ctx,out,scope_id,review,signature,registry_before):
 plan=ctx.artifact('register-adjudication:'+scope_id);s=load(signature);p=ctx.artifact('prepare');sc=load(plan/'scope.json')
 signed(s,'CONFIRM_ACTUAL_DIRECTED_ADJUDICATION',ctx.identity)
 require(s['scope_sha256']==sha(plan/'scope.json') and s['review_sha256']==sha(review),'Adjudication signature binding mismatch')
 require(sc['rule_sha256']==sha(p/'codebook.md') and sc['corpus_sha256']==sha(p/'corpus.csv'),'Scope source/rule invalidated')
 x=read_review(review);t=read(plan/'adjudication_review.csv');cat=read(p/'corpus.csv').set_index('unit_id')
 from group_readiness import effective_field_evidence
 f=effective_field_evidence(ctx);current={(r['unit_id'],r['field']):r for r in f.to_dict('records')}
 events,errors=validate_rows(x,t,s,cat,current,ctx.identity,sha(p/'codebook.md'),sha(review),sha(signature))
 csvout(out/'human_review_events.csv',events,columns=None if events else ['unit_id','field','value','event_id'])
 csvout(out/'unresolved_fields.csv',errors,columns=['unit_id','field','reason'])
 shutil.copyfile(review,out/('actual_return'+Path(review).suffix));shutil.copyfile(signature,out/'actual_signature.json');shutil.copyfile(plan/'scope.json',out/'registered_scope.json');shutil.copyfile(plan/'adjudication_review.csv',out/'registered_template.csv')
 jsonout(out/'import_result.json',dict(identity=ctx.identity,accepted_field_events=len(events),unresolved_returned_fields=len(errors),complete_return=False if errors else len(x)==len(t),statistical_identity='DIRECTED_NOT_RANDOM_REFERENCE',training_role_explicit=True))
