"""Orthogonal field, group, action-boundary and policy readiness; no label inference."""
from common import *
GROUPS={'G':LABELS[1:4],'T':LABELS[4:]}

def live_event(event,parent):
 if event.get('import_result')!='RULE_DERIVABLE_FROM_SIGNED_INELIGIBLE':return True
 return parent.get('value')=='0' and event.get('parent_event_id')==parent.get('event_id')

def zero_origin(event,field):
 if event.get('value')!='0':return 'EXPLICIT_HUMAN_FIELD'
 if event.get('import_result')=='RULE_DERIVABLE_FROM_SIGNED_INELIGIBLE':return 'RULE_DERIVABLE_FROM_INELIGIBLE'
 if event.get('zero_origin')=='HUMAN_COMPLETE_GROUP_UNSELECTED':return 'HUMAN_COMPLETE_GROUP_UNSELECTED'
 if event.get('import_result') in ['VALID_DIRECTED_ADJUDICATION_NOT_PROBABILITY_SAMPLE','VALID_ACTUAL_RETURN','VALID_ACTUAL_REVIEW'] or event.get('source_field_explicit')=='True':return 'HUMAN_EXPLICIT_ZERO'
 return 'HISTORICAL_ZERO_ORIGIN_UNRESOLVED'

def calculate(cat,candidate,fields,decisions,conflicts):
 cat=cat.set_index('unit_id',drop=False);c=candidate.set_index('unit_id',drop=False).copy();ev={(r['unit_id'],r['field']):r for r in fields.to_dict('records')}
 cat.index.name=None;c.index.name=None
 conflictmap={}
 for r in conflicts.to_dict('records'):
  if r.get('unit_id'):conflictmap.setdefault(r['unit_id'],set()).add(r.get('field',''))
 boundary={};bad=set();texts=cat.groupby(['policy_id','exact_evidence_text']).size().to_dict()
 for d in decisions.to_dict('records'):
  if d['value']!='CONFIRM' or d['type'] not in ['ACTION_COUNTING_RULE','ACTION_COUNTING_BOUNDARY']:continue
  for uid in json.loads(d['unit_ids']):
   r=cat.loc[uid];text=r.exact_evidence_text
   if d['type']=='ACTION_COUNTING_RULE':
    if not (int(r.parent_member_count)==1 and len(text.strip())>=20 and re.search(r'[。；;.!！?？]$',text.strip()) and texts[(r.policy_id,text)]==1):continue
    aid='ACT_'+digest([r.policy_id,r.policy_version_id,uid,text])[:24]
   else:aid=d.get('action_unit_id','')
   if not aid:continue
   if uid in boundary and boundary[uid][0]!=aid:bad.add(uid)
   boundary[uid]=(aid,d['decision_event_id'])
 maps=[]
 for uid,row in c.iterrows():
  cf=conflictmap.get(uid,set());source=boolean(row.source_rule_resolved);elig=ev.get((uid,'eligibility'));er=bool(source and elig and elig.get('value') in ['0','1'] and elig.get('evidence_id') and not (cf- set(LABELS[1:])) )
  if elig and elig['value']=='0' and any(ev.get((uid,k),{}).get('value')=='1' for k in LABELS[1:]):er=False
  c.loc[uid,'record_complete_10']=boolean(row.complete);c.loc[uid,'eligibility_ready']=er
  for group,ks in GROUPS.items():c.loc[uid,group+'_group_ready']=bool(er and not cf.intersection(ks) and all(ev.get((uid,k),{}).get('value') in ['0','1'] and ev.get((uid,k),{}).get('evidence_id') for k in ks))
  negative=er and elig['value']=='0';br=bool(er and (negative or uid in boundary and uid not in bad));c.loc[uid,'action_boundary_ready']=br
  aid=boundary.get(uid,('',''))[0] if br and not negative else ''
  maps.append(dict(unit_id=uid,policy_id=row.policy_id,action_unit_id=aid,action_boundary_ready=br,status='NOT_COUNTED_INELIGIBLE' if negative else 'APPROVED_BOUNDARY' if br else 'UNRESOLVED_BOUNDARY',decision_event_id=boundary.get(uid,('',''))[1]))
 mp=pd.DataFrame(maps)
 for aid,g in mp[mp.action_unit_id.ne('')].groupby('action_unit_id'):
  ids=list(g.unit_id)
  if g.policy_id.nunique()!=1:
   for uid in ids:c.loc[uid,'action_boundary_ready']=False
  for group,ks in GROUPS.items():
   valid=all(c.loc[uid,group+'_group_ready'] for uid in ids) and len(c.loc[ids,['C2_'+k for k in ks]].drop_duplicates())==1
   if not valid:
    for uid in ids:c.loc[uid,group+'_group_ready']=False
 mp['action_boundary_ready']=mp.unit_id.map(c.action_boundary_ready)
 policies=[]
 for pid,z in c.groupby('policy_id',sort=False):
  for group,ks in GROUPS.items():
   ready=bool(z.eligibility_ready.all() and z.action_boundary_ready.all() and z[group+'_group_ready'].all());positive=z[z.C2_eligibility.eq('1')];a=mp[mp.unit_id.isin(positive.index)&mp.action_unit_id.ne('')].drop_duplicates('action_unit_id');den=None;vals={k:'' for k in ks}
   if ready:
    values=c.loc[a.unit_id,['C2_'+k for k in ks]].astype(int);den=int(values.to_numpy().sum())
    if den:vals={k:float(values['C2_'+k].sum()/den) for k in ks}
   reason='MISSING_ELIGIBILITY_GROUP_OR_BOUNDARY' if not ready else 'NO_QUALIFYING_ACTION' if not len(a) else 'ZERO_GROUP_ASSIGNMENT_DENOMINATOR' if not den else 'DEFINED'
   ids=set(z.index);needed=['eligibility']+ks
   # Only this policy/group's fields, shared source and relevant action map enter binding.
   f=[{k:r.get(k,'') for k in ['unit_id','field','value','evidence_id','source_hash','rule_version','parent_evidence_id','decision_event_id']} for key,r in ev.items() if key[0] in ids and key[1] in needed]
   related=[{k:d.get(k,'') for k in ['decision_id','type','value','scope_sha256','source_binding','rule_text']} for d in decisions.to_dict('records') if d.get('type') in ['SOURCE_VERSION','SEMANTIC_RULE','ACTION_COUNTING_BOUNDARY','ACTION_COUNTING_RULE','EXACT_GROUP_SCOPE'] and ids.intersection(json.loads(d.get('unit_ids','[]')))]
   binding=digest(dict(fields=sorted(f,key=lambda r:(r['unit_id'],r['field'])),source=cat.loc[list(z.index),['unit_id','source_hash']].sort_values('unit_id').to_dict('records'),source_ready=z[['unit_id','source_rule_resolved']].sort_values('unit_id').to_dict('records'),mapping=mp[mp.unit_id.isin(ids)].sort_values('unit_id').to_dict('records'),rules=related,group=group,version='GROUP_ASSIGNMENT_V1'))
   policies.append(dict(policy_id=pid,group=group,measurement_ready=ready,quality_accepted=False,eligible_action_n=len(a) if ready else '',assignment_denominator=den if den is not None else '',undefined_reason=reason,group_binding_sha256=binding,**vals))
 policy=pd.DataFrame(policies).fillna('');stages=[]
 for group in GROUPS:
  ix=policy[policy.group.eq(group)].set_index('policy_id')
  c['policy_'+group+'_measurement_ready']=c.policy_id.map(ix.measurement_ready)
  c['policy_'+group+'_quality_accepted']=False
 if 'stage' in cat:
  ps=cat[['policy_id','stage']].drop_duplicates()
  for stage,z in ps.groupby('stage'):
   for group,ks in GROUPS.items():
    p=policy[policy.policy_id.isin(z.policy_id)&policy.group.eq(group)];complete=bool(p.measurement_ready.all());defined=p[p.undefined_reason.eq('DEFINED')]
    stages.append(dict(stage=stage,group=group,policy_n=len(p),ready_policy_n=int(p.measurement_ready.sum()),defined_policy_n=len(defined),coverage_complete=complete,status='GROUP_COVERAGE_COMPLETE_QUALITY_PENDING' if complete else 'INCOMPLETE_STAGE_NOT_FORMAL',**{k:float(defined[k].astype(float).mean()) if complete and len(defined) else '' for k in ks}))
 return c.reset_index(drop=True),mp,policy,pd.DataFrame(stages).fillna('')

def export(ctx,out,cat,c,fields,dec,conflicts):
 c,mp,p,stage=calculate(cat,c,fields,dec,conflicts)
 csvout(out/'C2_candidate.csv',c);csvout(out/'effective_field_evidence.csv',fields);csvout(out/'group_action_mapping.csv',mp);csvout(out/'policy_group_shares.csv',p);csvout(out/'stage_group_composition.csv',stage)
 from share_quality import apply_group_assessments
 approved=apply_group_assessments(ctx,out);csvout(out/'policy_group_shares.csv',approved)
 for group in GROUPS:c['policy_'+group+'_quality_accepted']=c.policy_id.map(approved[approved.group.eq(group)].set_index('policy_id').quality_accepted)
 csvout(out/'C2_candidate.csv',c)
 csvout(out/'group_readiness.csv',c[['unit_id','policy_id','record_complete_10','eligibility_ready','G_group_ready','T_group_ready','action_boundary_ready']])
 return c

def effective_field_evidence(ctx):
 """Resolve current field evidence only; cache by real content, not assembly row count."""
 from assemble_candidate import resolve_current_fields
 prep=ctx.artifact('prepare');reg=ctx.artifact('build-registry')
 deps={'config':sha(ctx.configpath),'code':{n:sha(ctx.code/n) for n in ['assemble_candidate.py','group_readiness.py','pool_audit.py']},'registry':{n:sha(reg/n) for n in ['human_field_evidence.csv','decision_registry.csv','registry_manifest.json']},'prepare':{n:sha(prep/n) for n in ['corpus.csv','codebook.md']},'audit':{k:filelist(a) for k,a in ctx.audit_events()},'accepted':{k:filelist(a) for k,a in ctx.accepted_pools()}}
 key=digest(deps)
 cached=getattr(ctx,'_effective_fields',None)
 if cached and cached[0]==key:return cached[1].copy()
 directory=ctx.root/'effective_field_cache';directory.mkdir(exist_ok=True);cache=directory/(key+'.csv');meta=directory/(key+'.json')
 if cache.exists() and meta.exists() and load(meta).get('content_sha256')==sha(cache):frame=read(cache)
 else:
  state=resolve_current_fields(ctx);frame=pd.DataFrame(list(state['fields'].values()));temp=directory/(key+'.pending.csv');csvout(temp,frame);os.replace(temp,cache);atomic_json(meta,dict(dependencies=deps,content_sha256=sha(cache)))
 ctx._effective_fields=(key,frame);return frame.copy()
