"""Failure paths on synthetic data only; real reviews and frozen versions untouched."""
from common import *
from coding_pipeline import execute
from candidate_publisher import validate
from review_registry import ingest_return,ingest_decisions
from signature_proposals import proposal
from train_limited import threshold_status,threshold_outputs
import tempfile,copy

def main():
 code=Path(__file__).resolve().parent;report=load(code/'end_to_end_test_report.json');require(report['passed'],'Complete positive integration test first')
 ctx=Context(report['workspace'],'full_chain');ctx._vcache={};ass=ctx.artifact('assemble-candidate');prep=ctx.artifact('prepare');original_artifact=ctx.artifact
 root=ctx.root/'negative_tests';root.mkdir(exist_ok=True);case=Path(tempfile.mkdtemp(prefix='isolated_',dir=root));checks={}
 def check(name,fn,expect_error=False):
  try:r=fn();checks[name]=(not expect_error) and (True if r is None else bool(r))
  except (ValueError,KeyError,Waiting,FileNotFoundError):checks[name]=expect_error
  require(checks[name],'Failed negative test: '+name)
 def candidate_case(name,mutator):
  folder=case/name;folder.mkdir();c=read(ass/'C2_candidate.csv');c=mutator(c);cp=folder/'candidate.csv';csvout(cp,c)
  return validate(ctx,folder,cp,ass/'candidate_evidence_bundle.json')
 check('empty_candidate_rejected',lambda:candidate_case('empty',lambda c:c.iloc[:0]),True)
 check('duplicate_ID_rejected',lambda:candidate_case('dup',lambda c:pd.concat([c,c.iloc[:1]])),True)
 check('missing_ID_rejected',lambda:candidate_case('missing',lambda c:c.iloc[1:]),True)
 def setone(c,k,v):c=c.copy();c.loc[0,k]=v;return c
 for name,k,v in [('blank_label','C2_G1',''),('illegal_label','C2_G1','2'),('unresolved_row','complete','False'),('forged_field_hash','evidence_G1','FAKE'),('unknown_path','status_G1','AUTO_TRUST_SCORE')]:
  check(name,lambda name=name,k=k,v=v:candidate_case(name,lambda c:setone(c,k,v)),True)
 # Clone the artifact to exercise the derivation checks, not merely an outer hash guard.
 clone=case/'derived_clone';shutil.copytree(ass,clone)
 e=read(clone/'field_evidence.csv');ix=e.index[e.status.eq('DERIVED_FROM_ACCEPTED_INELIGIBLE')][0];e.loc[ix,'parent_evidence_id']='INVALID_PARENT';csvout(clone/'field_evidence.csv',e)
 bundle=load(clone/'candidate_evidence_bundle.json');bundle['field_evidence_sha256']=sha(clone/'field_evidence.csv');jsonout(clone/'candidate_evidence_bundle.json',bundle)
 ctx.artifact=lambda key,required=True:clone if key=='assemble-candidate' else original_artifact(key,required)
 check('invalid_parent_cannot_derive_zero',lambda:validate(ctx,case/'unused'),True)
 ctx.artifact=original_artifact
 # A new file with a plausible signature still must preserve text and definite judgments.
 raw=read(prep/'sample.csv');source=Path(report['workspace'])/'fixture';signed=load(source/'return_signature.json')
 blank=case/'blank.csv';csvout(blank,raw);bs=dict(signed,review_sha256=sha(blank));jsonout(case/'blank_sig.json',bs);bo=case/'blank_import';bo.mkdir()
 ingest_return(ctx,bo,blank,case/'blank_sig.json')
 check('empty_review_creates_no_human_events',lambda:not (bo/'human_review_events.csv').exists() and load(bo/'import_result.json')['valid_n']==0)
 bad=read(source/'returned.csv');bad.loc[0,'text']='NOT_ACTUAL_TEXT';csvout(case/'changed_text.csv',bad);ss=dict(signed,review_sha256=sha(case/'changed_text.csv'));jsonout(case/'changed_sig.json',ss);dest=case/'changed_import';dest.mkdir()
 ingest_return(ctx,dest,case/'changed_text.csv',case/'changed_sig.json')
 check('text_conflict_is_local_not_zero',lambda:len(read(dest/'unresolved.csv'))==1 and load(dest/'import_result.json')['valid_n']==len(raw)-1)
 ss['reviewer']='';jsonout(case/'unsigned.json',ss)
 check('unsigned_human_return_rejected',lambda:ingest_return(ctx,case,case/'changed_text.csv',case/'unsigned.json'),True)
 # Existing signed proposals may never be overwritten.
 proposal_path=case/'proposal.json';proposal(ctx,'return',source/'returned.csv',proposal_path);before=sha(proposal_path)
 check('existing_signature_proposal_preserved',lambda:proposal(ctx,'return',source/'returned.csv',proposal_path),True)
 check('signature_bytes_preserved',lambda:sha(proposal_path)==before)
 check('string_false_is_false',lambda:boolean('False') is False)
 check('nonboolean_string_rejected',lambda:boolean('approved'),True)
 contract=load(prep/'training_contract.json');cs,grid=threshold_status([1,0],[np.nan,np.nan],'eligibility',['p1','p2'],contract)
 check('no_scores_no_usable_threshold',lambda:cs['usable_threshold'] is None and cs['diagnostic_threshold'] is None)
 # Group approval requires identical full context/source/version, not a similar sentence.
 d=read(source/'decisions.csv');d=d[d.type.eq('EXACT_GROUP_SCOPE')].copy();ids=['P0_0','P0_4']
 from review_registry import scope_binding
 cat=read(prep/'corpus.csv');d.loc[:,'unit_ids']=json.dumps(ids);d.loc[:,'scope_sha256']=digest(ids);d.loc[:,'source_binding']=scope_binding(cat,ids);csvout(case/'badgroup.csv',d)
 sg=load(source/'decision_signature.json');sg['decisions_sha256']=sha(case/'badgroup.csv');jsonout(case/'badgroup_signature.json',sg)
 check('different_context_group_rejected',lambda:ingest_decisions(ctx,case,case/'badgroup.csv',case/'badgroup_signature.json'),True)
 # Immutable stage execution: interrupt, same-ID content change and related-only invalidation.
 inp=case/'probe.txt';inp.write_text('A',encoding='utf-8')
 def interrupted(out):(out/'partial.txt').write_text('incomplete',encoding='utf-8');raise KeyboardInterrupt()
 try:ctx.stage('interrupt_probe',[],[inp],interrupted)
 except KeyboardInterrupt:pass
 check('interrupted_stage_not_complete',lambda:ctx.manifest['stages']['interrupt_probe']['state']=='RUNNING')
 r=ctx.stage('interrupt_probe',[],[inp],lambda out:(out/'complete.txt').write_text('restarted clean',encoding='utf-8'))
 check('resume_ignores_partial_block',lambda:r['state']=='COMPLETED' and not (ctx.root/r['artifact']/'partial.txt').exists())
 a=ctx.stage('cache_probe',[],[inp],lambda out:(out/'value.txt').write_text(inp.read_text(),encoding='utf-8'))
 old=ctx.root/a['artifact'];ctx.stage('dependent_probe',['cache_probe'],[],lambda out:jsonout(out/'ok.json',True));ctx.stage('independent_probe',[],[],lambda out:jsonout(out/'ok.json',True))
 inp.write_text('B',encoding='utf-8');ctx._vcache={}
 check('changed_input_invalidates_related_only',lambda:not ctx.valid('cache_probe') and not ctx.valid('dependent_probe') and ctx.valid('independent_probe'))
 b=ctx.stage('cache_probe',[],[inp],lambda out:(out/'value.txt').write_text(inp.read_text(),encoding='utf-8'))
 check('same_ID_new_contents_not_reused',lambda:not b['reused'] and (old/'value.txt').read_text()=='A' and (ctx.root/b['artifact']/'value.txt').read_text()=='B')
 def mutate(out):inp.write_text('C',encoding='utf-8');jsonout(out/'finished.json',True)
 r=ctx.stage('mutation_probe',[],[inp],mutate)
 check('mid_stage_input_mutation_fails',lambda:r['state']=='FAILED' and r['message']=='INPUT_CHANGED_DURING_STAGE')
 # Completed training has exact heldout exclusion and per-fold duplication separation.
 tr=ctx.artifact('train');membership=read(tr/'training_membership.csv');corpus=read(prep/'corpus.csv').set_index('unit_id')
 check('all_feature_and_fit_ids_development',lambda:corpus.loc[membership.unit_id,'split'].eq('DEVELOPMENT').all())
 for fold,g in membership.groupby('fold'):
  va=set(g.loc[g.role.eq('VALIDATION'),'unit_id']);fit=set(g.loc[g.role.isin(['FEATURE_FIT','SUPERVISION']),'unit_id'])
  check('fold_'+fold+'_family_isolation',lambda va=va,fit=fit:not set(corpus.loc[list(va),'cv_group'])&set(corpus.loc[list(fit),'cv_group']))
 # Code version is a dependency, and publication is not valid under silently changed code.
 oldhash=ctx.code_hash;ctx.code_hash=lambda key:dict(oldhash(key),negative_test_code_change='different');ctx._vcache={}
 check('changed_code_invalidates_validation',lambda:not ctx.valid('validate-candidate'))
 ctx.code_hash=oldhash;ctx._vcache={}
 # Manifest output corruption is caught even if the logical ID is unchanged.
 path=ctx.root/b['artifact']/'value.txt';saved=path.read_bytes();path.write_text('CORRUPT',encoding='utf-8');ctx._vcache={}
 check('cached_block_content_is_checked',lambda:not ctx.valid('cache_probe'))
 path.write_bytes(saved);ctx._vcache={}
 result=dict(identity='SYNTHETIC_TEST_ONLY',passed=all(checks.values()),checks=checks,fixture_directory=str(case),real_files_modified=False)
 jsonout(code/'negative_and_resume_test_report.json',result);print(json.dumps(dict(passed=result['passed'],checks=len(checks)),ensure_ascii=False))
if __name__=='__main__':main()

