"""Post-lock repairs and evidence export. No fit, no reference-label optimization."""
from common import *
from train_limited import threshold_outputs
from standalone_replay import independent_counts
from review_registry import scope_binding
import html

def development_outputs(ctx,out):
 tr=ctx.artifact('train');prep=ctx.artifact('prepare');oof=read(tr/'OOF_scores.csv');grid=read(tr/'threshold_search.csv');old=read(tr/'development_metrics.csv');contract=load(prep/'training_contract.json');result=[]
 for (spec,C),g in oof.groupby(['spec','C'],sort=False):
  contracts={}
  for k in LABELS:
   z=grid[grid.spec.eq(spec)&grid.C.eq(C)&grid.label.eq(k)]
   rows=z.to_dict('records');good=[r for r in rows if boolean(r['feasible'])]
   best=max(good,key=lambda r:(float(r['F2']),float(r['F1']),float(r['threshold']))) if good else None
   contracts[k]={'usable_threshold':float(best['threshold']) if best else None}
  scores=g[['score_'+k for k in LABELS]].replace('',np.nan).astype(float).to_numpy();raw,hard=threshold_outputs(scores,contracts,usable=True)
  y=g[['human_'+k for k in LABELS]].astype(int).to_numpy()
  for j,k in enumerate(LABELS):
   for domain,mask,p in [('RAW_ALL',np.ones(len(g),bool),raw[:,j]),('CONDITIONAL_HUMAN_ELIGIBLE',y[:,0]==1 if j else np.ones(len(g),bool),raw[:,j]),('END_TO_END',np.ones(len(g),bool),hard[:,j])]:
    m=answered_metrics(y[mask,j],p[mask]);d=old[old.spec.eq(spec)&old.C.eq(C)&old.label.eq(k)&old.domain.eq(domain)].iloc[0]
    result.append(dict(spec=spec,C=C,label=k,domain=domain,diagnostic_metric_pass=d.metric_requirement_pass,development_usable_output_status='DEVELOPMENT_ONLY' if contracts[k]['usable_threshold'] is not None else 'ABSTAIN_NO_USABLE_THRESHOLD',usable_metric_pass=quality(m,k,g.loc[mask&(y[:,j]==1),'policy_id'].nunique(),contract),automatic_pool_approval=False,**m))
 csvout(out/'development_usable_metrics.csv',result)
 # Fold reporting reuses frozen scores/cuts; never chooses a new model.
 lock=load(tr/'model_lock.json');sel=lock['selected_diagnostic_model'];g=oof[oof.spec.eq(sel['spec'])&oof.C.astype(float).eq(float(sel['C']))];fold=[]
 for f,z in g.groupby('fold'):
  _,pred=threshold_outputs(z[['score_'+k for k in LABELS]].replace('',np.nan).astype(float).to_numpy(),lock['contracts'])
  for j,k in enumerate(LABELS):fold.append(dict(fold=f,label=k,identity='FROZEN_OOF_DIAGNOSTIC_NOT_RESELECTED',**answered_metrics(z['human_'+k].astype(int),pred[:,j])))
 csvout(out/'frozen_fold_diagnostics.csv',fold)
 jsonout(out/'postprocessing_binding.json',dict(model_sha256=lock['model_sha256'],training_artifact=str(tr),training_code=ctx.manifest['stages']['train']['code'],postprocessing_code_sha256=sha(Path(__file__)),reference_labels_read=False,model_selection_changed=False,model_refitted=False))

def repairs(ctx,out):
 prep=ctx.artifact('prepare');reg=ctx.artifact('build-registry');led=ctx.artifact('part1-ledger');cat=read(prep/'corpus.csv');queue=read(led/'rejected_scope_repair_queue.csv');cards=read(prep/'source_cards.csv').set_index('policy_id');hum=read(reg/'registry_snapshot.csv').set_index('unit_id');texts={};mapping=[];results=[];tasks=[]
 # These are source-specific evidence descriptions, not inferred human labels.
 facts={
 'EARLY-ZY-2012-36':('招政发〔2012〕7号','正文有实施意见标题、招政发〔2012〕7号及招远市适用内容；标题缺发文机关不等于正文错误。','以该文号和正文而非完整通知标题绑定版本；不改变任何标签。'),
 'NAT_2022_MARINE_ECO_PLAN_01':('“十四五”海洋生态环境保护规划','现有32页PDF为2022年1月规划附件，包含封面、目录及规划正文；不应把附件当成六部门印发通知全文。','将载体身份明确为规划附件；发文机关/日期需通知来源，另交接第二部分。'),
 'SD_2020_SPARTINA_IMPL_01':('鲁自然资发〔2020〕7号','现有HTML有文号、发布机构、方案正文和网页导航/政策解读链接；导航不是治理行动。','生成方案正文阅读边界，导航和链接单独标记，保持原单元及标签。'),
 'LZ_2022_14FIVE_ECO_PLAN_01':('第一章 开启建设美丽莱州新征程','现有DOC转写从规划目录开始，正文为莱州规划；目录、控制字符和指标表不能视为完整治理行动。','恢复阅读层控制字符与表格提示；无法单凭目录证明通知与附件版本对应。'),
 'LK_2020_MARINE_ENV_QUALITY_PLAN_01':('龙口市海洋环境质量达标规划','105页PDF封面标2020年6月及编制单位，内页列委托单位；该规划报告不是政府办公室通知正文。','登记技术规划附件身份，保留报告正文；政府采纳/印发对应仍须明确。')}
 for r in queue.to_dict('records'):
  ids=json.loads(r['affected_ids']);g=cat[cat.unit_id.isin(ids)];pol=g.iloc[0].policy_id;file=longpath(g.iloc[0].source_clean_path)
  if pol not in texts:texts[pol]=file.read_text('utf-8-sig')
  text=texts[pol];kind=r['issue_type'];evidence='';fix='';question='';rawhash='';rawok=False;root=kind
  if kind=='BODY_IDENTITY_OR_ATTACHMENT_BOUNDARY':
   card=cards.loc[pol];carrier=ctx.workspace/'b1'/card.captured_source;rawhash=sha(carrier);rawok=rawhash==card.captured_sha256
   anchor,evidence,fix=facts[pol];require(norm(anchor) in norm(text),'Source-specific anchor missing')
   question='请仅裁定新证据中明确的载体身份/正文范围是否可采用；若仍拒绝，请指出错误版本或具体正文位置。原G/T不改。'
   start=0;end=len(text)
   if pol=='SD_2020_SPARTINA_IMPL_01':
    start=text.find('一、');end=text.find('扫一扫',start);end=end if end>=0 else len(text)
   target=out/(pol+'_reading_body.txt');display=text[start:end].replace('\x07','\t');target.write_text(display,encoding='utf-8')
   if '\x07' in text[start:end]:
    csvout(out/(pol+'_display_control_mapping.csv'),[dict(source_offset=i,original_codepoint='U+0007',display_codepoint='U+0009',interpretation='DOC_CELL_SEPARATOR_DISPLAY_ONLY_NOT_ACTION_BOUNDARY') for i in range(start,end) if text[i]=='\x07'])
   evidence+=' 原始载体SHA256='+rawhash+'；阅读层对应原文字符范围['+str(start)+','+str(end)+')；DOC单元格控制符仅在显示副本换成制表符，位置映射另存。'
   root=pol+':CARRIER_VS_NOTICE_IDENTITY'
  elif kind=='EXTRACTION_FRAGMENT':
   for x in g.itertuples():
    a=int(x.clean_start);b=int(x.clean_end);require(text[a:b]==x.exact_evidence_text,'Fragment source offsets changed')
    # Restore bounded paragraph context, without claiming it is one semantic action.
    left=text.rfind('\n\n',0,a);left=left+2 if left>=0 else max(0,a-240)
    right=text.find('\n\n',b);right=right if right>=0 else min(len(text),b+240)
    if right-left>1800:left=max(0,a-360);right=min(len(text),b+360)
    parent=text[left:right];short=len(norm(x.exact_evidence_text))<8
    cls='SHORT_TABLE_HEADER_OR_FRAGMENT_REQUIRES_CONTEXT' if short else 'SENTENCE_OR_PARAGRAPH_CONTEXT_RESTORED'
    mapping.append(dict(issue_id=r['issue_id'],policy_id=pol,unit_id=x.unit_id,original_text=x.exact_evidence_text,original_start=a,original_end=b,reading_start=left,reading_end=right,reading_text=parent,reading_hash=digest([pol,left,right,parent]),source_sha256=sha(file),classification=cls,old_parent_is_semantic_action=False,labels_changed=False,action_merge_approved=False))
   evidence='每个原单元均核对精确字符位置，并恢复带偏移量的阅读上下文；旧parent可能是滑动窗口，不能直接计为行动。'
   fix='已生成reading_context_mapping.csv；未重分段、未覆盖600、未改变训练语料或标签。'
   question='请批准阅读层上下文用于后续定向裁定；表格/标题仍按目标单元判断，不把邻近行动标签传播给碎片。行动边界另裁定。'
   root='READING_CONTEXT_NOT_ACTION_BOUNDARY'
  else:
   x=g.iloc[0];evidence='原目标：'+x.exact_evidence_text+'；上下文：'+x.context
   fix='将“来源/范围是否采用”和“目标是否合格”拆开；原判断保留，不自动改标签。'
   question='该目标属于背景问题陈述' if r['issue_id']=='RULE_05' else '该目标是指标表分类标题，含DOC控制字符'
   question+='。请只说明此前拒绝的是哪项语义解释；若需改标签，应另提交绑定现有字段的明确更正。'
   root=r['issue_id']+':RULE_NOT_LABEL'
  reusable=[uid for uid in ids if uid in hum.index]
  results.append(dict(issue_id=r['issue_id'],root_cause=root,policy_id=pol,original_decision='REJECT',original_rule_text=r['actual_rule_text'],affected_units=len(ids),evidence=evidence,specific_repair=fix,existing_human_records=len(reusable),human_label_reuse='ORIGINAL_TARGET_ONLY;NO_TRANSFER_TO_CHANGED_SEMANTIC_UNIT',author_unique_question=question,status='TECHNICAL_READING_REPAIR_DONE_SCOPE_NOT_AUTOMATICALLY_APPROVED',training_changed=False,source_hash=sha(file),carrier_hash=rawhash,carrier_hash_verified=rawok if rawhash else 'NOT_APPLICABLE'))
  tasks.append(dict(task_id='REPAIR_'+r['issue_id'],root_cause=root,issue_id=r['issue_id'],unit_ids=json.dumps(ids),scope_hash=digest(sorted(ids)),evidence=evidence,repair=fix,question=question,value='',rule_text=''))
 csvout(out/'reading_context_mapping.csv',mapping);csvout(out/'rejected_scope_repair_results.csv',results)
 # One reading-rule card links all 25 extraction scopes; retain exact individual scope bindings.
 grouped=[]
 approved_reading={}
 if (ctx.root/'reading_context_approvals.json').exists():
  for item in load(ctx.root/'reading_context_approvals.json')['items']:
   if item['source_binding']==scope_binding(cat,item['unit_ids']):approved_reading[item['issue_id']]=item
 for root in dict.fromkeys(t['root_cause'] for t in tasks):
  ts=[t for t in tasks if t['root_cause']==root]
  if root=='READING_CONTEXT_NOT_ACTION_BOUNDARY' and all(t['issue_id'] in approved_reading for t in ts):continue
  if root.endswith(':RULE_NOT_LABEL'):continue # rejected explanation retained; do not resend unchanged card
  grouped.append(dict(task_id='ROOT_'+digest(root)[:16],type='REPAIRED_SCOPE_REVIEW',question=ts[0]['question'],evidence='\n'.join(t['evidence'] for t in ts[:1 if len(ts)>1 else len(ts)]),repair=ts[0]['repair'],members=ts,scope_hash=digest(ts),value=''))
 return grouped

def route_and_check(ctx,out):
 prep=ctx.artifact('prepare');reg=ctx.artifact('build-registry');ass=ctx.artifact('assemble-candidate');led=ctx.artifact('part1-ledger');cat=read(prep/'corpus.csv');c=read(ass/'C2_candidate.csv');f=read(ass/'field_evidence.csv');ledger=read(led/'part1_completion_ledger.csv');pred=read(ctx.artifact('predict')/'corpus_predictions.csv').set_index('unit_id');ci=c.set_index('unit_id');rows=[]
 for uid,g in ledger.groupby('unit_id',sort=False):
  x=ci.loc[uid];known={k:x['C2_'+k] for k in LABELS if x['evidence_'+k] and x['C2_'+k] in ['0','1']};missing=[k for k in LABELS if k not in known]
  # Human/approved eligibility overrides MACHINE gates, not unresolved source evidence.
  elig=known.get('eligibility','');suggestions={k:pred.loc[uid,'usable_raw_'+k] for k in missing if pred.loc[uid,'usable_raw_'+k]!='' and (k=='eligibility' or elig=='1')}
  route='REUSE_EXISTING_FIELDS' if not missing and x.source_rule_resolved=='True' else 'SOURCE_OR_RULE_REPAIR' if x.source_rule_resolved!='True' else 'LOCAL_POOL_OR_DIRECTED_MISSING_FIELDS'
  rows.append(dict(unit_id=uid,policy_id=x.policy_id,existing_fields=json.dumps(known),missing_fields=';'.join(missing),necessary_first_question='eligibility' if elig=='' else ';'.join(missing),usable_hints=json.dumps(suggestions),route=route,real_human_eligibility=elig,model_may_exclude=False,failed_head_diagnostic_creates_task=False,automatic_pool_approval=False))
 csvout(out/'field_reuse_and_review_routes.csv',rows)
 pool=read(led/'pool_feasibility.csv');pool['decision']=''
 for i,r in pool.iterrows():
  n=int(r.net_members);a=int(r.estimated_audit_n_zero_error_benchmark)
  pool.loc[i,'decision']='NO_MEMBERS' if not n else 'DIRECT_REVIEW_NO_AUTOMATION_SAVING' if a>=n else 'PROTOCOL_APPROVAL_BEFORE_ANY_SAMPLE'
  pool.loc[i,'potential_operations_saved_upper_bound']=n-a
  pool.loc[i,'other_fields_and_counting']='Other missing labels and approved action boundaries remain required; savings refer to fields not complete records'
 csvout(out/'pool_feasibility.csv',pool)
 mapping=read(ass/'action_unit_mapping.csv');st=read(led/'policy_stage_registry.csv');expected,stexpected=independent_counts(c.to_dict('records'),mapping.to_dict('records'),st.to_dict('records'));actual=read(ass/'policy_level_shares.csv').set_index('policy_id')
 for r in expected:
  for k,v in r.items():
   a=actual.loc[r['policy_id'],k] if k!='policy_id' else r['policy_id']
   require(str(v)==a if k in ['policy_id'] or v=='' else boolean(a)==v if k=='measurement_ready' else np.isclose(float(a),float(v),rtol=0,atol=1e-12),'Independent arithmetic mismatch '+k)
 jsonout(out/'independent_measurement_check.json',dict(identity='REAL_DATA_INCOMPLETE_MEASUREMENT_CHECK',passed=True,policies=len(expected),defined_policies=sum(r['measurement_ready'] for r in expected),stages=len(stexpected),not_formal_share_validation=True))
 for name in ['C2_candidate.csv','field_evidence.csv','action_unit_mapping.csv','policy_level_shares.csv']:shutil.copyfile(ass/name,out/name)
 for name in ['policy_share_quality_report.csv','stage_composition_PREVIEW.csv','stage_composition.csv','quality_contract.json']:
  if (led/name).exists():shutil.copyfile(led/name,out/name)
 return rows,pool

def build(ctx,out):
 development_outputs(ctx,out);tasks=repairs(ctx,out);rows,pool=route_and_check(ctx,out)
 led=ctx.artifact('part1-ledger');ass=ctx.artifact('assemble-candidate');cp=read(ass/'counting_rule_scope_proposals.csv')
 if len(cp):tasks.append(dict(task_id='COUNTING_RULE_SCOPE',type='COUNTING_APPROVAL',question='是否批准完整、唯一、单parent且已有合格人审的单元按已登记规则计一次？例外单独裁定；该批准不改变标签。',evidence='Exact proposed scopes in counting_rule_scope_proposals.csv',repair='No rule applied before approval',members=cp.to_dict('records'),scope_hash=digest(cp.to_dict('records')),value=''))
 gp=read(led/'strict_equivalence_proposals.csv');usable=gp[gp.possible_human_representative.ne('')].copy()
 dec=read(ctx.artifact('build-registry')/'decision_registry.csv')
 approved_groups={digest(sorted(json.loads(x))) for x in dec.loc[dec.type.eq('EXACT_GROUP_SCOPE')&dec.value.eq('CONFIRM'),'unit_ids']}
 usable=usable[~usable.scope_sha256.isin(approved_groups)].copy()
 cat=read(ctx.artifact('prepare')/'corpus.csv').set_index('unit_id')
 for col in ['exact_evidence_text','context','policy_version_id','source_location']:usable[col]=usable.unit_id.map(cat[col])
 human=read(ctx.artifact('build-registry')/'registry_snapshot.csv').set_index('unit_id')
 usable['representative_actual_labels']=usable.possible_human_representative.map(lambda uid:json.dumps({k:human.loc[uid,'human_'+k] for k in LABELS},ensure_ascii=False))
 if len(usable):tasks.append(dict(task_id='STRICT_GROUPS_WITH_REAL_REPRESENTATIVE',type='GROUP_APPROVAL',question='是否逐组确认登记的真实代表及完全相同版本、原文和上下文范围？不同意的组留空；本项不批准行动合并。',evidence='strict_equivalence_proposals.csv',repair='Only groups with actual human representative are listed',members=usable.to_dict('records'),scope_hash=digest(usable.to_dict('records')),value=''))
 approved_audits=[]
 for key,entry in ctx.manifest['stages'].items():
  if not key.startswith('plan-audit:') or not ctx.valid(key):continue
  plan=ctx.root/entry['artifact'];protocol=load(plan/'protocol.json');pid=protocol['pool_id']
  shutil.copyfile(plan/'pool_members.csv',out/(pid+'_members.csv'))
  if entry['state']=='COMPLETED' and (plan/'protocol_approval.json').exists():
   approved_audits.append(dict(pool_id=pid,protocol_sha256=sha(plan/'protocol.json'),approval_sha256=sha(plan/'protocol_approval.json'),sample_sha256=sha(plan/'audit_review.csv'),sample_n=protocol['sample_n'],status='AUDIT_RETURN_REGISTERED' if any(k.startswith('ingest-audit:'+pid+':') and ctx.valid(k) for k in ctx.manifest['stages']) else 'WAITING_FOR_AUDIT_RETURN'))
   continue
  tasks.append(dict(task_id='PROTOCOL_'+pid,type='EXACT_POOL_PROTOCOL',question='是否批准此精确模型、成员及风险协议后导出验收样本？只批准抽样，不代表通过。来源/模型改变将使本批准失效。',evidence='协议成员见 '+pid+'_members.csv；全10池筛查采用另一个更保守的10声明假设，不替代这里已登记的6声明协议。',repair='Existing protocol retained without relaxing risk or increasing searches',members=[protocol],protocol_sha256=sha(plan/'protocol.json'),plan_artifact=str(plan),scope_hash=digest(protocol),value=''))
 jsonout(out/'author_tasks.json',dict(identity='UNAPPROVED_CONCRETE_TASKS',tasks=tasks,labels_changed=False))
 jsonout(out/'approved_audit_tasks.json',dict(identity='ACTUAL_PROTOCOL_APPROVAL_NOT_QUALITY_OR_ADOPTION',pools=approved_audits))
 # HTML keeps one return file and all exact member bindings. No preselected approval.
 data=json.dumps(tasks,ensure_ascii=False).replace('</','<\\/')
 page='''<!doctype html><meta charset="utf-8"><title>第一部分：修复后集中入口</title><style>body{font:16px sans-serif;max-width:1100px;margin:30px auto;line-height:1.6}section{border:1px solid #bbb;padding:18px;margin:18px 0}textarea{width:98%;height:90px}pre{white-space:pre-wrap;max-height:300px;overflow:auto}select,input{font-size:16px}</style><h1>修复后集中作者入口</h1><p>原52项、600/1200/200均不重填。本表是修复后的具体问题与新范围批准，不是原决定重发。空白不接受；本次返回不等于C2最终批准。各项可部分填写。</p><p>审核者 <input id="reviewer"> 实际完成时间 <input id="signed" type="datetime-local"></p><main id="cards"></main><button onclick="save()">导出一次返回JSON</button><script>const tasks=DATA;const esc=s=>String(s??'').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;');document.getElementById('cards').innerHTML=tasks.map((t,i)=>`<section><b>${esc(t.task_id)}</b><p>${esc(t.question)}</p><p>${esc(t.evidence)}</p><p>${esc(t.repair)}</p><details><summary>查看绑定范围与证据</summary><pre>${esc(JSON.stringify(t.members,null,2))}</pre></details>${["GROUP_APPROVAL","COUNTING_APPROVAL"].includes(t.type)?[...new Set(t.members.map(m=>m.group_id||m.decision_id))].map(id=>`<label style="display:block"><input type="checkbox" data-task="${i}" value="${esc(id)}">${esc(id)}</label>`).join(""):""}<select id="v${i}"><option value="">未处理</option><option value="CONFIRM">确认列明范围/规则</option><option value="REJECT">拒绝并说明具体位置</option><option value="UNRESOLVED">无法判断</option></select><textarea id="n${i}" placeholder="具体解释、例外或池ID；不以本表替代条款标签更正"></textarea></section>`).join('');function save(){const reviewer=document.getElementById('reviewer').value,signed_at=document.getElementById('signed').value;if(!reviewer||!signed_at){alert('填写真实审核者和完成时间');return}const result={reviewer,signed_at,statement:'ACTUAL_REPAIRED_TASK_RETURN_NOT_FINAL_C2_APPROVAL',tasks:tasks.map((t,i)=>({...t,value:document.getElementById('v'+i).value,notes:document.getElementById('n'+i).value,selected_scope_ids:[...document.querySelectorAll('input[data-task="'+i+'"]:checked')].map(e=>e.value)}))};let a=document.createElement('a');a.href=URL.createObjectURL(new Blob([JSON.stringify(result,null,2)],{type:'application/json;charset=utf-8'}));a.download='minimal_repair_author_RETURN.json';a.click()}</script>'''.replace('DATA',data)
 if approved_audits:
  banner='<section><h2>三池协议已批准，填写合并盲审表</h2><p>计数及协议确认已记录，不必重复确认。协议批准不等于质量通过或最终C2批准。</p><p><a href="three_pool_review_BLIND.xlsx">下载合并盲审工作簿</a> · <a href="THREE_POOL_REVIEW_README.md">填写与导入说明</a></p>'+''.join('<p>'+html.escape(a['pool_id'])+'：'+a['status']+'</p>' for a in approved_audits)+'</section>'
  page=page.replace('<main id="cards">',banner+'<main id="cards">')
 (out/'AUTHOR_REVIEW.html').write_text(page,encoding='utf-8')
 for name in ['counting_rule_scope_proposals.csv','action_counting_exceptions.csv']:shutil.copyfile(ass/name,out/name)
 shutil.copyfile(led/'strict_equivalence_proposals.csv',out/'strict_equivalence_proposals.csv')
 pin=load(ctx.root/'frozen_training_reuse.json')
 changed=sha(ctx.artifact('train')/'diagnostic_model.joblib')!=pin['model_sha256']
 jsonout(out/'minimal_status.json',dict(model_refitted_since_initial_patch=changed,training_input_changed_since_initial_patch=changed,original_human_unchanged=True,author_task_cards=len(tasks),reading_map_rows=len(read(out/'reading_context_mapping.csv')),remaining_rejected_scopes=len(read(out/'rejected_scope_repair_results.csv')),formal_release=False,PART1_COMPLETED=False,part2_started=False))

if __name__=='__main__':
 import argparse
 p=argparse.ArgumentParser();p.add_argument('--workspace',required=True);p.add_argument('--run-id',required=True);a=p.parse_args();ctx=Context(a.workspace,a.run_id)
 sources=[Path(__file__)]+([ctx.root/'reading_context_approvals.json'] if (ctx.root/'reading_context_approvals.json').exists() else [])
 result=ctx.stage('minimal-repair',['prepare','build-registry','train','predict','assemble-candidate','part1-ledger','plan-audit:*','ingest-audit:*'],sources,lambda out:build(ctx,out))
 print(result)
 if result['state']!='COMPLETED':raise SystemExit(1)
