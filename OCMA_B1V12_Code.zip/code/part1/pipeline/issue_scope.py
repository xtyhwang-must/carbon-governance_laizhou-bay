"""Evidence-scoped restrictions; title formatting is not a semantic label error."""
from common import *

def build_issue_scope(ctx,out,cat):
 rows=[]
 def emit(i,typ,ids,evidence,train,code,stock,recommendation):
  rows.append(dict(issue_id=i,issue_type=typ,affected_ids=json.dumps(sorted(ids)),affected_n=len(ids),evidence=evidence,blocks_training=train,blocks_coding=code,blocks_inventory=stock,existing_confirmation='BASELINE_LABELS_RETAINED_NOT_VERSION_APPROVAL',recommendation=recommendation,approval_status='NOT_NEWLY_APPROVED'))
 if (out/'source_cards.csv').exists():
  for r in read(out/'source_cards.csv').to_dict('records'):
   units=cat[cat.policy_id.eq(r['policy_id'])];ids=units.unit_id.tolist()
   # Only title already explicitly located in the actual hash-bound source qualifies.
   simple=r.get('resolved_scope')=='TITLE_TEXT_PRESENT' and r.get('body_source_relation')=='CAPTURED_SOURCE_BODY'
   evidence=json.dumps(r,ensure_ascii=False)
   emit('SRC_'+r['policy_id'],'TITLE_FORMAT_VARIANT' if simple else 'BODY_IDENTITY_OR_ATTACHMENT_BOUNDARY',ids,evidence,not simple,not simple,True,'Title-only warning does not invalidate existing labels' if simple else 'Confirm exact body/version or attachment scope once; do not relabel entire policy')
   emit('DATE_'+r['policy_id'],'EFFECTIVE_EXIT_METADATA',ids,'No new legal-date verification in coding stage',False,False,True,'Resolve before future inventory, not a G/T label')
 # Conservative detection of obvious extraction fragments, not machine-negative labels.
 bad=cat.exact_evidence_text.map(lambda t: bool(re.fullmatch(r'[\s\d一二三四五六七八九十百、.．()（）]+',str(t))) or bool(re.fullmatch(r'\s*(责任单位|牵头单位|配合单位|责任部门)\s*[:：].*',str(t))))
 for pol,g in cat[bad].groupby('policy_id'):
  emit('EXTRACT_'+pol,'EXTRACTION_FRAGMENT',g.unit_id.tolist(),json.dumps(g[['unit_id','exact_evidence_text','source_location']].to_dict('records'),ensure_ascii=False),True,True,False,'Check captured source and parent context; never treat as verified negative')
 if (out/'rule_cards.csv').exists():
  for r in read(out/'rule_cards.csv').to_dict('records'):emit(r['card_id'],'CLAUSE_SEMANTIC_RULE',[r['unit_id']],json.dumps(r,ensure_ascii=False),True,True,False,r.get('suggested_interpretation','Scoped semantic decision needed'))
 csvout(out/'issue_scope_audit.csv',rows,columns=['issue_id','issue_type','affected_ids','affected_n','evidence','blocks_training','blocks_coding','blocks_inventory','existing_confirmation','recommendation','approval_status'])

def semantic_signature_records(frame):
 # Counting-only recovery columns arise from heterogeneous event table concatenation.
 # Empty structural padding is not a semantic rule or supervised training input.
 structural=['source_recovery_sha256','covered_unit_ids']
 for k in structural:
  if k in frame:require(frame[k].fillna('').eq('').all(),'Nonempty counting metadata on semantic rule requires explicit schema resolution')
 return frame.drop(columns=structural,errors='ignore').to_dict('records')

def signatures(out,prep,labels,corpus,dec,complete):
 # IDs, actual supervised values, family identities and actual feature inputs only.
 lc=['unit_id','policy_id','cv_group']+['human_'+k for k in LABELS]
 tc=['unit_id','policy_id','cv_group','exact_evidence_text','parent_context_model','parent_clause_text','norm','cross_split_long_duplicate']
 dev_ids=set(corpus.unit_id)
 sem=dec[dec.type.eq('SEMANTIC_RULE')].copy()
 if len(sem):sem=sem[sem.unit_ids.map(lambda x:bool(set(json.loads(x))&dev_ids))]
 semantic_version=digest([sha(prep/'codebook.md'),semantic_signature_records(sem)])
 train=dict(labels=labels[lc].sort_values('unit_id').to_dict('records'),texts=corpus[tc].sort_values('unit_id').to_dict('records'),semantic_version=semantic_version,contract_sha256=sha(prep/'training_contract.json'),sample_gate_satisfied=complete)
 # Hash files contain no timestamps, aggregate-only audit changes or counting decisions.
 jsonout(out/'training_signature.json',dict(signature=digest(train),semantic_version=semantic_version,sample_gate_satisfied=complete))
 counting=dec[dec.type.isin(['ACTION_COUNTING_RULE','ACTION_COUNTING_BOUNDARY'])]
 jsonout(out/'measurement_signature.json',dict(signature=digest(counting.to_dict('records')),counting_version=digest(counting.to_dict('records'))))
 source=dec[dec.type.eq('SOURCE_VERSION')]
 jsonout(out/'audit_signature.json',dict(signature=digest([sha(out/'registry_snapshot.csv'),sha(out/'decision_registry.csv')]),source_scope_version=digest(source.to_dict('records'))))
 return digest([sha(prep/'codebook.md'),semantic_signature_records(dec[dec.type.eq('SEMANTIC_RULE')])])
