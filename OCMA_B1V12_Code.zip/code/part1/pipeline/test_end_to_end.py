"""Isolated full pipeline fixture. Every label/signature/model/publication is SYNTHETIC_TEST_ONLY."""
from common import *
from coding_pipeline import execute
from train_limited import threshold_outputs,weights
from pool_audit import error_bound
import tempfile,sys
IDENTITY='SYNTHETIC_TEST_ONLY'
def main():
 code=Path(__file__).resolve().parent;testroot=code/'synthetic_tests';testroot.mkdir(exist_ok=True)
 ws=Path(tempfile.mkdtemp(prefix='SYNTHETIC_TEST_ONLY_',dir=testroot));data=ws/'fixture';data.mkdir();checks={};stages=[]
 def ck(name,value):checks[name]=bool(value);require(checks[name],'TEST FAILED: '+name)
 def run(ctx,cmd,**kw):
  if cmd in ['plan-audit','ingest-audit']:
   kw['pool_id']='fixture';kw['batch_id']='batch01'
   if cmd=='ingest-audit' or kw.get('approval'):kw['protocol_sha256']=sha(ctx.root/ctx.manifest['stages']['plan-audit:fixture']['artifact']/'protocol.json')
   if kw.get('acceptance'):cmd='accept-pool';kw['approval']=kw.pop('acceptance')
  r=execute(ctx,cmd,**kw);stages.append(r);require(r.get('state')!='FAILED',r.get('message',''));return r
 corpus=[];human=[];samples=[];links=[];truth={};pred=[]
 for polno in range(8):
  pol='P'+str(polno);split='DEVELOPMENT' if polno<6 else 'HELD_OUT_POLICY';textmap={};valsmap={}
  N=400 if polno==7 else 40
  eligible=[i for i in range(N) if i%4!=0 and polno!=7];negative=[i for i in range(N) if i not in eligible]
  hset=set(eligible[:15]+negative[:3]);sset=set(eligible[15:]+negative[3:6])
  for i in range(N):
   uid=pol+'_'+str(i);elig=int(i in eligible);gt={k:int(elig and (i+j)%3!=0) for j,k in enumerate(LABELS[1:])};vals=dict(eligibility=elig,**gt);truth[uid]=vals;valsmap[uid]=vals
   text=('实施海洋生态保护治理行动 ' if elig else '历史目录信息背景无治理任务 ')+''.join((k+'保护执行 ' if gt[k] else k+'其他背景 ') for k in LABELS[1:])+'独立文本标记'+uid
   if polno==0 and i==36:text=textmap[pol+'_0']
   textmap[uid]=text
  source=data/(pol+'.txt');source.write_text('\n'.join(textmap.values()),encoding='utf-8');sourcehash=sha(source)
  for i in range(N):
   uid=pol+'_'+str(i);vals=valsmap[uid];text=textmap[uid];context='完整上下文 '+text
   row=dict(policy_id=pol,policy_version_id=pol+'_v1',policy_family_id=pol,cv_group=pol,unit_id=uid,source_hash=sourcehash,source_clean_path=str(source),source_clean_sha256=sourcehash,source_location=pol+':'+str(i),exact_evidence_text=text,context=context,parent_clause_text=text,parent_context_model=context,parent_clause_id='parent_'+(pol+'_0' if polno==0 and i==36 else uid),parent_member_count=2 if polno==0 and i in [0,36] else 1,norm=norm(text),cross_split_long_duplicate=False,split=split)
   corpus.append(row);pred.append(dict(unit_id=uid,policy_id=pol,**{'score_'+k:.9 if vals[k] else .1 for k in LABELS}))
   if i in hset:human.append(dict(unit_id=uid,policy_id=pol,source_hash=sourcehash,**{'human_'+k:str(vals[k]) for k in LABELS},reviewer=IDENTITY,review_time='2026-10-26T01:00:00+00:00',role='ORIGINAL_RANDOM_REFERENCE' if split!='DEVELOPMENT' else 'TARGETED_FINAL_BATCH',split=split,batch_id='BASE',original_workbook_sha256=digest(['fixture',pol]),evidence_record_sha256=digest(['human',uid]),label_origin='SYNTHETIC_EXPLICIT_JUDGMENT',training_allowed=split=='DEVELOPMENT'))
   if i in sset:
    samples.append(dict(unit_id=uid,policy_id=pol,text=text,context=context,source_location=row['source_location'],source_hash=sourcehash,eligibility_choice='',**{'human_'+k:'' for k in LABELS[1:]},notes=''))
    links.append(dict(unit_id=uid,policy_id=pol,split=split,stratum_N=len(sset)+len(set(range(N))-hset-sset),stratum_n=len(sset),design_weight=(N-len(hset))/len(sset),inclusion_probability=len(sset)/(N-len(hset))))
 csvout(data/'corpus.csv',corpus);csvout(data/'human.csv',human);csvout(data/'sample.csv',samples);csvout(data/'linkage.csv',links);csvout(data/'v3_scores.csv',pred)
 jsonout(data/'v3_lock.json',dict(model_sha256='SYNTHETIC_MODEL_ANCHOR',predictions_sha256=sha(data/'v3_scores.csv'),thresholds={k:.5 for k in LABELS}))
 (data/'codebook.md').write_text('SYNTHETIC_TEST_ONLY: Accepted ineligible implies GT zero. Policy shares count confirmed action units.',encoding='utf-8')
 contract=load(code.parent.parent/'review_optimization_v5_minimal/development_protocol_locked.json');jsonout(data/'contract.json',contract)
 csvout(data/'reference.csv',[dict(unit_id=r['unit_id']) for r in human if r['split']!='DEVELOPMENT'])
 csvout(data/'source_cards.csv',[dict(policy_id='P0')]);csvout(data/'rule_cards.csv',[dict(card_id='RULE',unit_id='P0_1',suggested_interpretation='Fixture rule only')])
 cfg=dict(project='B1 V1.2',identity=IDENTITY,inputs={k:str(data/f) for k,f in dict(corpus='corpus.csv',human='human.csv',codebook='codebook.md',contract='contract.json',sample='sample.csv',linkage='linkage.csv',v3_scores='v3_scores.csv',v3_lock='v3_lock.json',reference_ids='reference.csv',source_cards='source_cards.csv',rule_cards='rule_cards.csv').items()},require_complete_existing_sample_before_training=True,development_informed_by_prior_reference_failure=True,derive_ineligible_GT_zero=True,part2_enabled=False)
 jsonout(data/'config.json',cfg);ctx=Context(ws,'full_chain',data/'config.json');run(ctx,'prepare');run(ctx,'build-registry')
 wait=run(ctx,'train');ck('real_dependency_gate_blocks_before_return',wait['state']=='WAITING_FOR_HUMAN')
 prep=ctx.artifact('prepare');form=read(prep/'sample.csv')
 for i,r in form.iterrows():
  vals=truth[r.unit_id];form.loc[i,'eligibility_choice']='ELIGIBLE' if vals['eligibility'] else 'INELIGIBLE'
  for k in LABELS[1:]:form.loc[i,'human_'+k]=str(vals[k]) if vals['eligibility'] else ''
 csvout(data/'returned.csv',form)
 def sign(name,statement,**binding):
  f=data/name;jsonout(f,dict(identity=IDENTITY,statement=statement,reviewer=IDENTITY,signed_at='2026-10-27T01:00:00+00:00',**binding));return f
 rs=sign('return_signature.json','CONFIRM_ACTUAL_HUMAN_RETURN',review_sha256=sha(data/'returned.csv'),sample_sha256=sha(prep/'sample.csv'),model_sha256='SYNTHETIC_MODEL_ANCHOR',batch_id='RETURN01')
 run(ctx,'ingest-return',review=data/'returned.csv',signature=rs);second=run(ctx,'ingest-return',review=data/'returned.csv',signature=rs);ck('duplicate_batch_is_reused',second['reused'])
 # Scoped decisions and explicit action mappings, without replacing labels.
 from review_registry import scope_binding
 cat=read(prep/'corpus.csv');dec=[]
 def add(did,typ,ids,aid='',rep=''):
  dec.append(dict(decision_id=did,type=typ,unit_ids=json.dumps(sorted(ids)),value='CONFIRM',rule_text='SYNTHETIC_TEST_ONLY exact declared scope',action_unit_id=aid,representative_id=rep,scope_sha256=digest(sorted(ids)),source_binding=scope_binding(cat,ids)))
 add('SRC','SOURCE_VERSION',cat[cat.policy_id.eq('P0')].unit_id.tolist());add('RULE','SEMANTIC_RULE',['P0_1']);add('GROUP','EXACT_GROUP_SCOPE',['P0_0','P0_36'],rep='P0_0')
 for uid in cat.unit_id:
  if uid=='P0_36':continue
  add('ACTION_'+uid,'ACTION_COUNTING_BOUNDARY',['P0_0','P0_36'] if uid=='P0_0' else [uid],aid='A_'+uid)
 csvout(data/'decisions.csv',dec);ds=sign('decision_signature.json','APPROVE_SCOPED_CODING_DECISIONS',decisions_sha256=sha(data/'decisions.csv'))
 run(ctx,'ingest-decisions',decisions=data/'decisions.csv',signature=ds);run(ctx,'build-registry')
 reg=ctx.artifact('build-registry');rm=load(reg/'registry_manifest.json')
 ck('registry_appended_unique_actual_events_fixture',rm['actual_unique_human_n']==len(human)+len(samples))
 ck('reference_and_heldout_not_train',rm['original_reference_training_n']==0 and rm['heldout_training_n']==0)
 run(ctx,'train');tr=ctx.artifact('train');lock=load(tr/'model_lock.json')
 ck('fixed_training_budget',lock['fold_specifications']==18 and lock['final_refits']==1)
 wa=read(tr/'class_weight_audit.csv');mass=wa[wa.trainable.eq('True')]
 ck('all_candidates_same_actual_loss_anchor',np.allclose(mass.total_mass.astype(float),mass.anchor.astype(float)))
 ck('no_C0_supervised_mass',wa.weak_mass.astype(float).eq(0).all())
 run(ctx,'predict');prediction=read(ctx.artifact('predict')/'corpus_predictions.csv')
 ck('prediction_formal_fields_blank',prediction[['formal_C2_'+k for k in LABELS]].eq('').all(axis=None))
 # A single local eligibility-negative census resolves only its own population.
 definition=data/'pool_definition.json';jsonout(definition,dict(family_id='fixture_family',label='eligibility',direction='NEGATIVE',score_cut=1.0,design='SRSWOR_FINITE_POOL',seed=20261027,family_alpha=.05,planned_claims=1,risk_limit=.02,claim_scope='SYNTHETIC_TEST_ONLY_LOCAL_POOL'))
 proposal=run(ctx,'plan-audit',input=definition);ck('sample_export_requires_protocol_approval',proposal['state']=='WAITING_FOR_APPROVAL')
 proposed=ctx.root/proposal['artifact'];pa=sign('pool_protocol_approval.json','APPROVE_EXACT_LOCAL_POOL_PROTOCOL',protocol_sha256=sha(proposed/'protocol.json'))
 run(ctx,'plan-audit',input=definition,approval=pa);planpath=ctx.artifact('plan-audit:fixture');audit=read(planpath/'audit_review.csv');audit['truth']=[str(truth[u]['eligibility']) for u in audit.unit_id];csvout(data/'audit_return.csv',audit)
 aus=sign('audit_signature.json','CONFIRM_ACTUAL_POOL_AUDIT',review_sha256=sha(data/'audit_return.csv'),protocol_sha256=sha(planpath/'protocol.json'))
 sd=load(aus);sd['signed_at']='2026-10-27T02:00:00+00:00';jsonout(aus,sd)
 pending=run(ctx,'ingest-audit',review=data/'audit_return.csv',signature=aus);ck('risk_pass_does_not_imply_author_approval',pending['state']=='WAITING_FOR_APPROVAL')
 run(ctx,'assemble-candidate');pending_fields=read(ctx.artifact('assemble-candidate')/'field_evidence.csv')
 ck('audit_humans_reused_before_pool_approval',set(audit.unit_id)<=set(pending_fields.loc[pending_fields.field.eq('eligibility') & pending_fields.status.eq('HUMAN_ADJUDICATED'),'unit_id']))
 ar=ctx.root/pending['artifact'];ap=sign('acceptance.json','ACCEPT_EXACT_VALIDATED_POOL',audit_quality_sha256=sha(ar/'audit_quality.json'),protocol_sha256=sha(planpath/'protocol.json'))
 run(ctx,'ingest-audit',review=data/'audit_return.csv',signature=aus,acceptance=ap)
 run(ctx,'assemble-candidate');ass=ctx.artifact('assemble-candidate');cs=load(ass/'candidate_status.json')
 ck('all_fields_resolved_in_isolated_fixture',cs['labels_complete'])
 evidence=read(ass/'field_evidence.csv');autoids=set(evidence.loc[evidence.status.eq('AUTO_ACCEPTED_UNDER_VALIDATED_PROTOCOL'),'unit_id'])
 ck('audited_members_are_human_not_auto',not autoids.intersection(set(audit.unit_id)) and len(autoids)>0)
 ck('derived_zero_path_actually_executed',cs['derived_fields']>0)
 ck('strict_group_path_actually_executed',cs['actual_group_fields']>0)
 ck('explicit_action_mapping_ready',cs['POLICY_MEASUREMENT_READY'])
 share=read(ass/'policy_level_shares.csv');ck('zero_eligible_policy_share_not_zero',share.loc[share.policy_id.eq('P7'),'G1'].iloc[0]=='' and share.loc[share.policy_id.eq('P7'),'zero_eligible_policy'].iloc[0]=='UNDEFINED_NOT_ZERO')
 run(ctx,'validate-candidate');va=load(ctx.artifact('validate-candidate')/'validation.json')
 ck('pool_validated_once_not_per_field',va['unique_pool_packages_checked']==1)
 publishapproval=sign('final_author.json','APPROVE_EXACT_C2_LABELS_AND_EVIDENCE',candidate_sha256=sha(ass/'C2_candidate.csv'),bundle_sha256=sha(ass/'candidate_evidence_bundle.json'))
 run(ctx,'publish',approval=publishapproval);pub=ctx.artifact('publish');pm=load(pub/'publication_manifest.json')
 ck('actual_publication_copy_and_manifest',pm['C2_LABELS_FROZEN'] and (pub/'C2_candidate.csv').is_file())
 ck('synthetic_cannot_be_real_release',pm['identity']==IDENTITY)
 ck('SD_never_started',not pm['part2_started'])
 # Abstention metrics keep unanswered positives in the overall detection denominator.
 from common import answered_metrics
 m=answered_metrics([1,1,0],[1,np.nan,0]);ck('abstention_denominator_correct',m['answered_recall']==1 and m['overall_detection']==.5 and m['abstained_positive_n']==1)
 ck('noncensus_zero_errors_not_zero_risk',error_bound(100,30,0,.05)>0)
 # Full-chain resume does not retrain or need a new instruction.
 resumed=execute(ctx,'resume');ck('resume_reuses_completed_training',next(r for r in resumed if r['stage']=='train')['reused'])
 # Deliberately unfavorable actual judgment remains human even when the pool fails.
 from pool_audit import ingest,validate_human_audit
 bad=audit.copy();bad.loc[bad.index[0],'truth']='1';csvout(data/'adverse_audit.csv',bad)
 bs=dict(load(aus),review_sha256=sha(data/'adverse_audit.csv'));jsonout(data/'adverse_signature.json',bs)
 adverse=longpath(data/'adverse_output');adverse.mkdir()
 try:ingest(ctx,adverse,data/'adverse_audit.csv',data/'adverse_signature.json',None,'fixture',sha(planpath/'protocol.json'))
 except Waiting:pass
 actualbad=validate_human_audit(ctx,adverse)
 ck('adverse_audit_truth_preserved',actualbad.set_index('unit_id').loc[bad.iloc[0].unit_id,'value']=='1')
 ck('no_approval_no_auto_even_after_audit',not (adverse/'accepted_fields.csv').exists())
 report=dict(identity=IDENTITY,passed=all(checks.values()),checks=checks,workspace=str(ws),stages=stages,synthetic_model_trained=True,synthetic_publication_created=True,real_models_trained=0,real_human_reviews_created=0)
 jsonout(code/'end_to_end_test_report.json',report);print(json.dumps(dict(passed=report['passed'],checks=len(checks),workspace=str(ws)),ensure_ascii=False))
if __name__=='__main__':main()

