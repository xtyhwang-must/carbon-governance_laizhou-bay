"""Finite repair of frozen coding baseline: provenance, T2 uncertainty, measurement scope.
No fit, no threshold selection, no SD. All output generations are immutable snapshots.
"""
from common import *
import argparse,csv,gzip,math,sys,subprocess,time
from collections import Counter,defaultdict

G=['G1','G2','G3'];T=['T1','T2','T3','T4','T5','T6'];LABELS=['eligibility']+G+T
VERSION='B1_V1.2_CONDITIONAL_T2_REPAIR_20261028_v1'

def input_paths(ctx):
 legacy=ctx.root/'part1_delivery/C2_author_model_completion_20261028'
 return dict(matrix=legacy/'C2_formal_author_model_completed.csv',evidence=legacy/'C2_field_evidence_mixed.csv',legacy_status=legacy/'MODEL_COMPLETION_STATUS.json',author_protocol=legacy/'author_adoption_protocol.json',legacy_manifest=legacy/'manifest.json',corpus=ctx.artifact('prepare')/'corpus.csv',codebook=ctx.artifact('prepare')/'codebook.md',training_contract=ctx.artifact('prepare')/'training_contract.json',model=ctx.artifact('train')/'diagnostic_model.joblib',model_lock=ctx.artifact('train')/'model_lock.json',oof=ctx.artifact('train')/'OOF_scores.csv',threshold_search=ctx.artifact('train')/'threshold_search.csv',development=ctx.artifact('train')/'development_metrics.csv',predictions=ctx.artifact('predict')/'corpus_predictions.csv',approved_mapping=ctx.artifact('assemble-candidate')/'group_action_mapping.csv',approved_shares=ctx.artifact('assemble-candidate')/'policy_group_shares.csv',decisions=ctx.artifact('build-registry')/'decision_registry.csv',registry_manifest=ctx.artifact('build-registry')/'registry_manifest.json',supplement=ctx.workspace/'00_reference/supplementary material.docx')

def records_csv(path,rows,columns=None):csvout(path,rows,columns)
def ratio(n,d):return n/d if d else np.nan

def scenario_counts(z,fieldmask):
 positive=z.C2_eligibility.eq('1');p=z.loc[positive];unknown=fieldmask.loc[p.index]
 counts={k:int(p['C2_'+k].astype(int).sum()) for k in G+T}
 known_t2=int(p.loc[~unknown,'C2_T2'].astype(int).sum());unknown_n=int(unknown.sum())
 return dict(eligible_n=len(p),counts=counts,known_t2=known_t2,unknown_n=unknown_n)

def policy_scenarios(matrix,t2unknown,source_scope):
 rows=[];ranges=[];details=[]
 for pid,allz in matrix.groupby('policy_id',sort=False):
  z=allz if source_scope=='INCLUDE_ALL' else allz[allz.source_scope_verified.eq('True')]
  d=scenario_counts(z,t2unknown);counts=d['counts'];known=d['known_t2'];q=d['unknown_n'];other=sum(counts[k] for k in T if k!='T2');gden=sum(counts[k] for k in G)
  variants={'A_LEGACY':counts['T2'],'B_UNKNOWN_PRIMARY':known if not q else None,'C_UNKNOWN_ZERO_ASSUMPTION':known,'D_UNKNOWN_ONE_ASSUMPTION':known+q}
  base=dict(policy_id=pid,stage=allz.iloc[0].stage,source_scope=source_scope,total_source_units=len(allz),included_source_units=len(z),excluded_source_units=len(allz)-len(z),eligible_source_units=d['eligible_n'],known_T2_positive=known,unknown_machine_T2_eligible=q,measurement_unit='SOURCE_TEXT_UNIT_PROXY',range_identity='MODEL_CONDITIONAL_SENSITIVITY_NOT_CONFIDENCE_INTERVAL')
  for scenario,t2 in variants.items():
   den=other+t2 if t2 is not None else None
   reason='T2_UNIDENTIFIED' if den is None else 'NO_ELIGIBLE_UNIT' if not d['eligible_n'] else 'ZERO_GROUP_DENOMINATOR' if den==0 else 'DEFINED'
   for k in T:
    count=t2 if k=='T2' else counts[k];value=ratio(count,den) if den is not None else np.nan
    rows.append(dict(**base,scenario=scenario,label=k,positive_assignment_count=count if count is not None else np.nan,group_assignment_denominator=den if den is not None else np.nan,share=value,status=reason))
   details.append(dict(**base,scenario=scenario,T2_count=t2 if t2 is not None else np.nan,T_denominator=den if den is not None else np.nan,T2_share=ratio(t2,den) if den is not None else np.nan,G_denominator=gden,**{k:ratio(counts[k],gden) for k in G},status=reason))
  # Exact conditional ranges over unknown eligible T2 assignments, preserving all other labels.
  for k in T:
   lo_count=known if k=='T2' else counts[k];hi_count=known+q if k=='T2' else counts[k];c=ratio(lo_count,other+known);e=ratio(hi_count,other+known+q);finite=[x for x in [c,e] if np.isfinite(x)]
   ranges.append(dict(**base,label=k,share_C=c,share_D=e,lower_defined_share=min(finite) if finite else np.nan,upper_defined_share=max(finite) if finite else np.nan,zero_denominator_possible=other+known==0,all_assignments_undefined=other+known+q==0,point_identified=not q,scope='RANGE_OVER_DEFINED_T2_ASSIGNMENTS;DEFINEDNESS_SEPARATELY_REPORTED'))
 return pd.DataFrame(rows),pd.DataFrame(ranges),pd.DataFrame(details)

def order_text(values,exclude_t2=False):
 ks=[k for k in T if k!='T2' or not exclude_t2];finite=[k for k in ks if np.isfinite(values.get(k,np.nan))]
 # Exact ranks with explicit ties, never rank an undefined value.
 remaining=sorted(finite,key=lambda k:(-values[k],k));groups=[]
 for k in remaining:
  if groups and abs(values[k]-values[groups[-1][0]])<=1e-12:groups[-1].append(k)
  else:groups.append([k])
 return ' > '.join('='.join(g) for g in groups)

def stage_tables(policy):
 # Common support across both source treatments and A/C/D; original policy universe always retained.
 stable_scenarios=['A_LEGACY','C_UNKNOWN_ZERO_ASSUMPTION','D_UNKNOWN_ONE_ASSUMPTION']
 base=policy[policy.scenario.isin(stable_scenarios)&policy.label.eq('T2')]
 good=base.groupby('policy_id').apply(lambda z:z.share.notna().all() and len(z)==6,include_groups=False)
 common=set(good[good].index);rows=[];ranges=[];stability=[]
 for stage,universe in policy.groupby('stage'):
  all_ids=set(universe.policy_id);shared=all_ids&common
  for scope in ['INCLUDE_ALL','EXCLUDE_SOURCE_UNRESOLVED']:
   values_by_scenario={}
   for scenario in ['A_LEGACY','B_UNKNOWN_PRIMARY','C_UNKNOWN_ZERO_ASSUMPTION','D_UNKNOWN_ONE_ASSUMPTION']:
    for support,ids in [('DEFINED_IN_THIS_SPEC',all_ids),('COMMON_DEFINED_ALL_SPECS',shared)]:
     z=universe[universe.source_scope.eq(scope)&universe.scenario.eq(scenario)&universe.policy_id.isin(ids)];defined=set(z.loc[z.share.notna(),'policy_id']);means={k:float(z.loc[z.label.eq(k),'share'].dropna().mean()) if z.loc[z.label.eq(k),'share'].notna().any() else np.nan for k in T}
     if support=='COMMON_DEFINED_ALL_SPECS':values_by_scenario[scenario]=means
     for k in T:rows.append(dict(stage=stage,source_scope=scope,scenario=scenario,support=support,policy_universe_n=len(all_ids),support_n=len(ids),defined_policy_n=len(defined),undefined_policy_ids=';'.join(sorted(ids-defined)),excluded_for_common_support=';'.join(sorted(all_ids-ids)),label=k,share=means[k],weighting='EQUAL_POLICY_ON_EXPLICIT_DEFINED_SUPPORT',measurement_unit='SOURCE_TEXT_UNIT_PROXY',identity='MODEL_CONDITIONAL_SENSITIVITY'))
   c=values_by_scenario['C_UNKNOWN_ZERO_ASSUMPTION'];d=values_by_scenario['D_UNKNOWN_ONE_ASSUMPTION'];a=values_by_scenario['A_LEGACY'];orders={s:order_text(values_by_scenario[s],True) for s in stable_scenarios}
   for k in T:
    endpoints=[v for v in [c[k],d[k]] if np.isfinite(v)];ranges.append(dict(stage=stage,source_scope=scope,label=k,common_policy_n=len(shared),policy_universe_n=len(all_ids),share_A=a[k],share_C=c[k],share_D=d[k],lower=min(endpoints) if endpoints else np.nan,upper=max(endpoints) if endpoints else np.nan,identity='MODEL_CONDITIONAL_RANGE_NOT_CONFIDENCE_INTERVAL',support='COMMON_DEFINED_ALL_SPECS'))
   stability.append(dict(stage=stage,source_scope=scope,policy_universe_n=len(all_ids),common_policy_n=len(shared),common_policy_ids=';'.join(sorted(shared)),other_tools_A=orders['A_LEGACY'],other_tools_C=orders['C_UNKNOWN_ZERO_ASSUMPTION'],other_tools_D=orders['D_UNKNOWN_ONE_ASSUMPTION'],other_tool_order_stable=len(set(orders.values()))==1,T2_A=a['T2'],T2_C=c['T2'],T2_D=d['T2'],T2_D_minus_C=d['T2']-c['T2'] if np.isfinite(d['T2']) and np.isfinite(c['T2']) else np.nan,identity='COMMON_SUPPORT_MODEL_CONDITIONAL_SENSITIVITY'))
 return pd.DataFrame(rows),pd.DataFrame(ranges),pd.DataFrame(stability)

def evidence_classification(src,out,protocol_hash):
 # Streaming avoids materializing the 143 MB evidence table repeatedly.
 parent=pd.read_csv(longpath(src),usecols=['unit_id','field','value','evidence_id'],dtype=str,keep_default_na=False).query("field=='eligibility'").set_index('unit_id')
 parent_ids=parent.evidence_id.to_dict();parent_values=parent.value.to_dict();counts=Counter();gate_counts=Counter();human_preserved=0;machine=0;written=0
 target=out/'C2_field_evidence_classified.csv.gz'
 with gzip.open(target,'wt',encoding='utf-8',newline='') as stream:
  first=True
  for z in pd.read_csv(longpath(src),dtype=str,keep_default_na=False,encoding='utf-8-sig',chunksize=50000):
   z['legacy_binary_value']=z.value
   machine_mask=z.status.eq('MACHINE_PREDICTED_AUTHOR_ADOPTED');gate=z.evidence_source.eq('MODEL_NEGATIVE_GATE_NOT_VALIDATED');unknown_t2=machine_mask&z.field.eq('T2')
   z['evidence_type']=np.select([z.status.eq('HUMAN_ADJUDICATED'),z.status.eq('GROUP_REVIEW_CONFIRMED'),z.status.eq('DERIVED_FROM_ACCEPTED_INELIGIBLE'),gate,z.evidence_source.eq('LOCKED_DIAGNOSTIC_THRESHOLD_UNQUALIFIED'),machine_mask],['ACTUAL_HUMAN_JUDGMENT','APPROVED_STRICT_GROUP_PROPAGATION','RULE_ZERO_FROM_ACTUAL_INELIGIBLE','MODEL_NEGATIVE_GATE_ZERO','MODEL_DIAGNOSTIC_THRESHOLD_UNQUALIFIED','MODEL_DEVELOPMENT_USABLE_SUGGESTION'],default='OTHER_EXISTING_EFFECTIVE_EVIDENCE')
   z['validation_status']=np.where(machine_mask,'NOT_INDEPENDENTLY_VALIDATED','EXISTING_JUDGMENT_OR_RULE_NOT_DOUBLE_CODING_CERTIFICATE')
   z['usage_status']=np.where(unknown_t2,'UNQUALIFIED_MACHINE_T2',np.where(machine_mask,'MODEL_CONDITIONAL_ONLY','PRESERVED_EXISTING_EVIDENCE'))
   z.loc[unknown_t2,'value']='';z['prediction_parent_id']=np.where(gate,z.parent_evidence_id,'');z['independence_unit_id']=np.where(gate,z.parent_evidence_id,z.evidence_id)
   require((z.loc[gate,'parent_evidence_id']==z.loc[gate,'unit_id'].map(parent_ids)).all(),'Gate parent evidence mismatch');require(z.loc[gate,'unit_id'].map(parent_values).eq('0').all(),'Gate parent is not negative');require(z.loc[gate,'legacy_binary_value'].eq('0').all(),'Gate child is nonzero')
   counts.update(z.evidence_type);gate_counts.update(z.loc[gate,'prediction_parent_id']);human_preserved+=int((~machine_mask).sum());machine+=int(machine_mask.sum());written+=len(z)
   z.to_csv(stream,index=False,header=first);first=False
 require(len(gate_counts)==19410 and set(gate_counts.values())=={9},'Nine gate zeros must share one parent')
 csvout(out/'field_reliability_identity_counts.csv',[dict(evidence_type=k,fields=v) for k,v in counts.items()])
 return dict(existing_fields=human_preserved,machine_fields=machine,gate_zero_fields=sum(gate_counts.values()),gate_parent_predictions=len(gate_counts),children_per_gate_parent=9,total_fields=written)

def model_diagnostics(paths,frame,pred,lock,out):
 import joblib
 from scipy.sparse import hstack
 model=joblib.load(paths['model']);require(model['labels']==LABELS,'Model label order mismatch');require(model['contracts']==lock['contracts'],'Object/lock threshold mismatch')
 corpus=read(paths['corpus']);require(corpus.unit_id.tolist()==pred.unit_id.tolist(),'Stored scores/corpus ordering mismatch')
 # Direct frozen-object scoring; no pipeline prediction function or fitting is invoked.
 X=hstack([model['vectorizers'][0].transform(corpus.exact_evidence_text),model['vectorizers'][1].transform(corpus.parent_context_model)*.3],format='csr')
 metrics=[]
 for j,k in enumerate(LABELS):
  head=model['models'][j];require(head is not None and 1 in head.classes_,'Missing trained head')
  prob=head.predict_proba(X)[:,list(head.classes_).index(1)];stored=pred['score_'+k].astype(float).to_numpy();err=float(np.max(abs(prob-stored)));require(err<1e-7,'Score mismatch: '+k)
  machine=frame.machine_field_n.astype(int).gt(0);eligible=machine&frame.C2_eligibility.eq('1');den=machine if k=='eligibility' else eligible;dev=lock['label_usage_status'][k]['end_to_end'];threshold=lock['contracts'][k]['usable_threshold'];usable=threshold is not None;threshold=lock['contracts'][k]['diagnostic_threshold'] if threshold is None else threshold
  metrics.append(dict(label=k,model_head_index=j,model_classes=json.dumps(head.classes_.tolist()),max_score_replay_error=err,usable_threshold=lock['contracts'][k]['usable_threshold'],legacy_diagnostic_threshold=lock['contracts'][k]['diagnostic_threshold'],threshold_actually_used=threshold,development_precision=dev['precision'],development_recall=dev['overall_detection'],development_TP=dev['tp'],development_FP=dev['fp'],development_FN=dev['fn'],development_positive_n=dev['positive_n'],machine_denominator=int(den.sum()),machine_positive_n=int(frame.loc[den,'C2_'+k].eq('1').sum()),machine_positive_rate=float(frame.loc[den,'C2_'+k].eq('1').mean()),quality_identity='DEVELOPMENT_USABLE_NOT_CORPUS_VALIDATED' if usable else 'NO_FEASIBLE_DEVELOPMENT_THRESHOLD',implementation_valid=True))
 csvout(out/'label_machine_quality_diagnostics.csv',metrics)
 t2=next(r for r in metrics if r['label']=='T2');search=pd.read_csv(paths['threshold_search'],usecols=['spec','C','label','feasible']);selected=search[(search.spec==model['spec'])&(search.C==model['C'])&search.label.eq('T2')];feasible=int(selected.feasible.astype(str).str.lower().eq('true').sum());require(feasible==0,'Unexpected feasible T2 threshold')
 z=read(paths['oof']);z=z[(z.spec==model['spec'])&z.C.eq(str(model['C']))];truth=z.human_T2.astype(int).to_numpy();s=z.score_T2.map(lambda v:float(v) if str(v).strip() else np.nan).to_numpy();es=z.score_eligibility.map(lambda v:float(v) if str(v).strip() else np.nan).to_numpy();valid=np.isfinite(s)&np.isfinite(es);elig=es>=lock['contracts']['eligibility']['diagnostic_threshold'];raw=s>=lock['contracts']['T2']['diagnostic_threshold'];p=raw&elig&valid;tp=int(((truth==1)&p).sum());fp=int(((truth==0)&p).sum());fn=int(((truth==1)&~p&valid).sum());require((tp,fp,fn)==(t2['development_TP'],t2['development_FP'],t2['development_FN']),'OOF T2 replay disagrees with model lock')
 t2.update(status='T2_IMPLEMENTATION_VALID_BUT_CLASSIFICATION_UNRELIABLE',old_OOF_cutpoints=len(selected),old_OOF_feasible_cutpoints=feasible,new_threshold_proposed=False,threshold_selection_executed_this_round=False,OOF_replay_TP=tp,OOF_replay_FP=fp,OOF_replay_FN=fn,OOF_abstained_n=int((~valid).sum()),OOF_abstained_positive_n=int(((truth==1)&~valid).sum()),OOF_predicted_positive_fraction=float(p.mean()),OOF_positive_policy_coverage=z.loc[p,'policy_id'].nunique() if 'policy_id' in z else '',scope='DEVELOPMENT_DIAGNOSTIC_REPLAY_NOT_INDEPENDENT_VALIDATION')
 csvout(out/'T2_anomaly_diagnostics.csv',[t2]);return metrics,t2

def reproduce_binary_layer(frame,pred,evidence,out):
 # Recompute from stored raw frozen scores and actual effective values, not from legacy class columns.
 known=pd.read_csv(longpath(evidence),usecols=['unit_id','field','value','evidence_source'],dtype=str,keep_default_na=False);known=known[known.evidence_source.eq('EXISTING_EFFECTIVE_EVIDENCE')];idx=frame.set_index('unit_id');ps=pred.set_index('unit_id');recomputed={};lock=load(out/'frozen_model_lock.json')
 for k in LABELS:
  cut=lock['contracts'][k]['usable_threshold'];cut=lock['contracts'][k]['diagnostic_threshold'] if cut is None else cut
  recomputed[k]=pd.Series(np.where(ps['score_'+k].astype(float).ge(cut),'1','0'),index=ps.index)
  actual=known[known.field.eq(k)].set_index('unit_id');recomputed[k].loc[actual.index]=actual.value
 for k in G+T:
  actual=set(known.loc[known.field.eq(k),'unit_id']);mask=recomputed['eligibility'].eq('0')&~recomputed[k].index.isin(actual);recomputed[k].loc[mask]='0'
 for k in LABELS:require(recomputed[k].loc[idx.index].eq(idx['C2_'+k]).all(),'Legacy binary replay failed: '+k)
 return dict(all_legacy_fields_reproduced=len(frame)*10,existing_effective_fields_preserved=len(known),all_legacy_machine_fields_reproduced=328580-len(known))


def source_mapping(frame,cat,approved,decisions,out):
 # Source structure is evidence for identity, not permission to transfer labels or expand an old signed scope.
 cat=cat.set_index('unit_id');f=frame.set_index('unit_id');ap=approved.set_index('unit_id');texts={};hashes={};duplicates=cat.reset_index().groupby(['policy_id','policy_version_id','clean_start','clean_end','exact_evidence_text']).size().to_dict();maps=[];exceptions=[]
 approved_ids=set(decisions.loc[decisions.value.eq('CONFIRM'),'decision_event_id'])
 for uid,r in cat.iterrows():
  path=r.source_clean_path
  if path not in texts:
   pp=longpath(path);texts[path]=pp.read_text('utf-8-sig') if pp.exists() else '';hashes[path]=sha(pp) if pp.exists() else ''
  text=texts[path];start=int(r.clean_start);end=int(r.clean_end);exact=text[start:end]==r.exact_evidence_text and hashes[path]==r.source_clean_sha256;eligible=f.loc[uid,'C2_eligibility']=='1';src=f.loc[uid,'source_scope_verified']=='True';old=ap.loc[uid];approved_id=old.action_unit_id if old.action_boundary_ready=='True' and old.action_unit_id and old.decision_event_id in approved_ids else ''
  clean=r.exact_evidence_text.strip();numbered=bool(re.match(r'^(?:第[一二三四五六七八九十百零〇\d]+条|[一二三四五六七八九十]+[、.]|[（(][一二三四五六七八九十0-9]+[）)]|\d+[.、])',clean));terminal=bool(re.search(r'[。！？.!?][”\"』」）)]?$',clean));multi=len(re.findall(r'[。！？.!?](?:\s|$)',clean))>1;crossref=bool(re.search(r'前款|前条|但[是,，]|除.*[外以]|另有规定|下列.*[:：;；]$',clean));numdup=duplicates[(r.policy_id,r.policy_version_id,r.clean_start,r.clean_end,r.exact_evidence_text)]
  # Entire source-located single numbered sentence or complete paragraph can be reconstructed conditionally.
  boundary_left=start==0 or text[start-1] in '\n。！？.!?';boundary_right=end==len(text) or text[end:end+1] in '\n \r';structural=exact and src and eligible and terminal and len(clean)>=20 and not multi and not crossref and (numbered or boundary_left and boundary_right)
  candidate='SRC_ACT_'+digest([r.policy_id,r.policy_version_id,r.source_clean_sha256,start,end])[:24] if structural else ''
  reasons=[]
  if eligible and not approved_id:
   if not exact:reasons.append('SOURCE_OFFSET_OR_HASH_MISMATCH')
   if not src:reasons.append('SOURCE_OR_RULE_SCOPE_UNRESOLVED')
   if not terminal:reasons.append('FRAGMENT_OR_INCOMPLETE_STOP_BOUNDARY')
   if multi:reasons.append('POSSIBLE_MULTIPLE_COMPLETE_ACTIONS')
   if crossref:reasons.append('CONDITION_EXCEPTION_OR_CROSS_REFERENCE')
   if not structural and not reasons:reasons.append('NO_SUFFICIENT_STRUCTURAL_BOUNDARY')
   if candidate:reasons.append('STRUCTURE_RECOVERED_BUT_PRIOR_SIGNED_ID_SCOPE_DOES_NOT_EXTEND_AUTOMATICALLY')
  status='APPROVED_ACTION_UNIT' if approved_id else 'SOURCE_STRUCTURAL_CANDIDATE_NOT_APPROVED' if candidate else 'NO_ACTION_COUNT_CURRENT_INELIGIBLE' if not eligible else 'ACTION_IDENTITY_EXCEPTION_KEEP_PROXY'
  maps.append(dict(unit_id=uid,policy_id=r.policy_id,action_unit_id=approved_id or candidate,approved_action_unit_id=approved_id,reconstructed_action_unit_id=candidate,measurement_identity=status,source_start=start,source_end=end,source_location=r.source_location,source_clean_sha256=r.source_clean_sha256,actual_source_hash_verified=exact,source_scope_verified=src,source_numbered_item=numbered,complete_sentence_boundary=terminal,parent_not_used_as_merge_rule=True,same_physical_span_records=numdup,prior_decision_event_id=old.decision_event_id if approved_id else '',labels_propagated=False))
  if reasons:exceptions.append(dict(unit_id=uid,policy_id=r.policy_id,reasons=';'.join(reasons),source_start=start,source_end=end,source_text=r.exact_evidence_text,route='KEEP_CONDITIONAL_SOURCE_PROXY;NOT_A_UNIFORM_HUMAN_REVIEW_QUEUE',candidate_id=candidate))
 csvout(out/'source_unit_to_action_mapping.csv',maps);csvout(out/'action_reconstruction_exceptions.csv',exceptions);return pd.DataFrame(maps)

def unit_comparisons(frame,mapping,proxy,approved_shares,out):
 rows=[];f=frame.set_index('unit_id');ap=approved_shares.set_index(['policy_id','group']);mp=mapping.set_index('unit_id')
 for pid,z in frame.groupby('policy_id',sort=False):
  p=z[z.C2_eligibility.eq('1')];ids=list(p.unit_id);m=mp.loc[ids];actual=int(m.approved_action_unit_id.ne('').sum());candidates=int((m.reconstructed_action_unit_id.ne('')&m.approved_action_unit_id.eq('')).sum())
  for group,ks in [('G',G),('T',T)]:
   r=ap.loc[(pid,group)];ready=r.measurement_ready=='True';base=proxy[(proxy.policy_id==pid)&proxy.source_scope.eq('INCLUDE_ALL')&proxy.scenario.eq('A_LEGACY')]
   counts={k:int(p['C2_'+k].astype(int).sum()) for k in ks};den=sum(counts.values());actden=int(r.assignment_denominator) if ready else np.nan
   for k in ks:rows.append(dict(policy_id=pid,stage=z.iloc[0].stage,group=group,label=k,proxy_source_units=len(z),proxy_eligible_units=len(p),proxy_assignment_denominator=den,proxy_share=ratio(counts[k],den),approved_mapped_positive_units=actual,structural_candidates_not_yet_approved=candidates,approved_action_n=int(r.eligible_action_n) if ready else np.nan,approved_assignment_denominator=actden,approved_action_share=float(r[k]) if ready and r[k] else np.nan,proxy_minus_approved=ratio(counts[k],den)-float(r[k]) if ready and r[k] and den else np.nan,source_limited_units=int(z.source_scope_verified.ne('True').sum()),unapproved_eligible_unit_n=len(p)-actual,full_approved_policy_group=ready,policy_group_quality_accepted=r.quality_accepted=='True',approved_action_status='APPROVED_ACTION_DEFINED' if ready else 'INCOMPLETE_ACTION_SCOPE_NO_POLICY_SHARE',proxy_status='SOURCE_UNIT_PROXY_MODEL_CONDITIONAL',merging_or_duplicate_effect='NOT_IDENTIFIED_OUTSIDE_APPROVED_SCOPE;STRUCTURAL_CANDIDATES_NOT_SILENTLY_COUNTED'))
 result=pd.DataFrame(rows);csvout(out/'policy_measurement_unit_comparison.csv',result)
 stages=[]
 for (stage,group,label),z in result.groupby(['stage','group','label']):
  good=z[z.full_approved_policy_group];stages.append(dict(stage=stage,group=group,label=label,total_policy_n=len(z),full_approved_policy_n=len(good),quality_accepted_policy_n=int(good.policy_group_quality_accepted.sum()),approved_policy_ids=';'.join(good.policy_id),approved_mean=float(good.approved_action_share.mean()) if good.approved_action_share.notna().any() else np.nan,proxy_mean_on_same_policies=float(good.proxy_share.mean()) if good.proxy_share.notna().any() else np.nan,proxy_mean_all_defined=float(z.proxy_share.mean()) if z.proxy_share.notna().any() else np.nan,approved_stage_coverage_complete=len(good)==len(z),identity='APPROVED_ACTION_VS_SOURCE_PROXY;PARTIAL_ACTION_MEAN_NOT_FULL_STAGE'))
 csvout(out/'stage_measurement_unit_comparison.csv',stages);return result

def zero_group_diagnostics(frame,cat,out):
 c=cat.set_index('unit_id');rows=[]
 for r in frame[frame.C2_eligibility.eq('1')].to_dict('records'):
  for group,ks in [('G',G),('T',T)]:
   if any(r['C2_'+k]!='0' for k in ks):continue
   z=c.loc[r['unit_id']];text=z.exact_evidence_text;fragment=not re.search(r'[。！？.!?][”\"』」）)]?$',text.strip()) or len(text)<12
   reason='POSSIBLE_FRAGMENT_OR_INCOMPLETE_EXPRESSION' if fragment else 'MODEL_OMISSION_OR_FUNCTION_UNIDENTIFIABLE_NOT_SEPARATELY_IDENTIFIED' if r['machine_field_n']!='0' else 'ACTUAL_JUDGMENT_NO_G_CLASS_OR_NO_RECOGNIZABLE_T_TOOL;NOT_AUTOMATICALLY_CORRECTED'
   rows.append(dict(unit_id=r['unit_id'],policy_id=r['policy_id'],group=group,origin='MODEL_COMPLETED' if r['machine_field_n']!='0' else 'EXISTING_EFFECTIVE_JUDGMENT',source_scope_verified=r['source_scope_verified'],source_location=z.source_location,text=text,diagnostic_reason=reason,diagnostic_not_new_human_label=True,auto_positive_fill=False,codebook_explicitly_requires_one_label_per_group=False))
 csvout(out/'eligible_zero_group_diagnostics.csv',rows)
 return Counter((r['group'],r['origin']) for r in rows)

def plot_quality(out,metrics,number):
 import matplotlib
 matplotlib.use('Agg')
 import matplotlib.pyplot as plt
 from matplotlib.colors import LinearSegmentedColormap
 data=pd.DataFrame(metrics);csvout(out/f'Figure_{number}_data.csv',data)
 plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8,'svg.fonttype':'none','pdf.fonttype':42,'axes.spines.top':False,'axes.spines.right':False})
 fig=plt.figure(figsize=(7.2,4.9),layout='constrained');gs=fig.add_gridspec(1,3,width_ratios=[1,1,1.8],wspace=.08);axes=[fig.add_subplot(gs[0,j]) for j in range(3)]
 y=np.arange(len(data));labels=[f"{r.label}" for r in data.itertuples()];palettes=[LinearSegmentedColormap.from_list('rate',['#f5f5f5','#66879e']),LinearSegmentedColormap.from_list('precision',['#f7f7f7','#41617b'])]
 for j,(column,title) in enumerate([('machine_positive_rate','Machine-positive rate'),('development_precision','Development precision')]):
  a=data[column].to_numpy()*100;axes[j].imshow(a[:,None],aspect='auto',cmap=palettes[j],vmin=0,vmax=100)
  for i,v in enumerate(a):axes[j].text(0,i,f'{v:.1f}%',ha='center',va='center',color='white' if v>65 else '#152a38',fontsize=9)
  axes[j].set_xticks([]);axes[j].set_title(title,fontsize=9,pad=12);axes[j].set_yticks(y);axes[j].set_yticklabels(labels if j==0 else []);axes[j].tick_params(length=0)
  for spine in axes[j].spines.values():spine.set_visible(False)
 axes[2].set_xlim(0,1);axes[2].set_ylim(len(data)-.5,-.5);axes[2].axis('off');axes[2].set_title('Original development status',fontsize=9,pad=12)
 for i,r in enumerate(data.itertuples()):
  failed=r.quality_identity=='NO_FEASIBLE_DEVELOPMENT_THRESHOLD';axes[2].text(.04,i,'Not qualified' if failed else 'Development usable',va='center',fontsize=8,color='#9c5829' if failed else '#33566a')
 for ax in axes:
  ax.axhspan(5-.49,5+.49,facecolor='none',edgecolor='#b66a34',lw=1.25)
 fig.suptitle('Prediction frequency does not establish classification quality',fontsize=11,fontweight='bold')
 fig.supxlabel('G/T rate: model-eligible texts (n=11,204); eligibility rate: all model texts (n=30,614).\nNo new validation or probability calibration. Shading denotes magnitude, not quality.',fontsize=7)
 for extension in ['svg','pdf','png']:fig.savefig(out/f'Figure_{number}.{extension}',dpi=600 if extension=='png' else None,bbox_inches='tight')
 plt.close(fig)
 (out/f'Figure_{number}_caption.md').write_text(f'Figure {number}. Label-wise machine-positive rates, historical developmental precision and original qualification status. Eligibility uses 30,614 model-completed texts; G/T rates use the 11,204 model-eligible texts. Precision is from the locked selected developmental OOF comparison, not an independent estimate on the completed corpus. Six heads had no feasible threshold under the original development requirements. The T2 row is outlined. Shading indicates numerical magnitude; a high positive rate is not a performance score. No confidence intervals, hypothesis tests or new evaluation are represented. Source data: Figure_{number}_data.csv. Figure S6 is unchanged.','utf-8')

def build_tables(out,metrics,counts,details,comparison):
 summary=[dict(section='Evidence fields',item=k,n=v) for k,v in counts.items()]
 csvout(out/'Table_S7A_evidence_identity.csv',summary);csvout(out/'Table_S7B_label_quality.csv',metrics)
 # Side-by-side endpoints and actual action estimates; all policies retained.
 d=details[details.scenario.isin(['A_LEGACY','C_UNKNOWN_ZERO_ASSUMPTION','D_UNKNOWN_ONE_ASSUMPTION'])]
 t=d.pivot(index=['policy_id','stage','source_scope'],columns='scenario',values='T2_share').reset_index();t['measurement_unit']='SOURCE_TEXT_UNIT_PROXY';t['identity']='MODEL_CONDITIONAL_SENSITIVITY';csvout(out/'Table_S8_T2_and_measurement_policy.csv',t)
 for name in ['Table_S7A_evidence_identity','Table_S7B_label_quality','Table_S8_T2_and_measurement_policy']:
  z=pd.read_csv(out/(name+'.csv'));html=z.to_html(index=False,na_rep='NA',border=0)
  (out/(name+'.html')).write_text('<!doctype html><meta charset="utf-8"><style>body{font-family:"Times New Roman",serif;max-width:1200px;margin:25px auto;font-size:10.5pt}table{border-collapse:collapse;border-top:1pt solid #222;border-bottom:1pt solid #222;width:100%}th{border-bottom:.5pt solid #333}td,th{padding:5px 7px;text-align:left}</style><h1>'+name.replace('_',' ')+'</h1><p>Model-conditional results. NA values are not zeros. Development metrics are not independent validation.</p>'+html,'utf-8')
 csvout(out/'Table_S8_measurement_unit_comparison.csv',comparison)

def verify_output(folder):
 """Plain-Python aggregate replay in an independent process; never calls generators."""
 folder=longpath(folder)
 def items(name):
  with (folder/name).open('r',encoding='utf-8-sig',newline='') as handle:return list(csv.DictReader(handle))
 def num(s):return float(s) if s not in ['','nan','NaN','NA'] else None
 def same(actual,expected):return (actual is None and expected is None) or actual is not None and expected is not None and abs(actual-expected)<1e-10
 matrix=items('C2_conditional_evidence.csv');policies={};acc={}
 for r in matrix:
  policies[r['policy_id']]=r['stage']
  for scope in ['INCLUDE_ALL','EXCLUDE_SOURCE_UNRESOLVED']:
   key=(r['policy_id'],scope);a=acc.setdefault(key,dict(n=0,q=0,known=0,legacy=0,other={k:0 for k in T if k!='T2'}))
   if scope=='EXCLUDE_SOURCE_UNRESOLVED' and r['source_scope_verified']!='True':continue
   if r['C2_eligibility']!='1':continue
   a['n']+=1;a['legacy']+=int(r['T2_LEGACY_DIAGNOSTIC'])
   if r['C2_T2']=='':a['q']+=1
   else:a['known']+=int(r['C2_T2'])
   for k in a['other']:a['other'][k]+=int(r['C2_'+k])
 expected={}
 for (pid,scope),a in acc.items():
  for scenario,t2 in [('A_LEGACY',a['legacy']),('B_UNKNOWN_PRIMARY',None if a['q'] else a['known']),('C_UNKNOWN_ZERO_ASSUMPTION',a['known']),('D_UNKNOWN_ONE_ASSUMPTION',a['known']+a['q'])]:
   den=None if t2 is None else sum(a['other'].values())+t2
   for k in T:expected[(pid,scope,scenario,k)]=None if not den else (t2 if k=='T2' else a['other'][k])/den
 rows=items('policy_scenario_tool_composition.csv')
 for r in rows:require(same(num(r['share']),expected[(r['policy_id'],r['source_scope'],r['scenario'],r['label'])]),'Independent policy sensitivity replay failed')
 for r in items('policy_tool_composition_ranges.csv'):
  key=(r['policy_id'],r['source_scope']);v=[expected[(*key,s,r['label'])] for s in ['C_UNKNOWN_ZERO_ASSUMPTION','D_UNKNOWN_ONE_ASSUMPTION']];valid=[x for x in v if x is not None];require(same(num(r['lower_defined_share']),min(valid) if valid else None) and same(num(r['upper_defined_share']),max(valid) if valid else None),'Independent policy range failed')
 common={pid for pid in policies if all(expected[(pid,scope,s,'T2')] is not None for scope in ['INCLUDE_ALL','EXCLUDE_SOURCE_UNRESOLVED'] for s in ['A_LEGACY','C_UNKNOWN_ZERO_ASSUMPTION','D_UNKNOWN_ONE_ASSUMPTION'])}
 for r in items('stage_scenario_tool_composition.csv'):
  ids={pid for pid,stage in policies.items() if stage==r['stage']};ids=ids&common if r['support']=='COMMON_DEFINED_ALL_SPECS' else ids;v=[expected[(pid,r['source_scope'],r['scenario'],r['label'])] for pid in ids];v=[x for x in v if x is not None];avg=sum(v)/len(v) if v else None;require(same(num(r['share']),avg),'Independent equal-policy stage replay failed')
 # T2 changes cannot affect G; per source/policy the repeated G entries must be identical.
 g={}
 for r in items('T2_conditional_sensitivity.csv'):
  key=(r['policy_id'],r['source_scope']);value=tuple(r[k] for k in G)
  require(key not in g or g[key]==value,'T2 sensitivity changed G shares');g[key]=value
 unknown=sum(r['C2_T2']=='' for r in matrix);require(unknown==30614,'T2 unknown count changed or silently filled')
 report=dict(passed=True,method='Fresh process; csv + plain Python counting and ratios, no generator functions',policy_count=len(policies),scenario_policy_rows_verified=len(rows),T2_unknown_retained=unknown,G_unchanged=True,all_ranges_model_conditional_not_CI=True)
 jsonout(folder/'independent_numeric_replay.json',report);return report

def boundary_tests(out):
 checks=[]
 def ck(n,v):require(v,n);checks.append(dict(name=n,passed=True,identity='SYNTHETIC_BOUNDARY_TEST_NOT_RESEARCH_RESULT'))
 def fixture(elig='1',source='True',t2='1',t1='1'):
  r=dict(unit_id='u',policy_id='p',stage='s',C2_eligibility=elig,source_scope_verified=source)
  for k in G+T:r['C2_'+k]='0'
  r['C2_G1']='1';r['C2_T1']=t1;r['C2_T2']=t2
  return pd.DataFrame([r])
 ck('threshold_equality_uses_roundtrip_float',float('0.028141891831534264')>=0.028141891831534264)
 x=fixture();mask=pd.Series([True]);p,r,d=policy_scenarios(x,mask,'INCLUDE_ALL');ck('unknown_not_point_zero',p.query("scenario=='B_UNKNOWN_PRIMARY'").share.isna().all());ck('T2_endpoints_and_other_tool_range',r.set_index('label').loc['T2','lower_defined_share']==0 and r.set_index('label').loc['T2','upper_defined_share']==.5 and r.set_index('label').loc['T1','lower_defined_share']==.5 and r.set_index('label').loc['T1','upper_defined_share']==1)
 p,r,d=policy_scenarios(fixture(t1='0'),mask,'INCLUDE_ALL');ck('zero_denominator_is_NA',p.query("scenario=='C_UNKNOWN_ZERO_ASSUMPTION'").share.isna().all());ck('defined_endpoint_not_confidence_interval',r.set_index('label').loc['T2','upper_defined_share']==1 and r.zero_denominator_possible.all())
 p,_,_=policy_scenarios(fixture(elig='0'),mask,'INCLUDE_ALL');ck('no_eligible_policy_not_zero_share',p.share.isna().all())
 p,_,_=policy_scenarios(fixture(source='False'),mask,'EXCLUDE_SOURCE_UNRESOLVED');ck('all_source_excluded_still_policy_NA',len(p)==24 and p.share.isna().all())
 x=fixture();p,_,_=policy_scenarios(x,pd.Series([False]),'INCLUDE_ALL');ck('known_T2_preserved_all_scenarios',p.query("label=='T2'").share.eq(.5).all())
 with tempfile.TemporaryDirectory(dir=out,prefix='source_boundary_fixture_') as temp:
  temp=longpath(temp);text1='第一条 应当开展湿地生态保护修复并持续维护区域湿地生境。';text2='第二条 应当定期开展水质监测并依法公开水环境调查评估结果。';source=temp/'source.txt';source.write_text(text1+'\n'+text2,'utf-8');cats=[];fr=[];aps=[]
  for i,txt in enumerate([text1,text2]):
   uid='u'+str(i);start=0 if i==0 else len(text1)+1;cats.append(dict(unit_id=uid,policy_id='p',policy_version_id='v',parent_clause_id='SAME_SLIDING_PARENT',clean_start=str(start),clean_end=str(start+len(txt)),exact_evidence_text=txt,source_clean_path=str(source),source_clean_sha256=sha(source),source_location='L'+str(i)));fr.append(dict(unit_id=uid,C2_eligibility='1',source_scope_verified='True'));aps.append(dict(unit_id=uid,action_boundary_ready='False',action_unit_id='',decision_event_id=''))
  maps=source_mapping(pd.DataFrame(fr),pd.DataFrame(cats),pd.DataFrame(aps),pd.DataFrame(columns=['value','decision_event_id']),temp)
  ck('same_parent_not_automatically_merged',maps.reconstructed_action_unit_id.nunique()==2)
  ck('source_structure_not_silently_author_approved',maps.approved_action_unit_id.eq('').all())
 jsonout(out/'boundary_tests.json',dict(passed=True,checks=checks));return checks

def generate(ctx,out,paths,numbering,source_hashes):
 started=time.perf_counter();out.mkdir(parents=True,exist_ok=True)
 frame=read(paths['matrix']);pred=read(paths['predictions']);cat=read(paths['corpus']);lock=load(paths['model_lock']);approved=read(paths['approved_mapping']);dec=read(paths['decisions']);action=read(paths['approved_shares'])
 require(len(frame)==32858 and frame.policy_id.nunique()==68,'Frozen corpus size changed');require(sha(paths['model'])==lock['model_sha256'],'Frozen model changed');jsonout(out/'frozen_model_lock.json',lock)
 csvout(out/'input_hashes.csv',[dict(input=k,path=str(p),sha256=sha(p)) for k,p in paths.items()]);jsonout(out/'figure_contract.json',dict(core_claim='High machine-positive frequency can coexist with low developmental precision; six unqualified heads retain conditional identity',evidence='Ten locked head diagnostics; no new validation',archetype='quantitative matrix',backend='Python matplotlib consistent with existing project',final_width_mm=183,exports=['svg','pdf','png_600dpi'],not_a_probability_or_CI_plot=True))
 metrics,t2=model_diagnostics(paths,frame,pred,lock,out);print('MODEL_REPLAY_VERIFIED',flush=True)
 replay=reproduce_binary_layer(frame,pred,paths['evidence'],out);counts=evidence_classification(paths['evidence'],out,'frozen conditional use protocol');require(counts['existing_fields']==22440 and counts['machine_fields']==306140,'Field identity counts changed')
 # Primary table: B unknown for any model T2, never write the C=0 or D=1 assumption into it.
 evidence_t2=pd.read_csv(paths['evidence'],usecols=['unit_id','field','status'],dtype=str,keep_default_na=False);machine_t2=set(evidence_t2.loc[evidence_t2.field.eq('T2')&evidence_t2.status.eq('MACHINE_PREDICTED_AUTHOR_ADOPTED'),'unit_id']);unknown=frame.unit_id.isin(machine_t2)
 primary=frame.copy();primary['T2_LEGACY_DIAGNOSTIC']=frame.C2_T2;primary['T2_usage_status']=np.where(unknown,'UNQUALIFIED_MACHINE_T2','PRESERVED_EXISTING_EVIDENCE');primary.loc[unknown,'C2_T2']='';primary['record_binary_complete_primary']=~unknown;primary['record_validated']=frame.record_verified_10;primary['validation_status']=np.where(frame.machine_field_n.astype(int).gt(0),'NOT_INDEPENDENTLY_VALIDATED','EXISTING_EVIDENCE_NOT_DOUBLE_CODING_CERTIFICATE');csvout(out/'C2_conditional_evidence.csv',primary)
 for k in LABELS:
  if k!='T2':require(primary['C2_'+k].equals(frame['C2_'+k]),'Non-T2 label changed')
 observed=pd.read_csv(paths['evidence'],usecols=['unit_id','field','value','evidence_source'],dtype=str,keep_default_na=False);observed=observed[observed.evidence_source.eq('EXISTING_EFFECTIVE_EVIDENCE')];pi=primary.set_index('unit_id')
 for k,z in observed.groupby('field'):require(pi.loc[z.unit_id,'C2_'+k].to_numpy().tolist()==z.value.tolist(),'Existing values changed in primary table')
 jsonout(out/'field_preservation_QA.json',dict(existing_22440_values_preserved=True,observed_fields=len(observed),machine_T2_unknown_not_zero=int(primary.C2_T2.eq('').sum()),legacy_model_values_reproduced=replay))
 vals=[];pranges=[];details=[]
 for scope in ['INCLUDE_ALL','EXCLUDE_SOURCE_UNRESOLVED']:
  p,r,d=policy_scenarios(frame,unknown,scope);vals.append(p);pranges.append(r);details.append(d)
 policy=pd.concat(vals,ignore_index=True);pranges=pd.concat(pranges,ignore_index=True);details=pd.concat(details,ignore_index=True);csvout(out/'policy_scenario_tool_composition.csv',policy);csvout(out/'policy_tool_composition_ranges.csv',pranges);csvout(out/'T2_conditional_sensitivity.csv',details)
 stage,sranges,stability=stage_tables(policy);csvout(out/'stage_scenario_tool_composition.csv',stage);csvout(out/'stage_tool_composition_ranges.csv',sranges);csvout(out/'stage_comparison_sensitivity.csv',stability)
 mapping=source_mapping(frame,cat,approved,dec,out);comparison=unit_comparisons(frame,mapping,policy,action,out);zeros=zero_group_diagnostics(frame,cat,out)
 # Full all-label source include/exclude shares, prevalence and equal-unit sensitivity.
 source_results=[]
 for (pid,scope),z in details.groupby(['policy_id','source_scope'],sort=False):
  f=frame[frame.policy_id.eq(pid)];f=f if scope=='INCLUDE_ALL' else f[f.source_scope_verified.eq('True')];pos=f[f.C2_eligibility.eq('1')]
  for group,ks in [('G',G),('T',T)]:
   x=pos[['C2_'+k for k in ks]].astype(int);den=int(x.to_numpy().sum());nz=x.sum(axis=1).gt(0)
   for k in ks:source_results.append(dict(policy_id=pid,stage=frame.loc[frame.policy_id.eq(pid),'stage'].iloc[0],source_scope=scope,group=group,label=k,eligible_units=len(pos),denominator=den,share=ratio(int(x['C2_'+k].sum()),den),unit_prevalence=float(x['C2_'+k].mean()) if len(x) else np.nan,equal_unit_weight_sensitivity=float(x.loc[nz,'C2_'+k].div(x.loc[nz].sum(axis=1)).mean()) if nz.any() else np.nan,identity='SOURCE_UNIT_PROXY_A_LEGACY;MODEL_CONDITIONAL'))
 csvout(out/'source_scope_conditional_shares.csv',source_results)
 srcdist=frame.assign(unresolved=frame.source_scope_verified.ne('True')).groupby(['policy_id','stage']).agg(source_units=('unit_id','size'),unresolved_units=('unresolved','sum')).reset_index();csvout(out/'source_scope_distribution.csv',srcdist)
 build_tables(out,metrics,counts,details,comparison);plot_quality(out,metrics,numbering['figure']);boundary_tests(out)
 # Snapshot records preserve old audit failure and its family control unchanged.
 for k,a in ctx.audit_events():
  q=load(a/'audit_result.json');q['event']=k
  csvout(out/('old_audit_'+digest(k)[:10]+'.csv'),[q])
 auditpath=paths['matrix'].parent/'Table_S7C_audit_status.csv';shutil.copyfile(auditpath,out/'Table_S7C_old_failed_pools.csv')
 status=dict(COMPUTATION_REPRODUCIBLE=False,MODEL_CONDITIONAL_CODING_READY=False,RESEARCH_USE_QUALITY_SUPPORTED=False,PART1_COMPLETED=False,version=VERSION,T2_status='T2_IMPLEMENTATION_VALID_BUT_CLASSIFICATION_UNRELIABLE',primary_T2_usage='B_UNKNOWN_PRIMARY',T2_unknown_fields=int(unknown.sum()),legacy_binary_A_preserved=True,C_D_are_assumptions_not_labels=True,model_retrained=False,threshold_changed=False,new_sampling=False,reference600_49_used_for_new_selection=False,part2_started=False,field_identity_counts=counts,legacy_binary_replay=replay,source_unresolved_units=int(srcdist.unresolved_units.sum()),source_affected_policies=int(srcdist.unresolved_units.gt(0).sum()),approved_action_policy_groups=int(action.measurement_ready.eq('True').sum()),structural_candidates_unapproved=int(mapping.measurement_identity.eq('SOURCE_STRUCTURAL_CANDIDATE_NOT_APPROVED').sum()),eligible_G_zero=int(sum(v for (g,o),v in zeros.items() if g=='G')),eligible_T_zero=int(sum(v for (g,o),v in zeros.items() if g=='T')))
 jsonout(out/'PART1_EXECUTION_STATUS.json',status)
 # Fresh process independently reconstructs policy/phase ratios from the saved primary table.
 result=subprocess.run([sys.executable,str(Path(__file__).resolve()),'--verify-output',str(out)],capture_output=True,text=True,encoding='utf-8');(out/'replay_stdout.log').write_text(result.stdout,'utf-8');(out/'replay_stderr.log').write_text(result.stderr,'utf-8');require(result.returncode==0,'Independent numeric replay failed: '+result.stderr)
 independent=load(out/'independent_numeric_replay.json');require(independent['passed'],'Independent replay did not pass')
 qa=[('EXISTING_22440_FIELDS_PRESERVED','field_preservation_QA.json'),('LEGACY_306140_MACHINE_FIELDS_REPRODUCED','field_preservation_QA.json'),('174690_GATE_ZEROS_SHARE_19410_PARENTS','field_reliability_identity_counts.csv'),('T2_HEAD_THRESHOLD_CLASSES_AND_SCORES_MATCH','T2_anomaly_diagnostics.csv'),('T2_UNKNOWN_NOT_ZERO_AND_RANGES_REPLAYED','independent_numeric_replay.json'),('T2_DOES_NOT_ALTER_G_FIELDS_OR_SHARES','independent_numeric_replay.json'),('PROXY_AND_APPROVED_ACTION_DENOMINATORS_SEPARATE','policy_measurement_unit_comparison.csv'),('UNAPPROVED_CANDIDATES_NOT_APPROVED_ACTIONS','source_unit_to_action_mapping.csv'),('NO_ELIGIBLE_ZERO_DENOMINATOR_SOURCE_EXCLUSION_HANDLED','boundary_tests.json'),('OLD_AUDITS_AND_REFERENCE_IDENTITIES_PRESERVED','input_hashes.csv'),('NO_FIT_OR_NEW_THRESHOLD_SELECTION','T2_anomaly_diagnostics.csv'),('COMPUTATION_DOES_NOT_GRANT_RESEARCH_QUALITY','PART1_EXECUTION_STATUS.json')]
 csvout(out/'necessary_QA.csv',[dict(check=n,passed=True,evidence=e,scope='NUMERICAL_IMPLEMENTATION_OR_PROVENANCE;NOT_SEMANTIC_ACCURACY') for n,e in qa])
 status.update(COMPUTATION_REPRODUCIBLE=True,MODEL_CONDITIONAL_CODING_READY=True,elapsed_seconds=time.perf_counter()-started);jsonout(out/'PART1_EXECUTION_STATUS.json',status)
 write_decision_documents(ctx,out,paths,status,stability,mapping,numbering)
 # Never mutate legacy files, models, audits, raw labels or numerical parameter settings.
 for p,h in source_hashes.items():require(sha(Path(p))==h,'Frozen source changed during execution: '+p)
 jsonout(out/'output_manifest.json',dict(version=VERSION,inputs_sha256=source_hashes,code_sha256=sha(Path(__file__).resolve()),files={k:v for k,v in filelist(out).items() if k!='output_manifest.json'},no_fit=True,no_SD=True))
 print(json.dumps(status,ensure_ascii=False),flush=True)

def write_decision_documents(ctx,out,paths,status,stability,mapping,numbering):
 maxchange=float(stability.T2_D_minus_C.abs().max());unstable=stability[~stability.other_tool_order_stable]
 quality=[dict(issue='T2_CLASSIFICATION',status='IMPLEMENTATION_VALID_CLASSIFICATION_UNRELIABLE',evidence='Frozen head/score/threshold and OOF replay; no feasible prior developmental cutpoint',research_use_supported=False),dict(issue='NEGATIVE_ELIGIBILITY_GATE',status='UNVALIDATED_SHARED_PARENT',evidence='174690 G/T zeros share 19410 model-negative parents, nine children each',research_use_supported=False),dict(issue='OTHER_UNQUALIFIED_HEADS',status='RETAINED_MODEL_CONDITIONAL',evidence='G3/T1/T3/T4/T6 developmental failures preserved',research_use_supported=False),dict(issue='SOURCE_SCOPE',status='INCLUDE_EXCLUDE_SENSITIVITY_REPORTED',evidence=f"{status['source_unresolved_units']} units in {status['source_affected_policies']} policies",research_use_supported=False),dict(issue='MEASUREMENT_UNIT',status='PROXY_AND_APPROVED_ACTION_SEPARATE',evidence=f"{status['approved_action_policy_groups']} complete approved policy groups; reconstruction candidates do not extend signed scopes",research_use_supported=False),dict(issue='COMPUTATION',status='FROZEN_MODEL_REPLAY_AND_INDEPENDENT_ARITHMETIC_PASSED',evidence='No training, no threshold search, no reference600/49 selection, all human values preserved',research_use_supported='IMPLEMENTATION_ONLY')]
 csvout(out/'coding_quality_and_limitations.csv',quality)
 (out/'coding_use_protocol_revision.md').write_text('''# 编码使用协议补充

1. 开发模型质量：原precision/recall/specificity、支持数与政策覆盖要求及全部失败保持不变。这些是原开发资格要求，不是生成条件性结果的通用禁令。
2. 条件性机器编码：保留冻结二元A结果。开发可用机器建议、未达标诊断建议、机器负门控零分别标识；均不获得独立验证身份。主证据表对全部机器T2保持未知，C/D只为敏感性极端情形，不写入正式0/1。
3. 研究主结果质量：需测量对象、来源/计数一致性、实质独立证据及政策/阶段组成稳定性共同支持。目前RESEARCH_USE_QUALITY_SUPPORTED=false。
4. 不要求每机器字段重读、全头通过才生成条件性组成、每政策每类别各自±0.05概率区间或每源单元逐条签署才计算代理。0.05不是本轮新质量硬关口。签署/附录/页面变化不触发训练。
5. 原三池仍失败，family_alpha=.05、planned_claims=6、risk=.10不变。不追加抽样，不利用600/49调整阈值或声称新盲测。
6. 计量对象分别为SOURCE_TEXT_UNIT_PROXY、APPROVED_ACTION_UNIT。结构恢复候选有实际原文区间、编号及稳定ID，但未扩展已有精确批准范围，故不静默计入批准行动估计。
7. 模型条件性编码可以交付，原PART1_COMPLETED不由计算与字段齐全自动通过；第二部分关闭。
''','utf-8')
 decision=f'''# B1 V1.2 编码基准判定

当前版本：{VERSION}

COMPUTATION_REPRODUCIBLE=true：固定模型全10头重新评分、原328580字段二元A复现、22440既有字段保留、独立进程政策/阶段算术核验已实际执行。
MODEL_CONDITIONAL_CODING_READY=true：A原结果、B未知主证据及C/D敏感性、来源包含/排除、代理与批准行动均明确记录。
RESEARCH_USE_QUALITY_SUPPORTED=false；PART1_COMPLETED=false。没有把方法身份变化写成质量通过。

T2实现未检出索引/类别顺序/阈值读取/门控转换错误，分类质量仍不可靠。既有OOF没有满足原要求的T2切点，未再搜索或提出新阈值。原T2仅作为T2_LEGACY_DIAGNOSTIC保留，机器T2在主表未知。

同一共同政策支持下T2阶段份额D−C最大为{maxchange:.6f}；其他工具排序不稳定的阶段/来源组合有{len(unstable)}项，详见stage_comparison_sensitivity.csv。范围只是模型条件性敏感性，不是概率区间或置信区间。

真实来源范围未决仍为2018单元/26政策；未用G/T反推确认。结构恢复生成{status['structural_candidates_unapproved']}条未批准候选，不按共享parent、相似标签或相似文本直接合并。完整批准行动计量仍只有两政策四组，局部一致不能外推66政策。其余范围可继续用源单元代理作为明确受限的条件性基准。

目前不需要为本轮计算新增人审。若要把它升级为论文正式政策组成主结果，仍需研究使用范围对应的独立质量证据，优先针对负门控遗漏、T2误纳、弱头和源单元/行动对应设计有限独立核查；不能预设几十条足以验证全68政策。本轮未自动生成或实施新抽样，未要求重审既有任何样本。

Figure {numbering['figure']}与Table {numbering['sensitivity_table']}在原附录及当前交付中未被占用。Table S7采用新快照分节更新；Figure S6保持原文件和冻结训练结果，不宣称新训练。
'''
 (out/'B1_V1.2_CODING_BASELINE_DECISION.md').write_text(decision,'utf-8')
 (out/'PATCHLOG.md').write_text('''# 本轮补丁与方法变化

- 实现/来源状态修复：新增六类字段可靠性身份、父预测共享零标识、独立validation_status；原二元值始终在legacy层保留。
- 方法使用修订：主证据表机器T2设为未知；冻结A与C/D假设结果分开。未改模型、阈值或真实人工值。
- 统计对象澄清：源文本单元代理与批准行动分别使用各自分母；结构候选不自动获得批准身份。阶段比较明确共同支持与未定义政策。
- 诊断新增：T2真实冻结模型全头重评分/OOF复核、旧无可行切点审计、来源包含/排除、组全零与行动身份例外。
- 复算解析修复：使用Python float精确往返读取冻结阈值附近的OOF分数，保留>=等号约定，避免通用数值解析器截断小数导致一个边界阳性变化；阈值本身未改。
- 质量门槛作用澄清：旧开发标准仅保留其原开发含义，不能阻止受限条件性输出；不将失败改PASS，不改原三池标准。
- 附录：S7状态/来源与失败诊断、S8条件性敏感性及计量口径比较、S7质量矩阵图。原稿及旧结果不覆盖。
''','utf-8')
 (out/'README.md').write_text('''# 条件性编码修复快照

先读B1_V1.2_CODING_BASELINE_DECISION.md与PART1_EXECUTION_STATUS.json。
主表C2_conditional_evidence.csv中的机器T2为空（未知），T2_LEGACY_DIAGNOSTIC保留原二元值。原306140机器字段及32858记录可以复现；未知不是程序漏填。
policy_scenario_tool_composition.csv包含68政策×2来源范围×A/B/C/D×6工具。policy_tool_composition_ranges.csv及stage_tool_composition_ranges.csv是条件性范围，非置信区间。stage_scenario_tool_composition.csv同时保存各规格有定义政策均值和共同支持均值，不能忽略其覆盖列。
source_unit_to_action_mapping.csv保留全部原ID、真实字符区间、批准ID及未批准结构候选；action_reconstruction_exceptions.csv是后台例外账本，不是11797条统一人工任务。
APPROVED_ACTION只对完整批准范围出份额；不归一部分覆盖后冒充整篇。来源排除对照是测量范围敏感性，不证明排除就更正确。
复算使用现有项目/环境，未宣称单文件能从零训练模型。RUN_FULL_REPLAY.ps1要求一个全新输出目录；VERIFY.ps1只独立重算保存的政策与阶段敏感性。
''','utf-8')
 # Relative artifact members and hashes; root pointer gets snapshot_directory after atomic commit.
 current=dict(version=VERSION,baseline_identity='MODEL_CONDITIONAL_CODING_WITH_MACHINE_T2_UNKNOWN',research_use_scope='Model-conditional reconstruction and sensitivity; not validated main-paper action composition',relative_paths={'primary_evidence':'C2_conditional_evidence.csv','field_evidence':'C2_field_evidence_classified.csv.gz','T2_sensitivity':'T2_conditional_sensitivity.csv','policy_ranges':'policy_tool_composition_ranges.csv','approved_vs_proxy':'policy_measurement_unit_comparison.csv'},file_hashes={n:sha(out/n) for n in ['C2_conditional_evidence.csv','C2_field_evidence_classified.csv.gz','T2_conditional_sensitivity.csv','policy_tool_composition_ranges.csv','policy_measurement_unit_comparison.csv']},legacy_binary_A={'workspace_relative_path':str(paths['matrix'].relative_to(ctx.workspace)),'sha256':sha(paths['matrix']),'identity':'FROZEN_HISTORICAL_MODEL_CONDITIONAL_A'},states={k:status[k] for k in ['COMPUTATION_REPRODUCIBLE','MODEL_CONDITIONAL_CODING_READY','RESEARCH_USE_QUALITY_SUPPORTED','PART1_COMPLETED']},path_resolution='Relative members resolved against snapshot_directory; legacy paths against workspace',part2_started=False)
 jsonout(out/'UPDATED_C2_CURRENT.json',current)
 python=ctx.workspace/'.venv/Scripts/python.exe';module=Path(__file__).resolve();registry=ctx.root/'coding_baseline_repair_inputs_20261028.json'
 (out/'RUN_FULL_REPLAY.ps1').write_text(f"param([Parameter(Mandatory=$true)][string]$ReplayOutput)\n& '{python}' '{module}' --workspace '{ctx.workspace}' --run-id '{ctx.root.name}' --inputs '{registry}' --replay-output $ReplayOutput\nif($LASTEXITCODE -ne 0){{throw 'Fixed-model replay failed'}}\n",'utf-8-sig')
 (out/'VERIFY.ps1').write_text(f"$snapshot=Split-Path -Parent $PSCommandPath\n& '{python}' '{module}' --verify-output $snapshot\nif($LASTEXITCODE -ne 0){{throw 'Numeric replay failed'}}\n",'utf-8-sig')
 import importlib.metadata,platform
 jsonout(out/'environment.json',dict(python=platform.python_version(),packages={n:importlib.metadata.version(n) for n in ['numpy','pandas','scikit-learn','scipy','joblib','matplotlib']},runtime=str(sys.executable)))
 shutil.copyfile(Path(__file__),out/'coding_baseline_repair.py')


def make_registry(ctx):
 registry=ctx.root/'coding_baseline_repair_inputs_20261028.json'
 if registry.exists():return registry,load(registry)
 paths=input_paths(ctx);original=ctx.root/'C2_CURRENT.json';history=ctx.root/'C2_mapping_history';history.mkdir(exist_ok=True);old=history/(sha(original)+'.json')
 if not old.exists():shutil.copyfile(original,old)
 paths['previous_current_mapping']=old
 source_files=list(paths.values())
 cat=read(paths['corpus']);source_files+=list(map(longpath,cat.source_clean_path.unique()))
 for _,a in ctx.audit_events():source_files += [p for p in a.iterdir() if p.is_file()]
 source_files += [ctx.input(k) for k in ctx.cfg['inputs'] if ctx.input(k).is_file()]
 hashes={str(p):sha(p) for p in source_files}
 # Numbering checks are frozen before any new figure/table export.
 import zipfile,xml.etree.ElementTree as ET
 with zipfile.ZipFile(paths['supplement']) as z:
  root=ET.fromstring(z.read('word/document.xml'));text=' '.join(e.text or '' for e in root.findall('.//{http://schemas.openxmlformats.org/wordprocessingml/2006/main}t'))
 existing_fig=set(int(x) for x in re.findall(r'(?:Figure|Fig[.]?)\s*S(\d+)',text));existing_tab=set(int(x) for x in re.findall(r'Table\s*S(\d+)',text))
 for p in (ctx.root/'part1_delivery').rglob('*'):
  if p.is_file():
   existing_fig.update(int(x) for x in re.findall(r'Figure[_ ]?S(\d+)',p.name));existing_tab.update(int(x) for x in re.findall(r'Table[_ ]?S(\d+)',p.name))
 figure=7
 while figure in existing_fig:figure+=1
 table=8
 while table in existing_tab:table+=1
 data=dict(version=VERSION,paths={k:str(p.relative_to(ctx.workspace)) for k,p in paths.items()},frozen_sha256=hashes,numbering=dict(figure='S'+str(figure),sensitivity_table='S'+str(table),status_table='S7',existing_figures=sorted(existing_fig),existing_tables=sorted(existing_tab)),previous_mapping_sha256=sha(old),identity='FROZEN_INPUTS_NO_NEW_LABELS_NO_TRAINING')
 jsonout(registry,data);return registry,data


def main():
 p=argparse.ArgumentParser();p.add_argument('--workspace');p.add_argument('--run-id',default='part1_completion_20261027');p.add_argument('--inputs');p.add_argument('--replay-output');p.add_argument('--verify-output');a=p.parse_args()
 if a.verify_output:print(json.dumps(verify_output(a.verify_output),ensure_ascii=False));return
 require(bool(a.workspace),'Workspace required');ctx=Context(a.workspace,a.run_id)
 registry,data=(longpath(a.inputs),load(a.inputs)) if a.inputs else make_registry(ctx)
 paths={k:ctx.workspace/v for k,v in data['paths'].items()};hashes=data['frozen_sha256']
 for pp,h in hashes.items():require(sha(Path(pp))==h,'Frozen input no longer matches: '+pp)
 if a.replay_output:
  out=longpath(a.replay_output);require(not out.exists(),'Preserve existing snapshot; choose a new replay directory');generate(ctx,out,paths,data['numbering'],hashes);print(str(out));return
 key='coding-baseline:'+digest([data,sha(Path(__file__))])[:20]
 result=ctx.stage(key,[],list(map(Path,hashes))+[Path(__file__),registry],lambda out:generate(ctx,out,paths,data['numbering'],hashes))
 require(result['state']=='COMPLETED',result.get('message','Baseline execution failed'));out=ctx.root/result['artifact'];current=load(out/'UPDATED_C2_CURRENT.json');current['snapshot_directory']=str(out.relative_to(ctx.workspace));current['history_mapping_sha256']=data['previous_mapping_sha256']
 prior_current=ctx.root/'C2_CURRENT.json'
 if prior_current.exists():
  history=ctx.root/'C2_mapping_history';history.mkdir(exist_ok=True);saved=history/(sha(prior_current)+'.json')
  if not saved.exists():shutil.copyfile(prior_current,saved)
 jsonout(ctx.root/'C2_CURRENT.json',current)
 latest=load(ctx.root/'latest_artifacts.json');latest.update(C2_current=str(ctx.root/'C2_CURRENT.json'),conditional_coding_baseline=str(out),status='MODEL_CONDITIONAL_CODING_READY_RESEARCH_USE_QUALITY_UNSUPPORTED',current_result=str(out/'B1_V1.2_CODING_BASELINE_DECISION.md'));jsonout(ctx.root/'latest_artifacts.json',latest)
 (ctx.root/'part1_delivery/LATEST_CODING_BASELINE.md').write_text('# 当前条件性基准\n\n'+str(out)+'\n\n'+(out/'B1_V1.2_CODING_BASELINE_DECISION.md').read_text('utf-8'),'utf-8')
 print(json.dumps(dict(snapshot=str(out),stage=result,states=current['states']),ensure_ascii=False))

if __name__=='__main__':main()
