"""One actual author return -> existing inboxes. Does not fabricate approval or labels."""
from common import *
from review_registry import scope_binding

def confirmed_rule_note(task):
 note=task.get('notes','').strip()
 if note or task.get('value')!='CONFIRM':return note
 if task['type']=='EXACT_POOL_PROTOCOL':return 'EXPLICIT_CONFIRM_OF_REGISTERED_EXACT_POOL_PROTOCOL; NO_FREE_TEXT_REASON_SUPPLIED'
 if task['type'] in ['COUNTING_APPROVAL','GROUP_APPROVAL'] and task.get('selected_scope_ids'):
  return 'EXPLICIT_CONFIRM_OF_SELECTED_REGISTERED_SCOPE_AND_RULE; NO_FREE_TEXT_REASON_SUPPLIED'
 return ''

def validate_return(returned,registered):
 require(returned.get('statement')=='ACTUAL_REPAIRED_TASK_RETURN_NOT_FINAL_C2_APPROVAL','Wrong return identity')
 require(returned.get('reviewer') and returned.get('signed_at'),'Actual reviewer/time required')
 datetime.fromisoformat(returned['signed_at'])
 index={t['task_id']:t for t in registered['tasks']};seen=set();valid=[]
 for row in returned['tasks']:
  tid=row['task_id'];require(tid in index and tid not in seen,'Unknown/duplicate task');seen.add(tid)
  original=index[tid]
  for k,v in original.items():
   if k!='value':require(row.get(k)==v,'Protected scope/evidence changed: '+k)
  require(row.get('value','') in ['','CONFIRM','REJECT','UNRESOLVED'],'Unknown decision')
  if original.get('type') in ['COUNTING_APPROVAL','GROUP_APPROVAL']:
   allowed={m.get('group_id',m.get('decision_id')) for m in original['members']};chosen=row.get('selected_scope_ids',[])
   require(isinstance(chosen,list) and len(chosen)==len(set(chosen)) and set(chosen)<=allowed,'Unknown/duplicate selected subgroup')
  if row.get('value'):valid.append(row)
 return valid

def ingest(ctx,review,registered):
 returned=load(review);template=load(registered);tasks=validate_return(returned,template)
 base=ctx.root/'actual_minimal_returns'/sha(review)[:20];base.mkdir(parents=True,exist_ok=True)
 shutil.copyfile(review,base/'actual_return.json');shutil.copyfile(registered,base/'registered_tasks.json')
 cat=read(ctx.artifact('prepare')/'corpus.csv');decisions=[];pending=[];pools=[]
 for task in tasks:
  typ=task['type'];value=task['value'];note=confirmed_rule_note(task)
  if value=='CONFIRM' and not note:
   pending.append(dict(task_id=task['task_id'],reason='Concrete scope interpretation/check required; blank explanation not approval'));continue
  if typ=='REPAIRED_SCOPE_REVIEW':
   for member in task['members']:
    # Reading approval alone cannot resolve semantics/action identity of fragmented units.
    if member['root_cause']=='READING_CONTEXT_NOT_ACTION_BOUNDARY':
     pending.append(dict(task_id=task['task_id'],issue_id=member['issue_id'],reason='Reading-context decision preserved; no label or action-boundary clearance',actual_decision=value));continue
    ids=json.loads(member['unit_ids']);kind='SEMANTIC_RULE' if member['issue_id'].startswith('RULE_') else 'SOURCE_VERSION'
    decisions.append(dict(decision_id=member['issue_id'],type=kind,unit_ids=json.dumps(ids),value=value,rule_text=note+'; REPAIRED_EVIDENCE_HASH='+task['scope_hash'],action_unit_id='',representative_id='',scope_sha256=digest(sorted(ids)),source_binding=scope_binding(cat,ids)))
  elif typ=='COUNTING_APPROVAL':
   selected=set(task.get('selected_scope_ids',[]))
   if not selected:pending.append(dict(task_id=task['task_id'],reason='No exact counting scope selected'))
   for member in task['members']:
    if member['decision_id'] in selected:decisions.append(dict(member,value=value,rule_text=member['rule_text']+'; '+note))
  elif typ=='GROUP_APPROVAL':
   selected=set(task.get('selected_scope_ids',[]));g=pd.DataFrame(task['members']);g=g[g.group_id.isin(selected)]
   if not len(g):pending.append(dict(task_id=task['task_id'],reason='No exact equivalence group selected'))
   for gid,z in g.groupby('group_id'):
    ids=sorted(z.unit_id);rep=z.iloc[0].possible_human_representative
    decisions.append(dict(decision_id='MINIMAL_'+gid,type='EXACT_GROUP_SCOPE',unit_ids=json.dumps(ids),value=value,rule_text=note,action_unit_id='',representative_id=rep,scope_sha256=digest(ids),source_binding=scope_binding(cat,ids)))
  elif typ=='EXACT_POOL_PROTOCOL':
   if value=='CONFIRM':pools.append(task)
   else:pending.append(dict(task_id=task['task_id'],reason='Pool not approved',actual_decision=value))
 if decisions:
  q=base/'decisions.csv';csvout(q,decisions);sig=base/'signature.json'
  jsonout(sig,dict(identity=ctx.identity,statement='APPROVE_SCOPED_CODING_DECISIONS',reviewer=returned['reviewer'],signed_at=returned['signed_at'],decisions_sha256=sha(q),actual_return_sha256=sha(review),signature_origin='TRANSLATED_EXPLICIT_TASK_RETURN_NOT_INVENTED_ROW_SIGNATURE'))
  inbox=ctx.root/'inbox/decisions';inbox.mkdir(exist_ok=True);jsonout(inbox/('minimal_'+sha(review)[:20]+'.json'),dict(decisions=str(q),signature=str(sig)))
 # Queue exact approvals. Existing plan regenerates/checks hashes before sampling;
 # a new source decision/model invalidates old member bindings rather than transferring approval.
 for task in pools:
  proto=task['members'][0];pid=proto['pool_id'];plan=longpath(task['plan_artifact'])
  require(sha(plan/'protocol.json')==task['protocol_sha256'],'Registered protocol changed')
  ap=base/(pid+'_approval.json');jsonout(ap,dict(identity=ctx.identity,statement='APPROVE_EXACT_LOCAL_POOL_PROTOCOL',reviewer=returned['reviewer'],signed_at=returned['signed_at'],protocol_sha256=task['protocol_sha256'],actual_return_sha256=sha(review)))
  jsonout(ctx.root/'inbox/pools'/(pid+'.json'),dict(pool_id=pid,input=str(plan/'original_definition.json'),approval=str(ap),protocol_sha256=task['protocol_sha256']))
 csvout(base/'pending_tasks.csv',pending,columns=None if pending else ['task_id','reason'])
 report=dict(actual_tasks=len(tasks),scoped_decisions_queued=len(decisions),exact_pool_approvals_queued=len(pools),pending=len(pending),no_human_labels_created=True,no_final_C2_approval=True,archive=str(base))
 jsonout(base/'import_receipt.json',report);return report

if __name__=='__main__':
 import argparse
 p=argparse.ArgumentParser();p.add_argument('--workspace',required=True);p.add_argument('--run-id',required=True);p.add_argument('--review',required=True);p.add_argument('--registered',required=True);a=p.parse_args()
 print(json.dumps(ingest(Context(a.workspace,a.run_id),Path(a.review),Path(a.registered)),ensure_ascii=False))
