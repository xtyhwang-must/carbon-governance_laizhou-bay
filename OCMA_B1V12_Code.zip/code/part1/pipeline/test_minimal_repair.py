"""Real artifact invariants and separately labelled synthetic negative tests."""
from common import *
from train_limited import threshold_status,threshold_outputs,fit_heads
from share_quality import evidence_quality_gate
from part1_completion import acceptance_flags
import importlib.util
from unittest.mock import patch
from scipy.sparse import csr_matrix

def run(ctx,out):
 snapshot=ctx.root/'minimal_patch_snapshot_20261027';oldm=load(snapshot/'stage_manifest.json');checks=[]
 def ck(name,passed,kind='REAL_DATA_QA'):
  checks.append(dict(check=name,passed=bool(passed),identity=kind));require(passed,name)
 prep=ctx.artifact('prepare');reg=ctx.artifact('build-registry');tr=ctx.artifact('train');ass=ctx.artifact('assemble-candidate');pred=read(ctx.artifact('predict')/'corpus_predictions.csv');oldreg=ctx.root/oldm['stages']['build-registry']['artifact'];oldtr=ctx.root/oldm['stages']['train']['artifact'];oldprep=ctx.root/oldm['stages']['prepare']['artifact']
 ck('model_bytes_unchanged',sha(tr/'diagnostic_model.joblib')==sha(oldtr/'diagnostic_model.joblib'))
 ck('original_training_artifact_reused',tr==oldtr)
 ck('training_signature_unchanged',sha(reg/'training_signature.json')==sha(oldreg/'training_signature.json'))
 ck('all_real_human_events_unchanged',sha(reg/'human_registry_events.csv')==sha(oldreg/'human_registry_events.csv'))
 ck('reference_ids_unchanged',sha(prep/'reference_ids.csv')==sha(oldprep/'reference_ids.csv'))
 ck('original_corpus_bytes_unchanged',sha(prep/'corpus.csv')==sha(oldprep/'corpus.csv'))
 ck('no_automatic_formal_predictions',all(pred['formal_C2_'+k].eq('').all() for k in LABELS))
 lock=load(tr/'model_lock.json')
 for k in LABELS:
  if lock['contracts'][k]['usable_threshold'] is None:ck('unqualified_head_abstains_'+k,pred['usable_raw_'+k].eq('').all())
 c=read(ass/'C2_candidate.csv').set_index('unit_id');h=read(reg/'human_field_evidence.csv');pp=pred.set_index('unit_id');counter=0
 for r in h[h.field.eq('eligibility')&h.value.eq('1')].itertuples():
  if pp.loc[r.unit_id,'diagnostic_raw_eligibility']=='0.0':
   counter+=1;require(c.loc[r.unit_id,'C2_eligibility']=='1','Machine overwrote human eligibility')
 ck('human_eligible_not_overwritten_by_machine_negative',counter>0)
 ck('pending_scope_not_coerced_to_negative',c[c.source_rule_resolved.eq('False')].complete.eq('False').all())
 ck('unresolved_fields_remain_blank',all(c.loc[c['status_'+k].eq('UNRESOLVED'),'C2_'+k].eq('').all() for k in LABELS))
 # Per-cut equality on all frozen DEVELOPMENT score grids, never reference/heldout.
 spec=importlib.util.spec_from_file_location('frozen_threshold_impl',snapshot/'code/train_limited.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
 o=read(tr/'OOF_scores.csv');contract=load(prep/'training_contract.json');n=0
 for (model,C),g in o.groupby(['spec','C']):
  for j,k in enumerate(LABELS):
   z=g if j==0 or model=='H-ALLDOMAIN' else g[g.human_eligibility.eq('1')]
   args=(z['human_'+k].astype(int).to_numpy(),z['score_'+k].replace('',np.nan).astype(float).to_numpy(),k,z.policy_id.to_numpy(),contract)
   current=threshold_status(*args);frozen=mod.threshold_status(*args)
   require(current==frozen,'Threshold or per-cut metric changed');n+=len(current[1])
 ck('all_development_cut_metrics_and_ties_identical',n>0)
 # Explicit tie/NaN negative fixture and impossible usable threshold.
 y=np.array([1,0,1,0]);score=np.array([.5,.5,np.nan,.2]);pol=np.array(['a','b','c','d']);ck('ties_nan_greater_equal_unchanged',threshold_status(y,score,'G1',pol,contract)==mod.threshold_status(y,score,'G1',pol,contract),'SYNTHETIC_TEST_ONLY')
 raw,hard=threshold_outputs(np.ones((2,10)),{k:dict(usable_threshold=None,diagnostic_threshold=.5) for k in LABELS},True)
 ck('diagnostic_threshold_cannot_grant_usable_output',np.isnan(raw).all() and np.isnan(hard).all(),'SYNTHETIC_TEST_ONLY')
 fields=pd.DataFrame([dict(unit_id='x',field=k,value='0',status='HUMAN_ADJUDICATED',evidence_id=k) for k in LABELS]);review=dict(residual_error_actions='0',review_findings='budget only',evidence_ids='eligibility')
 ck('zero_declared_error_cannot_pass_quality',not evidence_quality_gate(fields,{'x'},review)[0],'SYNTHETIC_TEST_ONLY')
 review.update(omission_check='documented',rare_label_check='documented',small_denominator_check='documented',observed_error_check='documented')
 ck('actual_complete_fields_plus_checks_distinct_from_budget',evidence_quality_gate(fields,{'x'},review)[0],'SYNTHETIC_TEST_ONLY')
 fields.loc[0,'status']='AUTO_ACCEPTED_UNDER_VALIDATED_PROTOCOL';ck('unvalidated_auto_field_cannot_pass',not evidence_quality_gate(fields,{'x'},review)[0],'SYNTHETIC_TEST_ONLY')
 X=csr_matrix([[0.,1.],[1.,0.],[1.,1.],[0.,0.]])
 score,models,audit=fit_heads(X,X,np.zeros((4,10),int),'H-ALLDOMAIN',1,4)
 ck('missing_class_is_per_head_nan',np.isnan(score).all() and all(x is None for x in models),'SYNTHETIC_TEST_ONLY')
 def never_converges(self,*a,**kw):self.n_iter_=np.array([500]);return self
 with patch('train_limited.LogisticRegression.fit',never_converges):
  score,models,audit=fit_heads(X,X,np.tile([[0]*10,[1]*10],(2,1)),'H-ALLDOMAIN',1,4)
 ck('nonconvergence_recorded_nan_not_fatal_allfold',np.isnan(score).all() and all(r['failure_reason']=='NONCONVERGENCE' for r in audit),'SYNTHETIC_TEST_ONLY')
 ck('partial_completion_cannot_publish',not acceptance_flags(True,True,True,False,False,False,False,True,False,False,False)['PART1_COMPLETED'],'SYNTHETIC_TEST_ONLY')
 from import_minimal_return import validate_return
 fixture=dict(tasks=[dict(task_id='t',scope_hash='fixed',members=[dict(unit_id='x')],value='')])
 returned=dict(statement='ACTUAL_REPAIRED_TASK_RETURN_NOT_FINAL_C2_APPROVAL',reviewer='SYNTHETIC',signed_at='2026-10-27T12:00:00+08:00',tasks=[dict(fixture['tasks'][0],notes='')])
 ck('blank_unified_return_creates_no_decision',validate_return(returned,fixture)==[],'SYNTHETIC_TEST_ONLY')
 returned['tasks'][0]['value']='CONFIRM';ck('explicit_unified_return_is_partial_not_final',len(validate_return(returned,fixture))==1,'SYNTHETIC_TEST_ONLY')
 returned['tasks'][0]['scope_hash']='changed'
 try:validate_return(returned,fixture);bad=False
 except ValueError:bad=True
 ck('unified_return_scope_mutation_rejected',bad,'SYNTHETIC_TEST_ONLY')
 fixture={'tasks':[dict(task_id='g',type='GROUP_APPROVAL',members=[dict(group_id='one')],value='')]}
 returned['tasks']=[dict(fixture['tasks'][0],value='CONFIRM',selected_scope_ids=[],notes='No subset selected')]
 ck('empty_subgroup_selection_not_expanded',validate_return(returned,fixture)[0]['selected_scope_ids']==[],'SYNTHETIC_TEST_ONLY')
 returned['tasks'][0]['selected_scope_ids']=['other']
 try:validate_return(returned,fixture);bad=False
 except ValueError:bad=True
 ck('unregistered_group_cannot_be_approved',bad,'SYNTHETIC_TEST_ONLY')
 csvout(out/'minimal_patch_QA.csv',checks);jsonout(out/'minimal_patch_QA.json',dict(passed=True,checks=checks,development_threshold_cut_rows_checked=n,human_eligible_machine_negative_cases=counter,reference_labels_used_for_tuning=False,model_refitted=False))
 print(json.dumps(dict(passed=True,n=len(checks),cut_rows=n,human_machine_conflicts=counter)))

if __name__=='__main__':
 import argparse
 p=argparse.ArgumentParser();p.add_argument('--workspace',required=True);p.add_argument('--run-id',required=True);a=p.parse_args();ctx=Context(a.workspace,a.run_id);out=ctx.root/'assurance';out.mkdir(exist_ok=True);run(ctx,out)
