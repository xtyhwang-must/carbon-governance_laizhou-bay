"""Explicitly synthetic tests. No real judgment or publication approval generated."""
from common import *
from coding_pipeline import execute
from adjudication import validate_rows
from part1_completion import acceptance_flags,stage_composition,independent_stage_check
from share_quality import sensitivity
from standalone_replay import independent_counts

def main():
 code=Path(__file__).resolve().parent;prior=load(code/'end_to_end_test_report.json');ctx=Context(prior['workspace'],'part1_directed_checks_'+digest(now())[:8],Path(prior['workspace'])/'fixture/config.json');ctx._vcache={};checks={};tmp=ctx.root/'part1_extension_test';tmp.mkdir(exist_ok=True)
 def ck(k,v):checks[k]=bool(v);require(v,k)
 def run(cmd,**kw):
  r=execute(ctx,cmd,**kw);require(r['state']!='FAILED',r.get('message'));return r
 run('prepare');run('ingest-return',review=Path(prior['workspace'])/'fixture/returned.csv',signature=Path(prior['workspace'])/'fixture/return_signature.json');run('build-registry');run('train');run('predict');reg=ctx.artifact('build-registry');old_n=len(read(reg/'registry_snapshot.csv'));old_sig=sha(reg/'training_signature.json');cat=read(ctx.artifact('prepare')/'corpus.csv');known=set(read(reg/'registry_snapshot.csv').unit_id)
 uid=cat.loc[~cat.unit_id.isin(known)&cat.split.ne('DEVELOPMENT'),'unit_id'].iloc[-1]
 request=tmp/'request.csv';csvout(request,[dict(unit_id=uid,field='eligibility',role='C2_ONLY')]);run('register-adjudication',input=request,pool_id='directed_test')
 plan=ctx.artifact('register-adjudication:directed_test');template=read(plan/'adjudication_review.csv');blank=tmp/'blank.csv';csvout(blank,template)
 def sig(path,name):
  p=tmp/name;jsonout(p,dict(identity='SYNTHETIC_TEST_ONLY',statement='CONFIRM_ACTUAL_DIRECTED_ADJUDICATION',reviewer='SYNTHETIC_TESTER_NOT_AUTHOR',signed_at=now(),batch_id=name,review_sha256=sha(path),scope_sha256=sha(plan/'scope.json')));return p
 r=run('ingest-adjudication',review=blank,signature=sig(blank,'blank_signature.json'),pool_id='directed_test');events=read(ctx.root/r['artifact']/'human_review_events.csv');ck('blank_never_becomes_negative',len(events)==0)
 filled=template.copy();filled['value']='0';fp=tmp/'filled.csv';csvout(fp,filled);sp=sig(fp,'filled_signature.json');r=run('ingest-adjudication',review=fp,signature=sp,pool_id='directed_test');ev=read(ctx.root/r['artifact']/'human_review_events.csv');parent=ev[ev.field.eq('eligibility')].iloc[0]
 ck('actual_directed_negative_and_derived_fields',len(ev)==10 and set(ev.value)=={'0'})
 ck('derived_zero_parent_bound',ev.loc[ev.field.ne('eligibility'),'parent_event_id'].eq(parent.event_id).all())
 ck('reimport_idempotent',run('ingest-adjudication',review=fp,signature=sp,pool_id='directed_test')['reused'])
 run('build-registry');nr=ctx.artifact('build-registry');h=read(nr/'registry_snapshot.csv');ck('new_human_record_counted_once',len(h)==old_n+1)
 ck('C2_only_does_not_train',h.set_index('unit_id').loc[uid,'training_allowed']=='False')
 ck('C2_only_does_not_change_training_signature',sha(nr/'training_signature.json')==old_sig)
 ck('scope_registration_survives_partial_registry_append',run('register-adjudication',input=request,pool_id='directed_test')['reused'])
 # Scoped correction of an existing field, without relabeling unrelated fields.
 q=tmp/'correct_request.csv';csvout(q,[dict(unit_id=uid,field='eligibility',role='C2_ONLY',correction_reason='SYNTHETIC correction fixture')]);run('register-adjudication',input=q,pool_id='correction_test');cp=ctx.artifact('register-adjudication:correction_test');t=read(cp/'adjudication_review.csv');t['value']='1';f=tmp/'correct.csv';csvout(f,t);sg=tmp/'correct_signature.json';jsonout(sg,dict(identity='SYNTHETIC_TEST_ONLY',statement='CONFIRM_ACTUAL_DIRECTED_ADJUDICATION',reviewer='SYNTHETIC_TESTER',signed_at=now(),batch_id='correction',review_sha256=sha(f),scope_sha256=sha(cp/'scope.json')));run('ingest-adjudication',review=f,signature=sg,pool_id='correction_test');run('build-registry');h=read(ctx.artifact('build-registry')/'registry_snapshot.csv');ck('explicit_correction_chain_applied',h.set_index('unit_id').loc[uid,'human_eligibility']=='1');ck('changed_parent_invalidates_derived_GT_zeros',all(h.set_index('unit_id').loc[uid,'human_'+k]=='' for k in LABELS[1:]))
 # Field-wise source mutation and unbound correction negatives with independent expected event count.
 current={(uid,'eligibility'):dict(value='0',evidence_id='old')};t['previous_event_id']='wrong';tt=read(cp/'adjudication_review.csv');catidx=cat.set_index('unit_id');signature=load(sg)
 ev,err=validate_rows(t,tt,signature,catidx,current,'SYNTHETIC_TEST_ONLY','rule','review','signature');ck('wrong_correction_parent_rejected',not ev and len(err)==1)
 altered=tt.copy();altered['value']='0';altered['text']='WRONG SOURCE';ev,err=validate_rows(altered,tt,signature,catidx,{},'SYNTHETIC_TEST_ONLY','rule','review','signature');ck('source_change_invalidates_judgment',not ev and len(err)==1)
 # Independent arithmetic fixture: two policies have unequal action counts.
 candidate=[];mapping=[]
 for pol,uid,positive,elig in [('A','a1',['G1','G2','T1'],1),('A','a2',['G1','T2'],1),('B','b1',['G3','T6'],1),('C','c1',[],0)]:
  candidate.append(dict(unit_id=uid,policy_id=pol,complete='True',C2_eligibility=str(elig),**{'C2_'+k:str(int(k in positive)) for k in LABELS[1:]}));mapping.append(dict(unit_id=uid,policy_id=pol,counting_status='COUNTED_ELIGIBLE' if elig else 'NOT_COUNTED_INELIGIBLE',action_unit_id=uid if elig else ''))
 stage=[dict(policy_id=p,stage='S') for p in ['A','B','C']];policy,st=independent_counts(candidate,mapping,stage);pi={r['policy_id']:r for r in policy}
 ck('independent_assignment_denominator',pi['A']['G_assignment_denominator']==3 and np.isclose(pi['A']['G1'],2/3))
 ck('zero_policy_retained_NA',pi['C']['G1']=='' and pi['C']['eligible_action_n']==0)
 ck('stage_is_equal_policy_not_pooled_actions',np.isclose(st[0]['G1'],1/3) and np.isclose(st[0]['G3'],.5) and st[0]['G_defined_policy_n']==2)
 ps=pd.DataFrame(policy);ss=stage_composition(ps,pd.DataFrame(stage));ck('independent_stage_agrees',independent_stage_check(ps,pd.DataFrame(stage),ss))
 bad=[dict(x) for x in mapping];bad[2]['action_unit_id']='a1'
 try:independent_counts(candidate,bad,stage);checks['cross_policy_merge_rejected']=False
 except AssertionError:checks['cross_policy_merge_rejected']=True
 require(checks['cross_policy_merge_rejected'],'cross_policy_merge_rejected')
 flags=acceptance_flags(True,True,True,True,False,False,False,True,True,True,True);ck('labels_frozen_not_part1_complete',not flags['PART1_COMPLETED'])
 flags=acceptance_flags(True,True,True,True,True,True,False,True,True,True,True);ck('no_release_replay_no_completion',not flags['PART1_COMPLETED'])
 ck('only_all_gates_true_can_complete',acceptance_flags(True,True,True,True,True,True,True,True,True,True,True)['PART1_COMPLETED'])
 lo,hi=sensitivity(2,3,3,1);ck('small_denominator_conservative_sensitivity',lo<=1/6 and hi==1.)
 ck('zero_assumed_errors_is_explicit_sensitivity_not_CI',sensitivity(2,3,3,0)==(2/3,2/3))
 jsonout(code/'part1_extension_test_report.json',dict(identity='SYNTHETIC_TEST_ONLY',passed=all(checks.values()),checks=checks,actual_human_judgments_generated=False))
 print(json.dumps(checks))
if __name__=='__main__':main()
