"""Read-only evidence checks with derived reports; never clears a source issue."""
from common import *
from zipfile import ZipFile
import html,xml.etree.ElementTree as ET

def run(ctx):
 out=ctx.root/'evidence_checks';out.mkdir(exist_ok=True);prep=ctx.artifact('prepare');cat=read(prep/'corpus.csv');issues=read(prep/'issue_scope_audit.csv');ids=set()
 for x in issues[issues.issue_type.eq('EXTRACTION_FRAGMENT')].affected_ids:ids.update(json.loads(x))
 origins=read(ctx.workspace/'b1/02_policy/reconstructed/text_source_audit.csv').set_index('policy_id');cache={};rows=[]
 for r in cat[cat.unit_id.isin(ids)].itertuples():
  if r.policy_id not in cache:
   m=origins.loc[r.policy_id];p=ctx.workspace/'b1'/m.body_source_relative_path;captured=ctx.workspace/'b1'/m.captured_source_relative_path;txt='';error=''
   try:
    if p.suffix.lower()=='.pdf':
     from pypdf import PdfReader
     txt='\n'.join(page.extract_text() or '' for page in PdfReader(str(p)).pages)
    elif p.suffix.lower()=='.docx':
     with ZipFile(p) as z:root=ET.fromstring(z.read('word/document.xml'));txt=' '.join(t.text or '' for t in root.iter() if t.tag.endswith('}t'))
    else:txt=html.unescape(re.sub('<[^>]+>',' ',p.read_text(encoding=m.body_encoding or 'utf-8-sig',errors='replace')))
   except Exception as e:error=str(e)
   cache[r.policy_id]=(str(p),sha(p),sha(p)==m.body_source_sha256,captured.is_file() and sha(captured)==m.captured_source_sha256,norm(txt),error)
  path,h,ok,capok,text,err=cache[r.policy_id];target=norm(r.exact_evidence_text)
  rows.append(dict(unit_id=r.unit_id,policy_id=r.policy_id,source_location=r.source_location,text=r.exact_evidence_text,parent_context=r.parent_clause_text,body_source=path,body_sha256=h,body_sha_matches=ok,captured_sha_matches=capok,exact_fragment_found=bool(target and target in text),read_error=err,decision='REMAINS_SCOPED_PENDING_NOT_A_TRUE_NEGATIVE'))
 csvout(out/'extraction_fragment_carrier_check.csv',rows)
 amendments=load(ctx.input('amendments'));human=read(prep/'baseline_human.csv').set_index('unit_id');corrections=[]
 for correction in amendments['corrections']:
  uid=correction['unit_id'];corrections.append(dict(unit_id=uid,present_in_trusted_human=uid in human.index,statement=correction['author_statement'],current_eligibility=human.loc[uid,'human_eligibility'] if uid in human.index else '',source_ledger_sha256=sha(ctx.input('amendments'))))
 csvout(out/'five_author_corrections_check.csv',corrections)
 require(len(corrections)==5 and all(x['present_in_trusted_human'] for x in corrections),'Author corrections missing')
 # Scan actual named return locations, explicitly excluding synthetic and immutable artifacts.
 files=[]
 for base in [ctx.workspace/'05_revision_work/R1_20261026/01_coding',Path('D:/下载')]:
  for p in base.rglob('*'):
   if not p.is_file() or any(v in p.parts for v in ['synthetic_tests','artifacts','frozen_69qa_20261027','__pycache__']):continue
   if ('next200' in p.name.lower() or 'return' in p.name.lower() or 'signed' in p.name.lower()) and p.suffix.lower() in ['.csv','.xlsx','.json']:
    filled='NOT_A_REVIEW_TABLE'
    try:
     t=read_review(p)
     if 'eligibility_choice' in t:filled=str(int(t.eligibility_choice.ne('').sum()))
    except Exception:pass
    files.append(dict(path=str(p),sha256=sha(p),nonblank_eligibility=filled,identity='REAL_LOCATION_NOT_AUTOMATICALLY_TRUSTED'))
 csvout(out/'actual_return_file_search.csv',files)
 # Record legacy identities; do not rewrite old signed protocols or import synthetic receipts.
 legacy=[];oldroot=ctx.root.parent/'real_20261027';sources=[('REAL',oldroot)]
 oldreport=ctx.code.parent/'end_to_end_test_report.json'
 if oldreport.exists():
  oldws=longpath(load(oldreport)['workspace']);sources.append(('SYNTHETIC_TEST_ONLY',oldws/'05_revision_work/R1_20261026/01_coding/coding_pipeline_completion/runs/full_chain'))
 for identity,root in sources:
  m=load(root/'stage_manifest.json')
  for k,v in m['stages'].items():
   if k=='plan-audit' or k.startswith('ingest-audit:'):
    legacy.append(dict(identity=identity,old_run=str(root),old_stage=k,old_artifact=str(root/v['artifact']),proposed_explicit_pool_id='LEGACY_'+digest(str(root))[:12],migration_status='REFERENCE_MAPPING_ONLY_NOT_NEW_APPROVAL_OR_REAL_IMPORT'))
 csvout(out/'legacy_pool_migration_mapping.csv',legacy,columns=['identity','old_run','old_stage','old_artifact','proposed_explicit_pool_id','migration_status'])
 jsonout(out/'evidence_check_manifest.json',dict(identity=ctx.identity,files=filelist(out),new_approvals_created=0,fragment_count=len(rows),carrier_policies=len(cache),real_legacy_pool_count=sum(x['identity']=='REAL' for x in legacy),original_sample_nonblank=int(read(prep/'sample.csv').eligibility_choice.ne('').sum()),part2_started=False))
 print(json.dumps(dict(fragment_units=len(rows),carrier_policies=len(cache),read_errors=sum(bool(r['read_error']) for r in rows),actual_return_candidates=len(files))))
if __name__=='__main__':
 import argparse
 p=argparse.ArgumentParser();p.add_argument('--workspace',required=True);p.add_argument('--run-id',required=True);a=p.parse_args();run(Context(a.workspace,a.run_id))
