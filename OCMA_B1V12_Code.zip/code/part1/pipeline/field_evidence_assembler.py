"""Executable wrapper for the shared, dependency-checked pipeline."""
from coding_pipeline import main
if __name__=="__main__":main(forced='assemble-candidate')
