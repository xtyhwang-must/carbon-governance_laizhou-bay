import math
import numpy as np
import pandas as pd
G=['G1','G2','G3'];T=['T1','T2','T3','T4','T5','T6'];LABELS=['eligibility']+G+T
FEATURES=LABELS+[g+'x'+t for g in G for t in T]
VALID_UNITS={'VALID_SENTENCE_OR_CLAUSE','VALID_COMPOUND_CLAUSE'}
STAGES=['2000-2010','2011-2016','2017-2020','2021-2023']
def require(ok,message):
 if not ok:raise ValueError(message)
def numeric(s):return pd.to_numeric(s,errors='raise')

def observed_bit(value):
    if value is None or str(value).strip()=='':return None
    try:v=float(value)
    except (ValueError,TypeError):return None
    return int(v) if np.isfinite(v) and v in [0.,1.] else None

def feature_names(review_scope='FULL_10'):
    require(review_scope in ['FULL_10','G_ONLY'],'Unsupported review scope')
    return ['eligibility']+G if review_scope=='G_ONLY' else FEATURES

def feature_vector(r,kind='truth',review_scope='FULL_10'):
    features=feature_names(review_scope)
    if kind=='truth':
        # These facts prove zero G contribution even if unrelated source fields are unknown.
        if observed_bit(r.get('eligibility'))==0 or r.get('source_membership')=='OUTSIDE_TARGET' or r.get('unit_validity')=='SOURCE_NOT_TARGET' or (r.get('unit_validity')=='DUPLICATE_CONFIRMED' and str(r.get('duplicate_rule_confirmed','')).lower() in ['true','1']):return np.zeros(len(features))
        if r.get('source_membership')!='IN_TARGET' or r.get('unit_validity') not in VALID_UNITS:return None
        if observed_bit(r.get('eligibility'))!=1 or any(observed_bit(r.get(k)) is None for k in G):return None
        e=1;g=[observed_bit(r[k]) for k in G]
        if review_scope=='G_ONLY':return np.asarray([e]+g,float)
        if any(observed_bit(r.get(k)) is None for k in T):return None
        t=[observed_bit(r[k]) for k in T]
    else:
        e=int(r['C2_eligibility']);g=[e*int(r['C2_'+k]) for k in G]
        if review_scope=='G_ONLY':return np.asarray([e]+g,float)
        # Unknown auxiliary zero is never written to C2; unbiased design residuals supply T2 total.
        t=[e*(int(r['C2_'+k]) if str(r['C2_'+k])!='' else 0) for k in T]
    return np.asarray([e]+g+t+[a*b for a in g for b in t],float)

def audit_composition_impact(frame,sample,actual,allocation,review_scope='FULL_10',allow_partial=False,cached_moments=None):
    """Model-assisted finite-population difference totals and joint covariance.

    Complete primary probability return required. Ratios are Taylor estimates;
    policy-bootstrap intervals are not read or combined here.
    """
    require('statistical_identity' in sample and sample.statistical_identity.eq('JOINT_STRATIFIED_SRSWOR').all(),'Directed cases are not a probability audit')
    require(numeric(sample.inclusion_probability).between(0,1,inclusive='right').all(),'Invalid inclusion probability')
    require(actual.unit_id.is_unique and (set(actual.unit_id)<=set(sample.unit_id) if allow_partial else set(actual.unit_id)==set(sample.unit_id)),'Incomplete probability return; no design extrapolation')
    names=feature_names(review_scope)
    af=actual.set_index('unit_id');fi=frame.set_index('unit_id');moments={};rows=[]
    for pid,z in frame.groupby('policy_id',sort=True):
        if cached_moments and pid in cached_moments:
            moments[pid]=cached_moments[pid];continue
        total=sum((feature_vector(r,'aux',review_scope) for r in z.to_dict('records')),np.zeros(len(names)))
        cov=np.zeros((len(names),len(names)));reason=[]
        for h,a in allocation[allocation.policy_id.eq(pid)].set_index('stratum_id').iterrows():
            ss=sample[sample.stratum_id.eq(h)];N=int(a.N);n=int(a.sample_n)
            require(len(ss)==n,'Actual sample differs from allocation')
            require(np.allclose(numeric(ss.inclusion_probability),n/N,rtol=0,atol=1e-12),'Actual sample probability differs from locked stratum')
            residual=[]
            for uid in ss.unit_id:
                if uid not in af.index:reason.append('MISSING:'+uid);continue
                y=feature_vector(af.loc[uid].to_dict(),'truth',review_scope)
                if y is None:reason.append(uid);continue
                residual.append(y-feature_vector(fi.loc[uid].to_dict(),'aux',review_scope))
            if len(residual)!=n:continue
            res=np.asarray(residual);total+=N*res.mean(axis=0)
            if n<N:
                require(n>=2,'Variance unidentifiable for noncensus n1 stratum')
                cov+=N*N*(1-n/N)*np.cov(res,rowvar=False,ddof=1)/n
        a_policy=allocation[allocation.policy_id.eq(pid)]
        moments[pid]=(total,cov,reason,dict(has_noncensus_stratum=bool((numeric(a_policy.sample_n)<numeric(a_policy.N)).any()),feature_names=names,review_scope=review_scope))
    # Cached and newly computed policies have the same output contract.
    for pid,(total,cov,reason,_) in moments.items():
        for k,v in zip(names,total):rows.append(dict(policy_id=pid,feature=k,estimated_total=v if not reason else np.nan,
          standard_error=math.sqrt(max(0,cov[names.index(k),names.index(k)])) if not reason else np.nan,
          status='UNIDENTIFIED_UNIT_OR_SOURCE_MAPPING' if reason else 'DESIGN_ASSISTED_DIFFERENCE_ESTIMATE',
          variance_caveat='zero empirical residual variance is not proof of no unseen errors in noncensus strata',
          unresolved_unit_ids=';'.join(reason),scope='FIXED_EXTRACTED_UNITS;EXISTING_EVIDENCE_ASSUMED_VALID;OMITTED_SOURCE_CLAUSES_NOT_IDENTIFIED'))
    return moments,pd.DataFrame(rows)

def estimate_direct_stratified_HT(frame,sample,actual,allocation):
    """Post-audit sensitivity: fixed verified component + original SRSWOR HT.

    Count totals are design-unbiased conditional on the fixed evidence being
    valid; normalized shares are ratio estimators, not strictly unbiased.
    This function neither clips DIFF nor uses model predictions in sampled HT.
    """
    names=['eligibility']+G
    require(actual.unit_id.is_unique and set(actual.unit_id)==set(sample.unit_id),'HT requires complete original probability sample')
    require(sample.statistical_identity.eq('JOINT_STRATIFIED_SRSWOR').all(),'HT requires registered probability identities')
    fixed=frame.existing_fields_to_reuse.ne('')
    require(not set(frame.loc[fixed,'unit_id'])&set(sample.unit_id),'Fixed evidence counted twice')
    require(frame.loc[fixed,'existing_fields_to_reuse'].map(lambda x:set(LABELS)<=set(x.split(';'))).all(),'Fixed component lacks complete evidence')
    require(set(allocation.stratum_id)==set(sample.stratum_id),'HT stratum mismatch')
    af=actual.set_index('unit_id');moments={};rows=[]
    for pid,z in frame.groupby('policy_id',sort=True):
        fixedz=z[z.existing_fields_to_reuse.ne('')]
        fixed_total=sum((feature_vector(r,'aux','G_ONLY') for r in fixedz.to_dict('records')),np.zeros(4))
        total=fixed_total.copy();cov=np.zeros((4,4));unknown=[]
        alloc=allocation[allocation.policy_id.eq(pid)]
        require(int(pd.to_numeric(alloc.N).sum())==int(z.existing_fields_to_reuse.eq('').sum()),'HT frame partition mismatch')
        for a in alloc.itertuples():
            ss=sample[sample.stratum_id.eq(a.stratum_id)];N=int(a.N);n=int(a.sample_n)
            require(len(ss)==n and np.allclose(numeric(ss.inclusion_probability),n/N,rtol=0,atol=1e-12),'HT locked design mismatch')
            require(np.allclose(numeric(ss.design_weight),N/n,rtol=0,atol=1e-10),'HT weight mismatch')
            values=[]
            for uid in ss.unit_id:
                y=feature_vector(af.loc[uid].to_dict(),'truth','G_ONLY')
                if y is None:unknown.append(uid)
                else:values.append(y)
            if len(values)!=n:continue
            y=np.asarray(values);require(np.all(y>=0),'Negative true HT contribution')
            total+=N/n*y.sum(axis=0)
            if n<N:
                require(n>=2,'Noncensus HT stratum variance unidentified')
                cov+=N*N*(1-n/N)*np.cov(y,rowvar=False,ddof=1)/n
        require(np.all(total>=0),'Negative HT total is an implementation error')
        meta=dict(has_noncensus_stratum=bool((numeric(alloc.sample_n)<numeric(alloc.N)).any()),feature_names=names,
                  review_scope='G_ONLY',estimator='DIRECT_STRATIFIED_HT',identity='POST_AUDIT_ESTIMATOR_SENSITIVITY',
                  fixed_evidence_n=len(fixedz),sample_n=int(numeric(alloc.sample_n).sum()))
        moments[pid]=(total,cov,unknown,meta)
        for k,value,fix in zip(names,total,fixed_total):
            rows.append(dict(policy_id=pid,feature=k,estimated_total=value if not unknown else np.nan,
              fixed_evidence_total=fix,sampled_domain_total=value-fix if not unknown else np.nan,
              standard_error=math.sqrt(max(0,cov[names.index(k),names.index(k)])) if not unknown else np.nan,
              fixed_evidence_n=len(fixedz),sample_n=meta['sample_n'],unresolved_unit_ids=';'.join(unknown),
              status='UNRESOLVED_CONTRIBUTION' if unknown else 'ZERO_ESTIMATED_ASSIGNMENTS_NOT_CONFIRMED_G0' if value==0 and k in G else 'DESIGN_HT_TOTAL',
              identity='POST_AUDIT_ESTIMATOR_SENSITIVITY',scope='FIXED_EXTRACTED_UNIT_FRAME;FIXED_EVIDENCE_ASSUMED_VALID',
              ratio_identity='NORMALIZED_RATIO_NOT_STRICTLY_UNBIASED'))
    return moments,pd.DataFrame(rows)

def evaluate_function_history(frame,moments,group='G'):
    labs=G if group=='G' else T;policy=[];stage=[]
    for pid,z in frame.groupby('policy_id',sort=True):
        total,cov,unresolved=moments[pid][:3];meta=moments[pid][3] if len(moments[pid])>3 else {}
        names=meta.get('feature_names',FEATURES);require(all(k in names for k in labs),'Group not in reviewed scope')
        ix=[names.index(k) for k in labs];den=float(total[ix].sum())
        for j,k in zip(ix,labs):
            defined=not unresolved and den>0 and np.all(total[ix]>=0)
            grad=np.zeros(len(names));grad[ix]=-total[j]/den**2 if den else 0;grad[j]+=1/den if den else 0
            variance=float(grad@cov@grad) if defined else np.nan
            policy.append(dict(policy_id=pid,stage=z.iloc[0].stage,label=k,design_corrected_share=total[j]/den if defined else np.nan,
                standard_error=math.sqrt(max(0,variance)) if defined else np.nan,assignment_denominator=den if not unresolved else np.nan,
                negative_total_not_clipped=bool(np.any(total[ix]<0)),status='UNIDENTIFIED_OR_NONPOSITIVE_RATIO' if not defined else 'DESIGN_LINEARIZED_RATIO',
                sample_scope_complete=not unresolved,has_noncensus_stratum=meta.get('has_noncensus_stratum',False),
                variance_identity='CODING_AUDIT_DESIGN_ONLY_NOT_POLICY_BOOTSTRAP'))
    result=pd.DataFrame(policy)
    for (s,k),z in result.groupby(['stage','label']):
        full=z.design_corrected_share.notna().all();v=float(np.sum(z.standard_error**2)/len(z)**2) if full else np.nan
        value=float(z.design_corrected_share.mean()) if full else np.nan;se=math.sqrt(v) if full else np.nan
        interval_ok=full and (v>0 or not z.has_noncensus_stratum.any())
        stage.append(dict(stage=s,label=k,policy_n=len(z),design_corrected_share=value,standard_error=se,
          p025_normal_approx=value-1.96*se if interval_ok else np.nan,p975_normal_approx=value+1.96*se if interval_ok else np.nan,
          normal_interval_reportable=interval_ok,zero_empirical_variance_not_zero_risk=bool(full and v==0 and z.has_noncensus_stratum.any()),
          interval_identity='TAYLOR_NORMAL_AUDIT_DESIGN_APPROX_NOT_POLICY_COMPOSITION_BOOTSTRAP',
          limitation='small strata/rare labels may make normal approximation weak; no coverage guarantee; zero observed errors or zero residual variance do not prove zero population risk; source gaps excluded'))
    return result,pd.DataFrame(stage)

def stage_changes(stage):
    """Adjacent-stage contrasts under independently drawn policy strata."""
    rows=[]
    for earlier,later in zip(STAGES,STAGES[1:]):
        for k in sorted(stage.label.unique()):
            a=stage[stage.stage.eq(earlier)&stage.label.eq(k)];b=stage[stage.stage.eq(later)&stage.label.eq(k)]
            if len(a)!=1 or len(b)!=1:continue
            a=a.iloc[0];b=b.iloc[0]
            value=b.design_corrected_share-a.design_corrected_share;se=math.sqrt(a.standard_error**2+b.standard_error**2)
            ok=bool(a.normal_interval_reportable and b.normal_interval_reportable and np.isfinite(value) and np.isfinite(se))
            rows.append(dict(earlier_stage=earlier,later_stage=later,label=k,design_corrected_difference=value,standard_error=se,
                p025_normal_approx=value-1.96*se if ok else np.nan,p975_normal_approx=value+1.96*se if ok else np.nan,
                normal_interval_reportable=ok,identity='ADJACENT_STAGE_CODING_DESIGN_TAYLOR_APPROX;NOT_POLICY_BOOTSTRAP;NOT_QUALITY_PASS'))
    return pd.DataFrame(rows)

def error_metrics(frame,sample,actual,review_scope='FULL_10'):
    labs=['eligibility']+G if review_scope=='G_ONLY' else LABELS
    z=actual.merge(sample[['unit_id','design_weight']],on='unit_id',validate='one_to_one').merge(frame[['unit_id','policy_family_id']+['C2_'+k for k in labs]],on='unit_id',validate='one_to_one')
    rows=[]
    for dimension in ['ALL','stage','policy_family_id']:
        groups=[('ALL',z)] if dimension=='ALL' else list(z.groupby(dimension))
        for scope,q in groups:
            w=numeric(q.design_weight).to_numpy(float)
            for k in labs:
                # Reused fields support the fixed component but are not newly independent error observations.
                keep=~q.get('reused_fields',pd.Series('',index=q.index)).map(lambda v:k in str(v).split(';'))
                keep &= pd.to_numeric(q[k],errors='coerce').isin([0,1])
                qq=q[keep];ww=w[keep.to_numpy()]
                y=numeric(qq[k]).to_numpy(int);pred=pd.to_numeric(qq['C2_'+k],errors='coerce').to_numpy(float);known=np.isfinite(pred)
                masks=dict(TP=(y==1)&(pred==1),FP=(y==0)&(pred==1),FN=(y==1)&(pred==0),TN=(y==0)&(pred==0))
                row=dict(dimension=dimension,scope=scope,label=k,sample_n=len(qq),actual_positive_n=int(y.sum()),prediction_abstention_n=int((~known).sum()),
                  weighted_abstained_positives=float(ww[(~known)&(y==1)].sum()),identity='NEW_PROBABILITY_DOMAIN_ONLY;NOT_DIRECTED_CASES;FIXED_REUSE_COMPONENT_NOT_NEW_VALIDATION')
                for name,mask in masks.items():row[name]=int(mask.sum());row['HT_'+name]=float(ww[mask].sum())
                rows.append(row)
    return pd.DataFrame(rows)

def independent_coding_agreement(primary,secondary,review_scope='FULL_10'):
    """Only two genuinely current-coder observations enter field agreement."""
    paired=primary.merge(secondary,on='unit_id',suffixes=('_primary','_secondary'),validate='one_to_one');rows=[];differences=[]
    distinct=paired.reviewer_primary.str.strip().str.casefold().ne(paired.reviewer_secondary.str.strip().str.casefold()) if len(paired) else pd.Series([],dtype=bool)
    if len(paired) and review_scope!='G_ONLY':require(distinct.all(),'Second coder must be a distinct real reviewer')
    for k in (['eligibility']+G if review_scope=='G_ONLY' else LABELS):
        flag=lambda side: paired.get('independent_'+k+'_'+side,pd.Series(False,index=paired.index)).astype(str).str.lower().isin(['true','1'])
        valid=flag('primary')&flag('secondary')&distinct
        valid &= pd.to_numeric(paired[k+'_primary'],errors='coerce').isin([0,1])&pd.to_numeric(paired[k+'_secondary'],errors='coerce').isin([0,1])
        q=paired[valid];a=numeric(q[k+'_primary']).to_numpy(int);b=numeric(q[k+'_secondary']).to_numpy(int)
        pa=float((a==b).mean()) if len(q) else np.nan;pe=float(a.mean()*b.mean()+(1-a.mean())*(1-b.mean())) if len(q) else np.nan
        rows.append(dict(label=k,paired_actual_n=len(q),excluded_reused_or_unobserved_n=len(paired)-len(q),excluded_same_reviewer_n=int((~distinct).sum()),raw_agreement=pa,cohen_kappa=(pa-pe)/(1-pe) if len(q) and pe<1 else np.nan,identity='ACTUAL_INDEPENDENT_FIELDS_ONLY;UNWEIGHTED_NESTED_SAMPLE_DESCRIPTION'))
        for r in q.to_dict('records'):differences.append(dict(unit_id=r['unit_id'],field=k,primary_value=r[k+'_primary'],secondary_value=r[k+'_secondary'],agree=str(r[k+'_primary'])==str(r[k+'_secondary']),primary_reviewer=r['reviewer_primary'],secondary_reviewer=r['reviewer_secondary']))
    return pd.DataFrame(rows),pd.DataFrame(differences)