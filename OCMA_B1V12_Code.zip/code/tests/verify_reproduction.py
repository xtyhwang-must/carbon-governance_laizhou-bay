from pathlib import Path
import json,hashlib,pandas as pd,numpy as np
import argparse
ap=argparse.ArgumentParser();ap.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[2]);n=ap.parse_args().root.resolve();rows=[]
def ck(name,ok,detail):rows.append(dict(check=name,passed=bool(ok),detail=str(detail)));assert ok,(name,detail)
coal=pd.read_csv(n/'replay_check/one_vector_coalitions.csv');sc=pd.read_csv(n/'replay_check/B12P0001_scenarios.csv');errs=[]
for contrast,z in coal.groupby('contrast'):
 for mask,sid in [(0,contrast.split('-')[1]),(int(z.coalition_mask.max()),'S4')]:
  a=sc[sc.scenario.eq(sid)];v={'min_ES_2026_2030':a[a.year.between(2026,2030)].ES.min(),'ES_2030':a[a.year.eq(2030)].ES.iloc[0],'SR_2030':a[a.year.eq(2030)].SR.iloc[0]};q=z[z.coalition_mask.eq(mask)].iloc[0]
  errs.extend(abs(float(q[k])-x) for k,x in v.items())
ck('one-vector empty/full endpoints match main scenarios',max(errs)<1e-10,max(errs));c=pd.read_csv(n/'replay_check/one_vector_closure.csv');ck('per-vector Shapley closure',abs(c.closure).max()<1e-10,abs(c.closure).max())
p=n/'work/publication';lo=pd.read_csv(p/'plot_data/Figure7_LOYO.csv');ck('9 scopes widths x12 omissions',len(lo)==108 and lo.groupby(['policy_scope','coastal_band_km']).size().eq(12).all(),len(lo))
ck('108 delta signs exact',np.allclose(lo.delta_rho,lo.rho_without_year-lo.rho_full,atol=1e-14),'deleted minus full')
style=json.loads((p/'SCENARIO_STYLE.json').read_text('utf8'));ck('S4/S6 solid; S0 dashed; S5 dotted',style['S4']['linestyle']==style['S6']['linestyle']=='-' and style['S0']['linestyle']=='--' and style['S5']['linestyle']==':',style)
r=json.loads((n/'work/report_report.json').read_text('utf8'));ck('17 bounded figure pages',len(r['figures'])==17 and all(not x['text_outside_page'] for x in r['figure_bounds']),len(r['figures']))
for d in ['work','replay_check']:
 for f in (n/d).glob('*_read_trace.json'):
  z=json.loads(f.read_text('utf8'));ck(f.name+' no external research reads',not z['research_reads_outside_package_or_output'],z['research_reads_outside_package_or_output'])
ck('report optimizer and ODE zero',r['optimizer_calls']==r['report_ODE_calls']==0,r)
(p/'FINAL_NUMERICAL_AND_DISPLAY_QA.json').write_text(json.dumps(rows,indent=2),'utf8');print('checks',len(rows),'endpoint',max(errs))
