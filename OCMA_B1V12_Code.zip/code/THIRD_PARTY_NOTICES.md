# Third-party components

NumPy, pandas, SciPy, scikit-learn, joblib, Matplotlib, Numba/llvmlite, python-docx, openpyxl, pypdf and Pillow are installed dependencies, not redistributed environments. Their installed distributions retain their respective licences. No system font files are bundled. Windows PDF rendering uses installed Microsoft Word; Linux/other-platform rendering is not tested. Data rights are itemized separately; no new licence is assigned to third-party carrier content.
