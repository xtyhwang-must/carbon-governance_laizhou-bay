"""Submission display adapter. Frozen sources; 108 LOYO deletions; no model imports."""
from pathlib import Path
import os,sys,json,shutil,runpy,subprocess
import numpy as np,pandas as pd
from scipy.stats import spearmanr
import matplotlib.pyplot as plt
from pypdf import PdfWriter,PdfReader
C=Path(__file__).resolve().parents[1]

def run(D,O,R):
 out=O/'publication';out.mkdir(exist_ok=True);os.environ['B1_REPORT_DIR']=str(out)
 import report_r2 as core
 core.OUT=out;mapping=json.loads((C/'config/report_sources.json').read_text('utf8'));core.source=lambda key:D/mapping[key];core.data=lambda key:pd.read_csv(core.source(key));core.PART1=D/'results/part1'
 for n in ['figures','plot_data','display_tables','qa_previews','logs']:(out/n).mkdir(exist_ok=True)
 import report_r2_figures as f
 f.O=out;f.F=out/'figures';f.P=out/'plot_data'
 old_save=f.save
 def export(fig,name):
  fig.savefig(f.F/(name+'.tiff'),dpi=1000 if name in ['Figure3','Figure7','Figure9','Figure_S3'] else 500,pil_kwargs={'compression':'tiff_lzw'},facecolor='white');old_save(fig,name)
 f.save=export
 plt.rcParams.update({'font.family':f.S['font'],'font.size':8,'axes.labelsize':8,'axes.titlesize':9,'xtick.labelsize':8,'ytick.labelsize':8,'legend.fontsize':8,'svg.fonttype':'none','pdf.fonttype':42,'axes.spines.top':False,'axes.spines.right':False,'axes.linewidth':.65,'legend.frameon':False})
 # Stable scenario identity for both main and envelope views.
 style={s:dict(color=f.C[s],linestyle='--' if s=='S0' else ':' if s=='S5' else '-' if s in ['S4','S6'] else '-.',linewidth=1.8 if s in ['S4','S6'] else 1.0) for s in f.C};core.js(style,out/'SCENARIO_STYLE.json')
 for fun in [f.figure3,f.figure4,f.figure5,f.figure6,f.figure8,f.figure9,f.figure10]:fun()
 # Figure7: original pair arrays, re-ranked separately after each omission.
 series=core.data('g2_series');ref=core.data('g2_statistics').query("relationship=='G2-H'");rows=[];checks=[]
 for (scope,band),z in series.groupby(['policy_scope','coastal_band_km']):
  z=z[z.year.between(2011,2022)].dropna(subset=['G2','H']).sort_values('year');full=float(spearmanr(z.G2.to_numpy(copy=True),z.H.to_numpy(copy=True)).statistic);v=[]
  for year in z.year:
   sub=z[z.year.ne(year)];rho=float(spearmanr(sub.G2.to_numpy(copy=True),sub.H.to_numpy(copy=True)).statistic);v.append(rho);rows.append(dict(policy_scope=scope,coastal_band_km=band,omitted_year=int(year),n_full=len(z),n_after_omission=len(sub),rho_full=full,rho_without_year=rho,delta_rho=rho-full))
  r=ref[ref.policy_scope.eq(scope)&ref.coastal_band_km.eq(band)].iloc[0];err=max(abs(full-r.rho),abs(min(v)-r.LOYO_min),abs(max(v)-r.LOYO_max));assert err<1e-12;(checks.append(dict(scope=scope,band=int(band),max_error=err)))
 lo=pd.DataFrame(rows);assert len(lo)==108;core.csvout(lo,out/'plot_data/Figure7_LOYO.csv');core.js(checks,out/'Figure7_LOYO_QA.json')
 fig=f.frame(145);axes=fig.subplots(3,1,sharex=True,sharey=True);fig.subplots_adjust(left=.12,right=.97,bottom=.13,top=.90,hspace=.35);lim=abs(lo.delta_rho).max()*1.15
 for ax,band,letter in zip(axes,[5,10,20],'abc'):
  for j,(scope,label,col,hatch) in enumerate([('ALL_ELIGIBLE','All eligible','#507893',''),('A_GRADE','Grade A','#C29B57','//'),('LOCAL','Local','#609887','..')]):
   z=lo[lo.policy_scope.eq(scope)&lo.coastal_band_km.eq(band)].sort_values('omitted_year');ax.bar(np.arange(12)+(j-1)*.24,z.delta_rho,width=.22,color=col,label=label,edgecolor='white',linewidth=.25,hatch=hatch)
  ax.axhline(0,color='.35',lw=.6);ax.set_ylim(-lim,lim);f.panel(ax,letter,f'{band} km'+(' reference' if band==10 else ''))
 axes[0].legend(ncol=3,loc='lower center',bbox_to_anchor=(.5,1.23));axes[-1].set_xticks(range(12),range(2011,2023),rotation=45);axes[-1].set_xlabel('Omitted year');fig.supylabel('Change in Spearman ρ after omitting one year',x=.02,fontsize=9);f.save(fig,'Figure7')
 # FigureS8: same frozen ES matrix, original aggregation and counts.
 mat=f.specification_matrix();allmat=mat.copy();mat=mat[~mat.specification.str.startswith('REPORTING_SR_')].reset_index(drop=True);assert len(mat)==26;core.csvout(allmat,out/'plot_data/All_specifications_including_SR.csv');core.csvout(mat,out/'plot_data/Figure_S8_matrix.csv')
 fig=f.frame(185);ax=fig.add_axes([.52,.16,.38,.72]);v=mat[['S4-S0','S6-S0','S4-S6']].to_numpy()*1000;lim=np.nanmax(abs(v));im=ax.imshow(v,cmap='RdBu_r',vmin=-lim,vmax=lim,aspect='auto');ax.set_yticks([]);ax.set_xticks(range(3),['S4−S0','S6−S0','S4−S6']);ax.tick_params(length=0)
 for i,r in enumerate(mat.itertuples()):
  label=r.label.replace('CLIMATE BLOCK','Climate block ').replace('CODER SWAP','Coder swap').replace('COMPOUND X','Compound ×').replace('RISK TAU X','Risk delay ×').replace('SYNERGY X','Synergy ×')
  for x,text in [(-3.96,r.group),(-3.5,label),(-1.12,r.n_parameters),(-.72,r.n_climate_paths)]:ax.text(x,i,str(text),va='center',ha='left' if x<-2 else 'center',fontsize=7.1,clip_on=False)
  for j in range(3):ax.text(j,i,f'{v[i,j]:+.2f}',ha='center',va='center',fontsize=7.3,color='white' if abs(v[i,j])>.67*lim else '#26333E');ax.add_patch(f.Rectangle((j-.49,i-.49),.98,.98,fill=False,lw=.65 if abs(v[i,j])<=.5 else .2,edgecolor='black' if abs(v[i,j])<=.5 else 'white'))
 for x,text in [(-3.96,'Type'),(-3.5,'Specification'),(-1.12,'n p'),(-.72,'n c')]:ax.text(x,-1.4,text,ha='left' if x<-2 else 'center',fontsize=7.5,clip_on=False)
 fig.text(.07,.94,'Specification sensitivity of minimum ES',fontsize=10);fig.colorbar(im,cax=fig.add_axes([.53,.10,.36,.018]),orientation='horizontal',label='Paired minimum ES difference ×10⁻³');fig.text(.07,.025,'A reporting; B fixed parameters; C prior limited refit. Counts: parameters / climate paths.\nFinite sets, not probability intervals; SR-only checks remain in the data.',fontsize=7);f.save(fig,'Figure_S8')
 # New two-panel Figure11, same100 and distinct12, no connecting gate line.
 q=core.data('initialization_pairs').query("contrast=='S4-S6' and metric=='min_ES_2026_2030'").sort_values('parameter_set_id');gate=core.data('gate_summary').query("contrast=='S4-S6' and metric=='min_ES_2026_2030'");assert len(q)==100 and len(gate)==6
 fig=f.frame(115);gs=fig.add_gridspec(1,2,left=.12,right=.96,bottom=.14,top=.86,wspace=.44,width_ratios=[1,1]);a=fig.add_subplot(gs[0]);a.scatter(q.RESET*1000,q.CONTINUATION*1000,s=13,color=f.SUB['G'],alpha=.65);a.axhspan(-.5,.5,color='.88');a.axhline(0,color='.5',lw=.6);a.axvline(0,color='.5',lw=.6);a.set(xlabel='RESET difference ×10⁻³',ylabel='Continuation difference ×10⁻³');f.panel(a,'a','Initial-state sensitivity');a.text(.03,.03,'Matched vectors, n = 100',transform=a.transAxes,fontsize=7)
 sub=gs[1].subgridspec(2,1,hspace=.6)
 for i,init in enumerate(['RESET','CONTINUATION']):
  ax=fig.add_subplot(sub[i]);z=gate[gate.initialization.eq(init)].sort_values('midpoint');ax.errorbar(range(3),z['median']*1000,yerr=np.vstack([z['median']-z.P5,z.P95-z['median']])*1000,fmt='o',capsize=3,color=f.SUB['G'] if i==0 else f.SUB['E']);ax.axhspan(-.5,.5,color='.88');ax.axhline(0,color='.5',lw=.6);ax.set_xticks(range(3),['0.20','0.30','0.40']);ax.set_xlim(-.3,2.3);ax.set_ylabel('Difference ×10⁻³');ax.set_title(init.title()+'; n = 12',fontsize=8,loc='left');ax.text(.5,.98,'Main: 0.30',transform=ax.transAxes,va='top',fontsize=7)
  if i:ax.set_xlabel('AC gate midpoint')
 fig.text(.57,.92,'b  Adaptive-capacity gate sensitivity',fontsize=9);f.save(fig,'Figure11');core.csvout(q,out/'plot_data/Figure11_matched100.csv');core.csvout(gate,out/'plot_data/Figure11_gate12.csv')
 supplements(core,f,style)
 # Regenerate table display payload, editable DOCX, workbook with portable libraries.
 import report_publication_tables as pub
 pub.O=out;pub.old=lambda name:pd.read_csv(D/'results/table_sources'/name);pub.part=lambda name:pd.read_csv(D/'results/part1'/name);pub.build_views()
 audit=json.loads((D/'results/report_reference/TABLE_STYLE_SOURCE_AUDIT.json').read_text('utf8'));audit['manuscript']['path']=str(C/'config/style_main.docx');audit['supplement']['path']=str(C/'config/style_supplement.docx');core.js(audit,out/'TABLE_STYLE_SOURCE_AUDIT.json')
 runpy.run_path(str(R/'05_code/report_documents.py'),run_name='__main__')
 workbook(out)
 # Native Word optional rendering on Windows; Linux uses LibreOffice when available.
 if sys.platform=='win32':
  cmd=['powershell','-NoProfile','-ExecutionPolicy','Bypass','-File',str(R/'05_code/report_render_word.ps1'),'-ReportDir',str(out)];p=subprocess.run(cmd,capture_output=True);(out/'logs/word_render.log').write_bytes(p.stdout+p.stderr);assert p.returncode==0
 elif shutil.which('libreoffice'):
  for p in out.glob('*.docx'):subprocess.run(['libreoffice','--headless','--convert-to','pdf','--outdir',str(out),str(p)],check=True)
 else:raise RuntimeError('DOCX saved; PDF requires Word on Windows or LibreOffice; no false render success')
 captions=(D/'results/report_reference/FIGURE_CAPTIONS.md').read_text('utf8')
 paras=captions.split('\n\n');paras=[x for x in paras if not any(x.startswith('Figure '+n+'.') for n in ['7','11','S5','S7'])];paras += [
 'Figure 7. Year-specific influence on the G2–H association. Three panels show 5 km, 10 km reference and 20 km. Bars are rho after omission minus full-sample rho for each year 2011–2022, with independently reranked remaining pairs (n=11 versus full n=12). Colors identify All eligible, Grade A and Local, not the sign. All 108 deletions are shown; they are sensitivity calculations, not independent observations, annual effects or causal contributions. Table 4 retains the full-sample associations.',
 'Figure 11. Sensitivity of the S4–S6 contrast to initial states and adaptive-capacity gating. (a) Same100 matched vectors, 2023 constructed-state RESET versus historical CONTINUATION, fixed2011 reference and common forcing. (b) Distinct12 vectors, two initializations and three gate midpoints. Points are medians and bars P5–P95; different y-axis scales. The0.30 midpoint is the main setting, not an optimized gate. Each scenario minimum is taken separately over2026–2030 before subtraction; axes show1000 times the paired difference and the tolerance is0.5. These are finite-set sensitivities, not forecast probability intervals.',
 'Figure S5. Existing model diagnostics. (a) Fixed-other-parameter loss scans, not profile likelihood; no unperformed alpha_TF scan is implied. (b) Full target-signal summaries at the best point. (c) Local alpha_SM minus0.1,12 fixed original starts; signed change in the S4–S6 minimum-ES contrast. Parameter bounds/quantiles remain in Table S3.',
 'Figure S7. All seven scenario ES envelopes use the same scenario styles as Figure9, common axis limits,600 retained vectors and common forcing. Shading is finite-set P5–P95, not a calibrated prediction interval. S5 remains regardless of the social screen.',
 'Figure S8. Complete26 ES-affecting specifications formerly in Figure11a. A: reporting; B: fixed-parameter checks; C: prior limited refit. Parameter and climate-path counts are distinct. Original draw-specific paired summaries are retained; n=1 is not an ensemble. Four SR-only specifications remain in the data. Near-zero negative values remain visible.']
 (out/'FIGURE_CAPTIONS.md').write_text('\n\n'.join(paras),'utf8')
 writer=PdfWriter();pages=[]
 for name in [f'Figure{i}' for i in range(3,12)]+[f'Figure_S{i}' for i in range(1,9)]:
  rd=PdfReader(out/'figures'/(name+'.pdf'));assert len(rd.pages)==1;writer.add_page(rd.pages[0]);pages.append(name)
 with (out/'Figures_3_11_and_S1_S8.pdf').open('wb') as fp:writer.write(fp)
 assert not any(x in sys.modules for x in ['sd_model','v12_formal_calibration'])
 core.js(dict(report_ODE_calls=0,optimizer_calls=0,LOYO_deletions=108,LOYO_full_checks=9,figure_bounds=f.BOUNDS,figures=pages,main_tables=3,supplement_tables=7),O/'report_report.json');core.csvout(pd.DataFrame(f.MAPROWS),out/'FIGURE_TABLE_DATA_MAP.csv')

def supplements(core,f,styles):
 # Rebuild from frozen plotting source CSV, including previously unchanged supplements.
 d=core.data('ses');colors=['#355D80','#268E80','#C87E61']
 z=pd.read_csv(core.PART1/'G_WITHIN_STAGE_PAIRED_CONTRASTS.csv');fig,axs=plt.subplots(1,4,figsize=(178/25.4,55/25.4),sharey=True)
 for ax,(ss,g) in zip(axs,z.groupby('stage',sort=True)):
  ax.errorbar(g.difference*100,range(3),xerr=np.vstack([g.difference-g.p025,g.p975-g.difference])*100,fmt='o',color=colors[0]);ax.axvline(0,color='.7',ls='--');ax.set_title(ss,fontsize=8);ax.set_yticks(range(3),g.contrast);ax.set_xlabel('Difference (pp)')
 fig.tight_layout();f.save(fig,'Figure_S1')
 z=core.data('associations');z=z[(z.scope=='FULL_2011_2023')&(z['mode']=='level')&(z.state_a=='G')&z.state_b.isin(['SP','SC','WQ','TF','SM','H'])];fig,ax=plt.subplots(figsize=(178/25.4,80/25.4));ax.errorbar(z.rho,range(len(z)),xerr=np.vstack([z.rho-z.loo_min,z.loo_max-z.rho]),fmt='o',color=colors[0]);ax.set_yticks(range(len(z)),z.state_b);ax.axvline(0,color='.7');ax.set_xlabel('G association; ρ and leave-one-year range');fig.tight_layout();f.save(fig,'Figure_S2')
 fig,axs=plt.subplots(1,2,figsize=(178/25.4,80/25.4))
 for ax,cols in zip(axs,[['G1','G2','G3'],['WQ','H']]):
  for col,color in zip(cols,colors):ax.plot(d.year,d[col],label=col,color=color)
  ax.legend();ax.set_xlabel('Year');ax.set_ylabel('Constructed component')
 fig.tight_layout();f.save(fig,'Figure_S3')
 h=core.data('historical_ensemble');bas=core.data('simple_baselines');fig,axs=plt.subplots(2,4,figsize=(178/25.4,95/25.4));
 for ax,state in zip(axs.flat,['SP','SC','NS','OS','BS','TF','SM']):
  g=h.groupby('year')[state];m=g.median();ax.fill_between(m.index,g.quantile(.05),g.quantile(.95),alpha=.2,color=colors[0]);ax.plot(m.index,m,color=colors[0],label='Model');ax.plot(d.year,d[state],'o-',ms=2,lw=.8,color=colors[2],label='Constructed');ax.axvline(2020,color='.6',ls='--');ax.set_title(state);ax.set_ylim(0,1)
  for name,line in [('Persistence',':'),('Training endpoint drift','--')]:
   train=d[d.year.le(2020)];years=d[d.year.gt(2020)].year.to_numpy();last=float(train[state].iloc[-1]);pred=np.repeat(last,len(years)) if name=='Persistence' else np.clip(last+(years-2020)*(last-float(train[state].iloc[0]))/9,.001,.999);ax.plot(years,pred,line,lw=.8,label=name)
 axs.flat[-1].axis('off');handles,labels=axs.flat[0].get_legend_handles_labels();axs.flat[-1].legend(handles,labels,fontsize=6,loc='center');fig.tight_layout();f.save(fig,'Figure_S4')
 loss=core.data('loss_scans');sat=core.data('saturation');sm=core.data('sm_summary');fig,axs=plt.subplots(1,3,figsize=(178/25.4,80/25.4))
 for i,(name,g) in enumerate(loss.groupby('parameter')):axs[0].plot((g.grid_value-g.grid_value.min())/(g.grid_value.max()-g.grid_value.min()),g.training_loss,label=name,color=colors[i])
 axs[0].legend(fontsize=6);axs[0].set(xlabel='Position in displayed scan',ylabel='Training loss',title='a  Fixed-other-parameter scans')
 q=sat[sat.parameter_role.eq('BEST_POINT')&sat.point_class.eq('FREE_HISTORY')]
 for state,col in zip(['SC','TF','SM'],colors):
  g=q[q.state.eq(state)];axs[1].plot(g.period.map({'TRAIN_2011_2020':0,'RETRO_2021_2023':1}),g.target_P50,'o-',label=state,color=col)
 axs[1].set_xticks([0,1],['Training','Retrospective'],rotation=25);axs[1].set_ylim(0,1.02);axs[1].set_title('b  Complete targets');axs[1].legend(fontsize=6)
 q=sm[sm.metric.eq('min_ES_2026_2030')&sm.quantity.eq('difference_of_contrasts')&sm.contrast.eq('S4-S6')];axs[2].errorbar(q['median']*1e6,range(len(q)),xerr=np.vstack([q['median']-q.P5,q.P95-q['median']])*1e6,fmt='o',color=colors[0]);axs[2].set_yticks(range(len(q)),q.initialization,fontsize=6);axs[2].axvline(0,color='.7');axs[2].set(xlabel='Change in contrast ×10⁻⁶',title='c  SM local −0.1; n=12');fig.tight_layout();f.save(fig,'Figure_S5')
 a=core.data('sc_reconstruction');agg=core.data('sc_aggregations');dec=core.data('sc_decomposition');fig,axs=plt.subplots(2,2,figsize=(178/25.4,115/25.4));axs[0,0].plot(a.year,a.fiscal_raw,'o-',color=colors[0]);axs[0,0].set_title('a  Revenue / expenditure');axs[0,1].plot(a.year,a.education_raw,'o-',color=colors[1]);axs[0,1].set_title('b  Teachers / 1,000 pupils')
 for name,g in agg.groupby('specification'):axs[1,0].plot(g.year,g.SC,label=name)
 axs[1,0].legend(fontsize=5);axs[1,0].set_title('c  Input-only SC alternatives');r=dec[dec.year_start.eq(2020)&dec.year_end.eq(2023)].iloc[0];axs[1,1].bar(range(4),[r.fiscal_preclip_contribution,r.education_preclip_contribution,r.fiscal_clip_adjustment_contribution,r.education_clip_adjustment_contribution],color=colors+['.7']);axs[1,1].set_xticks(range(4),['Fiscal','Education','Fiscal clip','Education clip'],rotation=25,fontsize=6);axs[1,1].set_title('d  SC change, 2020–2023');fig.tight_layout();f.save(fig,'Figure_S6')
 x=core.data('scenario_trajectories');fig,axs=plt.subplots(2,4,figsize=(178/25.4,95/25.4),sharex=True,sharey=True)
 for ax,sid in zip(axs.flat,sorted(styles)):
  g=x[x.scenario.eq(sid)].groupby('year').ES;m=g.median();ax.fill_between(m.index,g.quantile(.05),g.quantile(.95),color=styles[sid]['color'],alpha=.2);ax.plot(m.index,m,**styles[sid]);ax.set_ylim(.30,.75);ax.axvspan(2026,2028,color='.92');ax.set_title(sid)
 axs.flat[-1].axis('off');fig.subplots_adjust(left=.07,right=.98,bottom=.17,top=.92,hspace=.4,wspace=.22);fig.text(.07,.03,'600 retained vectors; finite-set P5–P95, not prediction intervals',fontsize=7);f.save(fig,'Figure_S7')

def workbook(out):
 from openpyxl import Workbook,load_workbook
 from openpyxl.styles import Font,Alignment,Border,Side
 from openpyxl.utils import get_column_letter
 specs=json.loads((out/'tables_payload_R3.json').read_text('utf8'));wb=Workbook();wb.remove(wb.active);expected=[]
 for t in specs:
  name=t['id'].replace('TableS','Table S');name=name.replace('Table2','Table 2').replace('Table3','Table 3').replace('Table4','Table 4');ws=wb[name] if name in wb.sheetnames else wb.create_sheet(name)
  if ws.max_row==1 and ws.cell(1,1).value is None:ws.append([name+'. '+t['title']])
  if t['part_title']:ws.append([t['part_title']])
  ws.append(t['columns']);hdr=ws.max_row
  for row in t['rows']:ws.append(row)
  end=ws.max_row
  for row in ws.iter_rows(min_row=hdr,max_row=end,max_col=len(t['columns'])):
   for cell in row:cell.font=Font(name='Times New Roman',size=11,bold=cell.row==hdr);cell.alignment=Alignment(horizontal='left' if cell.column==1 else 'center',vertical='center',wrap_text=True);expected.append((name,cell.coordinate,cell.value))
  for row in [hdr,end]:
   for cell in ws[row][:len(t['columns'])]:cell.border=Border(bottom=Side(style='thin'),top=Side(style='thin') if row==hdr else Side())
  ws.append([t['note']]);ws.merge_cells(start_row=ws.max_row,start_column=1,end_row=ws.max_row,end_column=len(t['columns']));ws.row_dimensions[ws.max_row].height=90;ws.cell(ws.max_row,1).alignment=Alignment(wrap_text=True,vertical='top');ws.append([])
  for j in range(len(t['columns'])):ws.column_dimensions[get_column_letter(j+1)].width=max(17,120*t['widths'][j])
  for i in range(hdr,end+1):ws.row_dimensions[i].height=42 if name!='Table S1' else 60
 path=out/'Publication_Tables.xlsx';wb.save(path);back=load_workbook(path,data_only=True);assert len(back.sheetnames)==10;assert all(back[n][cell].value==v for n,cell,v in expected);(out/'WORKBOOK_QA.json').write_text(json.dumps(dict(cells=len(expected),mismatches=0,backend='portable openpyxl; new payload authoring and saved-cell readback')),'utf8')
