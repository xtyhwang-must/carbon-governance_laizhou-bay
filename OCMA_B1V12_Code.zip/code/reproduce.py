"""Portable, finite reproduction entry; never optimizes without full-analysis authorization."""
from pathlib import Path
import argparse,json,sys,os,shutil,subprocess,hashlib,importlib.metadata
C=Path(__file__).resolve().parent

def dump(p,z):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(z,ensure_ascii=False,indent=2,default=str),'utf8')
def assemble(data,out):
 r=out/'runtime';r.mkdir(parents=True,exist_ok=True)
 shutil.copytree(data/'processed/part2',r,dirs_exist_ok=True)
 shutil.copytree(C/'part2',r/'05_code',dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__','synthetic_tests','node_modules'))
 shutil.copytree(C/'part2/historical_code_reference',r/'00_handoff/historical_code_reference',dirs_exist_ok=True)
 return r

def main():
 p=argparse.ArgumentParser();p.add_argument('--stage',choices=['report','rebuild-derived','replay','full-analysis'],required=True);p.add_argument('--data-root',type=Path,default=C.parent/'data');p.add_argument('--output-root',type=Path,default=C.parent/'work');p.add_argument('--config',type=Path,default=C/'config/reproduction.json');a=p.parse_args();d=a.data_root.resolve();o=a.output_root.resolve();o.mkdir(parents=True,exist_ok=True)
 if o==d or d in o.parents:raise ValueError('Outputs cannot be under frozen data')
 cfg=json.loads(a.config.resolve().read_text('utf8'));dump(o/'effective_execution_config.json',cfg)
 if a.stage=='full-analysis':
  r=assemble(d,o)
  stages=['compare','calibrate','evaluate','scenarios','robustness','attribution','mechanisms','surface','numerical']
  z={'runtime_root':str(r),'commands':[[sys.executable,str(r/'05_code/run_v12.py'),'--stage',x] for x in stages],'dependency_files_present':all((r/'05_code'/n).exists() for n in ['compare_structures.py','v12_formal_calibration.py','engine/sd_model.py']),'executed':False,'optimizer_calls':0,'plan':['run_v12.py --stage compare','run_v12.py --stage calibrate','run_v12.py --stage evaluate','run_v12.py --stage scenarios','run_v12.py --stage attribution'],'note':'Inspect packaged run_v12 CLI and frozen protocol; full optimization is opt-in, not part of this release verification.'};dump(o/'full_analysis_plan.json',z);print(json.dumps(z));return
 r=assemble(d,o);env=dict(os.environ,PYTHONPATH='',PYTHONNOUSERSITE='1',PYTHONIOENCODING='utf-8',MPLCONFIGDIR=str(o/'matplotlib_runtime'));cmd=[sys.executable,str(C/'shared/worker.py'),a.stage,str(d),str(o),str(r)]
 q=subprocess.run(cmd,env=env,cwd=o,capture_output=True,text=True,encoding='utf8');(o/(a.stage+'.log')).write_text(q.stdout+q.stderr,'utf8');print(q.stdout);print(q.stderr,file=sys.stderr)
 if q.returncode:raise SystemExit(q.returncode)
if __name__=='__main__':main()
