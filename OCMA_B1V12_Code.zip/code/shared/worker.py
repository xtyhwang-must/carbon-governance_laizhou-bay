from pathlib import Path
import sys,os,json,hashlib,shutil,math
import numpy as np,pandas as pd
C=Path(__file__).resolve().parents[1];stage,D,O,R=sys.argv[1],*map(Path,sys.argv[2:]);reads=[]
def audit(event,args):
 if event=='open' and isinstance(args[0],(str,bytes)):
  s=os.fsdecode(args[0])
  if s.endswith(('.csv','.json','.yaml','.npz','.pkl','.joblib','.txt')):
   p=Path(s).resolve();allowed=[D.resolve(),O.resolve(),C.resolve(),Path(sys.prefix).resolve(),Path(sys.base_prefix).resolve()];reads.append(str(p))
   if not any(p==x or x in p.parents for x in allowed):raise RuntimeError('Research read outside package: '+str(p))
sys.addaudithook(audit)
def save(name,z):p=O/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(z,ensure_ascii=False,indent=2,default=str),'utf8')
def read(p):return pd.read_csv(p,keep_default_na=False)
def compare(a,b,keys,cols,tol=5e-6):
 x=a.set_index(keys).sort_index();y=b.set_index(keys).sort_index();assert x.index.equals(y.index),keys
 z=abs(x[cols].to_numpy(float)-y[cols].to_numpy(float));err=float(np.nanmax(z));assert err<=tol,(keys,err,tol);return err
sys.path[:0]=[str(R/'05_code'),str(R/'05_code/engine'),str(C/'part1'),str(C/'reporting')]
if stage=='rebuild-derived':
 import ht_kernels as h
 q=D/'processed/part1';f=read(q/'frame.csv');s=read(q/'sample.csv');a=read(q/'primary.csv');b=read(q/'secondary.csv');al=read(q/'allocation.csv')
 m,t=h.estimate_direct_stratified_HT(f,s,a,al);ps,st=h.evaluate_function_history(f,m);changes=h.stage_changes(st)
 dest=O/'rebuilt/part1';dest.mkdir(parents=True,exist_ok=True)
 checks={}
 h.independent_coding_agreement(a.assign(reviewer='CODER_1'),b.assign(reviewer='CODER_2'),'G_ONLY')[0].to_csv(dest/'independent_coding_agreement.csv',index=False)
 changes.to_csv(dest/'stage_changes.csv',index=False)
 for name,x,keys,cols in [('G_POLICY_HT_TOTALS.csv',t,['policy_id','feature'],['estimated_total','standard_error']),('G_POLICY_HT_SHARES.csv',ps,['policy_id','label'],['design_corrected_share','standard_error','assignment_denominator']),('G_STAGE_HT_ESTIMATES.csv',st,['stage','label'],['design_corrected_share','standard_error'])]:
  checks[name]=compare(x,read(q/name),keys,cols,1e-10);x.to_csv(dest/name,index=False)
 cov=[]
 for pid,(_,mat,_,_) in m.items():
  for i,k in enumerate(['eligibility']+h.G):
   for j,l in enumerate(['eligibility']+h.G):cov.append(dict(policy_id=pid,feature_1=k,feature_2=l,covariance=mat[i,j]))
 cv=pd.DataFrame(cov);checks['covariance']=compare(cv,read(q/'G_POLICY_HT_COVARIANCE.csv'),['policy_id','feature_1','feature_2'],['covariance'],1e-9);cv.to_csv(dest/'covariance.csv',index=False)
 ids=json.loads((q/'bootstrap_policy_index_map.json').read_text('utf8'));draw=np.load(q/'bootstrap_policy_indices.npz');rows=[]
 for i,ss in enumerate(h.STAGES):
  z=ps[ps.stage.eq(ss)].pivot(index='policy_id',columns='label',values='design_corrected_share').reindex(ids[ss])[h.G];vals=z.to_numpy()[draw[f'stage_{i}']].mean(1)
  for j,g in enumerate(h.G):rows.append(dict(stage=ss,label=g,HT_policy_equal_share=z[g].mean(),policy_bootstrap_p025=np.quantile(vals[:,j],.025),policy_bootstrap_p975=np.quantile(vals[:,j],.975)))
 boot=pd.DataFrame(rows);checks['bootstrap']=compare(boot,read(q/'Table2_updated.csv'),['stage','label'],['HT_policy_equal_share','policy_bootstrap_p025','policy_bootstrap_p975'],1e-12);boot.to_csv(dest/'bootstrap.csv',index=False)
 # Audit returns are frozen inputs; no drawing or labels created.
 import part2_ht_bridge as bridge
 bridge.main()
 import build_evidence as ev
 ev.indicator_chain()
 for name,keys,cols in [('03_indicators/model_input_B1.csv',['year'],['G1','G2','G3','SP','SC','NS','OS','BS','TF','SM','SR','ES','IM']),('02_policy/reconstructed/policy_stock_by_year_B1.csv',['year','channel'],['active_valid_policy_stock','G_observed_supply'])]:checks[name]=compare(read(R/name),read(D/'processed/part2'/name),keys,cols,5e-10)
 import part2_ses as ses
 sesframe=read(R/'03_indicators/model_input_B1.csv');sesframe['G']=sesframe[['G1','G2','G3']].mean(axis=1)
 associations=pd.DataFrame(ses.associations(sesframe,'FULL_2011_2023')+ses.associations(sesframe[sesframe.year.le(2022)],'EXCLUDE_ESTIMATED_2023'));ref=read(D/'processed/part2/06_runs/ses/associations_and_sensitivities.csv');ref=ref[ref.scope.isin(associations.scope)];checks['SES_associations']=compare(associations,ref,['scope','mode','state_a','state_b'],['rho','p_descriptive','loo_min','loo_max'],1e-12);associations.to_csv(O/'rebuilt/SES_associations.csv',index=False)
 save('rebuild_report.json',dict(checks=checks,primary_n=len(a),secondary_n=len(b),fixed_frame_n=len(f),scope='Actual frozen structured human inputs to HT/covariance/stages/original Bootstrap; prepared indicator tables to stocks and model input. Original carrier extraction and ML retraining not rerun.',optimizer_calls=0,ODE_calls=0))
elif stage=='replay':
 import sd_model as model
 calls=[];original=model.simulate
 def counted(*args,**kwargs):calls.append(dict(structure=kwargs.get('structure')));return original(*args,**kwargs)
 model.simulate=counted
 from v12_evaluation import one
 from v12_scenarios import vector_job
 from v12_attribution import one as attr
 from numeric_analysis import load_settings
 f=read(R/'03_indicators/model_input_B1.csv');cal=R/'06_runs/formal_main/calibration';status=json.loads((cal/'formal_calibration_status.json').read_text('utf8'));structure=status['structure'];names=model.parameter_names(structure);ens=read(cal/'accepted_parameter_ensemble.csv');best=json.loads((cal/'best_parameter_set.json').read_text('utf8'));params=best.get('parameters',best.get('params'));assert params is not None,best.keys()
 climate=read(R/'06_runs/formal_main/scenarios/common_climate_draw_001.csv');settings=load_settings();frozenH=read(R/'06_runs/formal_main/evaluation/historical_ensemble_trajectories.csv');frozenS=read(R/'06_runs/formal_main/scenarios/scenario_trajectories_long.csv');fields=['G1','G2','G3','SP','SC','NS','OS','BS','TF','SM','PR','PRS','IM','ES','SR'];rows=[]
 for pid,par in [('BEST',params)]+[(str(r.parameter_set_id),{k:float(r[k]) for k in names}) for _,r in ens.iloc[:2].iterrows()]:
  hist,_=one((pid,par,structure,f));_,sc=vector_job((pid,par,structure,f,settings,climate));hist.to_csv(O/(pid+'_history.csv'),index=False);sc.to_csv(O/(pid+'_scenarios.csv'),index=False)
  if pid=='BEST':
   ref=read(cal/'best_prediction_2011_2023.csv');eh=compare(hist,ref,['year'],[x for x in fields if x in ref],5e-6);es=None
  else:eh=compare(hist,frozenH[frozenH.parameter_set_id.eq(pid)],['year'],fields);es=compare(sc,frozenS[frozenS.parameter_set_id.eq(pid)],['scenario','year'],fields)
  rows.append(dict(parameter_set_id=pid,history_max_error=eh,scenario_max_error=es,scenario_comparison='no stored best-scenario reference; finite execution only' if pid=='BEST' else 'frozen exact-ID reference'))
 pid=str(ens.iloc[0].parameter_set_id);par={k:float(ens.iloc[0][k]) for k in names};con,coal=attr((pid,par,structure,f,climate,settings));ref=read(R/'06_runs/formal_main/attribution/coalition_outputs_and_inputs.csv');ec=compare(coal,ref[ref.parameter_set_id.eq(pid)],['contrast','coalition_mask'],['min_ES_2026_2030','ES_2030','SR_2030']);coal.to_csv(O/'one_vector_coalitions.csv',index=False)
 from v12_attribution import shapley,group_spec
 closures=[]
 for contrast,z in coal.groupby('contrast'):
  for metric in ['min_ES_2026_2030','ES_2030','SR_2030']:
   delta,phis=shapley(z,list(group_spec(contrast.split('-')[1],'S4')),metric);closures.append(dict(contrast=contrast,metric=metric,total=delta,closure=sum(x[1] for x in phis)-delta))
 pd.DataFrame(closures).to_csv(O/'one_vector_closure.csv',index=False)
 save('replay_report.json',dict(vectors=rows,coalition_max_error=ec,ODE_calls=len(calls),historical_vectors=3,scenario_trajectories=21,coalitions=24,optimizer_calls=0,full_calibration_recomputed=False,selection='BEST plus first two frozen accepted IDs; attribution first accepted ID'))
elif stage=='report':
 import publication_report
 publication_report.run(D,O,R)
save(stage+'_read_trace.json',dict(reads=sorted(set(reads)),research_reads_outside_package_or_output=[p for p in sorted(set(reads)) if not any(Path(p)==x or x in Path(p).parents for x in [D.resolve(),O.resolve(),C.resolve(),Path(sys.prefix).resolve(),Path(sys.base_prefix).resolve()])]))
