# Code and package changes

Original files checked against716 staging hashes:unchanged. Adapted build_evidence reads the packaged SST preparation CSV; model input and stocks reproduced exactly. Original model/solver equations, best and600 vectors are unchanged. The original numerical source code is copied under provenance, not only linked.

The portable worker extracts existing HT functions without equation edits, assembles compatible runtime directories from package data and rejects out-of-package research reads. Stable CODER_1/CODER_2 replace personal identifiers for the actual two-role agreement calculation; independently-entered field flags are retained.

Final reporting changes:Figure7 adds108 exact LOYO display values;Figure11 splits100 initialization and12 gate checks;S8 carries the full26 ES matrix;S5 removes repeated parameter distributions;Figure9/S7 styles match;Figure8 direction markers are independent of the unchanged magnitude width. The original baseline clipping rule(.001,.999) is retained in FigureS4, with14 weighted RMSE checks against frozen outputs.

Excluded from delivery:synthetic test trees, caches, R3 publication duplicates,private original review sheets,private correspondence,redacted empty manuscript/reviewer text derivative files. Local originals and rejected-removal directories are not deleted. Legacy compatibility modules remain where full-analysis dependencies are not ruled out; optional full-analysis has not been certified end to end.

Final publication manifests replace old current-page status only for this deliverable. No original R3 or formal numerical outputs are overwritten.
