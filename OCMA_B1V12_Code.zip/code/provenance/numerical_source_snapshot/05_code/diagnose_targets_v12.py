"""Observation-reset target decomposition, checked against actual RHS for seven states."""
from __future__ import annotations
import argparse,json,sys
from pathlib import Path
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'05_code/engine'),str(ROOT/'05_code')]
import engine_config as cfg
import sd_model as m
from v12_modeling import reference_for

STATES=['SP','SC','NS','OS','BS','TF','SM']
IDX=[3,4,5,6,7,8,9]

def terms(state,exo,baseline,p,structure):
    g1,g2,g3,sp,sc,ns,os_,bs,tf,sm,pr,prs,im=state
    mode=m.ModelMode();rep=m.reporting_states(state)
    wq=float(rep['WQ']);hab=float(rep['H'])
    pre=float(np.clip((3*pr-prs)/2,0,1))
    social_memory=(prs+2*pre)/3
    a1,a2,a3,im_ops,im_capacity=m._actions(state,exo,p,mode)
    nd=float(np.mean([exo['PPT'],exo['RUNOFF'],exo['SST']]))
    compound=float(np.cbrt(max(exo['PPT']*exo['RUNOFF']*exo['SST'],1e-9)))
    nutrient=.58*sp+.42*exo['RUNOFF']
    oxygen=.34*sp+.23*exo['RUNOFF']+.23*bs+.20*exo['SST']
    bloom_trigger=float(m.hill(ns,.48,3.0));bloom=bloom_trigger*(.50*exo['SST']+.30*os_+.20*exo['RUNOFF'])
    habitat_driver=.60*sp+.40*compound
    core={
      'SP':(m.logit(baseline['SP']),
        {'risk':p['k_pressure_feedback']*(social_memory-baseline['PR']),
         'natural':.30*p['k_natural']*(nd-baseline['ND']),
         'compound':.25*p['k_compound']*(compound-baseline['COMPOUND']),
         'governance':-p['k_governance']*(a1-baseline['A1']),
         'capacity':-.50*p['k_adaptive']*(sc-baseline['SC'])}),
      'SC':((p['alpha_AC'] if structure in ['M1_AC_INTERCEPT','M2_AC_SM_INTERCEPTS','M3_AC_SM_TF_INTERCEPTS'] else m.logit(baseline['SC'])),
        {'capacity':p['k_adaptive']*(a3-baseline['A3']),
         'habitat':.55*(hab-baseline['H']),'pressure':-.78*(sp-baseline['SP']),
         'compound':-.20*p['k_compound']*(compound-baseline['COMPOUND'])}),
      'NS':(m.logit(baseline['NS']),{'natural':p['k_natural']*(nutrient-baseline['NUTRIENT_DRIVER']),
         'compound':p['k_compound']*(compound-baseline['COMPOUND']),
         'governance':-p['k_governance']*(a1-baseline['A1'])}),
      'OS':(m.logit(baseline['OS']),{'natural':.82*p['k_natural']*(oxygen-baseline['OXYGEN_DRIVER']),
         'compound':.52*p['k_compound']*(compound-baseline['COMPOUND']),
         'governance':-.78*p['k_governance']*(a1-baseline['A1'])}),
      'BS':(m.logit(baseline['BS']),{'bloom':p['k_bloom']*(bloom-baseline['BLOOM_DRIVER']),
         'compound':.55*p['k_compound']*(compound-baseline['COMPOUND']),
         'governance':-.58*p['k_governance']*(a1-baseline['A1'])}),
      'TF':((p['alpha_TF'] if structure=='M3_AC_SM_TF_INTERCEPTS' else m.logit(baseline['TF'])),{'restoration':p['k_restore']*(a2-baseline['A2']),
         'habitat_pressure':-p['k_natural']*(habitat_driver-baseline['HABITAT_DRIVER']),
         'capacity':.22*p['k_adaptive']*(sc-baseline['SC'])}),
      'SM':((p['alpha_SM'] if structure in ['M2_AC_SM_INTERCEPTS','M3_AC_SM_TF_INTERCEPTS'] else m.logit(baseline['SM'])),
        {'restoration':1.20*p['k_restore']*(a2-baseline['A2']),
         'habitat_pressure':-.82*p['k_natural']*(habitat_driver-baseline['HABITAT_DRIVER']),
         'capacity':.30*p['k_adaptive']*(sc-baseline['SC'])})}
    conversion_tf=mode.tf_sm_conversion_scale*a2*tf*(1-sm)
    conversion_sm=cfg.TF_TO_SM_AREA_SCALE_RATIO*conversion_tf
    rows=[]
    for name,index in zip(STATES,IDX):
        intercept,drivers=core[name];signal=float(intercept+sum(drivers.values()));target=float(m.logistic(signal))
        rate=float(p['r_social'] if name in ['SP','SC'] else p['r_water'] if name in ['NS','OS','BS'] else
             p['r_habitat']*(1.70 if name=='TF' and target<state[index] else
             1.55 if name=='SM' and target<state[index] else 1.0))
        converted= -conversion_tf if name=='TF' else conversion_sm if name=='SM' else 0.
        expected_derivative=rate*(target-state[index])+converted
        rows.append({'state':name,'state_index':index,'observed':float(state[index]),
           'target_logit_intercept':float(intercept),'driver_terms_json':json.dumps(drivers,ensure_ascii=False),
           'target_signal':signal,'target_state':target,'adjustment_rate':rate,
           'conversion_term':converted,'reconstructed_derivative':expected_derivative,
           'G1':g1,'G2':g2,'G3':g3,'IM':im,'A1':a1,'A2':a2,'A3':a3,
           'implementation_ops':im_ops,'implementation_capacity':im_capacity,
           'WQ':wq,'H':hab,'risk_memory_PR':pr,'social_risk_memory_PRS':prs,
           'raw_state_clipped_for_RHS':bool(state[index]<.001 or state[index]>.999)})
    return rows

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--structure',default='M0_RUN_SPECIFIC')
    parser.add_argument('--parameter-json',default='00_reference_v1_1/calibration/best_parameter_set.json')
    parser.add_argument('--output',default='06_runs/P1_structure_diagnostics')
    args=parser.parse_args()
    frame=pd.read_csv(ROOT/'03_indicators/model_input_B1.csv').sort_values('year')
    payload=json.loads((ROOT/args.parameter_json).read_text(encoding='utf-8'))
    parameters=payload['parameters'] if 'parameters' in payload else payload
    p=m.parameter_dict(parameters,structure=args.structure)
    forcing=m.historical_forcing(frame);initial=m.initial_state(frame,year=2011)
    baseline=reference_for(frame,forcing,initial,parameters,args.structure)
    if baseline is None:baseline=m._baseline_context(initial,forcing.at(2011.),p,m.ModelMode())
    prediction=m.simulate(parameters,forcing,frame.year.to_numpy(float),initial,
        structure=args.structure,reference_context=baseline if args.structure!='M0_RUN_SPECIFIC' else None)
    lineage=pd.read_csv(ROOT/'03_indicators/indicator_lineage.csv').set_index(['year','state_id'])
    records=[]
    for r in frame.itertuples(index=False):
        year=int(r.year);state=np.array([float(getattr(r,name)) for name in cfg.STATE_NAMES]);exo=forcing.at(float(year))
        expected=m.rhs(float(year),state,p,forcing,baseline,m.ModelMode(),args.structure)
        for row in terms(state,exo,baseline,p,args.structure):
            name=row['state'];index=row.pop('state_index')
            assert abs(row['reconstructed_derivative']-expected[index])<1e-10,(year,name)
            source_name='AC' if name=='SC' else name
            source=lineage.loc[(year,source_name)]
            row.update({'year':year,'structure':args.structure,
                'observed_raw_value':source.raw_value,'observed_raw_unit':source.raw_unit,
                'transformation':source.transformation,'source_row_locator':source.source_row_locator,
                'simulated_free_run':float(prediction.loc[prediction.year.eq(year),name].iloc[0]),
                'free_run_error':float(prediction.loc[prediction.year.eq(year),name].iloc[0]-row['observed']),
                'RHS_derivative':float(expected[index]),'RHS_reconstruction_error':row['reconstructed_derivative']-expected[index],
                'diagnostic_role':'OBSERVATION_RESET_DIAGNOSTIC_NOT_FREE_RUN_VALIDATION'})
            records.append(row)
    out=ROOT/args.output;out.mkdir(parents=True,exist_ok=True)
    pd.DataFrame(records).to_csv(out/f'{args.structure}_seven_state_targets.csv',index=False,encoding='utf-8-sig')
    (out/f'{args.structure}_reference_context.json').write_text(json.dumps(baseline,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'structure':args.structure,'rows':len(records),
      'maximum_RHS_reconstruction_error':float(max(abs(x['RHS_reconstruction_error']) for x in records))},ensure_ascii=False))

if __name__=='__main__':main()
