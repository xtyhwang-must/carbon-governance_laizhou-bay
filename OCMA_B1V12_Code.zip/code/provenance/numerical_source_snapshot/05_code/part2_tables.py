"""Part2 same-version registries and report data; does not change numerical inputs."""
from pathlib import Path
import ast,json,sys
import numpy as np,pandas as pd
ROOT=Path(__file__).resolve().parents[1];sys.path[:0]=[str(ROOT/'05_code/engine'),str(ROOT/'05_code')]
import engine_config as cfg,sd_model as model
OUT=ROOT/'07_publication';CAL=ROOT/'06_runs/formal_main/calibration'
def write(df,name):df.to_csv(OUT/name,index=False,encoding='utf-8-sig')
def register():
 selection=json.loads((ROOT/'06_runs/structure_compare/model_selection.json').read_text('utf8'));structure=selection['selected_structure'];names=model.parameter_names(structure)
 rows=[]
 for n in names:
  low,high=(cfg.PARAMETER_BOUNDS|cfg.STRUCTURAL_PARAMETER_BOUNDS)[n];rows.append(dict(parameter=n,lower=low,upper=high,role='CALIBRATED',support='NUMERIC_LOGIT_BACKGROUND_NOT_EMPIRICAL_PRIOR' if n.startswith('alpha') else 'LEGACY_NINE_PARAMETER_RANGE',structure=structure))
 pd.DataFrame(rows).to_csv(ROOT/'04_model/parameter_registry.csv',index=False,encoding='utf-8-sig')
 tree=ast.parse((ROOT/'05_code/engine/sd_model.py').read_text('utf8'));rhs=next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=='rhs');eq=[]
 for x in rhs.body:
  if isinstance(x,ast.Assign):
   label=ast.unparse(x.targets[0])
   if label.endswith(('_signal','_target')) or label in ['dg','dim','dpr','dprs','dsp','dsc','dns','dos','dbs','dtf','dsm','conversion_tf_units','conversion_sm_units']:
    eq.append(dict(variable=label,formula=ast.unparse(x.value),code='engine/sd_model.py::rhs',line=x.lineno,structure=structure))
 pd.DataFrame(eq).to_csv(ROOT/'04_model/equation_registry.csv',index=False,encoding='utf-8-sig')
 return structure,names

def main():
 OUT.mkdir(exist_ok=True);structure,names=register();status=json.loads((CAL/'formal_calibration_status.json').read_text('utf8'));ens=pd.read_csv(CAL/'accepted_parameter_ensemble.csv')
 rows=[]
 for n in names:
  lo,hi=(cfg.PARAMETER_BOUNDS|cfg.STRUCTURAL_PARAMETER_BOUNDS)[n];x=ens[n];u=(x-lo)/(hi-lo)
  rows.append(dict(parameter=n,lower=lo,upper=hi,n=len(x),P5=x.quantile(.05),P50=x.median(),P95=x.quantile(.95),exact_boundary_fraction=((x==lo)|(x==hi)).mean(),near_1pct_boundary_fraction=((u<=.01)|(u>=.99)).mean(),identity='ACCEPTED_SET_NOT_POSTERIOR'))
 write(pd.DataFrame(rows),'Table_S4_parameter_summary.csv')
 metrics=pd.read_csv(ROOT/'06_runs/formal_main/evaluation/retrospective_state_summary.csv');base=pd.read_csv(ROOT/'06_runs/formal_main/evaluation/simple_baselines.csv');comp=[]
 for r in metrics[(metrics.state_role=='BASIC')&(metrics['2023_estimate_treatment']=='weighted')].itertuples():
  for b in base[base.state.eq(r.state)].itertuples():comp.append(dict(state=r.state,model_median_RMSE=r.RMSE,benchmark=b.benchmark,baseline_RMSE=b.RMSE,model_better=r.RMSE<b.RMSE))
 write(pd.DataFrame(comp),'Table_S15_model_vs_baselines.csv')
 # Descriptive residual addition fixed before evaluation; no fitted multiplier or coverage targeting.
 env=pd.read_csv(ROOT/'06_runs/formal_main/evaluation/pure_parameter_envelope.csv');res=pd.read_csv(ROOT/'06_runs/formal_main/evaluation/training_year_median_residuals_descriptive.csv');ext=[]
 for state,z in res.groupby('state'):
  low,high=z.observed_minus_ensemble_median.quantile([.05,.95])
  for r in env[env.year.ge(2021)].to_dict('records'):ext.append(dict(year=r['year'],state=state,lower=r[state+'_P5']+low,upper=r[state+'_P95']+high,identity='DESCRIPTIVE_PARAMETER_PLUS_TRAIN_YEAR_RESIDUAL_QUANTILES_NOT_PREDICTIVE_INTERVAL',n_residual_years=len(z)))
 write(pd.DataFrame(ext),'residual_extension_descriptive.csv')
 reported=[]
 for p in [ROOT/'06_runs/ses/state_trends_and_endpoints.csv',ROOT/'06_runs/formal_main/scenarios/scenario_summary.csv',ROOT/'06_runs/formal_main/scenarios/all_pair_tolerance_summary.csv']:
  for i,r in pd.read_csv(p).iterrows():
   for k,v in r.items():reported.append(dict(source=str(p.relative_to(ROOT)),row=int(i),field=k,value=v,run_id='B1V12_PART2_HT_20261028'))
 write(pd.DataFrame(reported),'reported_statistics.csv')
 import part2_export_result_tables
 print('Part2 parameter/equation registry and report statistics written',structure,len(names))
if __name__=='__main__':main()
