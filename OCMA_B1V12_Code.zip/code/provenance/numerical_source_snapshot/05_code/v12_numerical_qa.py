"""Step-size QA on matched scenario differences, with targeted 0.01-year fallback."""
from __future__ import annotations
import hashlib,json,sys
from pathlib import Path
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'05_code/engine'),str(ROOT/'05_code')]
import sd_model as model
from numeric_analysis import load_settings,scenario_forcing
from v12_modeling import reference_for
from cache_safety import atomic_json

CAL=ROOT/'06_runs/formal_main/calibration'
SCEN=ROOT/'06_runs/formal_main/scenarios'
OUT=ROOT/'06_runs/formal_main/qa'
PAIRS=[('S4','S0'),('S6','S0'),('S4','S6'),('S5','S0')]

def metrics(pred):
    shock=pred[pred.year.between(2026,2030)]
    end=pred[pred.year.eq(2030)].iloc[0]
    return {'min_ES_2026_2030':float(shock.ES.min()),'ES_2030':float(end.ES),
        'SR_2030':float(end.SR)}

def one_vector(pid,params,structure,frame,climate,settings,step):
    initial=model.initial_state(frame,year=2023)
    hist=model.historical_forcing(frame)
    ref=reference_for(frame,hist,model.initial_state(frame,year=2011),params,structure)
    out={}
    for sid in sorted({s for pair in PAIRS for s in pair}):
        forcing,_,_=scenario_forcing(frame,settings[sid],climate)
        pred=model.simulate(params,forcing,np.arange(2023,2031,dtype=float),initial,
            structure=structure,reference_context=ref,max_step=step)
        out[sid]=metrics(pred)
    return out

def main():
    OUT.mkdir(parents=True,exist_ok=True)
    frame=pd.read_csv(ROOT/'03_indicators/model_input_B1.csv').sort_values('year').reset_index(drop=True)
    status=json.loads((CAL/'formal_calibration_status.json').read_text(encoding='utf-8'))
    structure=status['structure'];names=model.parameter_names(structure)
    ensemble=pd.read_csv(CAL/'accepted_parameter_ensemble.csv')
    if ensemble.empty:raise RuntimeError('Cannot assess ensemble numerical ranking with no accepted vectors')
    sample=ensemble.iloc[np.unique(np.linspace(0,len(ensemble)-1,min(12,len(ensemble)),dtype=int))]
    settings=load_settings();climate=pd.read_csv(SCEN/'common_climate_draw_001.csv')
    primary=pd.read_csv(SCEN/'scenario_metrics_by_parameter.csv').set_index(['parameter_set_id','scenario'])
    rows=[]
    for r in sample.itertuples(index=False):
        pid=r.parameter_set_id;params={n:float(getattr(r,n)) for n in names}
        result={step:one_vector(pid,params,structure,frame,climate,settings,step) for step in [.05,.02]}
        for a,b in PAIRS:
            for metric in ['min_ES_2026_2030','ES_2030','SR_2030']:
                d05=result[.05][a][metric]-result[.05][b][metric]
                d02=result[.02][a][metric]-result[.02][b][metric]
                main=float(primary.loc[(pid,a),metric]-primary.loc[(pid,b),metric])
                if abs(main-d05)>1e-10:raise AssertionError('Main and numerical .05 paths differ')
                near=abs(d02)<=.0005+abs(d05-d02)
                need01=near or abs(d05-d02)>5e-5
                if need01 and .01 not in result:
                    result[.01]=one_vector(pid,params,structure,frame,climate,settings,.01)
                d01=(result[.01][a][metric]-result[.01][b][metric]) if need01 else np.nan
                err=abs(d02-d01) if need01 else abs(d05-d02)
                rows.append({'parameter_set_id':pid,'contrast':a+'-'+b,'metric':metric,
                    'D_step_005':d05,'D_step_002':d02,'D_step_001_if_needed':d01,
                    'step_error_estimate':err,'0p01_triggered':need01,
                    'near_0p0005_tolerance':bool(near),'numerically_distinguishable':bool(abs(d02)>.0005+err),
                    'numeric_error_too_large':bool(err>5e-5)})
        print(f'numeric QA {pid}',flush=True)
    audit=pd.DataFrame(rows);audit.to_csv(OUT/'paired_step_size_audit.csv',index=False,encoding='utf-8-sig')
    status={'complete':True,'tested_parameter_sets':len(sample),'contrasts':[a+'-'+b for a,b in PAIRS],
        'steps':[.05,.02,.01],'fallback_count':int(audit['0p01_triggered'].sum()),
        'max_step_error_estimate':float(audit.step_error_estimate.max()),
        'numeric_error_gate_pass':not bool(audit.numeric_error_too_large.any()),
        'near_tolerance_count':int(audit.near_0p0005_tolerance.sum()),
        'all_005_match_main':True}
    atomic_json(OUT/'numerical_qa_status.json',status)
    print(json.dumps(status),flush=True)

if __name__=='__main__':main()
