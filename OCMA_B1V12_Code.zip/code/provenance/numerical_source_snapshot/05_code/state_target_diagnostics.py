"""Inspect AC and SM target terms on the observed B1 path at fitted parameters."""
from __future__ import annotations
import json,sys
from pathlib import Path
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'05_code/engine'),str(ROOT/'05_code')]
import sd_model as m
import engine_config as c

def main():
    frame=pd.read_csv(ROOT/'03_indicators/model_input_B1.csv').sort_values('year')
    best=json.loads((ROOT/'06_runs/B1_v1_1/calibration/best_parameter_set.json').read_text(encoding='utf-8'))['parameters']
    p=m.parameter_dict(best);forcing=m.historical_forcing(frame);initial=m.initial_state(frame,year=2011)
    mode=m.ModelMode();base=m._baseline_context(initial,forcing.at(2011.),p,mode)
    pmax=c.PARAMETER_BOUNDS
    sc_signal_upper=(m.logit(base['SC'])+
        pmax['k_adaptive'][1]*(1-base['A3'])+
        .55*(1-base['H'])+.78*base['SP']+
        .20*p['k_compound']*base['COMPOUND'])
    sc_global_target_upper=float(m.logistic(sc_signal_upper))
    predicted=m.simulate(best,forcing,frame.year.to_numpy(float),initial)
    records=[]
    for i,r in frame.iterrows():
        obs=r[c.STATE_NAMES].to_numpy(float);time=float(r.year)
        exo=forcing.at(time)
        derivative=m.rhs(time,obs,p,forcing,base,mode)
        sc_target=obs[4]+derivative[4]/p['r_social']
        a2=m._actions(obs,exo,p,mode)[1]
        conversion_tf=mode.tf_sm_conversion_scale*a2*obs[8]*(1-obs[9])
        conversion_sm=c.TF_TO_SM_AREA_SCALE_RATIO*conversion_tf
        sm_pure=derivative[9]-conversion_sm
        sm_rate=p['r_habitat']*(1.55 if sm_pure<0 else 1.0)
        sm_target=obs[9]+sm_pure/sm_rate
        for state,index,target in [('AC',4,sc_target),('SM',9,sm_target)]:
            records.append({'year':int(time),'state':state,'observed_state':obs[index],
                'model_target_term_on_observed_path':target,'model_derivative_on_observed_path':derivative[index],
                'observed_next_year':float(frame.iloc[i+1]['SC' if state=='AC' else 'SM']) if i<len(frame)-1 else np.nan,
                'best_simulated_state':float(predicted.iloc[i][c.STATE_NAMES[index]]),
                'diagnostic_role':'target_term_at_observed_path_not_a_validation_or_global_reachability_proof'})
    out=ROOT/'06_runs/B1_v1_1/evaluation';out.mkdir(parents=True,exist_ok=True)
    pd.DataFrame(records).to_csv(out/'AC_SM_target_terms.csv',index=False,encoding='utf-8-sig')
    table=[]
    for state,g in pd.DataFrame(records).query('year<=2020').groupby('state'):
        table.append({'state':state,'observed_max_2011_2020':g.observed_state.max(),
          'target_max_on_observed_path':g.model_target_term_on_observed_path.max(),
          'best_simulated_max_2011_2020':g.best_simulated_state.max(),
          'max_target_minus_observed_max':g.model_target_term_on_observed_path.max()-g.observed_state.max(),
          'global_target_upper_bound':sc_global_target_upper if state=='AC' else np.nan,
          'observed_exceeds_global_target_bound':bool(g.observed_state.max()>sc_global_target_upper) if state=='AC' else np.nan,
          'interpretation':'AC_global_upper_from_registered_parameter_box_and_state_bounds' if state=='AC' else 'SM_local_target_diagnostic_not_global_feasibility_bound'})
    pd.DataFrame(table).to_csv(out/'AC_SM_reachability_diagnostics.csv',index=False,encoding='utf-8-sig')
    print(json.dumps(table,ensure_ascii=False))

if __name__=='__main__':main()
