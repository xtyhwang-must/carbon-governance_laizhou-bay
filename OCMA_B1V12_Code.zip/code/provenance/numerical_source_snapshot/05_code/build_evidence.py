"""Rebuild B1 inputs from packaged, source-reconstructed, author-adopted tables.

The original human clause fields remain blank; date assumptions stay distinct
from observed legal facts. All reads are inside the B1 workspace.
"""
from pathlib import Path
import hashlib
import json
import re
import sys
import platform

import numpy as np
import pandas as pd
import yaml
from scipy.stats import spearmanr, theilslopes

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / '01_sources'
OUT_POLICY = ROOT / '02_policy'
OUT_IND = ROOT / '03_indicators'
OUT_MODEL = ROOT / '04_model'
CONTRACT = yaml.safe_load((ROOT / '00_contract/baseline_contract.yaml').read_text(encoding='utf-8'))


def write(frame, path):
    path.parent.mkdir(parents=True, exist_ok=True)
    frame.to_csv(path, index=False, encoding='utf-8-sig', float_format='%.12g')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def scale(values, years, name):
    raw = np.asarray(values, float)
    year = np.asarray(years, int)
    if not np.isfinite(raw).all() or np.any(raw < 0):
        raise ValueError(f'Invalid or missing {name} source values')
    z = np.log1p(raw) if name in {'population','grain','meat','industry','fiscal','education'} else raw
    ref = z[(year >= 2011) & (year <= 2020)]
    assert len(ref) == 10
    lo, hi = np.quantile(ref, [.05, .95])
    if not hi > lo:
        raise ValueError(f'Degenerate calibration reference for {name}')
    preclip = .02 + .96 * (z - lo) / (hi - lo)
    val = np.clip(preclip, .02, .98)
    return val, {'variable': name, 'preprocessing': 'log1p' if name in {'population','grain','meat','industry','fiscal','education'} else 'none',
                 'lower': float(lo), 'upper': float(hi), 'reference': '2011-2020 P5/P95',
                 'clipped_low': int((preclip < .02).sum()), 'clipped_high': int((preclip > .98).sum()),
                 'zero_reference_range': False}, z


def policy_chain():
    if (ROOT/'00_contract/part2_run.json').exists():
        registry=pd.read_csv(OUT_POLICY/'reconstructed/policy_function_shares_HT.csv')
        write(registry,OUT_POLICY/'policy_registry.csv')
        write(pd.read_csv(OUT_POLICY/'reconstructed/policy_validity_decisions.csv'),OUT_POLICY/'policy_validity_ledger.csv')
        return registry,pd.DataFrame()
    admission = pd.read_csv(SOURCE / 'policy/admission_68.csv')
    upstream = OUT_POLICY / 'reconstructed'
    required = ['coded_clauses_B1.csv','policy_function_shares_B1.csv',
                'policy_validity_decisions.csv','relation_events_B1.csv',
                'policy_stock_by_year_B1.csv']
    if all((upstream / name).is_file() for name in required):
        coded = pd.read_csv(upstream / 'coded_clauses_B1.csv')
        shares = pd.read_csv(upstream / 'policy_function_shares_B1.csv')
        dates = pd.read_csv(upstream / 'policy_validity_decisions.csv')
        sources = pd.read_csv(upstream/'text_source_audit.csv')[['policy_id','body_source_relative_path','body_source_sha256']]
        sources['source_id'] = 'policy_text_' + sources.policy_id
        sources = sources.rename(columns={'body_source_relative_path':'fulltext_relative_path','body_source_sha256':'fulltext_sha256'})
        registry = admission[['policy_id','publication_year','政策标题','层级','text_evidence_grade','原始来源URL','适用县域']].merge(
            shares[['policy_id','qualified_action_units','G_assignment_total','G1_share','G2_share','G3_share','coding_origin','author_review_status']],
            on='policy_id',validate='one_to_one').merge(
            dates[['policy_id','stock_start_year','historical_stock_end_year','start_rule','end_rule','independent_stock_policy']],
            on='policy_id',validate='one_to_one').merge(sources,on='policy_id',validate='one_to_one')
        assert len(registry)==68 and registry.policy_id.is_unique
        assert len(coded)>0 and coded.unit_id.is_unique
        confirmation=json.loads((ROOT/'00_contract/author_confirmation.json').read_text(encoding='utf-8'))
        confirmed_rel='02_policy/reconstructed/coded_clauses_B1.csv'
        if (confirmation.get('status')!='CONFIRMED_BY_AUTHOR' or
            confirmation['confirmed_file_sha256'][confirmed_rel].lower()!=sha(upstream/'coded_clauses_B1.csv')):
            raise ValueError('B1 v1.2 author confirmation does not match frozen coding source')
        # Retain the v1.1 captured coding file unchanged. The present-release
        # registry records subsequent adoption without implying manual signing.
        coded['author_review_status']='CONFIRMED_BY_AUTHOR'
        coded['author_confirmation_source_sha256']=confirmation['confirmed_file_sha256'][confirmed_rel]
        registry['author_review_status']='CONFIRMED_BY_AUTHOR'
        registry['author_confirmation_source_sha256']=confirmation['confirmed_file_sha256'][confirmed_rel]
        write(registry,OUT_POLICY/'policy_registry.csv')
        write(coded,OUT_POLICY/'coded_clauses.csv')
        write(dates,OUT_POLICY/'policy_validity_ledger.csv')
        write(pd.read_csv(upstream/'policy_stock_by_year_B1.csv'),OUT_POLICY/'policy_stock_by_year.csv')
        write(pd.read_csv(upstream/'policy_relation_audit_B1.csv'),OUT_POLICY/'policy_relation_audit.csv')
        publish = registry.groupby('publication_year',as_index=False).policy_id.nunique().rename(columns={'policy_id':'new_policy_documents'})
        write(publish,OUT_POLICY/'policy_publication_counts.csv')
        return registry,coded
    raise FileNotFoundError('Persistent B1 reconstructed policy files are incomplete; build will not replace them with empty placeholders')
    draft = pd.read_csv(SOURCE / 'policy/action_unit_codes_machine_draft.csv')
    units = pd.read_csv(SOURCE / 'policy/analysis_units_candidate.csv')
    manifest = pd.read_csv(ROOT / '00_contract/source_manifest.csv')
    assert len(admission) == 68 and admission.policy_id.is_unique
    assert len(draft) == len(units) == 18808
    assert not draft.duplicated(['policy_id','unit_id']).any()
    assert set(draft.policy_id) == set(admission.policy_id)
    assert (draft[['policy_id','unit_id']].to_numpy() == units[['policy_id','unit_id']].to_numpy()).all()
    source_map = manifest.set_index('source_id')
    rows = []
    for row in admission.itertuples(index=False):
        source_id = 'policy_text_' + row.policy_id
        src = source_map.loc[source_id]
        rows.append({'policy_id': row.policy_id, 'publication_year': int(row.publication_year),
                     'title': getattr(row, '政策标题'), 'government_level': getattr(row, '层级'),
                     'text_evidence_grade': row.text_evidence_grade,
                     'original_url': getattr(row, '原始来源URL'),
                     'applicable_counties_text': getattr(row, '适用县域'),
                     'source_id': source_id, 'fulltext_relative_path': src.relative_path,
                     'fulltext_sha256': src.sha256,
                     'existing_single_coder_labels_available': False,
                     'manual_code_status': 'MISSING_ORIGINAL_SINGLE_CODER_CLAUSE_CODES',
                     'machine_candidate_units': int(draft.policy_id.eq(row.policy_id).sum()),
                     'machine_qualified_suggestions': int((draft.policy_id.eq(row.policy_id) & draft.qualified.eq(True)).sum()),
                     'policy_validity_status': 'START_AND_EXIT_NOT_CERTIFIED'})
    registry = pd.DataFrame(rows)
    write(registry, OUT_POLICY / 'policy_registry.csv')
    date_pattern = re.compile(r'自.{0,25}(?:起施行|起实施|生效)|有效期.{0,25}|(?:废止|失效|修订|替代).{0,25}')
    suggestions = {}
    for policy_id, group in units.groupby('policy_id'):
        texts = []
        for text in group.text.fillna('').astype(str):
            match = date_pattern.search(text)
            if match:
                texts.append(match.group(0)[:100])
            if len(texts) >= 3:
                break
        suggestions[policy_id] = texts
    ledger = registry[['policy_id','publication_year','source_id','fulltext_relative_path']].copy()
    ledger['effective_date_confirmed'] = pd.NA
    ledger['exit_date_confirmed'] = pd.NA
    ledger['repeal_or_replacement_confirmed'] = pd.NA
    ledger['date_candidate_snippets_json'] = ledger.policy_id.map(lambda x: json.dumps(suggestions[x], ensure_ascii=False))
    ledger['date_evidence_status'] = 'MACHINE_SEARCH_HINT_NOT_SEMANTICALLY_VERIFIED'
    ledger['stock_admission_status'] = 'BLOCKED_UNVERIFIED_EFFECTIVE_AND_EXIT_RULE'
    write(ledger, OUT_POLICY / 'policy_validity_ledger.csv')
    coded = units[['policy_id','unit_id','start_char','end_char','text']].copy()
    coded['original_qualification'] = pd.NA
    for col in ['G1','G2','G3','T1','T2','T3','T4','T5','T6']:
        coded['original_' + col] = pd.NA
    coded['manual_coder_count'] = 1
    coded['original_code_version'] = pd.NA
    coded['coding_status'] = 'ORIGINAL_SINGLE_CODER_LABEL_NOT_RECOVERED'
    coded['machine_qualified_suggestion'] = draft.qualified.to_numpy()
    for col in ['G1','G2','G3','T1','T2','T3','T4','T5','T6']:
        coded['machine_' + col + '_suggestion'] = draft[col].to_numpy()
    coded['machine_evidence_json'] = draft.evidence.to_numpy()
    coded['machine_review_status'] = draft.review_status.to_numpy()
    coded['source_id'] = coded.policy_id.map(lambda x: 'policy_text_' + x)
    coded['evidence_type'] = 'MACHINE_SUGGESTION_NOT_SINGLE_CODER_RECORD'
    write(coded, OUT_POLICY / 'coded_clauses.csv')
    publish = registry.groupby('publication_year', as_index=False).policy_id.nunique().rename(columns={'policy_id':'new_policy_documents'})
    write(publish, OUT_POLICY / 'policy_publication_counts.csv')
    stock = pd.MultiIndex.from_product([range(2000, 2024), ['G1','G2','G3']], names=['year','channel']).to_frame(index=False)
    stock['active_valid_policy_stock'] = np.nan
    stock['new_effective_admissions'] = np.nan
    stock['confirmed_exits'] = np.nan
    stock['stock_identity_evaluable'] = False
    stock['status'] = 'BLOCKED_MANUAL_CODES_AND_VALIDITY_DATES'
    write(stock, OUT_POLICY / 'policy_stock_by_year.csv')
    relations = registry[['policy_id','source_id']].copy()
    for col in ['joint_issuance_actors','administrative_applicability','unique_relation_edges','relation_events']:
        relations[col] = pd.NA
    relations['status'] = 'NO_VERIFIED_ISSUER_APPLICABILITY_EVENT_EXTRACTION'
    write(relations, OUT_POLICY / 'policy_relation_audit.csv')
    return registry, coded


def indicator_chain():
    if not (OUT_POLICY/'reconstructed/annual_policy_interface_B1.csv').is_file():
        raise FileNotFoundError('Persistent annual_policy_interface_B1.csv is required before indicator build')
    county = pd.read_csv(SOURCE / 'indicators/social_county_real_industry.csv')
    assert len(county) == 117 and county.groupby('year').size().eq(9).all()
    assert not county.duplicated(['year','county_code']).any()
    annual = []
    for year, g in county.groupby('year', sort=True):
        area = g.admin_area_reported_km2.astype(float)
        assert area.gt(0).all()
        required = ['registered_population_10k','grain_output_t','meat_output_t',
                    'secondary_industry_va_constant2011_10k_cny','revenue','expenditure','teachers','pupils']
        if g[required].isna().any().any() or not g[['expenditure','pupils']].gt(0).all().all():
            raise ValueError(f'Incomplete nine-county social source year {year}')
        area_total = area.sum()
        annual.append({'year': int(year), 'county_n': len(g), 'area_km2': area_total,
                       'population': g.registered_population_10k.sum()*10000/area_total,
                       'grain': g.grain_output_t.sum()/area_total,
                       'meat': g.meat_output_t.sum()/area_total,
                       'industry': g.secondary_industry_va_constant2011_10k_cny.sum()/area_total,
                       'fiscal': g.revenue.sum()/g.expenditure.sum(),
                       'education': g.teachers.sum()*1000/g.pupils.sum(),
                       'fiscal_revenue_total': g.revenue.sum(),
                       'fiscal_expenditure_total': g.expenditure.sum(),
                       'teachers_total': g.teachers.sum(), 'pupils_total': g.pupils.sum(),
                       'source_excel_rows': '|'.join(str(int(x)) for x in g.source_excel_row.dropna()),
                       'county_codes': '|'.join(str(int(x)) for x in g.county_code)})
    annual = pd.DataFrame(annual)
    assert annual.year.tolist() == list(range(2011, 2024))
    write(annual, OUT_IND / 'social_raw_annual_B1.csv')
    states = annual[['year']].copy()
    scale_rows = []
    lineage = []
    source_cols = ['population','grain','meat','industry','fiscal','education']
    units = {'population':'persons_per_km2','grain':'tonnes_per_km2','meat':'tonnes_per_km2',
             'industry':'10k_CNY_2011_per_km2','fiscal':'revenue_over_expenditure',
             'education':'teachers_per_1000_pupils'}
    for name in source_cols:
        values, scale_meta, transformed = scale(annual[name], annual.year, name)
        states[name] = values
        scale_rows.append(scale_meta)
        for i, row in annual.iterrows():
            lineage.append({'year': int(row.year), 'state_id': name, 'raw_value': float(row[name]),
                            'raw_unit': units[name], 'transformed_value': float(transformed[i]),
                            'model_input_value': float(values[i]), 'source_id': 'indicator_social_county_real_industry',
                            'source_row_locator': f'year={int(row.year)}; counties={row.county_codes}; Excel rows={row.source_excel_rows}',
                            'transformation': f'log1p then fixed 2011-2020 P5/P95 [{scale_meta["lower"]},{scale_meta["upper"]}] to [0.02,0.98]',
                            'spatial_support':'nine_counties_aggregated_to_bay',
                            'temporal_support':'annual', 'direction':'pressure' if name in ['population','industry','grain','meat'] else 'capacity',
                            'evidence_type':'DERIVED_INDICATOR_FROM_COUNTY_RECORD'})
    states['SP'] = (states.population + states.industry + (states.grain + states.meat)/2)/3
    states['AC'] = (states.fiscal + states.education)/2
    states['SC'] = states.AC
    states['SR'] = np.sqrt((1-states.SP)*states.AC)
    for state_name, formula in [('SP','mean(population,industry,mean(grain,meat))'),
                                ('AC','mean(fiscal,education)'), ('SC','alias(AC)'),
                                ('SR','sqrt((1-SP)*AC)')]:
        for _, row in states.iterrows():
            lineage.append({'year': int(row.year), 'state_id': state_name, 'raw_value': np.nan,
                            'raw_unit':'normalized_0_1', 'transformed_value':np.nan,
                            'model_input_value':float(row[state_name]),
                            'source_id':'indicator_social_county_real_industry',
                            'source_row_locator':f'year={int(row.year)}; annual components',
                            'transformation':formula, 'spatial_support':'Laizhou_Bay',
                            'temporal_support':'annual','direction':'resilience' if state_name=='SR' else 'mixed',
                            'evidence_type':'DERIVED_INDICATOR'})
    write(states, OUT_IND / 'social_states_B1.csv')
    water = pd.read_csv(SOURCE / 'indicators/water_quality_baseline_2011_2023.csv')
    assert water.year.tolist() == list(range(2011,2024))
    water['WQ_recomputed'] = ((1-water.NS)*(1-water.OS)*(1-water.BS))**(1/3)
    if not np.allclose(water.WQ, water.WQ_recomputed, atol=1e-9):
        raise AssertionError('WQ inconsistent with registered formula')
    gwl = pd.read_csv(SOURCE / 'indicators/gwl_habitat_2011_2022_raw.csv').query('coastal_band_km == 10')
    assert gwl.year.tolist() == list(range(2011,2023))
    bridge = json.loads((SOURCE / 'indicators/habitat_bridge_comparison.json').read_text(encoding='utf-8'))['class_results']
    habitat = pd.concat([gwl[['year','tf_area_km2','sm_area_km2']], pd.DataFrame([{
        'year':2023, 'tf_area_km2':bridge['tf']['reconstructed_2023_area_km2'],
        'sm_area_km2':bridge['sm']['reconstructed_2023_area_km2']}])], ignore_index=True)
    climate = pd.read_csv(SOURCE / 'indicators/terraclimate_annual_10km.csv')
    workbook = SOURCE / 'raw/莱州湾_SES精简指标体系与分析数据_2011-2023_20260722.xlsx'
    sst = pd.read_excel(workbook, sheet_name='生态核心_海湾年')[['year','sst_c']]
    env = water[['year','DIN','DIP','COD','DO_source_numeric','Chla_source_numeric','RNDia','red_tide','NS','OS','BS','WQ','status']].merge(
        habitat,on='year',validate='one_to_one').merge(climate[['year','PPT_mm','RUNOFF_mm']],on='year',validate='one_to_one').merge(
        sst,on='year',validate='one_to_one')
    for raw, state in [('tf_area_km2','TF'),('sm_area_km2','SM'),('PPT_mm','PPT'),('RUNOFF_mm','RUNOFF'),('sst_c','SST')]:
        val, scale_meta, transformed = scale(env[raw], env.year, raw)
        env[state] = val
        scale_meta['variable'] = state
        scale_meta['raw_variable'] = raw
        scale_rows.append(scale_meta)
        for i, row in env.iterrows():
            evidence = 'ESTIMATED_COMPONENT' if raw in ['tf_area_km2','sm_area_km2'] and row.year==2023 else 'DERIVED_INDICATOR'
            source_id = 'indicator_gwl_habitat_2011_2022_raw' if raw.startswith(('tf_','sm_')) and row.year<2023 else (
                'indicator_habitat_bridge_comparison' if raw.startswith(('tf_','sm_')) else
                'indicator_terraclimate_annual_10km' if raw in ['PPT_mm','RUNOFF_mm'] else 'SES_source_workbook')
            lineage.append({'year':int(row.year),'state_id':state,'raw_value':float(row[raw]),
                            'raw_unit':'km2' if raw.startswith(('tf_','sm_')) else 'mm_per_year' if raw in ['PPT_mm','RUNOFF_mm'] else 'deg_C',
                            'transformed_value':float(transformed[i]),'model_input_value':float(val[i]),
                            'source_id':source_id,'source_row_locator':f'year={int(row.year)}; coastal support=10km',
                            'transformation':f'fixed 2011-2020 P5/P95 [{scale_meta["lower"]},{scale_meta["upper"]}] to [0.02,0.98]',
                            'spatial_support':'frozen_10km_coastal_band' if state!='SST' else 'source_workbook_bay_seasonality_unverified',
                            'temporal_support':'annual','direction':'support' if state in ['TF','SM'] else 'external_forcing',
                            'evidence_type':evidence})
    env['H'] = np.sqrt(env.TF*env.SM)
    env['ES'] = np.sqrt(env.WQ*env.H)
    for state in ['NS','OS','BS','WQ','H','ES']:
        for _, row in env.iterrows():
            evidence = 'PROVISIONAL_UNIT_METADATA_PENDING' if state in ['NS','OS','BS','WQ'] else (
                'ESTIMATED_COMPONENT' if int(row.year)==2023 and state in ['H','ES'] else 'DERIVED_INDICATOR')
            lineage.append({'year':int(row.year),'state_id':state,'raw_value':np.nan,
                            'raw_unit':'normalized_0_1','transformed_value':np.nan,'model_input_value':float(row[state]),
                            'source_id':'water_quality_prepared' if state in ['NS','OS','BS','WQ'] else 'indicator_gwl_habitat_2011_2022_raw',
                            'source_row_locator':f'year={int(row.year)}',
                            'transformation': {'WQ':'((1-NS)*(1-OS)*(1-BS))**(1/3)','H':'sqrt(TF*SM)','ES':'sqrt(WQ*H)'}.get(state,'source_prepared_state'),
                            'spatial_support':'Laizhou_Bay_mixed_support','temporal_support':'annual',
                            'direction':'support' if state in ['WQ','H','ES'] else 'stress',
                            'evidence_type':evidence})
    write(env, OUT_IND / 'environment_states_B1.csv')
    write(pd.DataFrame(scale_rows), OUT_IND / 'scaling_registry.csv')
    model = env[['year','NS','OS','BS','WQ','TF','SM','H','ES','PPT','RUNOFF','SST']].merge(
        states[['year','SP','AC','SC','SR']],on='year',validate='one_to_one')
    interface_path=OUT_POLICY/'reconstructed/annual_policy_interface_B1.csv'
    if not interface_path.is_file():
        raise FileNotFoundError('Persistent annual_policy_interface_B1.csv is required; model input will not be rewritten with null governance')
    for name in ['G1','G2','G3','ETA_POTENTIAL','SYNERGY_LEVER','IM']:
        model[name] = np.nan
    if interface_path.is_file():
        interface=pd.read_csv(interface_path).set_index('year')
        assert interface.index.is_unique and interface.index.tolist()==model.year.tolist()
        for name in ['G1','G2','G3','ETA_POTENTIAL','SYNERGY_LEVER','synergy_share','eta_raw','feedback_raw']:
            model[name]=model.year.map(interface[name])
        gate=model.AC.to_numpy(float)**2/(.30**2+model.AC.to_numpy(float)**2)
        g3_hill=model.G3.to_numpy(float)**2.2/(.45**2.2+model.G3.to_numpy(float)**2.2)
        model['IM']=np.clip(model.ETA_POTENTIAL*g3_hill*(.12+.88*gate)/(1+.75*model.SP),.001,.999)
    model['PRS'] = model.SP.ewm(alpha=.45,adjust=False).mean()
    model['PRE'] = ((1-model.WQ+1-model.H)/2).ewm(alpha=.45,adjust=False).mean()
    model['PR'] = (model.PRS + 2*model.PRE)/3
    model['habitat_2023_estimated'] = model.year.eq(2023)
    required_model=['G1','G2','G3','ETA_POTENTIAL','SYNERGY_LEVER','IM']
    model['input_complete'] = model[required_model].notna().all(axis=1)
    model['blocking_fields'] = model.apply(lambda row:'|'.join(x for x in required_model if pd.isna(row[x])),axis=1)
    model['analysis_role'] = 'PART2_HT_WEIGHTED_FORMAL_SUPPLY_CONDITIONAL_PROXIES' if model.input_complete.all() else 'B1_SOURCE_BASED_PARTIAL_NOT_CALIBRATION_READY'
    write(model, OUT_IND / 'model_input_B1.csv')
    terms = []
    for _, row in model.iterrows():
        for state_name in ['AC','SM']:
            terms.append({'year':int(row.year),'state':state_name,
                          'observed_state':float(row['SC' if state_name=='AC' else 'SM']),
                          'model_target':np.nan,'model_derivative':np.nan,
                          'governance_action':np.nan,'implementation_gate':np.nan,
                          'status':'READY_FOR_MODEL_TARGET_DIAGNOSTIC' if bool(row.input_complete) else 'BLOCKED_G1_G2_G3_AND_ETA_INTERFACE_NOT_OBSERVED',
                          'simulation_result':False})
    write(pd.DataFrame(terms), ROOT / '06_runs/B1_preflight/state_target_terms.csv')
    write(pd.DataFrame([{'state':s,'observed_max_2011_2020':float(model.loc[model.year.le(2020),'SC' if s=='AC' else s].max()),
                         'reachable_upper_bound':np.nan,'status':'TARGET_DIAGNOSTIC_PENDING_CALIBRATION' if model.input_complete.all() else 'NOT_COMPUTABLE_WITHOUT_VERIFIED_G_AND_ETA',
                         'structural_fit_limitation_assessed_for_B1':False} for s in ['AC','SM']]),
          ROOT / '06_runs/B1_preflight/state_reachability_diagnostics.csv')
    for name in ['G1','G2','G3','ETA_POTENTIAL','SYNERGY_LEVER','IM']:
        for year in model.year:
            value=float(model.loc[model.year.eq(year),name].iloc[0]) if model.input_complete.all() else np.nan
            lineage.append({'year':int(year),'state_id':name,'raw_value':np.nan,'raw_unit':'policy_text_proxy_or_model_initialization',
                            'transformed_value':value,'model_input_value':value,
                            'source_id':'policy_annual_interface_B1' if model.input_complete.all() else 'admission_68',
                            'source_row_locator':f'year={int(year)}; 02_policy/reconstructed/annual_policy_interface_B1.csv',
                            'transformation':'stock/(stock+K) or eta P5/P95 or raw synergy or model IM initialization' if model.input_complete.all() else 'BLOCKED_NO_VERIFIED_CLAUSE_STOCK_OR_INTERFACE',
                            'spatial_support':'Laizhou_Bay','temporal_support':'annual','direction':'governance',
                            'evidence_type':'CODEX_SOURCE_RECONSTRUCTION_AUTHOR_PENDING' if model.input_complete.all() else 'MISSING_CRITICAL_OBSERVATION_OR_INTERFACE'})
    write(pd.DataFrame(lineage), OUT_IND / 'indicator_lineage.csv')
    summary = {'years':len(model),'county_year_rows':len(county),
               'social_and_environment_states_complete':True,
               'governance_and_implementation_states_complete':bool(model.input_complete.all()),
               'B1_full_model_input_ready':bool(model.input_complete.all()),
               'WQ_unit_metadata_status':'PROVISIONAL_UNIT_METADATA_PENDING',
               '2023_habitat_estimated':True,
               'no_B0_data_read':True}
    (OUT_IND / 'indicator_build_status.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
    return model, pd.DataFrame(lineage)


def registries(model, lineage):
    dictionary = []
    source_lookup = {'G1':'policy_stock','G2':'policy_stock','G3':'policy_stock',
                     'SP':'county_source','AC':'county_source','SC':'county_source','SR':'county_source',
                     'NS':'water_quality_prepared','OS':'water_quality_prepared','BS':'water_quality_prepared',
                     'TF':'GWL_2023_bridge','SM':'GWL_2023_bridge','WQ':'water_quality_prepared',
                     'H':'GWL_2023_bridge','ES':'mixed_ecology','PPT':'TerraClimate','RUNOFF':'TerraClimate','SST':'SES_workbook',
                     'PR':'derived_risk','PRS':'derived_risk','PRE':'derived_risk','IM':'policy_implementation'}
    formula = {'SP':'mean(population,industry,mean(grain,meat))','AC':'mean(fiscal,education)',
               'SC':'alias(AC)','SR':'sqrt((1-SP)*AC)','WQ':'((1-NS)*(1-OS)*(1-BS))**(1/3)',
               'H':'sqrt(TF*SM)','ES':'sqrt(WQ*H)','PR':'(PRS+2*PRE)/3',
               'PRS':'ewm(SP,alpha=.45)','PRE':'ewm((2-WQ-H)/2,alpha=.45)',
               **{g:f"HT_share_weighted_active_stock/(stock+{CONTRACT['policy']['K'][g]})" for g in ['G1','G2','G3']}}
    for name, source in source_lookup.items():
        dictionary.append({'variable':name,'role':'state' if name in ['G1','G2','G3','SP','SC','NS','OS','BS','TF','SM','PR','PRS','IM'] else 'reported_or_forcing',
                           'raw_source_family':source,'raw_field':name if name in ['NS','OS','BS'] else '',
                           'raw_unit':'see_indicator_lineage','model_unit':'normalized_0_1',
                           'direction':'stress' if name in ['SP','NS','OS','BS'] else 'support_or_driver',
                           'spatial_support':'nine_counties_to_bay' if name in ['SP','AC','SC','SR'] else 'bay_or_coastal_10km',
                           'temporal_support':'annual_2011_2023',
                           'transformation_or_aggregation':formula.get(name,'see_equation_registry'),
                           'reference_period':'2011-2020_P5_P95' if name in ['SP','AC','SC','TF','SM','PPT','RUNOFF','SST'] else 'not_applicable_or_missing',
                           'evidence_type':'CODEX_SOURCE_RECONSTRUCTION_AUTHOR_CONFIRMED' if name in ['G1','G2','G3'] else
                                           'MODEL_DERIVED_INITIALIZATION_NOT_OBSERVED' if name=='IM' else
                                           'ESTIMATED_COMPONENT_2023' if name in ['TF','SM','H','ES'] else 'DERIVED_INDICATOR'})
    write(pd.DataFrame(dictionary), OUT_IND / 'indicator_dictionary.csv')
    equations = pd.read_csv(ROOT / '00_contract/source_extracts/supplement_omml_formulas.csv')
    equations = equations.loc[equations.formula_id.str.startswith('supplement_T02_') | equations.formula_id.str.startswith('supplement_T01_')].copy()
    def function_for(x):
        if x.startswith('supplement_T01_'):
            return 'revised_core.reporting_or_B1_build_evidence'
        row = int(re.search(r'_R(\d+)_',x).group(1))
        return 'sd_model.rhs' if row>=4 else 'sd_model.reporting_states'
    equations['equation_id'] = equations.formula_id
    equations['state_or_auxiliary'] = equations.omml_text.str.extract(r'^([A-Za-z∆Δ][A-Za-z0-9*_,]*)',expand=False).fillna('symbol_or_definition')
    equations['full_expression_OMML_XML'] = equations.omml_xml
    equations['human_readable_expression'] = equations.omml_text
    equations['manuscript_location'] = equations.formula_id
    equations['code_function'] = equations.formula_id.map(function_for)
    equations['code_file'] = equations.code_function.map(lambda x: '05_code/engine/sd_model.py' if x.startswith('sd_model') else '05_code/revised_core.py')
    equations['initialization_and_bounds'] = 'see sd_model._baseline_context and engine_config; ODE [0.001,0.999]'
    equations['mapping_status'] = 'ORIGINAL_OMML_AND_HISTORICAL_COMPATIBLE_CODE_INDEXED_NOT_FULL_SYMBOLIC_EQUIVALENCE_CERTIFIED'
    write(equations[['equation_id','state_or_auxiliary','human_readable_expression','full_expression_OMML_XML',
                     'manuscript_location','code_file','code_function','initialization_and_bounds','mapping_status']],
          OUT_MODEL / 'equation_registry.csv')
    params = []
    for name, bounds in CONTRACT['parameter_bounds'].items():
        params.append({'parameter':name,'alias':name,'unit':'year^-1' if name.startswith('r_') else 'dimensionless',
                       'lower':bounds[0],'upper':bounds[1],'fixed_value':np.nan,'identity':'CALIBRATED',
                       'source':'supplement Table S2; B1 contract','historical_constraint':'seven-state 2011-2020 loss',
                       'scenario_only':False})
    for name, val in CONTRACT['fixed_parameters'].items():
        params.append({'parameter':name,'alias':name,'unit':'years' if name=='tau_risk' else 'dimensionless',
                       'lower':np.nan,'upper':np.nan,'fixed_value':val,'identity':'FIXED_MODEL_ASSUMPTION',
                       'source':'supplement Table S2; B1 contract','historical_constraint':'not_freely_calibrated',
                       'scenario_only':False})
    for name,val in CONTRACT['policy']['K'].items():
        params.append({'parameter':'K_'+name,'alias':name+'_stock_scale','unit':'policy_stock_units',
                       'lower':np.nan,'upper':np.nan,'fixed_value':val,'identity':'FIXED_MODEL_ASSUMPTION',
                       'source':'supplement Table S2','historical_constraint':'not_optimized_in_B1',
                       'scenario_only':False})
    write(pd.DataFrame(params), OUT_MODEL / 'parameter_registry.csv')
    settings = {'S0':([], 'P50',2,'P50','P50'),'S1':(['G1'],'P50',2,'P50','P50'),
                'S2':(['G2'],'P50',2,'P50','P50'),'S3':(['G3'],'P50',2,'P50','P50'),
                'S4':(['G1','G2','G3'],'P75',1,'P75','P75'),
                'S5':(['G1','G2','G3'],'P25',3,'P50','P50'),
                'S6':(['G1','G2'],'P75',2,'P50','P75')}
    quant = pd.read_csv(OUT_POLICY / 'reconstructed/interface_quantiles_B1.csv').set_index('interface')
    raw = {name: {q: float(quant.loc[source, q]) for q in ['P25','P50','P75']}
           for name, source in {'G1':'G1','G2':'G2','G3':'G3',
                                'eta':'eta_raw','feedback':'feedback_raw',
                                'synergy':'synergy_raw'}.items()}
    eta_scale = json.loads((OUT_POLICY/'reconstructed/interface_reconstruction_spec.json').read_text(encoding='utf-8'))['eta_scaler']
    stock_history=pd.read_csv(OUT_POLICY/'reconstructed/policy_stock_by_year_B1.csv')
    scenarios, audit = [], []
    for name,(channels,eta,tau,feedback,synergy) in settings.items():
        scenarios.append({'scenario_id':name,'governance_high_channels':'|'.join(channels),
                          'eta_setting':eta,'tau_years':tau,'feedback_setting':feedback,
                          'synergy_setting':synergy,'initial_year':2023,
                          'climate_forcing':'common_paired_3year_joint_blocks_with_2026_2028_compound_shock',
                          'policy_projection':'B1_2023_STOCK_PLUS_RECENT_MEDIAN_NEW_FLOW_045_INTENSIFICATION',
                          'model_executable':True})
        for lever in ['G1','G2','G3','eta','feedback','synergy','tau']:
            q = ('P75' if lever in channels else 'P50') if lever in ['G1','G2','G3'] else (
                eta if lever=='eta' else feedback if lever=='feedback' else synergy if lever=='synergy' else 'FIXED_YEARS')
            base = 2.0 if lever=='tau' else raw[lever]['P50']
            future = tau if lever=='tau' else raw[lever][q]
            if lever=='eta':
                lo,hi=eta_scale['lower'],eta_scale['upper']
                model_base,model_future=[float(np.clip(.02+.96*(x-lo)/(hi-lo),.02,.98)) for x in [base,future]]
                mapping='fixed_2011_2020_P5_P95_to_002_098'
            elif lever=='feedback':
                lo,hi=float(quant.loc['feedback_raw','min']),float(quant.loc['feedback_raw','max'])
                model_base,model_future=[float(np.clip((x-lo)/(hi-lo),0,1)) for x in [base,future]]
                mapping='B1_2011_2023_min_max_to_0_1_reconstruction_assumption'
            elif lever in ['synergy','tau']:
                model_base,model_future=base,future
                mapping='identity'
            else:
                stock_2023=float(stock_history.loc[(stock_history.year.eq(2023))&(stock_history.channel.eq(lever)),'active_valid_policy_stock'].iloc[0])
                flow=float(stock_history.loc[(stock_history.year.between(2021,2023))&(stock_history.channel.eq(lever)),'new_effective_admissions'].median())
                k=float(CONTRACT['policy']['K'][lever])
                q75=raw[lever]['P75']
                multiplier=1+.45*(future-base)/max(q75-base,1e-9)
                model_base=(stock_2023+7*flow)/(stock_2023+7*flow+k)
                model_future=(stock_2023+7*flow*multiplier)/(stock_2023+7*flow*multiplier+k)
                mapping='P50_to_P75_policy_flow_multiplier_1_plus_045_shift'
            audit.append({'scenario_id':name,'lever':lever,'raw_baseline':base,'raw_future':future,
                          'raw_delta':future-base,'raw_unit':{'tau':'years','synergy':'mixed_relation_event_share',
                              'feedback':'feedback_signal_policy_share','eta':'response_proxy_policy_share',
                              'G1':'historical_G1_index_quantile','G2':'historical_G2_index_quantile',
                              'G3':'historical_G3_index_quantile'}[lever],
                          'model_baseline':model_base,'model_future':model_future,
                          'model_delta':model_future-model_base,
                          'raw_to_model_mapping':mapping,
                          'actual_intervention_status':(
                              'UNCHANGED' if abs(future-base)<1e-12 and abs(model_future-model_base)<1e-12
                              else 'DEGENERATE_LEVER' if abs(model_future-model_base)<1e-12
                              else 'NONZERO_DEFINED_LEVER'),
                          'source':'B1 annual interface quantiles; historical scenario combination',
                          'initial_state_id':'B1_2023_CONDITIONAL_OBSERVED_AND_DERIVED_IM',
                          'forcing_id':'B1_COMMON_PAIRED_CLIMATE'})
    write(pd.DataFrame(scenarios), OUT_MODEL / 'scenario_registry.csv')
    write(pd.DataFrame(audit), OUT_MODEL / 'scenario_lever_audit.csv')
    eq_map = {'SP':'supplement_T02_R08_M01','SC':'supplement_T02_R09_M01',
              'NS':'supplement_T02_R10_M04','OS':'supplement_T02_R10_M05',
              'BS':'supplement_T02_R10_M06','TF':'supplement_T02_R11_M01',
              'SM':'supplement_T02_R11_M02','G1':'supplement_T02_R04_M01',
              'G2':'supplement_T02_R04_M01','G3':'supplement_T02_R04_M01',
              'WQ':'supplement_T02_R03_M01','H':'supplement_T02_R03_M02',
              'ES':'supplement_T02_R03_M03','SR':'supplement_T02_R03_M04'}
    trace = lineage.copy()
    trace['policy_id'] = pd.NA
    trace['clause_id'] = pd.NA
    trace['equation_id'] = trace.state_id.map(eq_map).fillna('B1_DERIVED_TRANSFORM_OR_UNRESOLVED_INTERFACE')
    trace['parameter_id'] = trace.state_id.map(lambda s: 'nine_parameter_box' if s in ['SP','SC','NS','OS','BS','TF','SM'] else 'none_or_missing')
    trace['scenario_id'] = 'S0-S6_B1_V1_1_REGISTERED'
    trace['metric_protocol_id'] = 'B1_CAL_2011_2020_NINE_PARAMETER_V1'
    trace['run_function'] = 'build_evidence.indicator_chain' 
    trace['result_file'] = '03_indicators/model_input_B1.csv'
    trace['trace_status'] = np.where(trace.model_input_value.notna(), 'VALUE_TRACEABLE_TO_CAPTURED_OR_RECONSTRUCTED_SOURCE',
                                     'MISSING_VALUE')
    policy_links=[]
    if not (ROOT/'00_contract/part2_run.json').exists():
        pass  # historical trace remains in frozen b1; Part2 uses HT bridge manifest

def descriptive(model):
    model=model.copy()
    model['G']=model[['G1','G2','G3']].mean(axis=1)
    rows = []
    for name in ['G','SP','AC','SR','NS','OS','BS','WQ','TF','SM','H','ES']:
        values = model[name].to_numpy(float)
        years = model.year.to_numpy(int)
        all_slope = theilslopes(values,years).slope
        loo = [theilslopes(values[years!=removed],years[years!=removed]).slope for removed in years]
        excl = theilslopes(values[years<2023],years[years<2023]).slope
        rows.append({'indicator':name,'2011':values[0],'2023':values[-1],
                     'net_change':values[-1]-values[0],
                     'theil_sen_slope':all_slope,'leave_one_year_out_min':min(loo),
                     'leave_one_year_out_max':max(loo),
                     'slope_excluding_2023':excl,'n_annual':13,
                     'analysis_role':'B1_SOURCE_BASED_RECONSTRUCTED_AUTHOR_PENDING'})
    write(pd.DataFrame(rows), ROOT / '06_runs/B1_preflight/descriptive_trends_partial.csv')
    assoc = []
    for a,b in [('SR','ES'),('SP','WQ'),('AC','H')]:
        for label, sample in [('all_2011_2023',model),('exclude_2023',model.loc[model.year.lt(2023)])]:
            rho,p = spearmanr(sample[a],sample[b])
            assoc.append({'state_a':a,'state_b':b,'sample':label,'n_years':len(sample),
                          'spearman_rho':rho,'p_value_descriptive':p,
                          'causal_interpretation':False})
    write(pd.DataFrame(assoc), ROOT / '06_runs/B1_preflight/descriptive_associations_partial.csv')


def main():
    manifest = pd.read_csv(ROOT / '00_contract/source_manifest.csv')
    checked = 0
    for row in manifest.itertuples(index=False):
        if row.availability == 'COPIED_HASH_MATCH' and not str(row.relative_path).startswith('05_code/'):
            path = ROOT / row.relative_path
            if not path.is_file() or sha(path) != row.sha256:
                raise RuntimeError(f'Source capture changed: {row.source_id}')
            checked += 1
    registry, coded = policy_chain()
    model, lineage = indicator_chain()
    registries(model,lineage)
    descriptive(model)
    def stage_done(relative):
        path=ROOT/'06_runs/B1_v1_1'/relative
        return bool(path.is_file() and json.loads(path.read_text(encoding='utf-8')).get('complete',False))
    status = {'version':CONTRACT['version'], 'source_files_hash_checked':checked,
              'policies':len(registry),'candidate_clause_rows':len(coded),
              'original_manual_clause_rows_recovered':0,
              'indicator_years':len(model),'indicator_lineage_rows':len(lineage),
              'full_model_input_complete':bool(model.input_complete.all()),
              'calibration_executed':stage_done('calibration/calibration_status.json'),
              'scenarios_executed':stage_done('scenarios/scenario_status.json'),
              'analysis_role':'B1_v1.2.0_source_reconstructed_author_confirmed' if model.input_complete.all() else 'source_based_reconstructed_revision_baseline_preflight',
              'no_B0_values_read_into_main_input':True}
    run = ROOT / '06_runs/B1_preflight'
    run.mkdir(parents=True,exist_ok=True)
    (run / 'build_status.json').write_text(json.dumps(status,ensure_ascii=False,indent=2),encoding='utf-8')
    identity = {'run_id':'B1_preflight_20261025',
                'input_hash':sha(OUT_IND / 'model_input_B1.csv'),
                'source_manifest_hash':sha(ROOT / '00_contract/source_manifest.csv'),
                'code_hash':sha(Path(__file__)),
                'model_code_hash':sha(ROOT / '05_code/engine/sd_model.py'),
                'config_hash':sha(ROOT / '00_contract/baseline_contract.yaml'),
                'environment_id':f'{platform.system()}|Python_{platform.python_version()}|pandas_{pd.__version__}|numpy_{np.__version__}',
                'parameter_vector_hash':None,
                'initial_state_id':None,
                'forcing_id':None,
                'scenario_id':None,
                'metric_protocol_id':'B1_SOURCE_BASED_DESCRIPTIVE_PRECHECK',
                'blocked_reason':None if model.input_complete.all() else 'B1 policy G and implementation interface absent'}
    (run / 'run_identity.json').write_text(json.dumps(identity,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(status,ensure_ascii=False), flush=True)


if __name__ == '__main__':
    main()
